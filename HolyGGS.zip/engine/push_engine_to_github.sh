#!/usr/bin/env bash
# push_engine_to_github.sh — безопасная подготовка и заливка игрового движка на GitHub
#
# Использование:
#   ./push_engine_to_github.sh [папка_движка] [имя_репо]
# Пример:
#   ./push_engine_to_github.sh ~/dev/MyEngine my-engine
#
# Переменные окружения:
#   KEEP_ASSETS=0   — не коммитить Content/Assets (получится лёгкий source-only репо)
#   FORCE=1         — игнорировать предупреждения о секретах и больших файлах (на свой риск)
#
# Скрипт: определяет стек (UE / Unity / Godot / кастомный C++), пишет .gitignore,
# проверяет файлы >90 МБ и сканирует на утёкшие ключи, затем делает commit и push.

set -euo pipefail

ENGINE_DIR="${1:-$(pwd)}"
REPO_NAME="${2:-$(basename "$ENGINE_DIR")}"
KEEP_ASSETS="${KEEP_ASSETS:-1}"
FORCE="${FORCE:-0}"
MAX_MB=90

say()  { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m[!] %s\033[0m\n' "$*"; }
die()  { printf '\033[1;31m[x] %s\033[0m\n' "$*"; exit 1; }

[ -d "$ENGINE_DIR" ] || die "Нет такой папки: $ENGINE_DIR"
cd "$ENGINE_DIR"

# ---------- 1. Определяем стек ----------
STACK="custom"
if ls ./*.uproject >/dev/null 2>&1; then STACK="ue"; fi
if [ -d ProjectSettings ] && [ -d Assets ]; then STACK="unity"; fi
if [ -f project.godot ]; then STACK="godot"; fi
say "Стек: $STACK | Папка: $(pwd)"

# ---------- 2. .gitignore ----------
if [ ! -f .gitignore ] || ! grep -q "AGENT-KIT-MARKER" .gitignore 2>/dev/null; then
  cat > .gitignore <<'BASE'
# ==== AGENT-KIT-MARKER (создано скриптом) ====
# --- секреты: никогда не коммитим ---
.env
.env.*
!.env.example
*.pem
*.key
*.pfx
*.p12
secrets.*
credentials.*
*credential*.json
service-account*.json
# --- мусор сборки ---
build/
Build/
out/
bin/
Bin/
obj/
Obj/
*.o
*.obj
*.a
*.lib
*.so
*.dylib
*.dll
*.exe
*.pdb
*.ilk
*.exp
*.log
logs/
*.tmp
*.bak
*.swp
.DS_Store
Thumbs.db
BASE

  case "$STACK" in
    ue) cat >> .gitignore <<'UE'
# ==== Unreal Engine ====
Binaries/
Intermediate/
Saved/
DerivedDataCache/
.vs/
*.VC.db
*.sdf
*.opensdf
*.suo
*.sln
*.xcodeproj/
UE
      ;;
    unity) cat >> .gitignore <<'UNITY'
# ==== Unity ====
[Ll]ibrary/
[Tt]emp/
[Oo]bj/
[Bb]uild/
[Bb]uilds/
[Ll]ogs/
[Uu]ser[Ss]ettings/
*.csproj
*.unityproj
*.sln
*.user
UNITY
      ;;
    godot) cat >> .gitignore <<'GODOT'
# ==== Godot ====
.godot/
export_presets.cfg
*.translation
GODOT
      ;;
    *) cat >> .gitignore <<'CPP'
# ==== Кастомный C++ / Vulkan / DX12 ====
.cache/
.vs/
cmake-build-*/
third_party/**/build/
*.spv
*.dxil
imgui.ini
CPP
      ;;
  esac

  if [ "$KEEP_ASSETS" = "0" ]; then
    cat >> .gitignore <<'ASSETS'
# ==== Ассеты НЕ коммитим (KEEP_ASSETS=0) ====
Content/
Assets/
GameData/
*.fbx
*.blend
*.psd
*.wav
ASSETS
  fi
  say ".gitignore создан ($STACK)"
else
  say ".gitignore уже есть — не трогаю"
fi

# ---------- 3. Файлы больше лимита GitHub ----------
say "Ищу файлы > ${MAX_MB} МБ (жёсткий лимит GitHub — 100 МБ на файл)"
BIG=$(find . -type f -size +${MAX_MB}M -not -path './.git/*' 2>/dev/null | head -20 || true)
if [ -n "$BIG" ]; then
  warn "Слишком большие файлы:"
  echo "$BIG"
  warn "Реши: Git LFS (git lfs track \"*.uasset\") или добавить в .gitignore."
  [ "$FORCE" = "1" ] || die "Прервано. Повтори с FORCE=1, если уверен."
fi

# ---------- 4. Скан на секреты ----------
say "Сканирую на секреты и ключи"
SUSPICIOUS_FILES=$(find . -type f \( -name '*.env*' -o -name '*.pem' -o -name '*.key' \
  -o -name '*.p12' -o -name 'id_rsa*' -o -name '*credential*' -o -name 'service-account*' \) \
  -not -path './.git/*' 2>/dev/null | head -20 || true)

PAT='(AKIA[0-9A-Z]{16})|(ghp_[A-Za-z0-9]{36})|(sk-[A-Za-z0-9_-]{20,})|(xox[baprs]-)|(-----BEGIN [A-Z ]*PRIVATE KEY-----)'
PATTERN_HITS=$(grep -rIlE "$PAT" --exclude-dir=.git . 2>/dev/null | head -20 || true)

if [ -n "$SUSPICIOUS_FILES" ] || [ -n "$PATTERN_HITS" ]; then
  [ -n "$SUSPICIOUS_FILES" ] && { warn "Подозрительные файлы:"; echo "$SUSPICIOUS_FILES"; }
  [ -n "$PATTERN_HITS" ] && { warn "Похоже на ключи/токены в:"; echo "$PATTERN_HITS"; }
  [ "$FORCE" = "1" ] || die "Похоже на секреты — убери их и запусти снова."
else
  say "Секретов не найдено"
fi

# ---------- 5. init + commit ----------
if [ ! -d .git ]; then git init -b main >/dev/null; say "git init (ветка main)"; fi
if ! git config user.email >/dev/null 2>&1; then
  warn "git не знает имя/почту — задаю локально для этого репозитория"
  git config user.name "${GIT_NAME:-$(whoami)}"
  git config user.email "${GIT_EMAIL:-$(whoami)@localhost}"
fi
git add -A
if git diff --cached --quiet; then
  say "Изменений нет — коммитить нечего"
else
  git commit -m "Import engine snapshot ($(date +%F))" >/dev/null
  say "Коммит создан"
fi
echo "Размер проекта без .git: $(du -sh --exclude=.git . | cut -f1)"
echo "Файлов в индексе: $(git ls-files | wc -l)"

# ---------- 6. push ----------
say "Публикация на GitHub"
if command -v gh >/dev/null 2>&1; then
  echo "gh CLI найден — создаю публичный репозиторий '$REPO_NAME' и пушу..."
  gh repo create "$REPO_NAME" --public --source=. --remote=origin --push
  say "Готово! Скопируй URL репозитория и пришли его агенту."
else
  cat <<EOF
gh CLI не найден. Два пути:

A) Установи GitHub CLI (https://cli.github.com), затем:
     gh auth login
     gh repo create $REPO_NAME --public --source=. --push

B) Вручную:
   1) Создай пустой репозиторий: https://github.com/new
      Имя: $REPO_NAME, видимость: Public, БЕЗ README/.gitignore.
   2) Выполни:
     git remote add origin https://github.com/ТВОЙ_НИК/$REPO_NAME.git
     git push -u origin main
EOF
fi
