/* tslint:disable */
/* eslint-disable */

export class Engine {
    free(): void;
    [Symbol.dispose](): void;
    add_entity(name: string, p: Float32Array): number;
    /**
     * Точка перед камерой на расстоянии dist.
     */
    camera_front(dist: number): Float32Array;
    clear(): void;
    descendants_of(id: number): Int32Array;
    edit_cell_on(id: number, cell: number): boolean;
    edit_cells_hex(id: number): string;
    /**
     * Выдавливание: копия сетки, сдвинутая на ячейку вдоль оси (0=X, 1=Y, 2=Z).
     */
    edit_extrude(id: number, axis: number): void;
    edit_id(): number;
    /**
     * Инверсия ячеек (пусто <-> заполнено).
     */
    edit_invert(id: number): void;
    edit_iso(): boolean;
    edit_mirror(): number;
    /**
     * Симметризация: каждая ячейка получает близнецов по осям axes (биты X/Y/Z).
     */
    edit_mirror_fill(id: number, axes: number): void;
    edit_reset_cells(id: number): void;
    /**
     * Поворот сетки ячеек на 90° вокруг оси (0=X, 1=Y, 2=Z).
     */
    edit_rot(id: number, axis: number): void;
    /**
     * Поставить/снять ячейку; при живом зеркале правка дублируется на близнецов.
     */
    edit_set_cell(id: number, cell: number, on: boolean): void;
    edit_toggle(id: number, cell: number): void;
    entity_ids(): Int32Array;
    entity_name(id: number): string;
    /**
     * Навести камеру на точку (режим правки).
     */
    focus_on(x: number, y: number, z: number, dist: number): void;
    frame(dt: number): void;
    get_edit(id: number): Float32Array;
    get_gfx(i: number): number;
    /**
     * [pos xyz, rot xyz (град), size xyz, color rgb 0..1, neon 0/1]
     */
    get_props(id: number): Float32Array;
    gizmo_begin(nx: number, ny: number): boolean;
    gizmo_drag(nx: number, ny: number): boolean;
    gizmo_end(): void;
    hdr(): boolean;
    is_play(): boolean;
    look(dx: number, dy: number): void;
    constructor(canvas_id: string);
    parent_of(id: number): number;
    pick(nx: number, ny: number): number;
    /**
     * Ячейка сетки под курсором (для режима правки).
     */
    pick_cell(nx: number, ny: number): number;
    player_pos(): Float32Array;
    pm_root(): number;
    remove_entity(id: number): void;
    reset_camera(): void;
    resize(w: number, h: number): void;
    select(id: number): void;
    selected(): number;
    /**
     * Своя текстура материала из галереи: квадратная RGBA8 (рекомендуется 256).
     */
    set_custom_mat(data: Uint8Array, w: number, h: number): void;
    /**
     * Своя текстура воды из галереи: квадратная RGBA8 (рекомендуется 256).
     */
    set_custom_water(data: Uint8Array, w: number, h: number): void;
    /**
     * Режим правки: subdiv (0..2), скругление 0..1, ячейки hex.
     */
    set_edit(id: number, sub: number, round: number, cells_hex: string): void;
    set_edit_hover(cell: number): void;
    set_edit_id(id: number): void;
    /**
     * Изолировать редактируемый объект (прятать остальные).
     */
    set_edit_iso(on: boolean): void;
    /**
     * Живое зеркало: биты X/Y/Z — правка ячейки дублируется на близнецов.
     */
    set_edit_mirror(axes: number): void;
    set_gfx(i: number, v: number): void;
    set_mode(m: number): void;
    set_move(strafe: number, forward: number, up: number): void;
    set_parent(id: number, parent: number): void;
    set_play(on: boolean): void;
    /**
     * Характеристики игрока из скрипта: скорость, прыжок, размер капсулы.
     */
    set_player_stats(speed: number, jump: number, size: number): void;
    set_pm_root(id: number): void;
    set_props(id: number, p: Float32Array): void;
    set_third(on: boolean): void;
    /**
     * Высота волн в точке (x, z) относительно уровня воды (для будущей плавучести).
     */
    water_height(x: number, z: number): number;
}

export function gfx_defaults(): Float32Array;

export function run_self_test(en: boolean): string;

export function version(): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_engine_free: (a: number, b: number) => void;
    readonly engine_add_entity: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly engine_camera_front: (a: number, b: number) => [number, number];
    readonly engine_clear: (a: number) => void;
    readonly engine_descendants_of: (a: number, b: number) => [number, number];
    readonly engine_edit_cell_on: (a: number, b: number, c: number) => number;
    readonly engine_edit_cells_hex: (a: number, b: number) => [number, number];
    readonly engine_edit_extrude: (a: number, b: number, c: number) => void;
    readonly engine_edit_id: (a: number) => number;
    readonly engine_edit_invert: (a: number, b: number) => void;
    readonly engine_edit_iso: (a: number) => number;
    readonly engine_edit_mirror: (a: number) => number;
    readonly engine_edit_mirror_fill: (a: number, b: number, c: number) => void;
    readonly engine_edit_reset_cells: (a: number, b: number) => void;
    readonly engine_edit_rot: (a: number, b: number, c: number) => void;
    readonly engine_edit_set_cell: (a: number, b: number, c: number, d: number) => void;
    readonly engine_edit_toggle: (a: number, b: number, c: number) => void;
    readonly engine_entity_ids: (a: number) => [number, number];
    readonly engine_entity_name: (a: number, b: number) => [number, number];
    readonly engine_focus_on: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly engine_frame: (a: number, b: number) => void;
    readonly engine_get_edit: (a: number, b: number) => [number, number];
    readonly engine_get_gfx: (a: number, b: number) => number;
    readonly engine_get_props: (a: number, b: number) => [number, number];
    readonly engine_gizmo_begin: (a: number, b: number, c: number) => number;
    readonly engine_gizmo_drag: (a: number, b: number, c: number) => number;
    readonly engine_gizmo_end: (a: number) => void;
    readonly engine_hdr: (a: number) => number;
    readonly engine_is_play: (a: number) => number;
    readonly engine_look: (a: number, b: number, c: number) => void;
    readonly engine_new: (a: number, b: number) => [number, number, number];
    readonly engine_parent_of: (a: number, b: number) => number;
    readonly engine_pick: (a: number, b: number, c: number) => number;
    readonly engine_pick_cell: (a: number, b: number, c: number) => number;
    readonly engine_player_pos: (a: number) => [number, number];
    readonly engine_pm_root: (a: number) => number;
    readonly engine_remove_entity: (a: number, b: number) => void;
    readonly engine_reset_camera: (a: number) => void;
    readonly engine_resize: (a: number, b: number, c: number) => void;
    readonly engine_select: (a: number, b: number) => void;
    readonly engine_selected: (a: number) => number;
    readonly engine_set_custom_mat: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly engine_set_custom_water: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly engine_set_edit: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly engine_set_edit_hover: (a: number, b: number) => void;
    readonly engine_set_edit_id: (a: number, b: number) => void;
    readonly engine_set_edit_iso: (a: number, b: number) => void;
    readonly engine_set_edit_mirror: (a: number, b: number) => void;
    readonly engine_set_gfx: (a: number, b: number, c: number) => void;
    readonly engine_set_mode: (a: number, b: number) => void;
    readonly engine_set_move: (a: number, b: number, c: number, d: number) => void;
    readonly engine_set_parent: (a: number, b: number, c: number) => void;
    readonly engine_set_play: (a: number, b: number) => void;
    readonly engine_set_player_stats: (a: number, b: number, c: number, d: number) => void;
    readonly engine_set_pm_root: (a: number, b: number) => void;
    readonly engine_set_props: (a: number, b: number, c: number, d: number) => void;
    readonly engine_set_third: (a: number, b: number) => void;
    readonly engine_water_height: (a: number, b: number, c: number) => number;
    readonly gfx_defaults: () => [number, number];
    readonly run_self_test: (a: number) => [number, number];
    readonly version: () => [number, number];
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
