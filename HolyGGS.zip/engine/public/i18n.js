const D = {
  ru: {
    projects: 'Проекты',
    empty: 'Проектов пока нет.\nНажмите «+», чтобы создать первый.',
    newProject: 'Новый проект',
    iconLabel: 'Иконка',
    namePh: 'Название игры',
    create: 'Создать',
    copyLog: 'Копировать лог',
    copied: 'Скопировано',
    close: 'Закрыть',
    menu: '‹ Меню',
    rotate: 'Поверните телефон\nгоризонтально',
    pos: 'Позиция',
    rot: 'Поворот°',
    size: 'Размер',
    color: 'Цвет',
    settings: 'Настройки',
    language: 'Язык',
    plate: 'Плита',
    checkFail: 'Ошибка проверки',
    log_start: 'Проверка целостности движка',
    log_core_fail: 'Rust core не загрузился: {0}',
    log_core_ok: 'Rust core v{0}',
    log_webgl: 'WebGL2 · GPU: {0}',
    log_tex: 'Макс. текстура: {0}px',
    log_webgl_fail: 'WebGL2: {0}',
    log_store_ok: 'Хранилище проектов',
    log_store_fail: 'Хранилище: {0}',
    log_threads: 'Потоки (SharedArrayBuffer): {0}',
    thr_yes: 'доступны',
    thr_no: 'недоступны, пока не нужны',
    log_physics: 'Физика: модуль ещё не подключён (план v0.3)',
    log_all_ok: 'Все проверки пройдены',
    log_some_fail: 'Есть ошибки, см. лог',
    log_exc: 'Исключение: {0}',
    confirmDel: 'Удалить проект «{0}»?',
    saveFail: 'Не удалось сохранить: {0}',
    coreNotLoaded: 'Rust core не загружен: {0}',
    engineFail: 'Не удалось создать движок: {0}',
    imgFail: 'Не удалось открыть картинку',
  },
  en: {
    projects: 'Projects',
    empty: 'No projects yet.\nTap “+” to create your first one.',
    newProject: 'New project',
    iconLabel: 'Icon',
    namePh: 'Game name',
    create: 'Create',
    copyLog: 'Copy log',
    copied: 'Copied',
    close: 'Close',
    menu: '‹ Menu',
    rotate: 'Rotate your phone\nto landscape',
    pos: 'Position',
    rot: 'Rotation°',
    size: 'Size',
    color: 'Color',
    settings: 'Settings',
    language: 'Language',
    plate: 'Plate',
    checkFail: 'Check failed',
    log_start: 'Engine integrity check',
    log_core_fail: 'Rust core failed to load: {0}',
    log_core_ok: 'Rust core v{0}',
    log_webgl: 'WebGL2 · GPU: {0}',
    log_tex: 'Max texture size: {0}px',
    log_webgl_fail: 'WebGL2: {0}',
    log_store_ok: 'Project storage',
    log_store_fail: 'Storage: {0}',
    log_threads: 'Threads (SharedArrayBuffer): {0}',
    thr_yes: 'available',
    thr_no: 'unavailable, not needed yet',
    log_physics: 'Physics: module not connected yet (planned v0.3)',
    log_all_ok: 'All checks passed',
    log_some_fail: 'Errors found, see log',
    log_exc: 'Exception: {0}',
    confirmDel: 'Delete project “{0}”?',
    saveFail: 'Failed to save: {0}',
    coreNotLoaded: 'Rust core is not loaded: {0}',
    engineFail: 'Failed to create engine: {0}',
    imgFail: 'Could not open the image',
  },
};

let lang = 'ru';
try {
  const s = localStorage.getItem('eng.lang');
  if (s === 'ru' || s === 'en') lang = s;
} catch {}

export const getLang = () => lang;

export function t(key, ...args) {
  let s = (D[lang] && D[lang][key]) ?? D.ru[key] ?? key;
  args.forEach((v, i) => { s = s.split('{' + i + '}').join(v); });
  return s;
}

export function applyDom() {
  document.documentElement.lang = lang;
  document.querySelectorAll('[data-i18n]').forEach((e) => { e.textContent = t(e.dataset.i18n); });
  document.querySelectorAll('[data-i18n-ph]').forEach((e) => { e.placeholder = t(e.dataset.i18nPh); });
}

export function setLang(l) {
  if (l !== 'ru' && l !== 'en') return;
  lang = l;
  try { localStorage.setItem('eng.lang', l); } catch {}
  applyDom();
}

Object.assign(D.ru, {
  block: 'Блок', addBlock: 'Блок', neon: 'Неон', del: 'Удалить', graphics: 'Графика', reset: 'Сброс',
  grp_time: 'Время и небо', grp_fx: 'Эффекты', grp_col: 'Цвет', grp_fog: 'Туман',
  g_time: 'Время суток', g_contrast: 'Контраст', g_exposure: 'Яркость', g_sat: 'Насыщенность',
  g_rays: 'Лучи', g_neon: 'Яркость неона', g_bloom: 'Блум', g_bthr: 'Порог блума',
  g_fogd: 'Плотность', g_fogs: 'Начало от игрока', g_skyb: 'Яркость неба', g_sun: 'Размер солнца',
  g_vig: 'Виньетка', g_amb: 'Окружающий свет',
});
Object.assign(D.en, {
  block: 'Block', addBlock: 'Block', neon: 'Neon', del: 'Delete', graphics: 'Graphics', reset: 'Reset',
  grp_time: 'Time & sky', grp_fx: 'Effects', grp_col: 'Color', grp_fog: 'Fog',
  g_time: 'Time of day', g_contrast: 'Contrast', g_exposure: 'Brightness', g_sat: 'Saturation',
  g_rays: 'Light rays', g_neon: 'Neon brightness', g_bloom: 'Bloom', g_bthr: 'Bloom threshold',
  g_fogd: 'Density', g_fogs: 'Start distance', g_skyb: 'Sky brightness', g_sun: 'Sun size',
  g_vig: 'Vignette', g_amb: 'Ambient light',
});

Object.assign(D.ru, { g_shadow: 'Тени', g_nlight: 'Свет от неона' });
Object.assign(D.en, { g_shadow: 'Shadows', g_nlight: 'Neon light' });

Object.assign(D.ru, {
  alpha: 'Прозрачн.', water: 'Вода', grp_water: 'Вода', grp_cam: 'Камера',
  g_waveh: 'Высота волн', g_waves: 'Скорость волн', g_bump: 'Рельеф поверхности',
  g_fov: 'Поле зрения (FOV)', g_sens: 'Чувствительность камеры',
});
Object.assign(D.en, {
  alpha: 'Opacity', water: 'Water', grp_water: 'Water', grp_cam: 'Camera',
  g_waveh: 'Wave height', g_waves: 'Wave speed', g_bump: 'Surface relief',
  g_fov: 'Field of view (FOV)', g_sens: 'Camera sensitivity',
});

Object.assign(D.ru, { fire: 'Огонь' });
Object.assign(D.en, { fire: 'Fire' });

Object.assign(D.ru, { g_fogn: 'Шум тумана', g_mie: 'Рассеяние света' });
Object.assign(D.en, { g_fogn: 'Fog noise', g_mie: 'Light scattering' });

Object.assign(D.ru, {
  grp_qual: 'Качество', g_texq: 'Качество текстур', g_shq: 'Качество теней', g_wq: 'Качество воды',
  q_low: 'Низкое', q_med: 'Среднее', q_high: 'Высокое',
  material: 'Материал', mat_stone: 'Камень', mat_glass: 'Стекло', mat_sand: 'Песок',
  mat_wood: 'Древесина', mat_planks: 'Доски', mat_custom: 'Из галереи',
  wtex: 'Текстура воды', wtex_std: 'Обычная', wtex_gal: 'Из галереи',
});
Object.assign(D.en, {
  grp_qual: 'Quality', g_texq: 'Texture quality', g_shq: 'Shadow quality', g_wq: 'Water quality',
  q_low: 'Low', q_med: 'Medium', q_high: 'High',
  material: 'Material', mat_stone: 'Stone', mat_glass: 'Glass', mat_sand: 'Sand',
  mat_wood: 'Wood', mat_planks: 'Planks', mat_custom: 'From gallery',
  wtex: 'Water texture', wtex_std: 'Default', wtex_gal: 'From gallery',
});
