const D = {
  ru: {
    projects: 'Проекты',
    empty: 'Проектов пока нет.\nНажмите «+», чтобы создать первый.',
    newProject: 'Новый проект',
    iconLabel: 'Иконка',
    namePh: 'Название игры',
    create: 'Создать',
    copyLog: 'Копировать лог',
    outChip: 'Вывод',
    copied: 'Скопировано',
    close: 'Закрыть',
    menu: '‹ Меню',
    rotate: 'Поверните телефон\nгоризонтально',
    pos: 'Позиция',
    rot: 'Поворот°',
    size: 'Размер',
    color: 'Цвет',
    settings: 'Настройки',
    language: 'Язык',
    plate: 'Плита',
    checkFail: 'Ошибка проверки',
    log_start: 'Проверка целостности движка',
    log_core_fail: 'Rust core не загрузился: {0}',
    log_core_ok: 'Rust core v{0}',
    log_webgl: 'WebGL2 · GPU: {0}',
    log_tex: 'Макс. текстура: {0}px',
    log_webgl_fail: 'WebGL2: {0}',
    log_store_ok: 'Хранилище проектов',
    log_store_fail: 'Хранилище: {0}',
    log_threads: 'Потоки (SharedArrayBuffer): {0}',
    thr_yes: 'доступны',
    thr_no: 'недоступны, пока не нужны',
    log_physics: 'Физика: модуль ещё не подключён (план v0.3)',
    log_all_ok: 'Все проверки пройдены',
    log_some_fail: 'Есть ошибки, см. лог',
    log_exc: 'Исключение: {0}',
    confirmDel: 'Удалить проект «{0}»?',
    saveFail: 'Не удалось сохранить: {0}',
    coreNotLoaded: 'Rust core не загружен: {0}',
    engineFail: 'Не удалось создать движок: {0}',
    imgFail: 'Не удалось открыть картинку',
  },
  en: {
    projects: 'Projects',
    empty: 'No projects yet.\nTap “+” to create your first one.',
    newProject: 'New project',
    iconLabel: 'Icon',
    namePh: 'Game name',
    create: 'Create',
    copyLog: 'Copy log',
    outChip: 'Output',
    copied: 'Copied',
    close: 'Close',
    menu: '‹ Menu',
    rotate: 'Rotate your phone\nto landscape',
    pos: 'Position',
    rot: 'Rotation°',
    size: 'Size',
    color: 'Color',
    settings: 'Settings',
    language: 'Language',
    plate: 'Plate',
    checkFail: 'Check failed',
    log_start: 'Engine integrity check',
    log_core_fail: 'Rust core failed to load: {0}',
    log_core_ok: 'Rust core v{0}',
    log_webgl: 'WebGL2 · GPU: {0}',
    log_tex: 'Max texture size: {0}px',
    log_webgl_fail: 'WebGL2: {0}',
    log_store_ok: 'Project storage',
    log_store_fail: 'Storage: {0}',
    log_threads: 'Threads (SharedArrayBuffer): {0}',
    thr_yes: 'available',
    thr_no: 'unavailable, not needed yet',
    log_physics: 'Physics: module not connected yet (planned v0.3)',
    log_all_ok: 'All checks passed',
    log_some_fail: 'Errors found, see log',
    log_exc: 'Exception: {0}',
    confirmDel: 'Delete project “{0}”?',
    saveFail: 'Failed to save: {0}',
    coreNotLoaded: 'Rust core is not loaded: {0}',
    engineFail: 'Failed to create engine: {0}',
    imgFail: 'Could not open the image',
  },
};

let lang = 'ru';
try {
  const s = localStorage.getItem('eng.lang');
  if (s === 'ru' || s === 'en') lang = s;
} catch {}

export const getLang = () => lang;

export function t(key, ...args) {
  let s = (D[lang] && D[lang][key]) ?? D.ru[key] ?? key;
  args.forEach((v, i) => { s = s.split('{' + i + '}').join(v); });
  return s;
}

export function applyDom() {
  document.documentElement.lang = lang;
  document.querySelectorAll('[data-i18n]').forEach((e) => { e.textContent = t(e.dataset.i18n); });
  document.querySelectorAll('[data-i18n-ph]').forEach((e) => { e.placeholder = t(e.dataset.i18nPh); });
}

export function setLang(l) {
  if (l !== 'ru' && l !== 'en') return;
  lang = l;
  try { localStorage.setItem('eng.lang', l); } catch {}
  applyDom();
}

Object.assign(D.ru, {
  block: 'Блок', addBlock: 'Блок', neon: 'Неон', del: 'Удалить', graphics: 'Графика', reset: 'Сброс',
  grp_time: 'Время и небо', grp_fx: 'Эффекты', grp_col: 'Цвет', grp_fog: 'Туман',
  g_time: 'Время суток', g_contrast: 'Контраст', g_exposure: 'Яркость', g_sat: 'Насыщенность',
  g_rays: 'Лучи', g_neon: 'Яркость неона', g_bloom: 'Блум', g_bthr: 'Порог блума',
  g_fogd: 'Плотность', g_fogs: 'Начало от игрока', g_skyb: 'Яркость неба', g_sun: 'Размер солнца',
  g_vig: 'Виньетка', g_amb: 'Окружающий свет',
});
Object.assign(D.en, {
  block: 'Block', addBlock: 'Block', neon: 'Neon', del: 'Delete', graphics: 'Graphics', reset: 'Reset',
  grp_time: 'Time & sky', grp_fx: 'Effects', grp_col: 'Color', grp_fog: 'Fog',
  g_time: 'Time of day', g_contrast: 'Contrast', g_exposure: 'Brightness', g_sat: 'Saturation',
  g_rays: 'Light rays', g_neon: 'Neon brightness', g_bloom: 'Bloom', g_bthr: 'Bloom threshold',
  g_fogd: 'Density', g_fogs: 'Start distance', g_skyb: 'Sky brightness', g_sun: 'Sun size',
  g_vig: 'Vignette', g_amb: 'Ambient light',
});

Object.assign(D.ru, { g_shadow: 'Тени', g_nlight: 'Свет от неона' });
Object.assign(D.en, { g_shadow: 'Shadows', g_nlight: 'Neon light' });

Object.assign(D.ru, {
  alpha: 'Прозрачн.', water: 'Вода', grp_water: 'Вода', grp_cam: 'Камера',
  g_waveh: 'Высота волн', g_waves: 'Скорость волн', g_bump: 'Рельеф поверхности',
  g_fov: 'Поле зрения (FOV)', g_sens: 'Чувствительность камеры',
});
Object.assign(D.en, {
  alpha: 'Opacity', water: 'Water', grp_water: 'Water', grp_cam: 'Camera',
  g_waveh: 'Wave height', g_waves: 'Wave speed', g_bump: 'Surface relief',
  g_fov: 'Field of view (FOV)', g_sens: 'Camera sensitivity',
});

Object.assign(D.ru, { fire: 'Огонь' });
Object.assign(D.en, { fire: 'Fire' });

Object.assign(D.ru, { g_fogn: 'Шум тумана', g_mie: 'Рассеяние света', g_clouds: 'Облака', server: 'Серверные скрипты', server_new: 'Новый скрипт', edit_brush: 'Кисть', edit_invert: 'Инверт', edit_mirror: 'Зеркало' });
Object.assign(D.en, { g_fogn: 'Fog noise', g_mie: 'Light scattering', g_clouds: 'Clouds', server: 'Server scripts', server_new: 'New script', edit_brush: 'Brush', edit_invert: 'Invert', edit_mirror: 'Mirror' });

Object.assign(D.ru, {
  grp_qual: 'Качество', g_texq: 'Качество текстур', g_shq: 'Качество теней', g_wq: 'Качество воды',
  q_low: 'Низкое', q_med: 'Среднее', q_high: 'Высокое',
  material: 'Материал', mat_stone: 'Камень', mat_glass: 'Стекло', mat_sand: 'Песок',
  mat_wood: 'Древесина', mat_planks: 'Доски', mat_custom: 'Из галереи',
  wtex: 'Текстура воды', wtex_std: 'Обычная', wtex_gal: 'Из галереи',
});
Object.assign(D.en, {
  grp_qual: 'Quality', g_texq: 'Texture quality', g_shq: 'Shadow quality', g_wq: 'Water quality',
  q_low: 'Low', q_med: 'Medium', q_high: 'High',
  material: 'Material', mat_stone: 'Stone', mat_glass: 'Glass', mat_sand: 'Sand',
  mat_wood: 'Wood', mat_planks: 'Planks', mat_custom: 'From gallery',
  wtex: 'Water texture', wtex_std: 'Default', wtex_gal: 'From gallery',
});
Object.assign(D.ru, {
  player: 'Игрок', player_model: 'Модель', player_model_none: 'не выбрана',
  player_create: 'Создать модель', shape: 'Форма', shape_cube: 'Куб', shape_tri: 'Призма',
  shape_sphere: 'Сфера', shape_wheel: 'Колесо', shape_oval: 'Овал',
  edit: 'Правка', edit_open: '✎ Открыть', edit_title: 'Режим правки', edit_grid: 'Сетка (кубиков)',
  edit_round: 'Скругление', edit_reset: 'Сбросить ячейки',
  edit_hint: 'Тап — удалить/вернуть кубик. Кисть — ведите пальцем. Зеркало X/Y/Z синхронизирует правки. ↻ — поворот на 90°, ⇈ — выдавить. ✕ — готово.',
  script_title: 'player.hgs', script_reset: 'Сбросить', save: 'Сохранить',
  script_hint: 'Скрипт игрока на языке @W/@L/@P/@F/@E. Запускается при ▶.',
  obj_script: 'Скрипт', edit_undo: 'Отмена', edit_iso: 'Изолировать',
  ce_check: 'Проверить', ce_fmt: 'Формат', ce_run: 'Запустить',
  ce_find_ph: 'Поиск… (Ctrl+F)',
  ce_hints: 'Ctrl+Space — подсказки · Ctrl+F — поиск · Ctrl+Enter — проверить · Tab — отступ',
  player_view: 'Вид игрока', player_sphere: 'Сфера', player_human: 'Модель',
  rotate_tip: 'Нажмите, чтобы продолжить',
  mappSaved: 'Файл .mapp сохранён', mappImported: 'Проект импортирован', mappBad: 'Неверный файл .mapp',
});
Object.assign(D.en, {
  player: 'Player', player_model: 'Model', player_model_none: 'not set',
  player_create: 'Create model', shape: 'Shape', shape_cube: 'Cube', shape_tri: 'Prism',
  shape_sphere: 'Sphere', shape_wheel: 'Wheel', shape_oval: 'Oval',
  edit: 'Edit', edit_open: '✎ Open', edit_title: 'Edit mode', edit_grid: 'Grid (cells)',
  edit_round: 'Rounding', edit_reset: 'Reset cells',
  edit_hint: 'Tap to remove/restore a cell. Brush: drag. Mirror X/Y/Z syncs edits. ↻ rotate 90°, ⇈ extrude. ✕ to finish.',
  script_title: 'player.hgs', script_reset: 'Reset', save: 'Save',
  script_hint: 'Player script in @W/@L/@P/@F/@E language. Runs on ▶.',
  obj_script: 'Script', edit_undo: 'Undo', edit_iso: 'Isolate',
  ce_check: 'Check', ce_fmt: 'Format', ce_run: 'Run',
  ce_find_ph: 'Search… (Ctrl+F)',
  ce_hints: 'Ctrl+Space — hints · Ctrl+F — search · Ctrl+Enter — check · Tab — indent',
  player_view: 'Player view', player_sphere: 'Sphere', player_human: 'Model',
  rotate_tip: 'Tap to continue',
  mappSaved: '.mapp file saved', mappImported: 'Project imported', mappBad: 'Invalid .mapp file',
});
