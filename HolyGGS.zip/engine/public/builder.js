/* ============================================================
 * builder.js — сборка самостоятельных APK из проекта HolyGGS
 * (zip STORE, SHA-256, RSA-PKCS#7 v1-подпись, правка AXML)
 * ============================================================ */

/* ---------- base64 / байты ---------- */
export function b64enc(bytes) {
  let bin = '';
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  for (let i = 0; i < u8.length; i += 0x8000) bin += String.fromCharCode(...u8.subarray(i, i + 0x8000));
  return btoa(bin);
}
export function b64dec(s) {
  const bin = atob(s);
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8;
}
const enc = new TextEncoder();
const dec = new TextDecoder();
const dec16 = new TextDecoder('utf-16le');
export const utf8 = (s) => enc.encode(s);

/* ---------- CRC32 (для zip) ---------- */
const CRCT = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(buf) {
  let c = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) c = CRCT[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}

/* ---------- SHA-256 (чистый JS) ---------- */
const K256 = new Uint32Array([
  0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
  0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
  0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
  0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
  0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
  0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
  0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
  0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2,
]);
export function sha256(msg) {
  const m = msg instanceof Uint8Array ? msg : new Uint8Array(msg);
  const H = new Uint32Array([0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]);
  const l = m.length;
  const withPad = (((l + 8) >> 6) + 1) << 6;
  const buf = new Uint8Array(withPad);
  buf.set(m);
  buf[l] = 0x80;
  const dv = new DataView(buf.buffer);
  dv.setUint32(withPad - 8, Math.floor(l / 0x20000000), false);
  dv.setUint32(withPad - 4, (l << 3) >>> 0, false);
  const w = new Uint32Array(64);
  for (let off = 0; off < withPad; off += 64) {
    for (let i = 0; i < 16; i++) w[i] = dv.getUint32(off + 4 * i, false);
    for (let i = 16; i < 64; i++) {
      const s0 = ((w[i-15] >>> 7) | (w[i-15] << 25)) ^ ((w[i-15] >>> 18) | (w[i-15] << 14)) ^ (w[i-15] >>> 3);
      const s1 = ((w[i-2] >>> 17) | (w[i-2] << 15)) ^ ((w[i-2] >>> 19) | (w[i-2] << 13)) ^ (w[i-2] >>> 10);
      w[i] = (w[i-16] + s0 + w[i-7] + s1) >>> 0;
    }
    let [a,b,c,d,e,f,g,h] = H;
    for (let i = 0; i < 64; i++) {
      const S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
      const ch = (e & f) ^ (~e & g);
      const t1 = (h + S1 + ch + K256[i] + w[i]) >>> 0;
      const S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const t2 = (S0 + maj) >>> 0;
      h = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
    }
    H[0]=(H[0]+a)>>>0; H[1]=(H[1]+b)>>>0; H[2]=(H[2]+c)>>>0; H[3]=(H[3]+d)>>>0;
    H[4]=(H[4]+e)>>>0; H[5]=(H[5]+f)>>>0; H[6]=(H[6]+g)>>>0; H[7]=(H[7]+h)>>>0;
  }
  const out = new Uint8Array(32);
  new DataView(out.buffer).setUint32(0, H[0], false);
  for (let i = 0; i < 8; i++) new DataView(out.buffer).setUint32(i * 4, H[i], false);
  return out;
}

/* ---------- DER ---------- */
function derLen(n) {
  if (n < 0x80) return Uint8Array.of(n);
  const b = [];
  let x = n;
  while (x > 0) { b.unshift(x & 0xFF); x >>>= 8; }
  return Uint8Array.of(0x80 | b.length, ...b);
}
function tlv(tag, content) {
  const c = content instanceof Uint8Array ? content : new Uint8Array(content);
  const l = derLen(c.length);
  const out = new Uint8Array(1 + l.length + c.length);
  out[0] = tag; out.set(l, 1); out.set(c, 1 + l.length);
  return out;
}
const derSeq = (...parts) => tlv(0x30, concat(parts));
const derSet = (...parts) => tlv(0x31, concat(parts));
const derOctet = (b) => tlv(0x04, b);
const derNull = () => Uint8Array.of(0x05, 0x00);
function derInt(bytesOrBig) {
  if (typeof bytesOrBig === 'number') bytesOrBig = BigInt(bytesOrBig);
  let b;
  if (typeof bytesOrBig === 'bigint') {
    let hex = bytesOrBig.toString(16);
    if (hex.length % 2) hex = '0' + hex;
    b = b64dec(btoa((hex.match(/../g) || []).map((h) => String.fromCharCode(parseInt(h, 16))).join('')));
  } else b = bytesOrBig instanceof Uint8Array ? bytesOrBig : new Uint8Array(bytesOrBig);
  let i = 0;
  while (i < b.length - 1 && b[i] === 0 && !(b[i+1] & 0x80)) i++;
  b = b.subarray(i);
  if (b.length === 0) b = Uint8Array.of(0);
  const needPad = b[0] & 0x80;
  const out = new Uint8Array(b.length + (needPad ? 1 : 0));
  if (needPad) out.set(b, 1); else out.set(b);
  return tlv(0x02, out);
}
function derOid(s) {
  const parts = s.split('.').map(Number);
  const bytes = [40 * parts[0] + parts[1]];
  for (const p of parts.slice(2)) {
    const v = [];
    let x = p;
    do { v.unshift(x & 0x7F); x >>>= 7; } while (x > 0);
    for (let i = 0; i < v.length - 1; i++) v[i] |= 0x80;
    bytes.push(...v);
  }
  return tlv(0x06, Uint8Array.from(bytes));
}
function derUtc(d) {
  const p = (n) => String(n).padStart(2, '0');
  const s = String(d.getUTCFullYear() % 100).padStart(2, '0') + p(d.getUTCMonth() + 1) + p(d.getUTCDate()) + p(d.getUTCHours()) + p(d.getUTCMinutes()) + p(d.getUTCSeconds()) + 'Z';
  return tlv(0x17, utf8(s));
}
function concat(parts) {
  const arr = parts.flat();
  let n = 0;
  for (const p of arr) n += p.length;
  const out = new Uint8Array(n);
  let o = 0;
  for (const p of arr) { out.set(p, o); o += p.length; }
  return out;
}

/* ---------- RSA (PKCS#1 v1.5, CRT) ---------- */
function bigFromBytes(b) {
  let hex = '';
  for (const x of b) hex += x.toString(16).padStart(2, '0');
  return hex ? BigInt('0x' + hex) : 0n;
}
function bytesFromBig(x, len) {
  let hex = x.toString(16);
  if (hex.length % 2) hex = '0' + hex;
  const b = b64dec(btoa((hex.match(/../g) || []).map((h) => String.fromCharCode(parseInt(h, 16))).join('')));
  if (len === undefined) return b;
  const out = new Uint8Array(len);
  out.set(b.subarray(Math.max(0, b.length - len)), Math.max(0, len - b.length));
  return out;
}
function modPow(base, exp, mod) {
  let r = 1n;
  base %= mod;
  while (exp > 0n) {
    if (exp & 1n) r = (r * base) % mod;
    base = (base * base) % mod;
    exp >>= 1n;
  }
  return r;
}
/* PKCS#8 → {n, e, d, p, q, dp, dq, qinv} */
function parsePkcs8(der) {
  // PKCS#8: SEQ { INT 0, SEQ { OID rsa, NULL }, OCTET(inner) } → inner SEQ { INT 0, n, e, d, p, q, dp, dq, qinv }
  const top = parseDerSeqs(der)[0];
  const items = parseDerSeqs(top.content);
  const inner = parseDerSeqs(parseDerSeqs(items[2].content)[0].content);
  const bi = (u8) => bigFromBytes(u8);
  return { n: bi(inner[1].content), e: bi(inner[2].content), d: bi(inner[3].content),
           p: bi(inner[4].content), q: bi(inner[5].content), dp: bi(inner[6].content),
           dq: bi(inner[7].content), qinv: bi(inner[8].content) };
}
function parseDerSeqs(der) {
  // возвращает список TLV {tag, content} верхнего уровня одного контейнера
  const out = [];
  let off = 0;
  while (off < der.length) {
    const tag = der[off];
    let l = der[off + 1], hl = 2;
    if (l & 0x80) { const n = l & 0x7F; l = 0; for (let i = 0; i < n; i++) l = (l << 8) | der[off + 2 + i]; hl = 2 + n; }
    out.push({ tag, content: der.subarray(off + hl, off + hl + l) });
    off += hl + l;
  }
  return out;
}
function rsaSignPkcs1(hash, key) {
  const k = key.n.toString(16).length >> 1;
  const t = concat([derSeq(derSeq(derOid('2.16.840.1.101.3.4.2.1'), derNull()), derOctet(hash))]);
  const psLen = k - t.length - 3;
  const em = new Uint8Array(k);
  em[0] = 0; em[1] = 1;
  em.fill(0xFF, 2, 2 + psLen);
  em[2 + psLen] = 0;
  em.set(t, 3 + psLen);
  const m = bigFromBytes(em);
  const m1 = modPow(m, key.dp, key.p);
  const m2 = modPow(m, key.dq, key.q);
  let h = (key.qinv * ((m1 - m2) % key.p + key.p)) % key.p;
  const s = m2 + h * key.q;
  return bytesFromBig(s, k);
}

/* ---------- zip (только STORE) ---------- */
export function zipRead(buf) {
  const u8 = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
  // EOCD
  let eocd = -1;
  for (let i = u8.length - 22; i >= 0 && i > u8.length - 66000; i--) {
    if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('zip: EOCD не найден');
  const count = dv.getUint16(eocd + 10, true);
  let off = dv.getUint32(eocd + 16, true);
  const entries = [];
  for (let i = 0; i < count; i++) {
    if (dv.getUint32(off, true) !== 0x02014b50) throw new Error('zip: CD повреждён');
    const method = dv.getUint16(off + 10, true);
    const csize = dv.getUint32(off + 20, true);
    const nlen = dv.getUint16(off + 28, true);
    const elen = dv.getUint16(off + 30, true);
    const clen = dv.getUint16(off + 32, true);
    const lho = dv.getUint32(off + 42, true);
    const name = dec.decode(u8.subarray(off + 46, off + 46 + nlen));
    if (method !== 0) throw new Error('zip: нужен STORE (' + name + ')');
    const lnlen = dv.getUint16(lho + 26, true);
    const lelen = dv.getUint16(lho + 28, true);
    const ds = lho + 30 + lnlen + lelen;
    entries.push({ name, data: u8.subarray(ds, ds + csize) });
    off += 46 + nlen + elen + clen;
  }
  return entries;
}
export function zipWrite(entries) {
  const parts = [];
  const cd = [];
  let offset = 0;
  const dosTime = 0, dosDate = 0x5821; // 2024-01-01
  for (const e of entries) {
    const name = utf8(e.name);
    const data = e.data instanceof Uint8Array ? e.data : new Uint8Array(e.data);
    const crc = crc32(data);
    // zipalign 4: данные записи выравниваются по 4 байтам extra-field'ом TLV 0x0000
    const need = (4 - ((offset + 30 + name.length) % 4)) % 4;
    const extraLen = need ? 4 + need : 0;
    const lh = new Uint8Array(30 + name.length + extraLen);
    const dv = new DataView(lh.buffer);
    dv.setUint32(0, 0x04034b50, true);
    dv.setUint16(4, 20, true); dv.setUint16(6, 0, true); dv.setUint16(8, 0, true);
    dv.setUint16(10, dosTime, true); dv.setUint16(12, dosDate, true);
    dv.setUint32(14, crc, true); dv.setUint32(18, data.length, true); dv.setUint32(22, data.length, true);
    dv.setUint16(26, name.length, true); dv.setUint16(28, extraLen, true);
    lh.set(name, 30);
    if (need) {
      lh[30 + name.length] = 0; lh[31 + name.length] = 0;
      lh[32 + name.length] = need & 0xFF; lh[33 + name.length] = 0;
    }
    parts.push(lh, data);
    const ch = new Uint8Array(46 + name.length);
    const cv = new DataView(ch.buffer);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(4, 20, true); cv.setUint16(6, 20, true);
    cv.setUint16(10, 0, true); cv.setUint16(12, dosTime, true); cv.setUint16(14, dosDate, true);
    cv.setUint32(16, crc, true); cv.setUint32(20, data.length, true); cv.setUint32(24, data.length, true);
    cv.setUint16(28, name.length, true);
    cv.setUint32(42, offset, true);
    ch.set(name, 46);
    cd.push(ch);
    offset += lh.length + data.length;
  }
  const cdBytes = concat(cd);
  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(8, entries.length, true); ev.setUint16(10, entries.length, true);
  ev.setUint32(12, cdBytes.length, true); ev.setUint32(16, offset, true);
  return concat([...parts, cdBytes, eocd]);
}

/* ---------- AXML: замена строк в пуле (пакет/имя игры) ---------- */
export function axmlReplaceStrings(axml, replacements) {
  const u8 = axml instanceof Uint8Array ? axml : new Uint8Array(axml);
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
  if (dv.getUint16(0, true) !== 0x0003) throw new Error('AXML: не XML-чанк');
  const rootSize = dv.getUint32(4, true);
  // пул строк — первый сабчанк
  if (dv.getUint16(8, true) !== 0x0001) throw new Error('AXML: нет пула строк');
  const poolOff = 8;
  const poolSize = dv.getUint32(poolOff + 4, true);
  const strCount = dv.getUint32(poolOff + 8, true);
  const styleCount = dv.getUint32(poolOff + 12, true);
  const flags = dv.getUint32(poolOff + 16, true);
  const stringsStart = dv.getUint32(poolOff + 20, true);
  const isUtf8 = !!(flags & 0x100);
  const offs = [];
  for (let i = 0; i < strCount; i++) offs.push(dv.getUint32(poolOff + 28 + 4 * i, true));
  const dataStart = poolOff + stringsStart;
  const strings = [];
  for (let i = 0; i < strCount; i++) {
    let p = dataStart + offs[i];
    if (isUtf8) {
      let l = u8[p]; p++;
      if (l & 0x80) { l = ((l & 0x7F) << 8) | u8[p]; p++; }
      let bl = u8[p]; p++;
      if (bl & 0x80) { bl = ((bl & 0x7F) << 8) | u8[p]; p++; }
      strings.push(dec.decode(u8.subarray(p, p + bl)));
    } else {
      let l = dv.getUint16(p, true); p += 2;
      if (l & 0x8000) { l = ((l & 0x7FFF) << 16) | dv.getUint16(p, true); p += 2; }
      strings.push(dec16.decode(u8.subarray(p, p + l * 2)));
    }
  }
  // замены
  let changed = false;
  for (let i = 0; i < strCount; i++) {
    const r = replacements[strings[i]];
    if (r !== undefined) { strings[i] = r; changed = true; }
  }
  if (!changed) return u8;
  // пересборка пула
  const chunks = [];
  const newOffs = [];
  let dataLen = 0;
  for (const s of strings) {
    newOffs.push(dataLen);
    const sb = utf8(s);
    if (isUtf8) {
      const chars = s.length;
      const hdr = [];
      if (chars < 0x80) hdr.push(chars); else hdr.push(0x80 | (chars >> 8), chars & 0xFF);
      if (sb.length < 0x80) hdr.push(sb.length); else hdr.push(0x80 | (sb.length >> 8), sb.length & 0xFF);
      const part = concat([Uint8Array.from(hdr), sb, Uint8Array.of(0)]);
      chunks.push(part); dataLen += part.length;
    } else {
      const units = [];
      for (const ch of s) {
        const cp = ch.codePointAt(0);
        if (cp > 0xFFFF) {
          const v = cp - 0x10000;
          units.push(0xD800 + (v >> 10), 0xDC00 + (v & 0x3FF));
        } else units.push(cp);
      }
      const hdr = units.length < 0x8000 ? Uint8Array.of(units.length & 0xFF, units.length >> 8)
        : Uint8Array.of((units.length >> 16) & 0x7F | 0x80, units.length >> 24, units.length & 0xFF, (units.length >> 8) & 0xFF);
      const u16 = new Uint8Array(units.length * 2 + 2);
      const uv = new DataView(u16.buffer);
      units.forEach((v, i) => uv.setUint16(i * 2, v, true));
      const part = concat([hdr, u16]);
      chunks.push(part); dataLen += part.length;
    }
  }
  const stringsStartNew = 28 + 4 * strCount;
  const pad = (4 - (dataLen % 4)) % 4;
  const pool = new Uint8Array(stringsStartNew + dataLen + pad);
  const pv = new DataView(pool.buffer);
  pv.setUint16(0, 0x0001, true);
  pv.setUint16(2, 28, true);
  pv.setUint32(4, pool.length, true);
  pv.setUint32(8, strCount, true);
  pv.setUint32(12, styleCount, true);
  pv.setUint32(16, flags, true);
  pv.setUint32(20, stringsStartNew, true);
  pv.setUint32(24, styleCount ? stringsStartNew + dataLen + pad : 0, true);
  for (let i = 0; i < strCount; i++) pv.setUint32(28 + 4 * i, newOffs[i], true);
  let o = stringsStartNew;
  for (const c of chunks) { pool.set(c, o); o += c.length; }
  const out = concat([u8.subarray(0, poolOff), pool, u8.subarray(poolOff + poolSize)]);
  const ov = new DataView(out.buffer, out.byteOffset, out.byteLength);
  ov.setUint32(4, out.length, true); // размер корневого XML-чанка
  return out;
}

/* ---------- ключ подписи экспорта (HolyGGS Game Export) ---------- */
const CERT_DER = b64dec('MIIDXTCCAkWgAwIBAgIUcVZh0SE6PwzYgX/4t/FQwX8TVBwwDQYJKoZIhvcNAQELBQAwPTEcMBoGA1UEAwwTSG9seUdHUyBHYW1lIEV4cG9ydDEQMA4GA1UECgwHSG9seUdHUzELMAkGA1UEBhMCUlUwIBcNMjYxMDA2MjEwMDE5WhgPMjEyNjA5MTIyMTAwMTlaMD0xHDAaBgNVBAMME0hvbHlHR1MgR2FtZSBFeHBvcnQxEDAOBgNVBAoMB0hvbHlHR1MxCzAJBgNVBAYTAlJVMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuU+cc3GaSxmbfCbhefle3nNCp3K0rOawHw3ht/kHALAbfhKjbRihmzogIKJ3gjWo/9cFUlMVbHVz2WJqHtapzHNxkth2Mt3PeQ906j6ajQRLZS9omxfQKj/ksdBiKa8/Khx8PwSHts0FU5FeLWoC6aqyygLYxUj0y0VD55u24cjSq1tZydejoi89emWhjwgZL8TsZ+0CroK1T1WWFv0rzHjNxvGr0e7HCFwx7nYSB+LyrF3NWgeWc2rdugn5pae4t9iThcgEF+tf4EGJd+KmvuC9HOVNUfckSzuxHbEQ0wRkdQp2RGzmOb0DJ5AJth8eXGWrtktfs8+g9lfX2u/9IwIDAQABo1MwUTAdBgNVHQ4EFgQUFc9so/lS5Ki8UWkLiXrNKOdzJr8wHwYDVR0jBBgwFoAUFc9so/lS5Ki8UWkLiXrNKOdzJr8wDwYDVR0TAQH/BAUwAwEB/zANBgkqhkiG9w0BAQsFAAOCAQEANkV4FHP1ojoiI74mBRSmGADL4e97mpDcHjwXfjsT9lDig0gaRtRn2CE0TZUPNLiLztJY3lV6MozpUa7EnQ41dMa42suGI2ADWkWVT9AAik+SPOsaHPny+srpM+WgGNYu08PdssQBOKjhBdUaUck1QKkiU0hAwWMuup0m7hG0TZ6JcRO5dzBOueOEUPLXsDQeFU51v2zTk2bIeoMycu52MH+8t1afKjKU3BC2ydchb1llzanzEPTHCE+Zwqx+wG6VHBv0wIvlTi1fUbckCPP+OxMsCdvBdlbML3nyF8MAmYd//PFpgHHG3H6LasaSV6A5aD4OsUmVM5rLZpe5OX0Cow==');
const KEY_DER = b64dec('MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC5T5xzcZpLGZt8JuF5+V7ec0KncrSs5rAfDeG3+QcAsBt+EqNtGKGbOiAgoneCNaj/1wVSUxVsdXPZYmoe1qnMc3GS2HYy3c95D3TqPpqNBEtlL2ibF9AqP+Sx0GIprz8qHHw/BIe2zQVTkV4tagLpqrLKAtjFSPTLRUPnm7bhyNKrW1nJ16OiLz16ZaGPCBkvxOxn7QKugrVPVZYW/SvMeM3G8avR7scIXDHudhIH4vKsXc1aB5Zzat26Cfmlp7i32JOFyAQX61/gQYl34qa+4L0c5U1R9yRLO7EdsRDTBGR1CnZEbOY5vQMnkAm2Hx5cZau2S1+zz6D2V9fa7/0jAgMBAAECggEADUBeqTi59l3d6wpivFSzTogCf7PprKWQeaAGAKBrukZdqO3PRvlocQ++hWbo0eRhce4f4Mu1L/zULHrnqM3j9Y1Z1UzqYufOstMCos+YQLZKZ/F0cwbIaYUJJxgGNQHlq+6+ickapV1S4K94AxpeG/SLdXuvoaf+bVzGJtVRRiL1fQFbGrL1n/nc8zbh1QLa/P5ppvlpLLwyQYqqaznIUG3P43B6aRegIOAiPDLjEQIVNoWn2zb9ZTcfT3GtRIELGqQZhf1sSsQwJX/ityoqqgeLi/0KNN3FozfwJhk0LheF4g+EK1sjsBvZUn9Q7WHHnxyE4xwA/fgW9cPjWe0zYQKBgQDtkCEwQlyuOYcjOmLbRMZIcsBz4YlgMCW4+dHWnJb8UnwBseW+ctST5Rnjn+dMaR2psEDpXmRAh3R3qCsfpgxDFrKtSVECEOCt5jmVQQgm6rD63/H+cXVIQnR0WyQN4DKuB4c7F6tB189NhOWjhogaY/LiVZpLOn1bjpfrJfHcgwKBgQDHsVhdJZa+u5P6LlJOVuR9FqKaJx6pnTu/Mhg4iHQ/zD7uQ4MuiQZp2Dee40t8nqA8vjrb59FL6gW4ON+a0JXhv+QKOqpJDpTDvzK9qyEVi5QZxdX9vJeuljm9EnKqxINvtg9i5Ohea/NB+bP2cI4VidM6JNsiu4W7Ujxan2K64QKBgH+d+5Y3MB6P3N650L1F1ta4flZCBFBdzQXvfiAyApINpXwrmuWSPkwsuJmlHtXXag3sFxLGmEhp+9ED0BayVsf7e4THa/MWKfyBPtHFG6H8VZKPlyo+vOhSesi+5UFm/RKsDKNb9a3rRvu3trz/2kGDC8k2fyqGgy0aDtZNjf4NAoGAVCGgg+XhQ8xNhNrdLEopi5XsvZt7rKQk1uGpGLBModBQNxvUedebDx7cGCHU3NUL12uh6qIZKK2Y6Ut00YnNi8XHspOSyKLPBEVagFRH5QbgR5d1F6jMEu8Rtlm+W7ndUkRW6ShdyeIbI5GrQ0maYvKlPlrmxBRTPF9iNB/wfaECgYEAst+b6kSE5G0MFridNBU5bS1C0hJPLaOV4VTbdp8KEFJCk0Umq5EKor06PUx5hbLdbZp1bDEW6xUFQ824WDzZfkf4OpYrpiaXyrgZO0h0K7+bYCPXJAII6Ea/pCG7pBY6i7cJ83xiZrKG9SeehTmhpDG/E0bozlfn139KF8QpD1E=');
const ISSUER_DER = b64dec('MD0xHDAaBgNVBAMME0hvbHlHR1MgR2FtZSBFeHBvcnQxEDAOBgNVBAoMB0hvbHlHR1MxCzAJBgNVBAYTAlJV');
const SERIAL_DER = b64dec('AhRxVmHRITo/DNiBf/i38VDBfxNUHA==');

/* ---------- подпись APK (v1 / JAR) ---------- */
function wrap72(line) {
  // перенос строк длиннее 70 байт (спека JAR: ≤72 без CRLF)
  const bytes = utf8(line);
  if (bytes.length <= 70) return line;
  const out = [];
  let i = 0;
  let first = true;
  while (i < bytes.length) {
    const take = first ? 70 : 69;
    const part = dec.decode(bytes.subarray(i, Math.min(bytes.length, i + take)));
    out.push(first ? part : ' ' + part);
    i += take;
    first = false;
  }
  return out.join('\r\n');
}
export function signApkV1(apkBytes, key) {
  const entries = zipRead(apkBytes).filter((e) => !e.name.startsWith('META-INF/') && !e.name.endsWith('/'));
  let mf = 'Manifest-Version: 1.0\r\nCreated-By: HolyGGS\r\n\r\n';
  const secs = [];
  for (const e of entries) {
    const head = wrap72('Name: ' + e.name) + '\r\n' + wrap72('SHA-256-Digest: ' + b64enc(sha256(e.data))) + '\r\n\r\n';
    secs.push({ name: e.name, bytes: utf8(head) });
    mf += head;
  }
  const mfBytes = utf8(mf);
  let sf = 'Signature-Version: 1.0\r\nCreated-By: HolyGGS\r\n';
  sf += wrap72('SHA-256-Digest-Manifest: ' + b64enc(sha256(mfBytes))) + '\r\n\r\n';
  for (const s of secs) {
    sf += wrap72('Name: ' + s.name) + '\r\n' + wrap72('SHA-256-Digest: ' + b64enc(sha256(s.bytes))) + '\r\n\r\n';
  }
  const sfBytes = utf8(sf);
  // PKCS#7 SignedData БЕЗ authenticatedAttributes (форма jarsigner):
  // подпись = RSA PKCS#1 v1.5 от sha256(sfBytes) напрямую по контенту.
  const signature = rsaSignPkcs1(sha256(sfBytes), key);
  const digestAlg = derSeq(derOid('2.16.840.1.101.3.4.2.1'), derNull());
  const signerInfo = derSeq(
    derInt(1),
    derSeq(ISSUER_DER, SERIAL_DER),
    digestAlg,
    derSeq(derOid('1.2.840.113549.1.1.1'), derNull()),
    derOctet(signature),
  );
  const signedData = derSeq(
    derInt(1),
    derSet(digestAlg),
    derSeq(derOid('1.2.840.113549.1.7.1')),
    tlv(0xA0, CERT_DER),
    derSet(signerInfo),
  );
  const contentInfo = derSeq(derOid('1.2.840.113549.1.7.2'), tlv(0xA0, signedData));
  const out = [
    { name: 'META-INF/MANIFEST.MF', data: mfBytes },
    { name: 'META-INF/CERT.SF', data: sfBytes },
    { name: 'META-INF/CERT.RSA', data: contentInfo },
    ...entries,
  ];
  return zipWrite(out);
}

/* ---------- главная сборка ---------- */
export function gamePackageName(label) {
  let slug = String(label || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
  if (/^[0-9]/.test(slug)) slug = 'g' + slug;
  if (!slug) slug = 'game';
  slug = slug.slice(0, 20);
  let h = 0x811c9dc5;
  for (const ch of String(label || '')) { h ^= ch.charCodeAt(0); h = Math.imul(h, 0x01000193); }
  const hex = (h >>> 0).toString(16).padStart(8, '0');
  return 'com.holyggs.game.' + slug + '_' + hex;
}
export function buildGameApk(opts) {
  const { templateBytes, engineFiles, gameJson, iconPng, label, key } = opts;
  const pkg = gamePackageName(label);
  const entries = zipRead(templateBytes).filter((e) => !e.name.startsWith('META-INF/') && !e.name.endsWith('/'));
  for (const e of entries) {
    if (e.name === 'AndroidManifest.xml') {
      e.data = axmlReplaceStrings(e.data, {
        'com.holyggs.game.XXXXXXXXXXXXXXXXXXXXXXXX': pkg,
        'HOLYGGS_GAME_NAME_PLACEHOLDER': String(label || 'HolyGGS Game').slice(0, 60),
      });
    } else if (iconPng && /^res\/.+\.(png|webp|jpg|jpeg)$/i.test(e.name)) {
      e.data = iconPng;
    }
  }
  for (const f of engineFiles) entries.push({ name: 'assets/public/' + f.name, data: f.data });
  entries.push({ name: 'assets/public/game.mapp', data: utf8(gameJson) });
  const apk = zipWrite(entries);
  return signApkV1(apk, key || parsePkcs8(KEY_DER));
}
export function getExportKey() { return parsePkcs8(KEY_DER); }
