/* HolyGGS Player — чистый рантайм экспортированной игры.
   Состав игры: player.html + player.js + lang.js + pkg/engine.js + pkg/engine_bg.wasm + game.mapp.
   Редактор сюда не входит. */
import init, { Engine, version, gfx_defaults } from './pkg/engine.js';
import { createRuntime } from './lang.js';
import { UIMgr } from './ui.js';

const $ = (id) => document.getElementById(id);
const clamp = (v) => Math.max(-1, Math.min(1, v));

/* ---------- фатальные ошибки ---------- */
function showFatal(msg) {
  try {
    const el = $('fatal');
    el.style.display = 'block';
    el.textContent += msg + '\n\n';
  } catch (e) { /* ok */ }
}
addEventListener('error', (e) => showFatal('Ошибка: ' + (e.message || '?') + '\n' + ((e.error && e.error.stack) || '')));
addEventListener('unhandledrejection', (e) => {
  const r = e.reason;
  showFatal('Promise: ' + ((r && (r.stack || r.message)) || String(r)));
});

/* ---------- консоль игры ---------- */
let logN = 0;
function consolePrint(s) {
  try {
    const el = $('log');
    if (logN++ > 120) { el.textContent = ''; logN = 1; }
    el.textContent += s + '\n';
  } catch (e) { /* ok */ }
}

/* ---------- ввод: джойстик / прыжок / поворот камеры ---------- */
const joy = { x: 0, z: 0, y: 0 };
const kb = { x: 0, z: 0, y: 0 };
const touch = { jump: 0 };
let engine = null;
function pushMove() {
  if (engine) engine.set_move(clamp(joy.x + kb.x), clamp(joy.z + kb.z), clamp(joy.y + kb.y + touch.jump));
}
function makeJoy(el, onChange, lockX = false) {
  const knob = el.querySelector('.knob');
  let pid = null;
  const upd = (e) => {
    const r = el.getBoundingClientRect();
    let dx = e.clientX - (r.left + r.width / 2);
    let dy = e.clientY - (r.top + r.height / 2);
    if (lockX) dx = 0;
    const max = (lockX ? r.height : r.width) / 2 - 20;
    const len = Math.hypot(dx, dy);
    if (len > max) { dx *= max / len; dy *= max / len; }
    knob.style.transform = `translate(${dx}px,${dy}px)`;
    onChange(dx / max, dy / max);
  };
  const end = (e) => {
    if (e.pointerId !== pid) return;
    pid = null;
    knob.style.transform = '';
    onChange(0, 0);
  };
  el.addEventListener('pointerdown', (e) => {
    if (pid !== null) return;
    pid = e.pointerId;
    el.setPointerCapture(pid);
    upd(e);
    e.preventDefault();
  });
  el.addEventListener('pointermove', (e) => { if (e.pointerId === pid) upd(e); });
  el.addEventListener('pointerup', end);
  el.addEventListener('pointercancel', end);
  el.addEventListener('lostpointercapture', end);
}

/* системный интерфейс из сцены */
function applySysUI(sui) {
  const set = (id, on) => { const el = $(id); if (el) el.classList.toggle('sys-off', !on); };
  set('joyL', sui.joy); set('joyR', sui.joy);
  set('jumpB', sui.jump); set('fps', sui.fps);
}

/* ---------- сцена ---------- */
function applyScene(s) {
  const ents = s && Array.isArray(s.entities) && s.entities.length ? s.entities : [{
    name: 'plate',
    props: [0, -0.5, 0, 0, 0, 0, 40, 1, 40, 0.22, 0.24, 0.27, 0, 1, 0, 0, 0, 0, 0, 0, 1],
  }];
  const newIds = ents.map((e) => engine.add_entity(e.name, new Float32Array(e.props && e.props.length ? e.props : 21)));
  ents.forEach((e, i) => {
    if (Number.isInteger(e.parent) && e.parent >= 0 && e.parent < newIds.length && e.parent !== i) {
      engine.set_parent(newIds[i], newIds[e.parent]);
    }
    if (e.edit && e.edit.cells) {
      engine.set_edit(newIds[i], e.edit.sub | 0, e.edit.round || 0, e.edit.cells);
      if (e.edit.colors) engine.set_edit_colors(newIds[i], e.edit.colors);
    }
  });
  const g = s && Array.isArray(s.gfx) ? s.gfx : [];
  const defs = Array.from(gfx_defaults_safe());
  defs.forEach((d, i) => engine.set_gfx(i, Number.isFinite(g[i]) ? g[i] : d));
  engine.set_pm_root(s && Number.isInteger(s.pmRoot) && s.pmRoot >= 0 && s.pmRoot < newIds.length ? newIds[s.pmRoot] : -1);
  engine.reset_camera();
  return {
    script: s && typeof s.script === 'string' ? s.script : '',
    objScripts: (s && s.objScripts && typeof s.objScripts === 'object') ? s.objScripts : {},
    srvScripts: (s && s.srvScripts && typeof s.srvScripts === 'object') ? s.srvScripts : {},
  };
}
let gfxDefaults = null;
function gfx_defaults_safe() {
  return gfxDefaults || [];
}

/* ---------- главный цикл ---------- */
let rt = null;
const objRts = [];
const srvRts = [];
let lastT = 0, raf = 0, frames = 0, fpsAcc = 0, wdCount = 0, rsRetry = 0;

/* ---------- UI игры (@UI) ---------- */
const uiMgr = new UIMgr($('uiRoot'), {
  edit: false,
  onEvent: (d, ev, val) => {
    const handler = ev === 'change' ? d.onChange : d.onClick;
    if (handler) uiFire(handler, [d.name, ev, val]);
  },
});
function uiFire(handler, args) {
  const name = String(handler || '').trim().replace(/^@F\.?/, '');
  if (!name) return;
  for (const r of [rt, ...objRts.map((o) => o.rt), ...srvRts.map((o) => o.rt)]) {
    if (r && typeof r.call === 'function') {
      let v;
      try { v = r.call(name, args); } catch (e) { consolePrint(name + '(): ' + e); return; }
      if (v !== undefined) return v;
    }
  }
}

function resizeCanvas() {
  if (!engine) return;
  const v = $('view');
  const w = v.clientWidth, h = v.clientHeight;
  if (w < 32 || h < 32) {
    if (!rsRetry) rsRetry = setTimeout(() => { rsRetry = 0; resizeCanvas(); }, 300);
    return;
  }
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const W = Math.floor(w * dpr), H = Math.floor(h * dpr);
  const cvv = $('c');
  if (Math.abs(cvv.width - W) <= 2 && Math.abs(cvv.height - H) <= 2) return;
  engine.resize(W, H);
}

function loop(ts) {
  const dt = Math.min((ts - lastT) / 1000, 0.1);
  lastT = ts;
  if (rt) { try { rt.update(dt); } catch (e) { consolePrint('script: ' + e); } }
  for (const o of objRts) { try { o.rt.update(dt); } catch (e) { consolePrint(o.nm + ': ' + e); } }
  for (const o of srvRts) { try { o.rt.update(dt); } catch (e) { consolePrint(o.nm + ': ' + e); } }
  if (++wdCount >= 30) { wdCount = 0; resizeCanvas(); }
  try { engine.frame(dt); } catch (e) { consolePrint('frame: ' + e); }
  frames++; fpsAcc += dt;
  if (fpsAcc >= 0.5) {
    try { $('fps').textContent = 'FPS ' + Math.round(frames / fpsAcc) + (engine.hdr() ? ' · HDR' : ''); } catch (e) { /* ok */ }
    frames = 0; fpsAcc = 0;
  }
  raf = requestAnimationFrame(loop);
}

/* ---------- старт ---------- */
(async () => {
  try {
    await init();
    consolePrint('HolyGGS Player v' + version());
    const r = await fetch('game.mapp', { cache: 'no-store' });
    if (!r.ok) throw new Error('game.mapp не найден');
    const d = await r.json();
    if (!d || !d.scene) throw new Error('game.mapp повреждён');
    engine = new Engine('c');
    try { gfxDefaults = Array.from(gfx_defaults()); } catch (e) { gfxDefaults = []; }
    const scripts = applyScene(d.scene);
    uiMgr.load((d.scene && d.scene.ui) || []);
    const sui = Object.assign({ joy: 1, cam: 1, jump: 1, fps: 1 }, d.scene.sysUI || {});
    applySysUI(sui);

    // рантаймы скриптов (логика игры)
    rt = createRuntime(engine, {
      print: consolePrint,
      setStats: (s, j, z) => engine.set_player_stats(s, j, z),
      ui: uiMgr,
    });
    let er = rt.load(scripts.script);
    if (er) consolePrint('script: ' + er);
    const ids = Array.from(engine.entity_ids());
    for (const [nm, txt] of Object.entries(scripts.objScripts)) {
      if (!txt || !String(txt).trim()) continue;
      const id = ids.find((x) => engine.entity_name(x) === nm);
      if (id === undefined) continue;
      const o = createRuntime(engine, { print: consolePrint, selfId: id, ui: uiMgr });
      er = o.load(txt);
      if (er) consolePrint(nm + ': ' + er);
      objRts.push({ nm, rt: o });
    }
    for (const [nm, txt] of Object.entries(scripts.srvScripts)) {
      if (!txt || !String(txt).trim()) continue;
      const o = createRuntime(engine, { print: consolePrint, ui: uiMgr });
      er = o.load(txt);
      if (er) consolePrint(nm + ': ' + er);
      srvRts.push({ nm, rt: o });
    }
    engine.set_play(true);
    engine.select(-1);
    rt.start();
    for (const o of objRts) { try { o.rt.start(); } catch (e) { consolePrint(o.nm + ': ' + e); } }
    for (const o of srvRts) { try { o.rt.start(); } catch (e) { consolePrint(o.nm + ': ' + e); } }

    // ввод
    makeJoy($('joyL'), (x, y) => { joy.x = x; joy.z = -y; pushMove(); });
    makeJoy($('joyR'), (x, y) => { joy.y = -y; pushMove(); }, true);
    const jEnd = () => { touch.jump = 0; pushMove(); };
    $('jumpB').addEventListener('pointerdown', (e) => { e.preventDefault(); touch.jump = 1; pushMove(); });
    $('jumpB').addEventListener('pointerup', jEnd);
    $('jumpB').addEventListener('pointercancel', jEnd);
    $('jumpB').addEventListener('lostpointercapture', jEnd);
    const keys = new Set();
    const updKeys = () => {
      const k = (c) => (keys.has(c) ? 1 : 0);
      kb.x = k('KeyD') - k('KeyA');
      kb.z = k('KeyW') - k('KeyS');
      kb.y = Math.max(k('Space'), k('KeyE')) - Math.max(k('ShiftLeft'), k('KeyQ'));
      pushMove();
    };
    addEventListener('keydown', (e) => {
      if (e.code === 'Space') e.preventDefault();
      if (!keys.has(e.code)) { keys.add(e.code); updKeys(); }
    });
    addEventListener('keyup', (e) => { keys.delete(e.code); updKeys(); });

    // поворот камеры
    const cv = $('c');
    let lookP = null;
    cv.addEventListener('pointerdown', (e) => {
      if (!sui.cam) return;
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      if (e.target.closest && e.target.closest('.joy,#jumpB')) return;
      lookP = { id: e.pointerId, x: e.clientX, y: e.clientY };
      cv.setPointerCapture(e.pointerId);
    });
    cv.addEventListener('pointermove', (e) => {
      if (!lookP || e.pointerId !== lookP.id) return;
      const dx = e.clientX - lookP.x, dy = e.clientY - lookP.y;
      lookP.x = e.clientX; lookP.y = e.clientY;
      if (sui.cam) engine.look(dx, dy);
    });
    const lookEnd = (e) => { if (lookP && e.pointerId === lookP.id) lookP = null; };
    cv.addEventListener('pointerup', lookEnd);
    cv.addEventListener('pointercancel', lookEnd);

    $('logBtn').onclick = () => $('log').classList.toggle('on');
    new ResizeObserver(resizeCanvas).observe($('view'));
    for (const ev of ['resize', 'fullscreenchange', 'orientationchange']) addEventListener(ev, resizeCanvas);
    resizeCanvas();
    lastT = performance.now();
    raf = requestAnimationFrame(loop);
  } catch (e) {
    showFatal('Не удалось запустить игру: ' + ((e && (e.stack || e.message)) || e));
  }
})();
