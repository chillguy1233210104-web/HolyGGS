/* lang.js — интерпретатор языка HolyGGS (@W @P @L @F @C @E).
   Грамматика: см. Readme.txt. Выполняется с бюджетом шагов (защита от WTD). */
export function createRuntime(engine, hooks = {}) {
  const selfId = hooks.selfId;
  const V = {};       // переменные @L / @P (вложенные)
  const B = {};       // живые привязки: путь -> источник
  const F = {};       // функции
  const E = { start: null, update: null };
  const names = {};   // имя объекта @W -> id
  let created = [];   // id, созданные скриптом (для очистки)
  let budget = 0;
  let err = '';

  /* ---------- токенизатор ---------- */
  function tokenize(src) {
    const T = [];
    let i = 0;
    const n = src.length;
    let line = 1;
    const push = (t, v) => T.push({ t, v, line });
    while (i < n) {
      const c = src[i];
      if (c === '\n') { push('nl'); i++; line++; continue; }
      if (c === ' ' || c === '\t' || c === '\r') { i++; continue; }
      if (c === '#') {
        const m2 = /^#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})(?![0-9a-fA-FwW])/.exec(src.slice(i));
        if (m2 && /[),\s]/.test(src[i + m2[0].length] || ')')) {
          push('color', m2[1]);
          i += m2[0].length;
          continue;
        } while (i < n && src[i] !== '\n') i++; continue; }
      if (c === ';') { push('nl'); i++; continue; }
      if ('(){}[],'.includes(c)) { push(c); i++; continue; }
      if (c === '"') {
        let s = ''; i++;
        while (i < n && src[i] !== '"') { if (src[i] === '\\') i++; s += src[i++]; }
        i++; push('str', s); continue;
      }
      if ('=<>!:+-*/%&|'.includes(c)) {
        let op = c; i++;
        if (c === '&' && src[i] === '&') op = '&&', i++;
        else if (c === '|' && src[i] === '|') op = '||', i++;
        else if (i < n && '=<>'.includes(src[i]) && (c === '=' || c === '!' || c === '<' || c === '>')) op += src[i++];
        else if (c === '*' && src[i] === '*') op = '**', i++;
        else if (c === '%' && src[i] === '=') op = '%=', i++;
        else if (c === '+' && src[i] === '=') op = '+=', i++;
        else if (c === '-' && src[i] === '=') op = '-=', i++;
        else if (c === '*' && src[i] === '=') op = '*=', i++;
        else if (c === '/' && src[i] === '=') op = '/=', i++;
        push('op', op); continue;
      }
      if (c === '.') {
        if (src[i + 1] === '.') { push('op', '..'); i += 2; continue; }
        if (/[0-9]/.test(src[i + 1] || '')) { /* число */ }
        else { push('dot'); i++; continue; }
      }
      if (c === '0' && (src[i + 1] === 'x' || src[i + 1] === 'X') && /[0-9a-fA-F]/.test(src[i + 2] || '')) {
        i += 2;
        let hs = '';
        while (i < n && /[0-9a-fA-F]/.test(src[i])) hs += src[i++];
        push('num', parseInt(hs, 16));
        continue;
      }
      if (/[0-9.]/.test(c)) {
        let s = '';
        while (i < n && /[0-9.eE+-]/.test(src[i])) {
          if ((src[i] === '+' || src[i] === '-') && !/[eE]/.test(s[s.length - 1] || '')) break;
          s += src[i++];
        }
        // 50% — проценты (UI); остаток от деления — только с пробелами/буквой после %
        if (src[i] === '%' && /[0-9.]/.test(s) && !/[0-9A-Za-z_(]/.test(src[i + 1] || '')) {
          i++; push('pct', parseFloat(s));
        } else push('num', parseFloat(s));
        continue;
      }
      if (/[A-Za-zА-Яа-яЁё_@]/.test(c)) {
        let s = '';
        while (i < n && /[A-Za-zА-Яа-яЁё0-9_.@]/.test(src[i])) s += src[i++];
        if (s.startsWith('@')) push('at', s);
        else if (s === 'if' || s === 'else' || s === 'WTD' || s === 'break' || s === 'end' || s === 'return' || s === 'continue') push('kw', s);
        else push('id', s);
        continue;
      }
      i++;
    }
    return T;
  }

  /* ---------- парсер ---------- */
  function parse(src) {
    const T = tokenize(src);
    let p = 0;
    const peek = (o = 0) => T[p + o];
    const eat = () => T[p++];
    const pt = (o = 0) => (T[p + o] ? T[p + o].t : 'eof');
    const pv = (o = 0) => (T[p + o] ? T[p + o].v : undefined);
    const isOp = (v) => pt() === 'op' && pv() === v;
    const skipNl = () => { while (peek() && pt() === 'nl') p++; };

    function parseExpr() { return parseOr(); }
    function parseOr() {
      let a = parseAnd();
      while (pt() === 'op' && pv() === '||') { eat(); a = { k: 'bin', op: '||', a, b: parseAnd() }; }
      return a;
    }
    function parseAnd() {
      let a = parseCmp();
      while (pt() === 'op' && pv() === '&&') { eat(); a = { k: 'bin', op: '&&', a, b: parseCmp() }; }
      return a;
    }
    function parseGlue() {
      let a = parseAdd();
      while (pt() === 'op' && pv() === '..') {
        eat(); a = { k: 'bin', op: '..', a, b: parseAdd() };
      }
      return a;
    }
    function parseCmp() {
      let a = parseGlue();
      while (pt() === 'op' && ['>', '<', '>=', '<=', '==', '!='].includes(pv())) {
        const op = eat().v; a = { k: 'bin', op, a, b: parseGlue() };
      }
      return a;
    }
    function parseAdd() {
      let a = parseMul();
      while (pt() === 'op' && (pv() === '+' || pv() === '-')) {
        const op = eat().v; a = { k: 'bin', op, a, b: parseMul() };
      }
      return a;
    }
    function parseMul() {
      let a = parseUn();
      while (pt() === 'op' && (pv() === '*' || pv() === '/' || pv() === '%')) {
        const op = eat().v; a = { k: 'bin', op, a, b: parseUn() };
      }
      return a;
    }
    function parseUn() {
      if (isOp('-')) { eat(); return { k: 'neg', a: parseUn() }; }
      return parsePow();
    }
    let inIndex = 0;
    let fdefDepth = 0, evDepth = 0;
    function scanForEnd(name) {
      const target = '@' + name;
      for (let j = p; j < T.length; j++) {
        // @F.End() — совместимый закрывающий тег из спеки
        if (T[j].t === 'at' && /^@f\.end$/i.test(T[j].v) && T[j + 1] && T[j + 1].t === '(') return true;
        if (T[j].t === 'at' && T[j].v === target) {
          let k = j + 1, paren = 0;
          if (T[k] && T[k].t === '(') {
            paren = 1; k++;
            while (k < T.length && paren > 0) {
              if (T[k].t === '(') paren++;
              if (T[k].t === ')') paren--;
              k++;
            }
          }
          if (T[k] && T[k].t === 'dot' && T[k + 1] && T[k + 1].t === 'kw' && T[k + 1].v === 'end') return true;
        }
      }
      return false;
    }
    function parseIndexInner() {
      inIndex++;
      try { return parseExpr(); } finally { inIndex--; }
    }
    function segsNode(base, segs) {
      if (!segs || !segs.length) return { k: 'ref', path: base };
      return { k: 'refn', base, segs };
    }
    function parseSegTails(segs) {
      for (;;) {
        if (!peek() || pt() === 'nl') break;
        if (p > 0 && T[p - 1] && T[p - 1].t === 'nl') break;
        if (pt() === '[') {
          eat();
          segs.push({ e: parseIndexInner() });
          if (pt() === ']') eat();
          continue;
        }
        if (pt() === 'dot') {
          eat();
          if (pt() === '[') {
            eat();
            segs.push({ e: parseIndexInner() });
            if (pt() === ']') eat();
            continue;
          }
          if (pt() === 'id') {
            const id = eat().v;
            for (const q of id.split('.')) if (q !== '') segs.push({ n: q });
            continue;
          }
          break;
        }
        break;
      }
      return segs;
    }
    function parseBracketRef() {
      if (pt() === 'at' || pt() === 'id') {
        const t0 = eat();
        let base = String(t0.v).replace(/^@/, '');
        const segs = [];
        if (base.endsWith('.')) base = base.slice(0, -1);
        parseSegTails(segs);
        let node = segsNode(base, segs);
        // постфиксы: [L.contains(2)], [D.keys().length], [S.split(",").[0]]
        for (;;) {
          if (!peek() || pt() === 'nl' || pt() === ']') break;
          if (pt() === '(') {
            const args = parseArgs();
            if (node.k === 'ref' || node.k === 'refn') node = { k: 'call', path: base, tail: segs.slice(), args };
            else node = { k: 'callm', obj: node, name: '__call', args };
            continue;
          }
          if (pt() === 'dot') {
            eat();
            if (pt() === '[') {
              eat();
              const e = parseIndexInner();
              if (pt() === ']') eat();
              node = { k: 'idx', obj: node, e };
              continue;
            }
            if (pt() === 'id') {
              const id = eat().v;
              if (pt() === '(') {
                const args = parseArgs();
                node = { k: 'callm', obj: node, name: id, args };
              } else node = { k: 'prop', obj: node, name: id };
              continue;
            }
            break;
          }
          break;
        }
        if (pt() === ']') eat();
        return node;
      }
      const e0 = parseIndexInner();
      if (pt() === ']') eat();
      return e0;
    }
    function parsePostfix() {
      let node = parseAtom();
      for (;;) {
        if (!peek() || pt() === 'nl') break;
        if (p > 0 && T[p - 1] && T[p - 1].t === 'nl') break;
        if (pt() === 'dot') {
          if (pt(1) === '[') {
            eat(); eat();
            const e = parseIndexInner();
            if (pt() === ']') eat();
            node = { k: 'idx', obj: node, e };
            continue;
          }
          if (pt(1) === 'id') {
            eat();
            const id = eat().v;
            if (pt() === '(') {
              const args = parseArgs();
              node = { k: 'callm', obj: node, name: id, args };
              continue;
            }
            node = { k: 'prop', obj: node, name: id };
            continue;
          }
          break;
        }
        break;
      }
      return node;
    }
    function parsePow() {
      let a = parsePostfix();
      if (isOp('**')) { eat(); return { k: 'bin', op: '**', a, b: parseUn() }; }
      return a;
    }
    function parseAtom() {
      const t = peek();
      if (!t) return { k: 'num', v: 0 };
      if (t.t === 'num') { eat(); return { k: 'num', v: t.v }; }
      if (t.t === 'pct') { eat(); return { k: 'str', v: String(t.v) + '%' }; }
      if (t.t === 'str') { eat(); return { k: 'str', v: t.v }; }
      if (t.t === 'color') { eat(); return { k: 'color', v: t.v }; }
      if (t.t === 'none' || (t.t === 'id' && t.v === 'none')) { eat(); return { k: 'none' }; }
      if (t.t === '(') {
        eat();
        const items = [];
        while (peek() && pt() !== ')' && pt() !== 'nl') {
          items.push(parseExpr());
          if (pt() === ',') eat();
          else break;
        }
        if (pt() === ')') eat();
        return items.length === 1 ? items[0] : { k: 'tuple', items };
      }
      if (t.t === '[') {
        eat();
        let depth = 0, isList = pt() === ']';
        for (let j = p; T[j] && !isList; j++) {
          const q = T[j];
          if (q.t === '(' || q.t === '[' || q.t === '{') depth++;
          else if (q.t === ')' || q.t === ']' || q.t === '}') { if (depth === 0) break; depth--; }
          else if (q.t === ',' && depth === 0) isList = true;
        }
        if (isList) {
          const items = [];
          while (peek() && pt() !== ']' && pt() !== 'nl') {
            if (pt() === ',') { eat(); continue; }
            items.push(parseExpr());
            if (pt() === ',') eat();
            else break;
          }
          if (pt() === ']') eat();
          return { k: 'list', items };
        }
        return parseBracketRef();
      }
      if (t.t === '{') {
        eat();
        const pairs = [];
        while (peek() && pt() !== '}' && pt() !== 'nl') {
          if (pt() === ',') { eat(); continue; }
          let kk = null;
          if (pt() === 'id') kk = String(eat().v);
          else if (pt() === 'str') kk = String(eat().v);
          else if (pt() === 'num') kk = String(eat().v);
          else break;
          if (pt() === 'op' && pv() === ':') eat(); else break;
          pairs.push({ key: kk, e: parseExpr() });
          if (pt() === ',') eat();
          else break;
        }
        if (pt() === '}') eat();
        return { k: 'dict', pairs };
      }
      if (t.t === 'at') {
        eat();
        let path = t.v.replace(/^@/, '');
        const tail = [];
        if (path.endsWith('.')) { path = path.slice(0, -1); parseSegTails(tail); }
        else if (pt() === '[' || pt() === 'dot') parseSegTails(tail);
        if (pt() === '(') {
          const args = parseArgs();
          return { k: 'call', path, tail, args };
        }
        return segsNode(path, tail);
      }
      if (t.t === 'id') {
        eat();
        if (pt() === '(') {
          const args = parseArgs();
          return { k: 'call', path: t.v, tail: [], args };
        }
        if (inIndex) {
          const segs = [];
          let base = t.v;
          if (base.endsWith('.')) { base = base.slice(0, -1); parseSegTails(segs); }
          else if (pt() === '[' || pt() === 'dot') parseSegTails(segs);
          return segsNode(base, segs);
        }
        return { k: 'str', v: t.v };
      }
      eat();
      return { k: 'num', v: 0 };
    }
    function parseArgs() {
      eat(); // (
      const args = [];
      while (peek() && pt() !== ')') {
        let key = null;
        if ((pt() === 'id' || pt() === 'at') && pt(1) === 'op' && pv(1) === ':') {
          key = eat().v; eat();
        }
        args.push({ key, e: parseExpr() });
        if (pt() === ',') eat();
      }
      eat(); // )
      return args;
    }

    function parseObj() {
      eat(); // {
      const props = [];
      while (peek() && pt() !== '}') {
        skipNl();
        if (pt() === '}') break;
        const name = eat().v;
        if (pt() === 'op' && pv() === ':') {
          throw { message: 'словарь {ключ: значение} нельзя присвоить объекту @W — используйте @L' };
        }
        const args = pt() === '(' ? parseArgs() : [];
        props.push({ name, args });
        if (pt() === ',') eat();
        skipNl();
      }
      eat(); // }
      return props;
    }

    function parseBlockStmts(stopKw) {
      const out = [];
      skipNl();
      while (peek()) {
        if (pt() === 'kw' && stopKw.includes(pv())) break;
        if (pt() === '}' || pt() === ']') break;
        const s = parseStmt();
        if (s) out.push(s);
        skipNl();
      }
      return out;
    }

    function parseBraceBlock() {
      // { ... } — блок операторов (условие/код)
      eat(); // {
      const body = parseBlockStmts([]);
      if (pt() === '}') eat();
      return body;
    }

    function parseIfInner(bracket) {
      // if COND { ... } else { ... }  |  if { COND; ... } else { ... }
      // bracket=true: форма [ if COND ] ... ] — тело до сопоставленной ]
      if (!(pt() === 'kw' && pv() === 'if')) return null;
      eat();
      let cond, body;
      if (pt() === '{') {
        const inner = parseBraceBlock();
        if (inner.length && inner[0].k === 'exprstmt') {
          cond = inner[0].e; body = inner.slice(1);
        } else if (inner.length && inner[0].k === 'cond') {
          cond = inner[0].e; body = inner.slice(1);
        } else {
          cond = { k: 'num', v: 1 }; body = inner;
        }
      } else {
        cond = parseExpr();
        skipNl();
        // форма [ if cond ] тело ] — первая ] закрывает заголовок, тело идёт до следующей ]
        if (bracket && pt() === ']') eat();
        body = pt() === '{' ? parseBraceBlock() : (bracket ? parseBlockStmts([]) : []);
      }
      let els = [];
      skipNl();
      if (pt() === 'kw' && pv() === 'else') {
        eat(); skipNl();
        if (pt() === 'kw' && pv() === 'if') {
          els = [{ k: 'if', cond: null, body: null, nested: parseIfInner() }];
        } else {
          els = pt() === '{' ? parseBraceBlock() : [];
        }
      }
      return { k: 'if', cond, body, els };
    }

    function parseStmt() {
      skipNl();
      const t = peek();
      if (!t) return null;
      if (t.t === '[') {
        let o = 1;
        while (peek(o) && pt(o) === 'nl') o++;
        const inner = peek(o);
        if (!(inner && inner.t === 'kw' && (inner.v === 'if' || inner.v === 'WTD'))) {
          return { k: 'exprstmt', e: parseExpr() };
        }
        eat();
        skipNl();
        let s = null;
        if (pt() === 'kw' && pv() === 'if') s = parseIfInner(true);
        else if (pt() === 'kw' && pv() === 'WTD') {
          const body = pt(1) === '{' ? (eat(), parseBraceBlock()) : [];
          s = { k: 'wtd', body };
        } else s = { k: 'block', body: parseBlockStmts([]) };
        skipNl();
        if (pt() === ']') eat();
        return s;
      }
      if (t.t === 'kw' && t.v === 'if') return parseIfInner();
      if (t.t === 'kw' && t.v === 'WTD') {
        eat();
        const body = pt() === '{' ? parseBraceBlock() : [];
        return { k: 'wtd', body };
      }
      if (t.t === 'kw' && t.v === 'break') {
        eat();
        let target = '';
        if (pt() === 'id' || pt() === 'kw') target = eat().v;
        return { k: 'break', target };
      }
      if (t.t === 'kw' && t.v === 'continue') {
        eat();
        let target = '';
        if (pt() === 'id' || pt() === 'kw') target = eat().v;
        return { k: 'continue', target };
      }
      if (t.t === 'kw' && t.v === 'return') {
        eat();
        if (!peek() || pt() === 'nl' || pt() === ']' || pt() === '}') return { k: 'return', e: null };
        return { k: 'return', e: parseExpr() };
      }
      if (t.t === 'at') {
        eat();
        let path = t.v.replace(/^@/, '');
        const tail = [];
        if (path.endsWith('.')) { path = path.slice(0, -1); parseSegTails(tail); }
        else if (pt() === '[' || pt() === 'dot') parseSegTails(tail);
        if (pt() === 'op' && pv() === '=') {
          eat();
          if (path.startsWith('W.') && !tail.length && pt() === '{') {
            const props = parseObj();
            let attach = null;
            if (pt() === 'op' && pv() === '..') {
              eat();
              attach = parseExpr();
            }
            return { k: 'wset', path, props, attach };
          }
          if (path.startsWith('UI.') && !tail.length && pt() === '{') {
            return { k: 'uiset', path, props: parseObj() };
          }
          if (path === 'LIB' && !tail.length && pt() === '{') {
            return { k: 'libmeta', props: parseObj() };
          }
          return { k: 'assign', path, tail, e: parseExpr() };
        }
        if (pt() === 'op' && ['+=', '-=', '*=', '/='].includes(pv())) {
          const op = eat().v;
          return { k: 'assign', path, tail, op, e: parseExpr() };
        }
        if (pt() === 'op' && pv() === ':') {
          eat();
          return { k: 'bind', path, tail, e: parseExpr() };
        }
        if (pt() === 'op' && pv() === '..') {
          eat();
          return { k: 'attach', path, tail, e: parseExpr() };
        }
        if (pt() === '(') {
          const args = parseArgs();
          if (pt() === 'dot' && pt(1) === 'kw' && pv(1) === 'end') {
            eat(); eat(); // .end
            fdefDepth = Math.max(0, fdefDepth - 1);
            return { k: 'end', path };
          }
          if (pt() === 'op' && pv() === '=' && path.startsWith('F.')) {
            eat();
            fdefDepth++;
            return {
              k: 'fdef_head', path, e: parseExpr(), oneLine: true,
              argNames: args.map((a) => (a.e && a.e.k === 'str' ? a.e.v : (a.key || ''))).filter(Boolean),
            };
          }
          if (path.startsWith('F.') && !/^F\.End$/i.test(path) && !fdefDepth && !evDepth && pt() === 'nl' && scanForEnd(path)) {
            fdefDepth++;
            return {
              k: 'fdef_head', path, e: { k: 'num', v: 0 },
              argNames: args.map((a) => (a.e && a.e.k === 'str' ? a.e.v : (a.key || ''))).filter(Boolean),
            };
          }
          if (/^(E\.|S\.)?(OnStart|OnUpdate|OnClick|OnKey|OnDraw|OnKeyDown)$/.test(path)) evDepth++;
          else if (/^([ES]\.)?End$/i.test(path)) evDepth = Math.max(0, evDepth - 1);
          return { k: 'call', path, tail, args };
        }
        return { k: 'refstmt', path, tail };
      }
      if (t.t === 'id') {
        eat();
        if (pt() === '(') {
          const args = parseArgs();
          return { k: 'call', path: t.v, args };
        }
        return { k: 'exprstmt', e: { k: 'str', v: t.v } };
      }
      if (t.t === 'num' || t.t === 'str' || t.t === '[') {
        return { k: 'exprstmt', e: parseExpr() };
      }
      eat();
      return null;
    }

    const stmts = parseBlockStmts([]);
    return stmts;
  }

  /* ---------- сборка событий/функций из плоского списка ---------- */
  function assemble(stmts) {
    const out = [];
    let i = 0;
    while (i < stmts.length) {
      const s = stmts[i];
      if (s.k === 'fdef_head' && s.path.startsWith('F.')) {
        const name = s.path.slice(2);
        if (s.oneLine) {
          // @F.name(args) = expr — тело это выражение, .end не нужен
          F[name.toLowerCase()] = {
            argNames: s.argNames || [],
            body: [{ k: 'return', e: s.e }],
            head: s,
          };
          i++;
          continue;
        }
        // ищем .end с тем же именем
        const body = [];
        i++;
        let depth = 1;
        while (i < stmts.length) {
          const t = stmts[i];
          if (t.k === 'end' && t.path.slice(2) === name) { i++; break; }
          if (t.k === 'call' && /^(f\.)?end$/i.test(String(t.path || ''))) { i++; break; }
          if (t.k === 'fdef_head' && t.path.slice(2) === name) depth++;
          body.push(t);
          i++;
        }
        F[name.toLowerCase()] = {
          argNames: s.argNames || [],
          body: [{ k: 'exprstmt', e: s.e }].concat(body),
          head: s,
        };
        continue;
      }
      if (s.k === 'end') { i++; continue; }
      out.push(s);
      i++;
    }
    return out;
  }

  function assembleEvents(stmts) {
    const out = [];
    let i = 0;
    while (i < stmts.length) {
      const s = stmts[i];
      if (s.k === 'call' && /^(E\.|S\.)?(OnStart|OnUpdate|OnClick|OnKey|OnDraw|OnKeyDown)$/.test(s.path)) {
        const keyMap = { OnStart: 'start', OnUpdate: 'update', OnClick: 'click', OnKey: 'key', OnKeyDown: 'key', OnDraw: 'draw' };
        const name = keyMap[s.path.split('.').pop()] || 'start';
        const args = s.args.map((a) => (a.e && (a.e.path || a.e.v)) || '');
        const body = [];
        i++;
        while (i < stmts.length) {
          const t2 = stmts[i];
          const isEnd = (t2.k === 'end' && /On(Start|Update)/.test(t2.path))
            || (t2.k === 'call' && /^([ES]\.)?End$/i.test(t2.path));
          if (isEnd) break;
          body.push(t2); i++;
        }
        i++; // .end
        E[name] = { args, body };
        continue;
      }
      out.push(s);
      i++;
    }
    return out;
  }

  /* ---------- выполнение ---------- */
  const strip = (path) => path.replace(/^(L|P|W)\.(?=[A-ZА-ЯЁё_])/, '').replace(/^@/, '');
  function lookup1(o, k) {
    if (o === null || o === undefined) return undefined;
    if (isEntRef(o)) return entLookup(o, k);
    if (Array.isArray(o)) {
      if (k === 'length') return o.length;
      const AX = { x: 0, y: 1, z: 2, w: 3 };
      let idx = AX[k] !== undefined ? AX[k] : (/^-?\d+$/.test(String(k)) ? +k : NaN);
      if (Number.isNaN(idx)) return undefined;
      if (idx < 0) idx += o.length;
      return idx >= 0 && idx < o.length ? o[idx] : undefined;
    }
    if (typeof o === 'string') return k === 'length' ? o.length : undefined;
    if (typeof o !== 'object') return undefined;
    if (k in o) return o[k];
    return k === 'length' ? Object.keys(o).length : undefined;
  }
  function lookup(obj, path) {
    let o = obj;
    for (const k of path.split('.')) {
      o = lookup1(o, k);
      if (o === undefined) return undefined;
    }
    return o;
  }
  function getPath(path) {
    if (path in B) return getPath(B[path]);
    const sp0 = strip(path);
    if (sp0 === 'UI' || sp0.startsWith('UI.')) {
      if (!hooks.ui) return undefined;
      const up = sp0.split('.');
      const unm = up[1] || '';
      if (up.length === 2) return hooks.ui.find(unm) ? { __ui: unm } : undefined;
      return hooks.ui.get(unm, up.slice(2).join('.'));
    }
    const parts = sp0.split('.');
    // [W] — корень мира: [W].allObjects() и т.п.
    if (parts.length === 1 && parts[0] === 'W') return { __world: 1 };
    // живая ссылка с хвостом компонент: [Pos.x] при @L.Pos : @P.pos
    if (parts.length > 1 && parts[0] in B) {
      return getPath(B[parts[0]] + '.' + parts.slice(1).join('.'));
    }
    const tail = (v, i) => (i >= parts.length ? v : lookup(v, parts.slice(i).join('.')));
    // Self.<pos|size|dist|name> — сам объект (скрипты объектов)
    if (parts[0] === 'Self' && selfId !== undefined && selfId !== null) {
      const b = parts[1] || 'pos';
      if (b === 'name') return tail(engine.entity_name(selfId), 2);
      const props = engine.get_props(selfId);
      if (b === 'pos') return tail([props[0], props[1], props[2]], 2);
      if (b === 'size') return tail([props[6], props[7], props[8]], 2);
      if (b === 'dist') {
        const p = engine.player_pos();
        return tail(Math.hypot(props[0] - p[0], props[1] - p[1], props[2] - p[2]), 2);
      }
    }
    // pos / P.pos / Player.pos (+компоненты .x/.y/.z)
    const isPl = parts[0] === 'P' || parts[0] === 'Player';
    if ((isPl && parts[1] === 'pos') || (parts.length === 1 && parts[0] === 'pos')) {
      const p = engine.player_pos();
      return tail([p[0], p[1], p[2]], isPl ? 2 : 1);
    }
    const direct = lookup(V, sp0);
    if (direct !== undefined) return direct;
    const directRaw = lookup(V, path);
    if (directRaw !== undefined) return directRaw;
    if (parts.length === 1 && names[parts[0]] !== undefined && engine.entity_ids().includes(names[parts[0]])) {
      return entRef(names[parts[0]], parts[0]);
    }
    if (parts.length >= 2 && names[parts[0]] !== undefined && engine.entity_ids().includes(names[parts[0]])) {
      return tail(lookup1(entRef(names[parts[0]], parts[0]), parts[1]), 2);
    }
    const sp = strip(path);
    if (sp !== path) {
      const v = lookup(V, sp);
      if (v !== undefined) return v;
    }
    const fl = lookup(V.L, path);
    return fl !== undefined ? fl : lookup(V.P, path);
  }
  function setPath(path, val) {
    const sp = strip(path);
    delete B[path]; delete B[sp];
    if (sp.startsWith('UI.')) {
      const up = sp.split('.');
      if (hooks.ui) hooks.ui.set(up[1] || '', up.slice(2).join('.'), val);
      return;
    }
    const parts = sp.split('.');
    // запись в свойства объекта: Name.pos[.x], Name.size[.y], Name.rot[.z] — двигает/масштабирует объект
    if (parts.length >= 2 && names[parts[0]] !== undefined && ['pos', 'size', 'rot'].includes(parts[1])) {
      const id = names[parts[0]];
      const props = Array.from(engine.get_props(id));
      const off = parts[1] === 'pos' ? 0 : parts[1] === 'size' ? 6 : 3;
      if (parts.length >= 3) {
        const comp = ({ x: 0, y: 1, z: 2 })[parts[2]];
        if (comp !== undefined) props[off + comp] = num(val, props[off + comp]);
      } else if (Array.isArray(val)) {
        props[off] = num(val[0], props[off]);
        props[off + 1] = num(val[1], props[off + 1]);
        props[off + 2] = num(val[2], props[off + 2]);
      }
      engine.set_props(id, new Float32Array(props));
      return;
    }
    if (parts.length >= 2 && names[parts[0]] !== undefined && V[parts[0]] === undefined
        && !['pos', 'size', 'rot'].includes(parts[1]) && engine.entity_ids().includes(names[parts[0]])) {
      setEntPropPath(entRef(names[parts[0]], parts[0]), parts.slice(1), val);
      return;
    }
    let o = V;
    for (let i = 0; i < parts.length - 1; i++) {
      if (typeof o[parts[i]] !== 'object' || o[parts[i]] === null) o[parts[i]] = {};
      o = o[parts[i]];
    }
    o[parts[parts.length - 1]] = val;
    if (['Speed', 'Jump', 'Size', 'P.Speed', 'P.Jump', 'P.Size'].includes(sp)) applyStats();
  }
  function applyStats() {
    if (hooks.setStats) {
      const g = (k, d) => {
        const v = getPath(k);
        return typeof v === 'number' && isFinite(v) ? v : d;
      };
      hooks.setStats(g('Speed', 8), g('Jump', 2.6), g('Size', 1));
    }
  }
  function num(v, d) { return typeof v === 'number' && isFinite(v) ? v : d; }
  function truthy(v) {
    if (v === null || v === undefined) return 0;
    if (typeof v === 'number') return v !== 0 ? 1 : 0;
    if (typeof v === 'string') return v !== '' && v !== '0' && !/^false$/i.test(v) ? 1 : 0;
    return 1;
  }
  const entAttrs = {};

  /* ---------- v0.3: списки/словари/ссылки/шум ---------- */
  class RetSig { constructor(v) { this.v = v; } }
  function entRef(id, nm) { return { __ent: id, __name: nm }; }
  function isEntRef(v) { return !!v && typeof v === 'object' && !Array.isArray(v) && v.__ent !== undefined; }
  function entLookup(ref, k) {
    const id = ref.__ent;
    if (id === undefined || !engine.entity_ids().includes(id)) return undefined;
    const props = engine.get_props(id);
    const key = String(k);
    if (key === 'name') return ref.__name !== undefined ? ref.__name : engine.entity_name(id);
    const off = { pos: 0, rot: 3, size: 6, color: 9 }[key];
    if (off !== undefined) return [props[off], props[off + 1], props[off + 2]];
    if (key === 'alpha') return props[13];
    if (key === 'dist') {
      const p = engine.player_pos();
      return Math.hypot(props[0] - p[0], props[1] - p[1], props[2] - p[2]);
    }
    if (key === 'visible') return (props[20] === undefined || props[20] > 0.5) ? 1 : 0;
    if (/^\d+$/.test(key)) return props[+key];
    const at = entAttrs[id];
    if (at && key in at) return at[key];
    if (key in ref && key !== '__ent' && key !== '__name') return ref[key];
    return undefined;
  }
  function valEq(a, b) {
    if (a === b) return true;
    if (isEntRef(a) && isEntRef(b)) return a.__ent === b.__ent;
    if (Array.isArray(a) && Array.isArray(b)) return a.length === b.length && a.every((x, i) => valEq(x, b[i]));
    if ((a === undefined || a === null) && (b === undefined || b === null)) return true;
    if (a === undefined || a === null || b === undefined || b === null) return false;
    return String(a) === String(b);
  }
  function removeValue(arr, v) {
    for (let i = 0; i < arr.length; i++) if (valEq(arr[i], v)) { arr.splice(i, 1); return 1; }
    return 0;
  }
  function setEntPropPath(ref, keys, val) {
    const id = ref.__ent;
    if (id === undefined || !engine.entity_ids().includes(id)) return;
    const props = Array.from(engine.get_props(id));
    const k = String(keys[0]);
    const off = { pos: 0, rot: 3, size: 6, color: 9 }[k];
    if (off !== undefined) {
      if (keys.length >= 2) {
        const comp = ({ x: 0, y: 1, z: 2 })[String(keys[1])];
        if (comp !== undefined) props[off + comp] = num(val, props[off + comp]);
      } else if (Array.isArray(val)) {
        for (let i = 0; i < 3; i++) props[off + i] = num(val[i], props[off + i]);
      } else {
        props[off] = num(val, props[off]);
        props[off + 1] = num(val, props[off + 1]);
        props[off + 2] = num(val, props[off + 2]);
      }
    } else if (k === 'alpha') props[13] = num(val, props[13]);
    else if (k === 'visible') props[20] = (val === 0 || val === false || /^false|no|off|0$/i.test(String(val))) ? 0 : 1;
    else if (/^\d+$/.test(k)) props[+k] = num(val, props[+k]);
    else {
      (entAttrs[id] = entAttrs[id] || {})[k] = val;
      ref[k] = val;
      return;
    }
    engine.set_props(id, new Float32Array(props));
  }
  function resolveBaseVal(path) {
    const p = String(path || '').replace(/^@/, '');
    if (p.startsWith('W.')) {
      const nm = strip(p.slice(2));
      if (names[nm] !== undefined && engine.entity_ids().includes(names[nm])) return entRef(names[nm], nm);
    }
    return getPath(p);
  }
  function keyOfSeg(s, env) {
    return s.n !== undefined ? s.n : undefined;
  }
  function* getTailVal(path, tail, env) {
    let v = resolveBaseVal(path);
    for (const s of tail) {
      if (v === undefined || v === null) return undefined;
      v = s.n !== undefined ? lookup1(v, s.n) : lookup1(v, yield* evalE(s.e, env));
    }
    return v;
  }
  function* setTailVal(path, tail, val, env) {
    if (!tail.length) { setPath(path, val); return; }
    let o = resolveBaseVal(path);
    if (o === undefined || o === null) {
      setPath(path, {});
      o = resolveBaseVal(path);
    }
    for (let i = 0; i < tail.length - 1; i++) {
      if (isEntRef(o)) {
        const keys = [];
        for (let j = i; j < tail.length; j++) {
          keys.push(tail[j].n !== undefined ? tail[j].n : yield* evalE(tail[j].e, env));
        }
        setEntPropPath(o, keys, val);
        return;
      }
      o = tail[i].n !== undefined ? lookup1(o, tail[i].n) : lookup1(o, yield* evalE(tail[i].e, env));
      if (o === undefined || o === null) return;
    }
    const last = tail[tail.length - 1];
    const key = last.n !== undefined ? last.n : yield* evalE(last.e, env);
    if (isEntRef(o)) { setEntPropPath(o, [key], val); return; }
    if (Array.isArray(o) && /^-?\d+$/.test(String(key))) {
      let i = +key;
      if (i < 0) i += o.length;
      if (i >= 0 && i < o.length) o[i] = val;
      return;
    }
    if (o && typeof o === 'object') {
      if (isEntRef(o)) return;
      o[key] = val;
    }
  }
  function* methodCall(obj, name, args, env) {
    const m = String(name || '').toLowerCase();
    if (obj && typeof obj === 'object' && obj.__world) {
      // методы корня мира: [W].allObjects()
      if (m === 'allobjects' || m === 'objects' || m === 'children' || m === 'descendants') {
        return engine.entity_ids().map((cid) => entRef(cid, engine.entity_name(cid)));
      }
      return undefined;
    }
    if (isEntRef(obj)) return yield* entMethod(obj.__ent, obj.__name, m, args, env);
    if (Array.isArray(obj)) {
      if (m === 'add' || m === 'push') {
        const v = yield* argVal(args, 'x', 0, env, null);
        obj.push(v);
        return obj.length;
      }
      if (m === 'remove') {
        const a = yield* argVal(args, 'x', 0, env, null);
        if (typeof a === 'number' && isFinite(a)) {
          let i = a < 0 ? obj.length + a : a;
          if (i >= 0 && i < obj.length) { obj.splice(i, 1); return 1; }
          return 0;
        }
        return removeValue(obj, a);
      }
      if (m === 'remove_at') {
        const a = num(yield* argVal(args, 'i', 0, env, 0), 0);
        let i = a < 0 ? obj.length + a : a;
        if (i >= 0 && i < obj.length) { obj.splice(i, 1); return 1; }
        return 0;
      }
      if (m === 'remove_value') return removeValue(obj, yield* argVal(args, 'v', 0, env, null));
      if (m === 'clear') { obj.length = 0; return 1; }
      if (m === 'contains') {
        const a = yield* argVal(args, 'x', 0, env, null);
        return obj.some((q) => valEq(q, a)) ? 1 : 0;
      }
      if (m === 'index_of') {
        const a = yield* argVal(args, 'x', 0, env, null);
        for (let i = 0; i < obj.length; i++) if (valEq(obj[i], a)) return i;
        return -1;
      }
      return undefined;
    }
    if (typeof obj === 'string') {
      if (m === 'split') {
        const sep = String((yield* argVal(args, 'sep', 0, env, '')) ?? '');
        return sep === '' ? obj.split('') : obj.split(sep);
      }
      if (m === 'contains') return obj.includes(String((yield* argVal(args, 'x', 0, env, '')) ?? '')) ? 1 : 0;
      if (m === 'index_of') return obj.indexOf(String((yield* argVal(args, 'x', 0, env, '')) ?? ''));
      if (m === 'upper') return obj.toUpperCase();
      if (m === 'lower') return obj.toLowerCase();
      if (m === 'trim') return obj.trim();
      if (m === 'replace') {
        const a2 = String((yield* argVal(args, 'a', 0, env, '')) ?? '');
        const b2 = String((yield* argVal(args, 'b', 1, env, '')) ?? '');
        return obj.split(a2).join(b2);
      }
      return undefined;
    }
    if (obj && typeof obj === 'object') {
      const rawKey = yield* argVal(args, 'key', 0, env, undefined);
      const key = String(rawKey === undefined ? (yield* argVal(args, 'x', 0, env, '')) ?? '' : rawKey);
      if (m === 'remove' || m === 'remove_key') {
        const had = Object.prototype.hasOwnProperty.call(obj, key);
        delete obj[key];
        return had ? 1 : 0;
      }
      if (m === 'clear') { for (const k of Object.keys(obj)) delete obj[k]; return 1; }
      if (m === 'keys') return Object.keys(obj);
      if (m === 'values') return Object.keys(obj).map((k) => obj[k]);
      if (m === 'has_key') return Object.prototype.hasOwnProperty.call(obj, key) ? 1 : 0;
      return undefined;
    }
    return undefined;
  }
  function* evalCallNode(node, env) {
    if (node.k === 'callm') {
      const obj = yield* evalE(node.obj, env);
      return yield* methodCall(obj, node.name, node.args, env);
    }
    if (node.tail && node.tail.length) {
      // сначала локальные переменные/аргументы функций ([obj].tween внутри @F)
      let obj;
      if (env && node.path in env) obj = env[node.path];
      else if (env && node.path.indexOf('.') > 0) {
        const dot = node.path.indexOf('.');
        const root = node.path.slice(0, dot);
        if (root in env) obj = lookup(env[root], node.path.slice(dot + 1));
      }
      if (obj === undefined || obj === null) obj = resolveBaseVal(node.path);
      for (let i = 0; i < node.tail.length - 1; i++) {
        const s = node.tail[i];
        if (obj === undefined || obj === null) return 0;
        obj = s.n !== undefined ? lookup1(obj, s.n) : lookup1(obj, yield* evalE(s.e, env));
      }
      const last = node.tail[node.tail.length - 1];
      const method = last.n !== undefined ? last.n : String((yield* evalE(last.e, env)) ?? '');
      return yield* methodCall(obj, method, node.args, env);
    }
    return yield* runCall(node.path, node.args, env, true);
  }
  let rngState = 0x9e3779b9;
  function seedRng(s) { rngState = (s >>> 0) || 0x9e3779b9; }
  function rng() {
    rngState = (rngState + 0x6D2B79F5) >>> 0;
    let t = rngState;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  const PM = new Uint8Array(512);
  function seedPerm(seed) {
    const r0 = [];
    let s2 = (seed >>> 0) || 1;
    const rnd = () => {
      s2 = (s2 + 0x6D2B79F5) >>> 0;
      let t = s2;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
    for (let i = 0; i < 256; i++) r0.push(i);
    for (let i = 255; i > 0; i--) {
      const j = Math.floor(rnd() * (i + 1));
      const t2 = r0[i]; r0[i] = r0[j]; r0[j] = t2;
    }
    for (let i = 0; i < 512; i++) PM[i] = r0[i & 255];
  }
  seedPerm(1337);
  const pfade = (t) => t * t * t * (t * (t * 6 - 15) + 10);
  const lerpn = (a, b, t) => a + (b - a) * t;
  function grad2(h, x, y) {
    switch (h & 7) {
      case 0: return x + y;
      case 1: return -x + y;
      case 2: return x - y;
      case 3: return -x - y;
      case 4: return x;
      case 5: return -x;
      case 6: return y;
      default: return -y;
    }
  }
  function grad3(h, x, y, z) {
    const u = h < 8 ? x : y;
    const v = h < 4 ? y : (h === 12 || h === 14 ? x : z);
    return ((h & 1) === 0 ? u : -u) + ((h & 2) === 0 ? v : -v);
  }
  function pnoise2(x, y) {
    const X = Math.floor(x) & 255, Y = Math.floor(y) & 255;
    const xf = x - Math.floor(x), yf = y - Math.floor(y);
    const u = pfade(xf), v = pfade(yf);
    const aa = PM[PM[X] + Y], ab = PM[PM[X] + Y + 1], ba = PM[PM[X + 1] + Y], bb = PM[PM[X + 1] + Y + 1];
    const x1 = lerpn(grad2(aa, xf, yf), grad2(ba, xf - 1, yf), u);
    const x2 = lerpn(grad2(ab, xf, yf - 1), grad2(bb, xf - 1, yf - 1), u);
    return lerpn(x1, x2, v);
  }
  function pnoise3(x, y, z) {
    const X = Math.floor(x) & 255, Y = Math.floor(y) & 255, Z = Math.floor(z) & 255;
    const xf = x - Math.floor(x), yf = y - Math.floor(y), zf = z - Math.floor(z);
    const u = pfade(xf), v = pfade(yf), w = pfade(zf);
    const A = PM[X] + Y, AA = PM[A] + Z, AB = PM[A + 1] + Z;
    const B = PM[X + 1] + Y, BA = PM[B] + Z, BB = PM[B + 1] + Z;
    return lerpn(
      lerpn(lerpn(grad3(PM[AA], xf, yf, zf), grad3(PM[BA], xf - 1, yf, zf), u),
        lerpn(grad3(PM[AB], xf, yf - 1, zf), grad3(PM[BB], xf - 1, yf - 1, zf), u), v),
      lerpn(lerpn(grad3(PM[AA + 1], xf, yf, zf - 1), grad3(PM[BA + 1], xf - 1, yf, zf - 1), u),
        lerpn(grad3(PM[AB + 1], xf, yf - 1, zf - 1), grad3(PM[BB + 1], xf - 1, yf - 1, zf - 1), u), v),
      w);
  }
  const clamp01 = (n) => (n < 0 ? 0 : n > 1 ? 1 : n);
  function noise2(x, y) { return clamp01(pnoise2(x, y) * 0.5 + 0.5); }
  function noise3(x, y, z) { return clamp01(pnoise3(x, y, z) * 0.5 + 0.5); }
  function fbm2(x, z, oct, scale, pers) {
    let f = scale, a = 1, sum = 0, norm = 0;
    for (let i = 0; i < oct; i++) {
      sum += a * noise2(x * f, z * f);
      norm += a;
      a *= pers;
      f *= 2;
    }
    return norm > 0 ? sum / norm : 0;
  }

  function interpStr(s) {
    return String(s).replace(/\[([^\]]+)\]/g, (_, p) => {
      const v = getPath(p.trim());
      return v === undefined ? '' : Array.isArray(v) ? v.map((x) => Math.round(x * 1000) / 1000).join(', ') : String(v);
    });
  }

  /* ---------- исполнение (генераторы: поддержка wait/событий) ---------- */
  let warned = false;
  const COLOR_NAMES = {
    gold: [1, 0.84, 0], yellow: [1, 0.9, 0.2], red: [0.9, 0.2, 0.16], green: [0.3, 0.75, 0.35],
    blue: [0.25, 0.5, 0.95], white: [1, 1, 1], black: [0.05, 0.05, 0.07], gray: [0.55, 0.57, 0.6],
    grey: [0.55, 0.57, 0.6], orange: [1, 0.6, 0.15], purple: [0.65, 0.35, 0.85], pink: [0.95, 0.55, 0.7],
    brown: [0.55, 0.35, 0.2], cyan: [0.2, 0.8, 0.85], teal: [0.15, 0.65, 0.6], lime: [0.6, 0.9, 0.25],
    silver: [0.75, 0.77, 0.8], navy: [0.15, 0.2, 0.5],
  };
  const MATERIALS = {
    stone: { mat: 0 }, dirt: { mat: 0, color: [0.55, 0.42, 0.28] },
    grass: { mat: 0, color: [0.42, 0.72, 0.32] },
    snow: { mat: 0, color: [0.94, 0.95, 0.99], rough: 0.55 },
    glass: { mat: 1, alpha: 0.18 }, sand: { mat: 2 },
    wood: { mat: 3 }, leaves: { mat: 3, color: [0.36, 0.62, 0.26] },
    planks: { mat: 4 }, iron: { mat: 0, rough: 0.2, color: [0.62, 0.64, 0.68] },
    water: { water: 1 }, neon: { neon: 1 },
  };
  function resolvePos(v) {
    if (Array.isArray(v)) return v;
    if (isEntRef(v)) {
      const pr = engine.get_props(v.__ent);
      return [pr[0], pr[1], pr[2]];
    }
    if (typeof v === 'string') {
      const nm = v.includes('.') ? v.split('.').pop() : v;
      const id = names[nm];
      if (id !== undefined) {
        const pr = engine.get_props(id);
        return [pr[0], pr[1], pr[2]];
      }
    }
    return [0, 0, 0];
  }
  function nameToId(p) {
    const sp = strip(String(p || '').replace(/^@/, ''));
    const nm = sp.includes('.') ? sp.split('.').pop() : sp;
    return names[nm];
  }

  function* evalE(e, env) {
    switch (e.k) {
      case 'num': return e.v;
      case 'str': return interpStr(e.v);
      case 'none': return null;
      case 'color': {
        const h = String(e.v);
        const nn = h.length === 3 ? h.split('').map((x) => x + x).join('') : h;
        return [parseInt(nn.slice(0, 2), 16) / 255, parseInt(nn.slice(2, 4), 16) / 255, parseInt(nn.slice(4, 6), 16) / 255];
      }
      case 'tuple': {
        const out = [];
        for (const it of e.items) out.push(yield* evalE(it, env));
        return out;
      }
      case 'list': {
        const out = [];
        for (const it of e.items) out.push(yield* evalE(it, env));
        return out;
      }
      case 'dict': {
        const o = {};
        for (const p of e.pairs) o[p.key] = yield* evalE(p.e, env);
        return o;
      }
      case 'neg': return -num(yield* evalE(e.a, env), 0);
      case 'ref': {
        if (env && e.path in env) return env[e.path];
        if (env && e.path.indexOf('.') > 0) {
          const dot = e.path.indexOf('.');
          const root = e.path.slice(0, dot);
          if (root in env) return lookup(env[root], e.path.slice(dot + 1));
        }
        return getPath(e.path);
      }
      case 'refn': {
        let v;
        if (env && e.base in env) v = env[e.base];
        else {
          const alt = strip(e.base);
          if (env && alt !== e.base && alt in env) v = env[alt];
          else v = getPath(e.base);
        }
        for (const s of e.segs) {
          if (v === undefined || v === null) return undefined;
          v = s.n !== undefined ? lookup1(v, s.n) : lookup1(v, yield* evalE(s.e, env));
        }
        return v;
      }
      case 'idx': {
        const o = yield* evalE(e.obj, env);
        return lookup1(o, yield* evalE(e.e, env));
      }
      case 'prop': {
        const o = yield* evalE(e.obj, env);
        return lookup(o, e.name);
      }
      case 'callm': return yield* evalCallNode(e, env);
      case 'call': return yield* evalCallNode(e, env);
      case 'bin': {
        const a = yield* evalE(e.a, env);
        const b = yield* evalE(e.b, env);
        if (e.op === '..') {
          const sa = Array.isArray(a) ? fmt(a) : (a === null || a === undefined ? '' : a);
          const sb = Array.isArray(b) ? fmt(b) : (b === null || b === undefined ? '' : b);
          return String(sa) + String(sb);
        }
        if (e.op === '+') {
          if (Array.isArray(a) && Array.isArray(b)) return a.map((x, i) => num(x, 0) + num(b[i], 0));
          const av = a === undefined || a === null || a === '' ? 0 : a;
          const bv = b === undefined || b === null || b === '' ? 0 : b;
          if (typeof av === 'number' && typeof bv === 'number') return av + bv;
          return (a ?? '') + (b ?? '');
        }
        if (e.op === '&&' || e.op === '||') {
          const ta = truthy(a), tb = truthy(b);
          return e.op === '&&' ? (ta && tb ? 1 : 0) : (ta || tb ? 1 : 0);
        }
        if (e.op === '==' || e.op === '!=') {
          let eq;
          if ((a === undefined || a === null) && (b === undefined || b === null)) eq = true;
          else if (a === undefined || a === null || b === undefined || b === null) eq = false;
          else if (isEntRef(a) && isEntRef(b)) eq = a.__ent === b.__ent;
          else eq = a === b || String(a) === String(b);
          return e.op === '==' ? (eq ? 1 : 0) : (eq ? 0 : 1);
        }
        const x = num(a, 0), y = num(b, 0);
        switch (e.op) {
          case '-':
            if (Array.isArray(a) && Array.isArray(b)) return a.map((q, i) => num(q, 0) - num(b[i], 0));
            return x - y;
          case '*': return x * y;
          case '/': return y !== 0 ? x / y : 0;
          case '%': return y !== 0 ? x % y : 0;
          case '**': return Math.pow(x, y);
          case '>': return x > y ? 1 : 0;
          case '<': return x < y ? 1 : 0;
          case '>=': return x >= y ? 1 : 0;
          case '<=': return x <= y ? 1 : 0;
          case '==': return x === y || String(a) === String(b) ? 1 : 0;
          case '!=': return x === y || String(a) === String(b) ? 0 : 1;
        }
        return 0;
      }
    }
    return 0;
  }

  function* argVal(args, key, idx, env, dflt) {
    for (const a of args) {
      if (a.key === key) return yield* evalE(a.e, env);
    }
    if (args[idx] && !args[idx].key) return yield* evalE(args[idx].e, env);
    return dflt;
  }

  function* runCall(path, args, env, asExpr) {
    const p = path.replace(/^@/, '');
    const low = p.toLowerCase();
    const lowBare = low.replace(/^(l|p)\./, '');
    // wait(n) — пауза в секундах (0 = один кадр)
    if (low === 'wait') {
      const secs = num(yield* argVal(args, 'n', 0, env, 0), 0);
      yield Math.max(0, secs);
      return 1;
    }
    // встроенные функции (§15)
    if (low === 'root' || lowBare === 'root') {
      return Math.sqrt(Math.abs(num(yield* argVal(args, 'x', 0, env, 0), 0)));
    }
    if (low === 'pow' || lowBare === 'pow') {
      return Math.pow(num(yield* argVal(args, 'x', 0, env, 0), 0), num(yield* argVal(args, 'y', 1, env, 0), 0));
    }
    const D2R = Math.PI / 180;
    if (low === 'sin' || lowBare === 'sin') return Math.sin(num(yield* argVal(args, 'x', 0, env, 0), 0) * D2R);
    if (low === 'cos' || lowBare === 'cos') return Math.cos(num(yield* argVal(args, 'x', 0, env, 0), 0) * D2R);
    if (low === 'tan' || lowBare === 'tan') return Math.tan(num(yield* argVal(args, 'x', 0, env, 0), 0) * D2R);
    if (low === 'abs' || lowBare === 'abs') return Math.abs(num(yield* argVal(args, 'x', 0, env, 0), 0));
    if (low === 'min' || lowBare === 'min') {
      return Math.min(num(yield* argVal(args, 'a', 0, env, 0), 0), num(yield* argVal(args, 'b', 1, env, 0), 0));
    }
    if (low === 'max' || lowBare === 'max') {
      return Math.max(num(yield* argVal(args, 'a', 0, env, 0), 0), num(yield* argVal(args, 'b', 1, env, 0), 0));
    }
    if (low === 'random' || lowBare === 'random') {
      const a0 = num(yield* argVal(args, 'min', 0, env, 0), 0);
      const b0 = num(yield* argVal(args, 'max', 1, env, 1), 1);
      return a0 + rng() * (b0 - a0);
    }
    if (low === 'random_int' || lowBare === 'random_int') {
      const a0 = Math.floor(num(yield* argVal(args, 'min', 0, env, 0), 0));
      const b0 = Math.floor(num(yield* argVal(args, 'max', 1, env, 0), 0));
      return a0 + Math.floor(rng() * (b0 - a0 + 1));
    }
    if (low === 'random_bool' || lowBare === 'random_bool') return rng() < 0.5 ? 1 : 0;
    if (low === 'random_seed' || lowBare === 'random_seed') {
      seedRng(Math.floor(num(yield* argVal(args, 'seed', 0, env, 0), 0)));
      return rng();
    }
    if (low === 'random_choice' || lowBare === 'random_choice') {
      const v = yield* argVal(args, 'list', 0, env, null);
      if (Array.isArray(v) && v.length) return v[Math.floor(rng() * v.length)];
      return v === undefined ? null : v;
    }
    if (low === 'noise' || lowBare === 'noise') {
      const x = num(yield* argVal(args, 'x', 0, env, 0), 0);
      const y2 = num(yield* argVal(args, 'y', 1, env, 0), 0);
      const z = num(yield* argVal(args, 'z', 2, env, 0), 0);
      const has3 = args.filter((a) => !a.key).length >= 3;
      return has3 ? noise3(x, y2, z) : noise2(x, y2);
    }
    if (low === 'noise_seed' || lowBare === 'noise_seed') {
      const x = num(yield* argVal(args, 'x', 0, env, 0), 0);
      const z = num(yield* argVal(args, 'z', 1, env, 0), 0);
      seedPerm(Math.floor(num(yield* argVal(args, 'seed', 2, env, 0), 0)));
      return noise2(x, z);
    }
    if (low === 'noise_octaves' || lowBare === 'noise_octaves' || low === 'noise_octaves_full' || lowBare === 'noise_octaves_full') {
      const x = num(yield* argVal(args, 'x', 0, env, 0), 0);
      const z = num(yield* argVal(args, 'z', 1, env, 0), 0);
      const oct = Math.max(1, Math.floor(num(yield* argVal(args, 'octaves', 2, env, 1), 1)));
      const scale = num(yield* argVal(args, 'scale', 3, env, 0.05), 0.05);
      const pers = low.includes('full') ? num(yield* argVal(args, 'persistence', 4, env, 0.5), 0.5) : 0.5;
      return fbm2(x, z, oct, scale, pers);
    }
    if (low === 'str' || lowBare === 'str' || low === 'to_str' || lowBare === 'to_str') {
      const v = yield* argVal(args, 'x', 0, env, 0);
      return fmt(v);
    }
    if (low === 'to_int' || lowBare === 'to_int') {
      const v = yield* argVal(args, 'x', 0, env, 0);
      if (typeof v === 'number') return Math.trunc(v);
      const n2 = parseInt(String(v ?? ''), 10);
      return isFinite(n2) ? n2 : 0;
    }
    if (low === 'to_float' || lowBare === 'to_float') {
      const v = yield* argVal(args, 'x', 0, env, 0);
      const n2 = parseFloat(String(v ?? ''));
      return isFinite(n2) ? n2 : 0;
    }
    if (low === 'floor' || lowBare === 'floor') return Math.floor(num(yield* argVal(args, 'x', 0, env, 0), 0));
    if (low === 'ceil' || lowBare === 'ceil') return Math.ceil(num(yield* argVal(args, 'x', 0, env, 0), 0));
    if (low === 'round' || lowBare === 'round') return Math.round(num(yield* argVal(args, 'x', 0, env, 0), 0));
    if (low === 'clamp' || lowBare === 'clamp') {
      const v0 = num(yield* argVal(args, 'x', 0, env, 0), 0);
      const lo = num(yield* argVal(args, 'min', 1, env, 0), 0);
      const hi = num(yield* argVal(args, 'max', 2, env, 1), 1);
      return Math.max(lo, Math.min(hi, v0));
    }
    if (low === 'length' || lowBare === 'length') {
      const v = yield* argVal(args, 'v', 0, env, 0);
      const p0 = Array.isArray(v) ? v : resolvePos(v);
      return Math.hypot(num(p0[0], 0), num(p0[1], 0), num(p0[2], 0));
    }
    if (low === 'dist' || lowBare === 'dist') {
      const a0 = resolvePos(yield* argVal(args, 'a', 0, env, 0));
      const b0 = resolvePos(yield* argVal(args, 'b', 1, env, 0));
      return Math.hypot(num(a0[0], 0) - num(b0[0], 0), num(a0[1], 0) - num(b0[1], 0), num(a0[2], 0) - num(b0[2], 0));
    }
    if (low === 'dot' || lowBare === 'dot') {
      const a0 = resolvePos(yield* argVal(args, 'a', 0, env, 0));
      const b0 = resolvePos(yield* argVal(args, 'b', 1, env, 0));
      return num(a0[0], 0) * num(b0[0], 0) + num(a0[1], 0) * num(b0[1], 0) + num(a0[2], 0) * num(b0[2], 0);
    }
    if (low === 'cross' || lowBare === 'cross') {
      const a0 = resolvePos(yield* argVal(args, 'a', 0, env, 0));
      const b0 = resolvePos(yield* argVal(args, 'b', 1, env, 0));
      return [
        num(a0[1], 0) * num(b0[2], 0) - num(a0[2], 0) * num(b0[1], 0),
        num(a0[2], 0) * num(b0[0], 0) - num(a0[0], 0) * num(b0[2], 0),
        num(a0[0], 0) * num(b0[1], 0) - num(a0[1], 0) * num(b0[0], 0),
      ];
    }
    if (low === 'lerp' || lowBare === 'lerp') {
      const a = yield* argVal(args, 'a', 0, env, 0);
      const b = yield* argVal(args, 'b', 1, env, 0);
      const tt = num(yield* argVal(args, 't', 2, env, 0), 0);
      if (Array.isArray(a) || Array.isArray(b)) {
        const pa = Array.isArray(a) ? a : [a, a, a];
        const pb = Array.isArray(b) ? b : [b, b, b];
        return pa.map((x, i) => num(x, 0) + (num(pb[i], 0) - num(x, 0)) * tt);
      }
      return num(a, 0) + (num(b, 0) - num(a, 0)) * tt;
    }
    if (low === 'find' || lowBare === 'find') {
      const v = yield* argVal(args, 'name', 0, env, 0);
      if (isEntRef(v)) return v.__name !== undefined ? v.__name : '';
      return String(v ?? '');
    }
    if (low === 'collide' || lowBare === 'collide') {
      const va = yield* argVal(args, 'a', 0, env, 0);
      const vb = yield* argVal(args, 'b', 1, env, 0);
      const ida = isEntRef(va) ? va.__ent : nameToId(String(va ?? ''));
      const idb = isEntRef(vb) ? vb.__ent : nameToId(String(vb ?? ''));
      if (ida === undefined || idb === undefined) return 0;
      const pa = engine.get_props(ida), pb = engine.get_props(idb);
      if ((pa[20] !== undefined && pa[20] < 0.5) || (pb[20] !== undefined && pb[20] < 0.5)) return 0;
      const dx = Math.abs(pa[0] - pb[0]), dy = Math.abs(pa[1] - pb[1]), dz = Math.abs(pa[2] - pb[2]);
      return (dx < (pa[6] + pb[6]) / 2 && dy < (pa[7] + pb[7]) / 2 && dz < (pa[8] + pb[8]) / 2) ? 1 : 0;
    }
    if (low === 'raycast' || lowBare === 'raycast') return null;
    if (lowBare === 'text.pr' || lowBare === 'text.print' || lowBare === 'pr') {
      const parts = [];
      for (const a of args) {
        const v = yield* evalE(a.e, env);
        parts.push(a.key ? `${a.key}: ${fmt(v)}` : fmt(v));
      }
      if (hooks.print) hooks.print(parts.join(' '));
      return 1;
    }
    if (low === 'w.destroy' || low === 'destroy' || lowBare === 'destroy') {
      const a = args.find((x) => x.key === 'obj') || args[0];
      let id;
      if (a) {
        const obj = yield* evalE(a.e, env);
        if (isEntRef(obj)) id = obj.__ent;
        else if (typeof obj === 'number') id = obj;
        else if (obj !== undefined && obj !== null) id = names[String(obj).split('.').pop()];
        if (id === undefined && a.e && a.e.k === 'ref') id = names[a.e.path.split('.').pop()];
      }
      if (id !== undefined && id !== null && id >= 0 && engine.entity_ids().includes(id)) {
        engine.remove_entity(id);
        for (const k of Object.keys(names)) if (names[k] === id) delete names[k];
        tweens = tweens.filter((t) => t.id !== id);
      }
      return 1;
    }
    if (p.startsWith('UI.')) {
      const rest = p.slice(3);
      const dot = rest.lastIndexOf('.');
      const nm = dot > 0 ? rest.slice(0, dot) : rest;
      const method = dot > 0 ? rest.slice(dot + 1) : '';
      if (!hooks.ui) return 0;
      const m0 = String(method).toLowerCase();
      // @UI.X.tween(pos(10%, 5), size(200, 48), color(r,g,b,a), alpha(0), 1.5, smooth)
      if (dot > 0 && m0 === 'tween') {
        let time = 1, easeName = 'linear';
        const blocks = [];
        for (const a of args) {
          const e = a.e || {};
          if (e.k === 'call') {
            const pn = String(e.path || '').toLowerCase();
            const pvals = [];
            for (const sa of e.args || []) pvals.push(yield* evalE(sa.e, env));
            blocks.push([pn, pvals]);
          } else {
            const v = yield* evalE(e, env);
            if (typeof v === 'number') time = num(v, 1);
            else if (typeof v === 'string') easeName = v.toLowerCase();
          }
        }
        for (const [pn, pvals] of blocks) {
          if (pn === 'pos' || pn === 'position') {
            startUiTween(nm, 'x', pvals[0], time, easeName);
            startUiTween(nm, 'y', pvals[1], time, easeName);
          } else if (pn === 'size') {
            startUiTween(nm, 'w', pvals[0], time, easeName);
            startUiTween(nm, 'h', pvals[1], time, easeName);
          } else {
            startUiTween(nm, pn, pvals.length > 1 ? pvals : pvals[0], time, easeName);
          }
        }
        return 1;
      }
      if (dot > 0 && m0 === 'stop') {
        uiTweens = uiTweens.filter((t) => t.name !== nm);
        return 1;
      }
      const argsV = [];
      for (const a of args) argsV.push(yield* evalE(a.e, env));
      if (!hooks.ui) return 0;
      const first = argsV[0] !== undefined && argsV[0] !== null ? String(argsV[0]).split('.').pop() : '';
      if (dot < 0) {
        // корневые методы: @UI.show(Имя), @UI.hide(Имя), @UI.find(Имя), @UI.destroy(Имя), @UI.clear()
        const fn = nm.toLowerCase();
        if (fn === 'show') { hooks.ui.show(first); return 1; }
        if (fn === 'hide') { hooks.ui.hide(first); return 1; }
        if (fn === 'destroy') { hooks.ui.destroy(first); return 1; }
        if (fn === 'clear') { hooks.ui.clear(); return 1; }
        if (fn === 'find') return hooks.ui.find(first) ? first : 0;
        return 0;
      }
      // методы элемента: @UI.Box.show(), @UI.Box.set(text, ...), @UI.Box.click()
      const m = String(method).toLowerCase();
      if (m === 'show') { hooks.ui.show(nm); return 1; }
      if (m === 'hide') { hooks.ui.hide(nm); return 1; }
      if (m === 'destroy') { hooks.ui.destroy(nm); return 1; }
      if (m === 'click') { if (hooks.ui.click) hooks.ui.click(nm); return 1; }
      if (m === 'set' || m === 'setprop') {
        hooks.ui.set(nm, argsV[0], argsV.length > 2 ? argsV.slice(1) : argsV[1]);
        return 1;
      }
      if (m === 'get' || m === 'getprop') return hooks.ui.get(nm, argsV[0]);
      return 0;
    }
    if (p.startsWith('W.')) {
      const rest = p.slice(2);
      const dot = rest.lastIndexOf('.');
      const nm = dot > 0 ? rest.slice(0, dot) : rest;
      const method = dot > 0 ? rest.slice(dot + 1) : '';
      let id = names[nm];
      if (id === undefined) {
        // @W.Obj.method — Obj может быть переменной с объектом
        const v = getPath(nm);
        if (isEntRef(v)) id = v.__ent;
        else if (typeof v === 'number' && engine.entity_ids().includes(v)) id = v;
      }
      if (id === undefined || id === null || !engine.entity_ids().includes(id)) {
        if (!dot && ['tween', 'move', 'tp', 'destroy', 'fade_out', 'children', 'descendants', 'pr', 'print'].includes(nm.toLowerCase())) {
          err = '@W.' + nm + ': не указан объект — используйте [объект].' + nm + '(...) или @W.Имя.' + nm + '(...)';
        }
        return 0;
      }
      return yield* entMethod(id, nm, method, args, env);
    }
    const fname = low.replace(/^f\./, '');
    if (F[fname]) {
      const f = F[fname];
      const local = {};
      const namesArgs = f.argNames || [];
      for (let i = 0; i < namesArgs.length; i++) {
        local[namesArgs[i]] = f.head ? yield* argVal(args, namesArgs[i], i, env, 0) : 0;
      }
      try {
        yield* exec(f.body, { ...env, ...local, dt: env && env.dt, __f: 1 });
      } catch (er) {
        if (er instanceof RetSig) return er.v;
        throw er;
      }
      return null;
    }
    // методы списков/словарей/объектов: @L.List.add(...), List.remove(...) и т.п.
    {
      const sp = strip(p);
      const parts = sp.split('.');
      if (parts.length >= 2) {
        const obj = getPath(parts.slice(0, -1).join('.'));
        if (obj !== undefined && obj !== null) {
          const r = yield* methodCall(obj, parts[parts.length - 1], args, env);
          if (r !== undefined) return r;
        }
      }
    }
    return 0;
  }

  function* entMethod(id, nm, method, args, env) {
    if (id === undefined || id === null || !engine.entity_ids().includes(id)) return 0;
    if (method === 'move') {
      const t = yield* argVal(args, 'target', 0, env, null);
      const tp = Array.isArray(t) ? t : resolvePos(t);
      if (Array.isArray(tp)) {
        const props = engine.get_props(id);
        const spd = num(getPath(nm + '.Speed'), 5) * num(env && env.dt, 0.016);
        const dx = num(tp[0], 0) - props[0], dy = num(tp[1], 0) - props[1], dz = num(tp[2], 0) - props[2];
        const d = Math.hypot(dx, dy, dz) || 1;
        const k = Math.min(spd / d, 1);
        engine.set_props(id, new Float32Array([
          props[0] + dx * k, props[1] + dy * k, props[2] + dz * k,
          props[3], props[4], props[5], props[6], props[7], props[8],
          props[9], props[10], props[11], props[12], props[13], props[14], props[15], props[16], props[17], props[18] || 0, props[19] === undefined ? 0.35 : props[19], props[20] === undefined ? 1 : props[20],
        ]));
      }
      return 1;
    }
    if (method === 'tween') {
      const prop = String(yield* argVal(args, 'prop', 0, env, '') ?? '').toLowerCase();
      const goal = yield* argVal(args, 'to', 1, env, 0);
      const dur = num(yield* argVal(args, 'time', 2, env, 1), 1);
      const easeName = String(yield* argVal(args, 'easing', 3, env, 'linear') ?? 'linear').toLowerCase();
      startTween(id, prop, goal, dur, easeName);
      return 1;
    }
    if (method === 'tp') {
      const t = yield* argVal(args, 'pos', 0, env, null);
      const tp = Array.isArray(t) ? t : resolvePos(t);
      if (Array.isArray(tp)) {
        const props = engine.get_props(id);
        engine.set_props(id, new Float32Array([
          num(tp[0], 0), num(tp[1], 0), num(tp[2], 0),
          props[3], props[4], props[5], props[6], props[7], props[8],
          props[9], props[10], props[11], props[12], props[13], props[14], props[15], props[16], props[17], props[18] || 0, props[19] === undefined ? 0.35 : props[19], props[20] === undefined ? 1 : props[20],
        ]));
      }
      return 1;
    }
    if (method === 'pr' || method === 'print') {
      const parts = [];
      for (const a of args) {
        const v = yield* evalE(a.e, env);
        parts.push(a.key ? `${a.key}: ${fmt(v)}` : fmt(v));
      }
      if (hooks.print) hooks.print(parts.join(' '));
      return 1;
    }
    if (method === 'destroy') {
      if (engine.entity_ids().includes(id)) {
        engine.remove_entity(id);
        for (const k of Object.keys(names)) if (names[k] === id) delete names[k];
        tweens = tweens.filter((t) => t.id !== id);
      }
      return 1;
    }
    if (method === 'fade_out') {
      const t = num(yield* argVal(args, 'time', 0, env, 0.3), 0.3);
      startTween(id, 'alpha', 0, t, 'ease_in');
      fades.push({ id, t: 0, dur: Math.max(0.01, t) });
      return 1;
    }
    if (method === 'children') {
      const cs = engine.children_of ? engine.children_of(id) : [];
      return cs.map((cid) => entRef(cid, engine.entity_name(cid)));
    }
    if (method === 'descendants') {
      const cs = engine.descendants_of ? engine.descendants_of(id) : [];
      return cs.map((cid) => entRef(cid, engine.entity_name(cid)));
    }
    return 0;
  }

  function fmt(v) {
    if (v === null || v === undefined) return '';
    if (isEntRef(v)) return v.__name !== undefined ? v.__name : String(v.__ent);
    if (Array.isArray(v)) return v.map((x) => (x && typeof x === 'object') ? fmt(x) : Math.round(x * 100) / 100).join(', ');
    if (typeof v === 'number') return String(Math.round(v * 1000) / 1000);
    if (typeof v === 'object') return '{' + Object.keys(v).map((k) => k + ': ' + fmt(v[k])).join(', ') + '}';
    return String(v);
  }

  function budgetErr() {
    err = 'лимит шагов исчерпан 300 кадров подряд — похоже на бесконечный цикл без break WTD (код «каждый кадр» пишите в @E.OnUpdate)';
    if (!warned) { warned = true; if (hooks.print) hooks.print('HGS: ' + err); }
  }

  function* exec(stmts, env) {
    for (const s of stmts) {
      if (budget <= 0) {
        const ctl = env && env.__ctl;
        if (ctl) {
          ctl.slices++;
          if (ctl.slices > 300) { budgetErr(); return 'break'; }
        }
        yield 0;
        continue;
      }
      budget--;
      switch (s.k) {
        case 'block': {
          const r = yield* exec(s.body, env);
          if (r === 'break' || r === 'continue') return r;
          break;
        }
        case 'if': {
          if (s.nested) {
            const r = yield* exec([s.nested], env);
            if (r === 'break' || r === 'continue') return r;
            break;
          }
          const c = num(yield* evalE(s.cond, env), 0);
          const r = c ? yield* exec(s.body, env) : yield* exec(s.els, env);
          if (r === 'break' || r === 'continue') return r;
          break;
        }
        case 'wtd': {
          for (;;) {
            if (budget <= 0) {
              const ctl = env && env.__ctl;
              if (ctl) {
                ctl.slices++;
                if (ctl.slices > 300) { budgetErr(); return 'break'; }
              }
              yield 0;
              continue;
            }
            budget--;
            const r = yield* exec(s.body, env);
            if (r === 'break') break;
          }
          break;
        }
        case 'break': return 'break';
        case 'continue': return 'continue';
        case 'return': throw new RetSig(s.e ? yield* evalE(s.e, env) : null);
        case 'assign': {
          const val = yield* evalE(s.e, env);
          if (s.tail && s.tail.length) {
            if (s.op) {
              const cur = yield* getTailVal(s.path, s.tail, env);
              const c0 = num(cur, 0), x = num(val, 0);
              const r2 = s.op === '+=' ? c0 + x : s.op === '-=' ? c0 - x : s.op === '*=' ? c0 * x : (x !== 0 ? c0 / x : c0);
              yield* setTailVal(s.path, s.tail, r2, env);
            } else {
              yield* setTailVal(s.path, s.tail, val, env);
            }
            break;
          }
          const cur = getPath(s.path);
          if (s.op) {
            const c0 = num(cur, 0), x = num(val, 0);
            const r2 = s.op === '+=' ? c0 + x : s.op === '-=' ? c0 - x : s.op === '*=' ? c0 * x : (x !== 0 ? c0 / x : c0);
            setPath(s.path, r2);
          } else {
            setPath(s.path, val);
          }
          break;
        }
        case 'bind': {
          const src = !s.tail.length && s.e.k === 'ref' ? s.e.path : null;
          if (src) B[strip(s.path)] = src;
          else if (s.tail && s.tail.length) yield* setTailVal(s.path, s.tail, yield* evalE(s.e, env), env);
          else setPath(s.path, yield* evalE(s.e, env));
          break;
        }
        case 'attach': {
          let aid;
          if (s.tail && s.tail.length) {
            const v = yield* getTailVal(s.path, s.tail, env);
            aid = isEntRef(v) ? v.__ent : (typeof v === 'number' ? v : nameToId(String(v ?? '')));
          } else aid = nameToId(s.path);
          let bid;
          const av = yield* evalE(s.e, env);
          if (isEntRef(av)) bid = av.__ent;
          else if (s.e && s.e.k === 'ref') bid = nameToId(s.e.path);
          else bid = nameToId(String(av ?? ''));
          if (aid !== undefined && aid !== null && bid !== undefined && bid !== null && aid !== bid) {
            try { engine.set_parent(aid, bid); } catch (e) { /* нет API */ }
          }
          break;
        }
        case 'wset': {
          const nm = s.path.slice(2);
          const props = { pos: [0, 0, 0], size: [1, 1, 1], color: [0.8, 0.8, 0.8], rot: [0, 0, 0], alpha: 1, mat: 0, neon: 0, shape: 0, rough: 0.35, water: 0, visible: 1 };
          const explicit = {};
          const ordered = [];
          for (const pr of s.props) {
            const vals = [];
            for (const a of pr.args) vals.push(yield* evalE(a.e, env));
            ordered.push([pr.name, vals]);
            explicit[pr.name] = true;
          }
          let matName = '';
          for (const [pn, vals] of ordered) {
            if (pn !== 'material') continue;
            const m = MATERIALS[String(vals[0] ?? '').toLowerCase()];
            matName = String(vals[0] ?? '').toLowerCase();
            if (m) {
              if (m.mat !== undefined) props.mat = m.mat;
              if (m.water !== undefined) props.water = m.water;
              if (m.neon !== undefined && !explicit.glow) props.neon = m.neon;
              if (m.alpha !== undefined && !explicit.alpha) props.alpha = m.alpha;
              if (m.color !== undefined && !explicit.color) props.color = m.color.slice();
              if (m.rough !== undefined && !explicit.rough) props.rough = m.rough;
            }
          }
          for (const [pn, vals] of ordered) {
            if (pn === 'pos') props.pos = vals.map((v, i) => num(v, props.pos[i] || 0));
            else if (pn === 'size') props.size = vals.map((v, i) => num(v, props.size[i] || 1));
            else if (pn === 'color') {
              if (Array.isArray(vals[0])) props.color = [0, 1, 2].map((i) => num(vals[0][i], 0.8));
              else if (typeof vals[0] === 'number' && Number.isInteger(vals[0]) && vals[0] > 0xff) {
                const h2 = Math.min(0xffffff, vals[0]) >>> 0;
                props.color = [((h2 >> 16) & 255) / 255, ((h2 >> 8) & 255) / 255, (h2 & 255) / 255];
              } else {
                const named = typeof vals[0] === 'string' ? COLOR_NAMES[String(vals[0]).toLowerCase()] : null;
                props.color = [0, 1, 2].map((i) => (named ? named[i] : num(vals[i], 0.8)));
              }
            }
            else if (pn === 'rot') props.rot = vals.map((v, i) => num(v, props.rot[i] || 0));
            else if (pn === 'alpha') props.alpha = num(vals[0], 1);
            else if (pn === 'mat') {
              const mname = typeof vals[0] === 'string' ? String(vals[0]).toLowerCase() : '';
              if (mname === 'water') props.water = 1;
              else props.mat = num(vals[0], 0);
            }
            else if (pn === 'neon' || pn === 'glow') props.neon = (/^(true|yes|on|1)$/i.test(String(vals[0])) || num(vals[0], 0) > 0.5) ? 1 : 0;
            else if (pn === 'shape') props.shape = num(vals[0], 0);
            else if (pn === 'rough') props.rough = num(vals[0], 0.35);
            else if (pn === 'visible') props.visible = /^false|no|off|0$/i.test(String(vals[0])) ? 0 : 1;
          }
          let id = names[nm];
          const arr = new Float32Array([
            ...props.pos, ...props.rot, ...props.size, ...props.color,
            props.neon, props.alpha, props.water, 0, props.mat, 0, props.shape, props.rough,
            props.visible,
          ]);
          const factory = !!(env && env.__f);
          if (id === undefined || !engine.entity_ids().includes(id) || factory) {
            id = engine.add_entity(nm, arr);
            names[nm] = id;
            created.push(id);
          } else {
            engine.set_props(id, arr);
          }
          (entAttrs[id] = entAttrs[id] || {}).material = matName;
          if (s.attach) {
            let bid;
            const av = yield* evalE(s.attach, env);
            if (isEntRef(av)) bid = av.__ent;
            else if (s.attach.k === 'ref') bid = nameToId(s.attach.path);
            else bid = nameToId(String(av ?? ''));
            if (bid !== undefined && bid !== null && bid !== id) {
              try { engine.set_parent(id, bid); } catch (e) { /* нет API */ }
            }
          }
          break;
        }
        case 'uiset': {
          const toCol = (vals, dflt) => {
            const d = dflt || [255, 255, 255, 255];
            if (!vals.length) return d.slice();
            if (vals.length === 1) {
              const v = vals[0];
              if (typeof v === 'string' && COLOR_NAMES && COLOR_NAMES[v.toLowerCase()]) {
                const n = COLOR_NAMES[v.toLowerCase()];
                return [Math.round(n[0] * 255), Math.round(n[1] * 255), Math.round(n[2] * 255), d[3] === undefined ? 255 : d[3]];
              }
              return v;
            }
            return vals.slice();
          };
          let nm = s.path.slice(3);
          const def = { name: nm, type: 'label' };
          const apply = [];
          for (const pr of s.props) {
            const pn = String(pr.name || '').toLowerCase();
            const vals = [];
            for (const a of pr.args) {
              if ((pn === 'onclick' || pn === 'onchange' || pn === 'onmove') && a.e && a.e.k === 'ref') {
                vals.push(String(a.e.path || '').replace(/^@?F\.?/i, ''));
              } else vals.push(yield* evalE(a.e, env));
            }
            apply.push([pn, vals]);
          }
          for (const [pn, vals] of apply) {
            const v0 = vals[0];
            if (pn === 'type' || pn === 'kind') def.type = String(v0 || 'label').toLowerCase();
            else if (pn === 'name') nm = def.name = String(v0 || nm);
            else if (pn === 'parent') def.parent = String(v0 || '');
            else if (pn === 'pos') { def.x = vals[0]; def.y = vals[1]; }
            else if (pn === 'size') { def.w = vals[0]; def.h = vals[1]; }
            else if (pn === 'x') def.x = v0;
            else if (pn === 'y') def.y = v0;
            else if (pn === 'w' || pn === 'width') def.w = v0;
            else if (pn === 'h' || pn === 'height') def.h = v0;
            else if (pn === 'text' || pn === 'value') def.text = v0 === undefined || v0 === null ? '' : String(v0);
            else if (pn === 'placeholder') def.placeholder = String(v0 || '');
            else if (pn === 'color' || pn === 'bg' || pn === 'background') def.bg = toCol(vals, def.bg || [40, 40, 52, 210]);
            else if (pn === 'textcolor' || pn === 'fg') def.fg = toCol(vals, [255, 255, 255, 255]);
            else if (pn === 'border') {
              if (typeof vals[0] === 'number' && vals.length >= 2) {
                def.borderW = vals[0];
                def.border = toCol(vals.slice(1), [255, 255, 255, 255]);
              } else def.border = toCol(vals, [255, 255, 255, 255]);
            }
            else if (pn === 'bordercolor') def.border = toCol(vals, [255, 255, 255, 255]);
            else if (pn === 'borderw' || pn === 'borderwidth') def.borderW = v0;
            else if (pn === 'radius' || pn === 'borderradius') def.radius = v0;
            else if (pn === 'font' || pn === 'fontsize') def.fontSize = v0;
            else if (pn === 'align' || pn === 'textalign') def.align = String(v0 || 'left');
            else if (pn === 'alpha') def.alpha = v0;
            else if (pn === 'visible') def.visible = v0;
            else if (pn === 'zindex' || pn === 'z') def.zIndex = v0;
            else if (pn === 'onclick') def.onClick = String(v0 || '');
            else if (pn === 'onchange') def.onChange = String(v0 || '');
            else if (pn === 'onmove') def.onMove = String(v0 || '');
          }
          if (hooks.ui) hooks.ui.create(nm, def);
          break;
        }
        case 'call': {
          if (/^(E|S)\./.test(s.path)) break;
          // вызов @F с wait внутри, как оператор, — фоновая задача (не блокирует вызывающего)
          {
            const fname3 = String(s.path || '').replace(/^@/, '').toLowerCase().replace(/^f\./, '');
            const fdef3 = F[fname3];
            if (fdef3 && stmtSuspending(fdef3) && !(s.tail && s.tail.length)) {
              const local3 = {};
              const namesArgs3 = fdef3.argNames || [];
              for (let i = 0; i < namesArgs3.length; i++) {
                local3[namesArgs3[i]] = fdef3.head ? yield* argVal(s.args, namesArgs3[i], i, env, 0) : 0;
              }
              spawnExec(fdef3.body, { ...env, ...local3, dt: env && env.dt, __f: 1 }, 'f');
              break;
            }
          }
          yield* evalCallNode(s, env);
          break;
        }
        case 'fdef_head': break;
        case 'end': break;
        case 'libmeta': break;
        case 'exprstmt': yield* evalE(s.e, env); break;
        case 'refstmt': {
          if (s.tail && s.tail.length) yield* getTailVal(s.path, s.tail, env);
          else getPath(s.path);
          break;
        }
      }
    }
    return '';
  }

  /* ---------- твины ---------- */
  const EASINGS = {
    linear: (t) => t,
    ease_in: (t) => t * t,
    ease_out: (t) => 1 - (1 - t) * (1 - t),
    ease_in_out: (t) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2),
    bounce: (t) => {
      const n = 7.5625, d = 2.75;
      if (t < 1 / d) return n * t * t;
      if (t < 2 / d) return n * (t -= 1.5 / d) * t + 0.75;
      if (t < 2.5 / d) return n * (t -= 2.25 / d) * t + 0.9375;
      return n * (t -= 2.625 / d) * t + 0.984375;
    },
    elastic: (t) => (t <= 0 ? 0 : t >= 1 ? 1 : Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * (2 * Math.PI / 3)) + 1),
    back: (t) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); },
  };
  let tweens = [];
  let fades = [];
  let uiTweens = [];
  function uiEaseName(n) {
    const a = {
      smooth: 'ease_in_out', smoothstep: 'ease_in_out', in: 'ease_in', out: 'ease_out',
      inout: 'ease_in_out', 'ease-in': 'ease_in', 'ease-out': 'ease_out', 'ease-in-out': 'ease_in_out',
    };
    return a[n] || n;
  }
  function startUiTween(name, prop, goal, dur, easeName) {
    if (!hooks.ui || !hooks.ui.find || !hooks.ui.find(name)) return;
    const aliases = { font: 'fontsize', bg: 'color', background: 'color', fg: 'textcolor', border: 'bordercolor', z: 'zindex', position: 'pos' };
    const p = aliases[String(prop).toLowerCase()] || String(prop).toLowerCase();
    let from, to, kind;
    if (p === 'x' || p === 'y' || p === 'w' || p === 'h') {
      kind = 'unit';
      const cur = hooks.ui.get(name, p) || { px: 0, pr: 0 };
      from = { px: num(cur.px, 0), pr: num(cur.pr, 0) };
      to = { px: from.px, pr: from.pr };
      if (typeof goal === 'string' && goal.trim().endsWith('%')) to.pr = parseFloat(goal) || 0;
      else if (typeof goal === 'number') to.px = goal;
      else if (goal && typeof goal === 'object' && !Array.isArray(goal)) {
        if (goal.px !== undefined) to.px = num(goal.px, to.px);
        if (goal.pr !== undefined) to.pr = num(goal.pr, to.pr);
      } else to.px = num(goal, from.px);
    } else if (p === 'color' || p === 'textcolor' || p === 'bordercolor') {
      kind = 'col';
      const cur = hooks.ui.get(name, p) || [255, 255, 255, 255];
      from = [num(cur[0], 255), num(cur[1], 255), num(cur[2], 255), num(cur[3], 255)];
      to = from.slice();
      const gv = Array.isArray(goal) ? goal : [goal];
      if (gv.length === 1 && typeof gv[0] === 'string' && COLOR_NAMES && COLOR_NAMES[gv[0].toLowerCase()]) {
        const n = COLOR_NAMES[gv[0].toLowerCase()];
        to = [n[0] * 255, n[1] * 255, n[2] * 255, from[3]];
      } else if (gv.length === 1 && typeof gv[0] === 'number' && gv[0] > 0xff) {
        const h = Math.min(0xffffff, gv[0]) >>> 0;
        to = [(h >> 16) & 255, (h >> 8) & 255, h & 255, from[3]];
      } else {
        for (let i = 0; i < 4; i++) if (gv[i] !== undefined && gv[i] !== null) to[i] = num(gv[i], to[i]);
      }
    } else if (p === 'alpha' || p === 'fontsize' || p === 'radius' || p === 'borderw' || p === 'zindex') {
      kind = 'num';
      from = num(hooks.ui.get(name, p), 0);
      to = num(goal, from);
    } else return;
    uiTweens = uiTweens.filter((t) => !(t.name === name && t.prop === p));
    uiTweens.push({ name, prop: p, kind, from, to, dur: Math.max(0.001, dur), t: 0, ease: EASINGS[uiEaseName(String(easeName).toLowerCase())] || EASINGS.linear });
  }
  function tickUiTweens(dt) {
    if (!uiTweens.length) return;
    for (const tw of uiTweens) {
      tw.t += dt;
      if (!hooks.ui || !hooks.ui.find || !hooks.ui.find(tw.name)) { tw.t = tw.dur; continue; }
      const e = tw.ease(Math.min(1, tw.t / tw.dur));
      if (tw.kind === 'unit') {
        hooks.ui.set(tw.name, tw.prop, {
          px: tw.from.px + (tw.to.px - tw.from.px) * e,
          pr: tw.from.pr + (tw.to.pr - tw.from.pr) * e,
        }, true);
      } else if (tw.kind === 'col') {
        hooks.ui.set(tw.name, tw.prop, [0, 1, 2, 3].map((i) => tw.from[i] + (tw.to[i] - tw.from[i]) * e), true);
      } else {
        hooks.ui.set(tw.name, tw.prop, tw.from + (tw.to - tw.from) * e, true);
      }
    }
    uiTweens = uiTweens.filter((t) => t.t < t.dur);
  }
  function startTween(id, prop, goal, dur, easeName) {
    if (id === undefined || id === null || !engine.entity_ids().includes(id)) return;
    const off = { pos: 0, rot: 3, size: 6, color: 9 }[prop];
    let from, to;
    if (prop === 'alpha') {
      const cur = engine.get_props(id);
      from = num(cur[13], 1);
      to = num(goal, from);
    } else if (off !== undefined) {
      const cur = engine.get_props(id);
      from = [cur[off], cur[off + 1], cur[off + 2]];
      if (typeof goal === 'string') {
        const named = COLOR_NAMES[String(goal).toLowerCase()];
        to = named ? named.slice() : from.slice();
      } else if (Array.isArray(goal)) {
        to = [0, 1, 2].map((i) => (goal[i] === undefined ? from[i] : num(goal[i], from[i])));
      } else {
        to = [num(goal, from[0]), num(goal, from[1]), num(goal, from[2])];
      }
    } else return;
    tweens = tweens.filter((t) => !(t.id === id && t.prop === prop));
    tweens.push({ id, prop, from, to, dur: Math.max(0.001, dur), t: 0, ease: EASINGS[easeName] || EASINGS.linear });
  }
  function tickTweens(dt) {
    tickUiTweens(dt);
    if (fades.length) {
      const keepF = [];
      for (const f of fades) {
        f.t += dt;
        if (f.t >= f.dur) {
          if (engine.entity_ids().includes(f.id)) {
            engine.remove_entity(f.id);
            for (const k of Object.keys(names)) if (names[k] === f.id) delete names[k];
            tweens = tweens.filter((t) => t.id !== f.id);
          }
        } else keepF.push(f);
      }
      fades = keepF;
    }
    if (!tweens.length) return;
    for (const tw of tweens) {
      tw.t += dt;
      const e = tw.ease(Math.min(1, tw.t / tw.dur));
      const id = tw.id;
      if (id === undefined || !engine.entity_ids().includes(id)) continue;
      const cur = Array.from(engine.get_props(id));
      if (tw.prop === 'alpha') {
        cur[13] = tw.from + (tw.to - tw.from) * e;
      } else {
        const off = { pos: 0, rot: 3, size: 6, color: 9 }[tw.prop];
        for (let i = 0; i < 3; i++) cur[off + i] = tw.from[i] + (tw.to[i] - tw.from[i]) * e;
      }
      try { engine.set_props(id, new Float32Array(cur)); } catch (er) { /* ок */ }
    }
    tweens = tweens.filter((t) => t.t < t.dur);
  }

  /* ---------- волокна (wait/события) ---------- */
  let fibers = [];
  let clock = 0;
  function spawn(gen, kind, ctl) { fibers.push({ gen, kind: kind || 'x', resumeAt: clock, ctl: ctl || null }); }
  // содержит ли тело функции wait в СОБСТВЕННОМ теле (не через вложенные вызовы):
  // такая функция-оператор = фоновая задача; обёртки без wait остаются синхронными
  function suspends(node, seen) {
    if (!node || typeof node !== 'object') return false;
    if (Array.isArray(node)) return node.some((x) => suspends(x, seen));
    if (node.k === 'call') {
      const p = String(node.path || '').replace(/^@/, '').toLowerCase();
      return p === 'wait' || p.endsWith('.wait');
    }
    if (node.k === 'exprstmt' || node.k === 'return') return suspends(node.e, seen);
    if (node.k === 'block') return suspends(node.body, seen);
    if (node.k === 'if') {
      return suspends(node.nested, seen) || suspends(node.body, seen) || suspends(node.els, seen);
    }
    if (node.k === 'wtd') return suspends(node.body, seen);
    return false;
  }
  function stmtSuspending(fdef) {
    return !!fdef && suspends(fdef.body || [], new Set());
  }
  function spawnExec(stmts, env, kind) {
    const ctl = { slices: 0 };
    env.__ctl = ctl;
    spawn(exec(stmts, env), kind, ctl);
  }
  function hasFiber(kind) { return fibers.some((f) => f.kind === kind); }
  function tickFibers() {
    if (!fibers.length) return;
    const now = clock;
    const keep = [];
    for (const f of fibers) {
      if (f.resumeAt > now) { keep.push(f); continue; }
      let r;
      try { r = f.gen.next(); } catch (e) {
        if (!(e instanceof RetSig)) err = String(e);
        continue;
      }
      if (!r.done) {
        const w = Math.max(0, num(r.value, 0));
        if (w > 0 && f.ctl) f.ctl.slices = 0;
        f.resumeAt = now + w;
        keep.push(f);
      }
    }
    fibers = keep;
  }

  /* ---------- функции: разбор аргументов из заголовка ---------- */
  function fixFuncArgs(src) {
    // повторно проходим исходник, чтобы забрать имена аргументов @F.name(a, b)
    const re = /@F\.([\w.]+)\s*\(([^)]*)\)\s*=/g;
    let m;
    while ((m = re.exec(src))) {
      const name = m[1].toLowerCase();
      const args = m[2].split(',').map((x) => x.trim()).filter(Boolean);
      if (F[name] && (!F[name].argNames || !F[name].argNames.length)) F[name].argNames = args;
    }
  }

  /* ---------- публичный API ---------- */
  return {
    _tokens: tokenize,
    load(src) {
      for (const k of Object.keys(V)) delete V[k];
      for (const k of Object.keys(B)) delete B[k];
      for (const k of Object.keys(F)) delete F[k];
      E.start = null; E.update = null; E.click = null; E.key = null; E.draw = null;
      for (const k of Object.keys(names)) delete names[k];
      created = [];
      err = '';
      warned = false;
      tweens = [];
      fades = [];
      uiTweens = [];
      fibers = [];
      try {
        this._raw = parse(src);
        const flat = assembleEvents(assemble(parse(src)));
        fixFuncArgs(src);
        this._flat = flat;
      } catch (e) {
        err = String(e);
        this._flat = [];
      }
      return err;
    },
    call(name, args) {
      const fname = String(name || '').toLowerCase().replace(/^@?f\.?/, '');
      const f = F[fname];
      if (!f) return undefined;
      budget = 800000;
      const local = {};
      const namesArgs = f.argNames || [];
      const av = Array.isArray(args) ? args : [];
      for (let i = 0; i < namesArgs.length; i++) local[namesArgs[i]] = i < av.length ? av[i] : 0;
      const env = { ...local, dt: 0.016, __f: 1 };
      try {
        if (stmtSuspending(f)) {
          spawnExec(f.body, env, 'f');
          tickFibers();
          return null;
        }
        const it = exec(f.body, env, 'main');
        let r = it.next();
        while (!r.done && r.value && r.value.w !== undefined) r = it.next();
        return r.done ? (r.value === undefined ? null : r.value) : null;
      } catch (er) {
        if (er instanceof RetSig) return er.v;
        throw er;
      }
    },
    start() {
      budget = 800000;
      err = '';
      clock = 0;
      fibers = [];
      if (this._flat && this._flat.length) spawnExec(this._flat, {}, 'main');
      if (E.start) spawnExec(E.start.body, {}, 'main');
      tickFibers();
      applyStats();
    },
    update(dt) {
      budget = 400000;
      err = '';
      clock += num(dt, 0.016);
      tickTweens(num(dt, 0.016));
      if (E.update && !hasFiber('upd')) {
        const env = {};
        if (E.update.args && E.update.args[0]) env[E.update.args[0]] = dt;
        env.dt = dt;
        spawnExec(E.update.body, env, 'upd');
      }
      if (E.draw && !hasFiber('draw')) {
        const env = { dt };
        spawnExec(E.draw.body, env, 'draw');
      }
      tickFibers();
      return err;
    },
    event(name, args) {
      const key = String(name || '').toLowerCase();
      const h = E[key];
      if (!h) return;
      const env = { dt: 0.016 };
      if (h.args && h.args[0] && args && args.length) env[h.args[0]] = args[0];
      spawnExec(h.body, env, 'ev' + key + (Math.random() * 1e9 | 0));
    },
    stop() {
      fibers = [];
      tweens = [];
      for (const id of created) {
        if (engine.entity_ids().includes(id)) engine.remove_entity(id);
      }
      created = [];
    },
    get(p) { return getPath(p); },
    set(p, v) { setPath(p, v); },
    vars() { return V; },
    error() { return err; },
  };
}

// ================= ЛИНТЕР И ФОРМАТТЕР HGS =================
const KNOWN_EVENTS = ['OnStart', 'OnUpdate', 'OnDraw', 'OnKey', 'OnKeyDown', 'OnClick', 'OnHover', 'OnCollide'];

export function lint(src) {
  const errs = [];
  let T;
  try {
    T = tokenizeH(src);
  } catch (e) {
    errs.push({ line: e && e.line ? e.line : 1, msg: String(e && e.message ? e.message : e) });
    return errs;
  }
  let depth = 0;
  const fdefs = [];
  for (let i = 0; i < T.length; i++) {
    const tk = T[i];
    if (tk.t === '{') depth++;
    if (tk.t === '}') { depth--; if (depth < 0) { errs.push({ line: tk.line, msg: 'лишняя }' }); depth = 0; } }
    if (tk.t === 'at' && typeof tk.v === 'string' && tk.v.startsWith('@F.')) {
      const name = tk.v.slice(3);
      // пропускаем (args)
      let j = i + 1;
      let paren = 0;
      if (T[j] && T[j].t === '(') {
        paren = 1; j++;
        while (j < T.length && paren > 0) {
          if (T[j].t === '(') paren++;
          if (T[j].t === ')') paren--;
          j++;
        }
      }
      const nxt = T[j];
      const nx2 = T[j + 1];
      if (nxt && nxt.t === 'op' && nxt.v === '=') {
        fdefs.push({ name, line: tk.line, closed: false, sure: true });
      } else if (nxt && nxt.t === 'nl') {
        fdefs.push({ name, line: tk.line, closed: false, sure: false }); // блочный заголовок или вызов
      } else if (nxt && nxt.t === 'dot' && nx2 && nx2.t === 'kw' && nx2.v === 'end') {
        let m = null;
        for (let q = fdefs.length - 1; q >= 0; q--) if (fdefs[q].name === name && !fdefs[q].closed) { m = fdefs[q]; break; }
        if (m) m.closed = true;
        else if (!fdefs.some((f) => f.name === name)) errs.push({ line: tk.line, msg: `@F.${name}.end без определения` });
      }
    }
    if (tk.t === 'kw' && tk.v === 'break') {
      const nx = T[i + 1];
      if (nx && ((nx.t === 'id') || (nx.t === 'kw' && nx.v !== 'WTD')) && nx.v !== 'WTD') {
        errs.push({ line: tk.line, msg: `break ${nx.v}: допустим только break WTD` });
      }
    }
    if (tk.t === 'kw' && tk.v === 'continue') {
      const nx = T[i + 1];
      if (nx && ((nx.t === 'id') || (nx.t === 'kw' && nx.v !== 'WTD')) && nx.v !== 'WTD') {
        errs.push({ line: tk.line, msg: `continue ${nx.v}: допустим только continue WTD` });
      }
    }
    if (tk.t === 'at' && typeof tk.v === 'string' && !/^@[WPCLFESI](\.|$)/.test(tk.v) && !tk.v.startsWith('@UI') && !tk.v.startsWith('@LIB') && tk.v !== '@P') {
      errs.push({ line: tk.line, msg: `неизвестная секция ${tk.v}` });
    }
    if (tk.t === 'kw' && tk.v === 'WTD') {
      if (i > 0 && T[i - 1] && T[i - 1].t === 'kw' && (T[i - 1].v === 'break' || T[i - 1].v === 'continue')) continue;
      let d = 0, saw = false, hasBreak = false, hasWait = false, j = i;
      while (j < T.length) {
        const q = T[j];
        if (q.t === '{') { d++; saw = true; }
        if (q.t === '}') { d--; if (saw && d <= 0) break; }
        if (saw && q.t === 'kw' && q.v === 'break') hasBreak = true;
        if (saw && q.t === 'id' && q.v === 'wait') hasWait = true;
        j++;
      }
      if (!hasBreak && !hasWait) errs.push({ line: tk.line, msg: 'WTD без break WTD — бесконечный цикл; код «каждый кадр» пишите в @E.OnUpdate(dt)' });
    }
  }
  if (depth > 0) errs.push({ line: T.length ? T[T.length - 1].line : 1, msg: `незакрытых { : ${depth}` });
  for (const f of fdefs) if (!f.closed && f.sure) errs.push({ line: f.line, msg: `у @F.${f.name} нет .end` });

  // события @E.X ... @E.End()
  let ev = null;
  for (let i = 0; i < T.length; i++) {
    const tk = T[i];
    if (tk.t === 'at' && typeof tk.v === 'string' && (tk.v.startsWith('@E.') || tk.v.startsWith('@S.'))) {
      const name = tk.v.slice(3);
      if (name === 'End') {
        if (!ev) errs.push({ line: tk.line, msg: '@E.End() без @E.OnStart/OnUpdate' });
        ev = null;
      } else {
        if (ev) errs.push({ line: tk.line, msg: `@E.${name}: событие @E.${ev} не закрыто @E.End()` });
        if (!KNOWN_EVENTS.includes(name)) errs.push({ line: tk.line, msg: `неизвестное событие @E.${name} (есть: ${KNOWN_EVENTS.join(', ')})` });
        ev = name;
      }
    }
  }
  if (ev) errs.push({ line: T.length ? T[T.length - 1].line : 1, msg: `@E.${ev} не закрыто @E.End()` });
  return errs;
}

// Токенайзер, доступный снаружи (для форматтера)
function tokenizeH(src) {
  const rt = createRuntime({}, {});
  return rt._tokens(src);
}

export function format(src) {
  const out = [];
  let ind = 0;
  for (let raw of src.split('\n')) {
    let line = raw.replace(/\s+$/, '').replace(/[ \t]{2,}/g, ' ');
    const t = line.trim();
    if (!t) { out.push(''); continue; }
    if (t.startsWith('}')) ind = Math.max(0, ind - 1);
    if (t.startsWith(']')) ind = Math.max(0, ind - 1);
    let pad = ind;
    if (t.startsWith('@E.') || t.startsWith('@S.') || t.startsWith('@W.') || t.startsWith('@P.') || t.startsWith('@L.') || t.startsWith('@F.') || t.startsWith('@C.')) pad = 0;
    out.push('  '.repeat(pad) + t);
    if (t.endsWith('{')) ind++;
    if (t.endsWith('[')) ind++;
  }
  return out.join('\n');
}
