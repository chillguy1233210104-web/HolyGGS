/* lang.js — интерпретатор языка HolyGGS (@W @P @L @F @C @E).
   Грамматика: см. Readme.txt. Выполняется с бюджетом шагов (защита от WTD). */
export function createRuntime(engine, hooks = {}) {
  const selfId = hooks.selfId;
  const V = {};       // переменные @L / @P (вложенные)
  const B = {};       // живые привязки: путь -> источник
  const F = {};       // функции
  const E = { start: null, update: null };
  const names = {};   // имя объекта @W -> id
  let created = [];   // id, созданные скриптом (для очистки)
  let budget = 0;
  let err = '';

  /* ---------- токенизатор ---------- */
  function tokenize(src) {
    const T = [];
    let i = 0;
    const n = src.length;
    let line = 1;
    const push = (t, v) => T.push({ t, v, line });
    while (i < n) {
      const c = src[i];
      if (c === '\n') { push('nl'); i++; line++; continue; }
      if (c === ' ' || c === '\t' || c === '\r') { i++; continue; }
      if (c === '#') {
        const m2 = /^#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})(?![0-9a-fA-FwW])/.exec(src.slice(i));
        if (m2 && /[),\s]/.test(src[i + m2[0].length] || ')')) {
          push('color', m2[1]);
          i += m2[0].length;
          continue;
        } while (i < n && src[i] !== '\n') i++; continue; }
      if (c === ';') { push('nl'); i++; continue; }
      if ('(){}[],'.includes(c)) { push(c); i++; continue; }
      if (c === '"') {
        let s = ''; i++;
        while (i < n && src[i] !== '"') { if (src[i] === '\\') i++; s += src[i++]; }
        i++; push('str', s); continue;
      }
      if ('=<>!:+-*/%'.includes(c)) {
        let op = c; i++;
        if (i < n && '=<>'.includes(src[i]) && (c === '=' || c === '!' || c === '<' || c === '>')) op += src[i++];
        else if (c === '*' && src[i] === '*') op = '**', i++;
        else if (c === '%' && src[i] === '=') op = '%=', i++;
        else if (c === '+' && src[i] === '=') op = '+=', i++;
        else if (c === '-' && src[i] === '=') op = '-=', i++;
        else if (c === '*' && src[i] === '=') op = '*=', i++;
        else if (c === '/' && src[i] === '=') op = '/=', i++;
        push('op', op); continue;
      }
      if (c === '.') {
        if (src[i + 1] === '.') { push('op', '..'); i += 2; continue; }
        if (/[0-9]/.test(src[i + 1] || '')) { /* число */ }
        else { push('dot'); i++; continue; }
      }
      if (/[0-9.]/.test(c)) {
        let s = '';
        while (i < n && /[0-9.eE+-]/.test(src[i])) {
          if ((src[i] === '+' || src[i] === '-') && !/[eE]/.test(s[s.length - 1] || '')) break;
          s += src[i++];
        }
        push('num', parseFloat(s)); continue;
      }
      if (/[A-Za-zА-Яа-яЁё_@]/.test(c)) {
        let s = '';
        while (i < n && /[A-Za-zА-Яа-яЁё0-9_.@]/.test(src[i])) s += src[i++];
        if (s.startsWith('@')) push('at', s);
        else if (s === 'if' || s === 'else' || s === 'WTD' || s === 'break' || s === 'end') push('kw', s);
        else push('id', s);
        continue;
      }
      i++;
    }
    return T;
  }

  /* ---------- парсер ---------- */
  function parse(src) {
    const T = tokenize(src);
    let p = 0;
    const peek = (o = 0) => T[p + o];
    const eat = () => T[p++];
    const pt = (o = 0) => (T[p + o] ? T[p + o].t : 'eof');
    const pv = (o = 0) => (T[p + o] ? T[p + o].v : undefined);
    const isOp = (v) => pt() === 'op' && pv() === v;
    const skipNl = () => { while (peek() && pt() === 'nl') p++; };

    function parseExpr() { return parseCmp(); }
    function parseGlue() {
      let a = parseAdd();
      while (pt() === 'op' && pv() === '..') {
        eat(); a = { k: 'bin', op: '..', a, b: parseAdd() };
      }
      return a;
    }
    function parseCmp() {
      let a = parseGlue();
      while (pt() === 'op' && ['>', '<', '>=', '<=', '==', '!='].includes(pv())) {
        const op = eat().v; a = { k: 'bin', op, a, b: parseGlue() };
      }
      return a;
    }
    function parseAdd() {
      let a = parseMul();
      while (pt() === 'op' && (pv() === '+' || pv() === '-')) {
        const op = eat().v; a = { k: 'bin', op, a, b: parseMul() };
      }
      return a;
    }
    function parseMul() {
      let a = parseUn();
      while (pt() === 'op' && (pv() === '*' || pv() === '/' || pv() === '%')) {
        const op = eat().v; a = { k: 'bin', op, a, b: parseUn() };
      }
      return a;
    }
    function parseUn() {
      if (isOp('-')) { eat(); return { k: 'neg', a: parseUn() }; }
      return parsePow();
    }
    function parsePow() {
      let a = parseAtom();
      if (isOp('**')) { eat(); return { k: 'bin', op: '**', a, b: parseUn() }; }
      return a;
    }
    function parseAtom() {
      const t = peek();
      if (!t) return { k: 'num', v: 0 };
      if (t.t === 'num') { eat(); return { k: 'num', v: t.v }; }
      if (t.t === 'str') { eat(); return { k: 'str', v: t.v }; }
      if (t.t === 'color') { eat(); return { k: 'color', v: t.v }; }
      if (t.t === 'none' || (t.t === 'id' && t.v === 'none')) { eat(); return { k: 'none' }; }
      if (t.t === '(') {
        eat();
        const items = [];
        while (peek() && pt() !== ')' && pt() !== 'nl') {
          items.push(parseExpr());
          if (pt() === ',') eat();
          else break;
        }
        if (pt() === ')') eat();
        return items.length === 1 ? items[0] : { k: 'tuple', items };
      }
      if (t.t === '[') {
        eat();
        let path = '';
        while (peek() && pt() !== ']') path += eat().v ?? '';
        eat();
        return { k: 'ref', path: path.trim() };
      }
      if (t.t === 'at') {
        eat();
        return { k: 'ref', path: t.v.replace(/^@/, '') };
      }
      if (t.t === 'id') {
        eat();
        if (pt() === '(') {
          const args = parseArgs();
          return { k: 'call', path: t.v, args };
        }
        return { k: 'str', v: t.v };
      }
      eat();
      return { k: 'num', v: 0 };
    }
    function parseArgs() {
      eat(); // (
      const args = [];
      while (peek() && pt() !== ')') {
        let key = null;
        if ((pt() === 'id' || pt() === 'at') && pt(1) === 'op' && pv(1) === ':') {
          key = eat().v; eat();
        }
        args.push({ key, e: parseExpr() });
        if (pt() === ',') eat();
      }
      eat(); // )
      return args;
    }

    function parseObj() {
      eat(); // {
      const props = [];
      while (peek() && pt() !== '}') {
        skipNl();
        if (pt() === '}') break;
        const name = eat().v;
        const args = pt() === '(' ? parseArgs() : [];
        props.push({ name, args });
        if (pt() === ',') eat();
        skipNl();
      }
      eat(); // }
      return props;
    }

    function parseBlockStmts(stopKw) {
      const out = [];
      skipNl();
      while (peek()) {
        if (pt() === 'kw' && stopKw.includes(pv())) break;
        if (pt() === '}' || pt() === ']') break;
        const s = parseStmt();
        if (s) out.push(s);
        skipNl();
      }
      return out;
    }

    function parseBraceBlock() {
      // { ... } — блок операторов (условие/код)
      eat(); // {
      const body = parseBlockStmts([]);
      if (pt() === '}') eat();
      return body;
    }

    function parseIfInner() {
      // if COND { ... } else { ... }  |  if { COND; ... } else { ... }
      if (!(pt() === 'kw' && pv() === 'if')) return null;
      eat();
      let cond, body;
      if (pt() === '{') {
        const inner = parseBraceBlock();
        if (inner.length && inner[0].k === 'exprstmt') {
          cond = inner[0].e; body = inner.slice(1);
        } else if (inner.length && inner[0].k === 'cond') {
          cond = inner[0].e; body = inner.slice(1);
        } else {
          cond = { k: 'num', v: 1 }; body = inner;
        }
      } else {
        cond = parseExpr();
        skipNl();
        body = pt() === '{' ? parseBraceBlock() : [];
      }
      let els = [];
      skipNl();
      if (pt() === 'kw' && pv() === 'else') {
        eat(); skipNl();
        if (pt() === 'kw' && pv() === 'if') {
          els = [{ k: 'if', cond: null, body: null, nested: parseIfInner() }];
        } else {
          els = pt() === '{' ? parseBraceBlock() : [];
        }
      }
      return { k: 'if', cond, body, els };
    }

    function parseStmt() {
      skipNl();
      const t = peek();
      if (!t) return null;
      if (t.t === '[') {
        let o = 1;
        while (peek(o) && pt(o) === 'nl') o++;
        const inner = peek(o);
        if (!(inner && inner.t === 'kw' && (inner.v === 'if' || inner.v === 'WTD'))) {
          return { k: 'exprstmt', e: parseExpr() };
        }
        eat();
        skipNl();
        let s = null;
        if (pt() === 'kw' && pv() === 'if') s = parseIfInner();
        else if (pt() === 'kw' && pv() === 'WTD') {
          const body = pt(1) === '{' ? (eat(), parseBraceBlock()) : [];
          s = { k: 'wtd', body };
        } else s = { k: 'block', body: parseBlockStmts([]) };
        skipNl();
        if (pt() === ']') eat();
        return s;
      }
      if (t.t === 'kw' && t.v === 'if') return parseIfInner();
      if (t.t === 'kw' && t.v === 'WTD') {
        eat();
        const body = pt() === '{' ? parseBraceBlock() : [];
        return { k: 'wtd', body };
      }
      if (t.t === 'kw' && t.v === 'break') {
        eat();
        let target = '';
        if (pt() === 'id' || pt() === 'kw') target = eat().v;
        return { k: 'break', target };
      }
      if (t.t === 'at') {
        eat();
        const path = t.v.replace(/^@/, '');
        if (pt() === 'op' && pv() === '=') {
          eat();
          if (path.startsWith('W.') && pt() === '{') {
            const props = parseObj();
            let attach = null;
            if (pt() === 'op' && pv() === '..') {
              eat();
              attach = parseExpr();
            }
            return { k: 'wset', path, props, attach };
          }
          if (path === 'LIB' && pt() === '{') {
            return { k: 'libmeta', props: parseObj() };
          }
          return { k: 'assign', path, e: parseExpr() };
        }
        if (pt() === 'op' && ['+=', '-=', '*=', '/='].includes(pv())) {
          const op = eat().v;
          return { k: 'assign', path, op, e: parseExpr() };
        }
        if (pt() === 'op' && pv() === ':') {
          eat();
          return { k: 'bind', path, e: parseExpr() };
        }
        if (pt() === 'op' && pv() === '..') {
          eat();
          return { k: 'attach', path, e: parseExpr() };
        }
        if (pt() === '(') {
          const args = parseArgs();
          if (pt() === 'dot' && pt(1) === 'kw' && pv(1) === 'end') {
            eat(); eat(); // .end
            return { k: 'end', path };
          }
          if (pt() === 'op' && pv() === '=' && path.startsWith('F.')) {
            eat();
            return {
              k: 'fdef_head', path, e: parseExpr(),
              argNames: args.map((a) => (a.e && a.e.k === 'str' ? a.e.v : (a.key || ''))).filter(Boolean),
            };
          }
          return { k: 'call', path, args };
        }
        return { k: 'refstmt', path };
      }
      if (t.t === 'id') {
        eat();
        if (pt() === '(') {
          const args = parseArgs();
          return { k: 'call', path: t.v, args };
        }
        return { k: 'exprstmt', e: { k: 'str', v: t.v } };
      }
      if (t.t === 'num' || t.t === 'str' || t.t === '[') {
        return { k: 'exprstmt', e: parseExpr() };
      }
      eat();
      return null;
    }

    const stmts = parseBlockStmts([]);
    return stmts;
  }

  /* ---------- сборка событий/функций из плоского списка ---------- */
  function assemble(stmts) {
    const out = [];
    let i = 0;
    while (i < stmts.length) {
      const s = stmts[i];
      if (s.k === 'fdef_head' && s.path.startsWith('F.')) {
        // ищем .end с тем же именем
        const name = s.path.slice(2);
        const body = [];
        i++;
        let depth = 1;
        while (i < stmts.length) {
          const t = stmts[i];
          if (t.k === 'end' && t.path.slice(2) === name) { i++; break; }
          if (t.k === 'fdef_head' && t.path.slice(2) === name) depth++;
          body.push(t);
          i++;
        }
        F[name.toLowerCase()] = {
          argNames: s.argNames || [],
          body: [{ k: 'exprstmt', e: s.e }].concat(body),
          head: s,
        };
        continue;
      }
      out.push(s);
      i++;
    }
    return out;
  }

  function assembleEvents(stmts) {
    const out = [];
    let i = 0;
    while (i < stmts.length) {
      const s = stmts[i];
      if (s.k === 'call' && /^(E\.|S\.)?(OnStart|OnUpdate|OnClick|OnKey|OnDraw|OnKeyDown)$/.test(s.path)) {
        const keyMap = { OnStart: 'start', OnUpdate: 'update', OnClick: 'click', OnKey: 'key', OnKeyDown: 'key', OnDraw: 'draw' };
        const name = keyMap[s.path.split('.').pop()] || 'start';
        const args = s.args.map((a) => (a.e && (a.e.path || a.e.v)) || '');
        const body = [];
        i++;
        while (i < stmts.length) {
          const t2 = stmts[i];
          const isEnd = (t2.k === 'end' && /On(Start|Update)/.test(t2.path))
            || (t2.k === 'call' && /^([ES]\.)?End$/i.test(t2.path));
          if (isEnd) break;
          body.push(t2); i++;
        }
        i++; // .end
        E[name] = { args, body };
        continue;
      }
      out.push(s);
      i++;
    }
    return out;
  }

  /* ---------- выполнение ---------- */
  const strip = (path) => path.replace(/^(L|P|W)\.(?=[A-ZА-ЯЁё_])/i, '').replace(/^@/, '');
  function lookup1(o, k) {
    if (o === null || o === undefined) return undefined;
    if (Array.isArray(o)) {
      const AX = { x: 0, y: 1, z: 2, w: 3 };
      const idx = AX[k] !== undefined ? AX[k] : (/^\d+$/.test(k) ? +k : -1);
      return idx >= 0 && idx < o.length ? o[idx] : undefined;
    }
    if (typeof o !== 'object') return undefined;
    return k in o ? o[k] : undefined;
  }
  function lookup(obj, path) {
    let o = obj;
    for (const k of path.split('.')) {
      o = lookup1(o, k);
      if (o === undefined) return undefined;
    }
    return o;
  }
  function getPath(path) {
    if (path in B) return getPath(B[path]);
    const sp0 = strip(path);
    const parts = sp0.split('.');
    // живая ссылка с хвостом компонент: [Pos.x] при @L.Pos : @P.pos
    if (parts.length > 1 && parts[0] in B) {
      return getPath(B[parts[0]] + '.' + parts.slice(1).join('.'));
    }
    const tail = (v, i) => (i >= parts.length ? v : lookup(v, parts.slice(i).join('.')));
    // Self.<pos|size|dist|name> — сам объект (скрипты объектов)
    if (parts[0] === 'Self' && selfId !== undefined && selfId !== null) {
      const b = parts[1] || 'pos';
      if (b === 'name') return tail(engine.entity_name(selfId), 2);
      const props = engine.get_props(selfId);
      if (b === 'pos') return tail([props[0], props[1], props[2]], 2);
      if (b === 'size') return tail([props[6], props[7], props[8]], 2);
      if (b === 'dist') {
        const p = engine.player_pos();
        return tail(Math.hypot(props[0] - p[0], props[1] - p[1], props[2] - p[2]), 2);
      }
    }
    // pos / P.pos / Player.pos (+компоненты .x/.y/.z)
    const isPl = parts[0] === 'P' || parts[0] === 'Player';
    if ((isPl && parts[1] === 'pos') || (parts.length === 1 && parts[0] === 'pos')) {
      const p = engine.player_pos();
      return tail([p[0], p[1], p[2]], isPl ? 2 : 1);
    }
    const direct = lookup(V, sp0);
    if (direct !== undefined) return direct;
    const directRaw = lookup(V, path);
    if (directRaw !== undefined) return directRaw;
    if (parts.length >= 2 && names[parts[0]] !== undefined) {
      const id = names[parts[0]];
      const props = engine.get_props(id);
      const b = parts[1];
      if (b === 'pos') return tail([props[0], props[1], props[2]], 2);
      if (b === 'size') return tail([props[6], props[7], props[8]], 2);
      if (b === 'dist') {
        const p = engine.player_pos();
        return tail(Math.hypot(props[0] - p[0], props[1] - p[1], props[2] - p[2]), 2);
      }
    }
    const sp = strip(path);
    if (sp !== path) {
      const v = lookup(V, sp);
      if (v !== undefined) return v;
    }
    const fl = lookup(V.L, path);
    return fl !== undefined ? fl : lookup(V.P, path);
  }
  function setPath(path, val) {
    const sp = strip(path);
    delete B[path]; delete B[sp];
    const parts = sp.split('.');
    // запись в свойства объекта: Name.pos[.x], Name.size[.y], Name.rot[.z] — двигает/масштабирует объект
    if (parts.length >= 2 && names[parts[0]] !== undefined && ['pos', 'size', 'rot'].includes(parts[1])) {
      const id = names[parts[0]];
      const props = Array.from(engine.get_props(id));
      const off = parts[1] === 'pos' ? 0 : parts[1] === 'size' ? 6 : 3;
      if (parts.length >= 3) {
        const comp = ({ x: 0, y: 1, z: 2 })[parts[2]];
        if (comp !== undefined) props[off + comp] = num(val, props[off + comp]);
      } else if (Array.isArray(val)) {
        props[off] = num(val[0], props[off]);
        props[off + 1] = num(val[1], props[off + 1]);
        props[off + 2] = num(val[2], props[off + 2]);
      }
      engine.set_props(id, new Float32Array(props));
      return;
    }
    let o = V;
    for (let i = 0; i < parts.length - 1; i++) {
      if (typeof o[parts[i]] !== 'object' || o[parts[i]] === null) o[parts[i]] = {};
      o = o[parts[i]];
    }
    o[parts[parts.length - 1]] = val;
    if (['Speed', 'Jump', 'Size', 'P.Speed', 'P.Jump', 'P.Size'].includes(sp)) applyStats();
  }
  function applyStats() {
    if (hooks.setStats) {
      const g = (k, d) => {
        const v = getPath(k);
        return typeof v === 'number' && isFinite(v) ? v : d;
      };
      hooks.setStats(g('Speed', 8), g('Jump', 2.6), g('Size', 1));
    }
  }
  function num(v, d) { return typeof v === 'number' && isFinite(v) ? v : d; }

  function interpStr(s) {
    return String(s).replace(/\[([^\]]+)\]/g, (_, p) => {
      const v = getPath(p.trim());
      return v === undefined ? '' : Array.isArray(v) ? v.map((x) => Math.round(x * 1000) / 1000).join(', ') : String(v);
    });
  }

  /* ---------- исполнение (генераторы: поддержка wait/событий) ---------- */
  let warned = false;
  const COLOR_NAMES = {
    gold: [1, 0.84, 0], yellow: [1, 0.9, 0.2], red: [0.9, 0.2, 0.16], green: [0.3, 0.75, 0.35],
    blue: [0.25, 0.5, 0.95], white: [1, 1, 1], black: [0.05, 0.05, 0.07], gray: [0.55, 0.57, 0.6],
    grey: [0.55, 0.57, 0.6], orange: [1, 0.6, 0.15], purple: [0.65, 0.35, 0.85], pink: [0.95, 0.55, 0.7],
    brown: [0.55, 0.35, 0.2], cyan: [0.2, 0.8, 0.85], teal: [0.15, 0.65, 0.6], lime: [0.6, 0.9, 0.25],
    silver: [0.75, 0.77, 0.8], navy: [0.15, 0.2, 0.5],
  };
  const MATERIALS = {
    stone: { mat: 0 }, dirt: { mat: 0, color: [0.55, 0.42, 0.28] },
    glass: { mat: 1, alpha: 0.18 }, sand: { mat: 2 },
    wood: { mat: 3 }, leaves: { mat: 3, color: [0.36, 0.62, 0.26] },
    planks: { mat: 4 }, iron: { mat: 0, rough: 0.2, color: [0.62, 0.64, 0.68] },
    water: { water: 1 }, neon: { neon: 1 },
  };
  function resolvePos(v) {
    if (Array.isArray(v)) return v;
    if (typeof v === 'string') {
      const nm = v.includes('.') ? v.split('.').pop() : v;
      const id = names[nm];
      if (id !== undefined) {
        const pr = engine.get_props(id);
        return [pr[0], pr[1], pr[2]];
      }
    }
    return [0, 0, 0];
  }
  function nameToId(p) {
    const sp = strip(String(p || '').replace(/^@/, ''));
    const nm = sp.includes('.') ? sp.split('.').pop() : sp;
    return names[nm];
  }

  function* evalE(e, env) {
    switch (e.k) {
      case 'num': return e.v;
      case 'str': return interpStr(e.v);
      case 'none': return null;
      case 'color': {
        const h = String(e.v);
        const nn = h.length === 3 ? h.split('').map((x) => x + x).join('') : h;
        return [parseInt(nn.slice(0, 2), 16) / 255, parseInt(nn.slice(2, 4), 16) / 255, parseInt(nn.slice(4, 6), 16) / 255];
      }
      case 'tuple': {
        const out = [];
        for (const it of e.items) out.push(yield* evalE(it, env));
        return out;
      }
      case 'neg': return -num(yield* evalE(e.a, env), 0);
      case 'ref': {
        if (env && e.path in env) return env[e.path];
        return getPath(e.path);
      }
      case 'call': return yield* runCall(e.path, e.args, env, true);
      case 'bin': {
        const a = yield* evalE(e.a, env);
        const b = yield* evalE(e.b, env);
        if (e.op === '..') {
          const sa = Array.isArray(a) ? fmt(a) : (a === null || a === undefined ? '' : a);
          const sb = Array.isArray(b) ? fmt(b) : (b === null || b === undefined ? '' : b);
          return String(sa) + String(sb);
        }
        if (e.op === '+') {
          if (Array.isArray(a) && Array.isArray(b)) return a.map((x, i) => num(x, 0) + num(b[i], 0));
          const av = a === undefined || a === null || a === '' ? 0 : a;
          const bv = b === undefined || b === null || b === '' ? 0 : b;
          if (typeof av === 'number' && typeof bv === 'number') return av + bv;
          return (a ?? '') + (b ?? '');
        }
        const x = num(a, 0), y = num(b, 0);
        switch (e.op) {
          case '-':
            if (Array.isArray(a) && Array.isArray(b)) return a.map((q, i) => num(q, 0) - num(b[i], 0));
            return x - y;
          case '*': return x * y;
          case '/': return y !== 0 ? x / y : 0;
          case '%': return y !== 0 ? x % y : 0;
          case '**': return Math.pow(x, y);
          case '>': return x > y ? 1 : 0;
          case '<': return x < y ? 1 : 0;
          case '>=': return x >= y ? 1 : 0;
          case '<=': return x <= y ? 1 : 0;
          case '==': return x === y || String(a) === String(b) ? 1 : 0;
          case '!=': return x === y || String(a) === String(b) ? 0 : 1;
        }
        return 0;
      }
    }
    return 0;
  }

  function* argVal(args, key, idx, env, dflt) {
    for (const a of args) {
      if (a.key === key) return yield* evalE(a.e, env);
    }
    if (args[idx] && !args[idx].key) return yield* evalE(args[idx].e, env);
    return dflt;
  }

  function* runCall(path, args, env, asExpr) {
    const p = path.replace(/^@/, '');
    const low = p.toLowerCase();
    const lowBare = low.replace(/^(l|p)\./, '');
    // wait(n) — пауза в секундах (0 = один кадр)
    if (low === 'wait') {
      const secs = num(yield* argVal(args, 'n', 0, env, 0), 0);
      yield Math.max(0, secs);
      return 1;
    }
    // встроенные функции (§15)
    if (low === 'root' || lowBare === 'root') {
      return Math.sqrt(Math.abs(num(yield* argVal(args, 'x', 0, env, 0), 0)));
    }
    if (low === 'pow' || lowBare === 'pow') {
      return Math.pow(num(yield* argVal(args, 'x', 0, env, 0), 0), num(yield* argVal(args, 'y', 1, env, 0), 0));
    }
    const D2R = Math.PI / 180;
    if (low === 'sin' || lowBare === 'sin') return Math.sin(num(yield* argVal(args, 'x', 0, env, 0), 0) * D2R);
    if (low === 'cos' || lowBare === 'cos') return Math.cos(num(yield* argVal(args, 'x', 0, env, 0), 0) * D2R);
    if (low === 'tan' || lowBare === 'tan') return Math.tan(num(yield* argVal(args, 'x', 0, env, 0), 0) * D2R);
    if (low === 'abs' || lowBare === 'abs') return Math.abs(num(yield* argVal(args, 'x', 0, env, 0), 0));
    if (low === 'min' || lowBare === 'min') {
      return Math.min(num(yield* argVal(args, 'a', 0, env, 0), 0), num(yield* argVal(args, 'b', 1, env, 0), 0));
    }
    if (low === 'max' || lowBare === 'max') {
      return Math.max(num(yield* argVal(args, 'a', 0, env, 0), 0), num(yield* argVal(args, 'b', 1, env, 0), 0));
    }
    if (low === 'random' || lowBare === 'random') {
      const a0 = num(yield* argVal(args, 'min', 0, env, 0), 0);
      const b0 = num(yield* argVal(args, 'max', 1, env, 1), 1);
      return a0 + Math.random() * (b0 - a0);
    }
    if (low === 'length' || lowBare === 'length') {
      const v = yield* argVal(args, 'v', 0, env, 0);
      const p0 = Array.isArray(v) ? v : resolvePos(v);
      return Math.hypot(num(p0[0], 0), num(p0[1], 0), num(p0[2], 0));
    }
    if (low === 'dist' || lowBare === 'dist') {
      const a0 = resolvePos(yield* argVal(args, 'a', 0, env, 0));
      const b0 = resolvePos(yield* argVal(args, 'b', 1, env, 0));
      return Math.hypot(num(a0[0], 0) - num(b0[0], 0), num(a0[1], 0) - num(b0[1], 0), num(a0[2], 0) - num(b0[2], 0));
    }
    if (low === 'dot' || lowBare === 'dot') {
      const a0 = resolvePos(yield* argVal(args, 'a', 0, env, 0));
      const b0 = resolvePos(yield* argVal(args, 'b', 1, env, 0));
      return num(a0[0], 0) * num(b0[0], 0) + num(a0[1], 0) * num(b0[1], 0) + num(a0[2], 0) * num(b0[2], 0);
    }
    if (low === 'cross' || lowBare === 'cross') {
      const a0 = resolvePos(yield* argVal(args, 'a', 0, env, 0));
      const b0 = resolvePos(yield* argVal(args, 'b', 1, env, 0));
      return [
        num(a0[1], 0) * num(b0[2], 0) - num(a0[2], 0) * num(b0[1], 0),
        num(a0[2], 0) * num(b0[0], 0) - num(a0[0], 0) * num(b0[2], 0),
        num(a0[0], 0) * num(b0[1], 0) - num(a0[1], 0) * num(b0[0], 0),
      ];
    }
    if (low === 'lerp' || lowBare === 'lerp') {
      const a = yield* argVal(args, 'a', 0, env, 0);
      const b = yield* argVal(args, 'b', 1, env, 0);
      const tt = num(yield* argVal(args, 't', 2, env, 0), 0);
      if (Array.isArray(a) || Array.isArray(b)) {
        const pa = Array.isArray(a) ? a : [a, a, a];
        const pb = Array.isArray(b) ? b : [b, b, b];
        return pa.map((x, i) => num(x, 0) + (num(pb[i], 0) - num(x, 0)) * tt);
      }
      return num(a, 0) + (num(b, 0) - num(a, 0)) * tt;
    }
    if (low === 'find' || lowBare === 'find') {
      const v = yield* argVal(args, 'name', 0, env, 0);
      return String(v ?? '');
    }
    if (low === 'collide' || lowBare === 'collide') {
      const ida = nameToId(String(yield* argVal(args, 'a', 0, env, 0) ?? ''));
      const idb = nameToId(String(yield* argVal(args, 'b', 1, env, 0) ?? ''));
      if (ida === undefined || idb === undefined) return 0;
      const pa = engine.get_props(ida), pb = engine.get_props(idb);
      const dx = Math.abs(pa[0] - pb[0]), dy = Math.abs(pa[1] - pb[1]), dz = Math.abs(pa[2] - pb[2]);
      return (dx < (pa[6] + pb[6]) / 2 && dy < (pa[7] + pb[7]) / 2 && dz < (pa[8] + pb[8]) / 2) ? 1 : 0;
    }
    if (low === 'raycast' || lowBare === 'raycast') return null;
    if (lowBare === 'text.pr' || lowBare === 'text.print' || lowBare === 'pr') {
      const parts = [];
      for (const a of args) {
        const v = yield* evalE(a.e, env);
        parts.push(a.key ? `${a.key}: ${fmt(v)}` : fmt(v));
      }
      if (hooks.print) hooks.print(parts.join(' '));
      return 1;
    }
    if (low === 'w.destroy') {
      const a = args.find((x) => x.key === 'obj') || args[0];
      let nm = null;
      let obj = null;
      if (a && a.e && a.e.k === 'ref') {
        nm = a.e.path.split('.').pop();
        obj = names[nm];
      } else {
        obj = yield* argVal(args, 'obj', 0, env, null);
        nm = String(obj ?? '');
      }
      const id = typeof obj === 'number' ? obj : names[nm];
      if (id !== undefined && id >= 0) {
        engine.remove_entity(id);
        for (const k of Object.keys(names)) if (names[k] === id) delete names[k];
      }
      return 1;
    }
    if (p.startsWith('W.')) {
      const rest = p.slice(2);
      const dot = rest.lastIndexOf('.');
      const nm = dot > 0 ? rest.slice(0, dot) : rest;
      const method = dot > 0 ? rest.slice(dot + 1) : '';
      const id = names[nm];
      if (id === undefined) return 0;
      if (method === 'move') {
        const t = yield* argVal(args, 'target', 0, env, null);
        const tp = Array.isArray(t) ? t : resolvePos(t);
        if (Array.isArray(tp)) {
          const props = engine.get_props(id);
          const spd = num(getPath(nm + '.Speed'), 5) * num(env && env.dt, 0.016);
          const dx = num(tp[0], 0) - props[0], dy = num(tp[1], 0) - props[1], dz = num(tp[2], 0) - props[2];
          const d = Math.hypot(dx, dy, dz) || 1;
          const k = Math.min(spd / d, 1);
          engine.set_props(id, new Float32Array([
            props[0] + dx * k, props[1] + dy * k, props[2] + dz * k,
            props[3], props[4], props[5], props[6], props[7], props[8],
            props[9], props[10], props[11], props[12], props[13], props[14], props[15], props[16], props[17], props[18] || 0, props[19] === undefined ? 0.35 : props[19],
          ]));
        }
        return 1;
      }
      if (method === 'tween') {
        const prop = String(yield* argVal(args, 'prop', 0, env, '') ?? '').toLowerCase();
        const goal = yield* argVal(args, 'to', 1, env, 0);
        const dur = num(yield* argVal(args, 'time', 2, env, 1), 1);
        const easeName = String(yield* argVal(args, 'easing', 3, env, 'linear') ?? 'linear').toLowerCase();
        startTween(nm, prop, goal, dur, easeName);
        return 1;
      }
      if (method === 'tp') {
        const t = yield* argVal(args, 'pos', 0, env, null);
        const tp = Array.isArray(t) ? t : resolvePos(t);
        if (Array.isArray(tp)) {
          const props = engine.get_props(id);
          engine.set_props(id, new Float32Array([
            num(tp[0], 0), num(tp[1], 0), num(tp[2], 0),
            props[3], props[4], props[5], props[6], props[7], props[8],
            props[9], props[10], props[11], props[12], props[13], props[14], props[15], props[16], props[17], props[18] || 0, props[19] === undefined ? 0.35 : props[19],
          ]));
        }
        return 1;
      }
      return 0;
    }
    const fname = low.replace(/^f\./, '');
    if (F[fname]) {
      const f = F[fname];
      const local = {};
      const namesArgs = f.argNames || [];
      for (let i = 0; i < namesArgs.length; i++) {
        local[namesArgs[i]] = f.head ? yield* argVal(args, namesArgs[i], i, env, 0) : 0;
      }
      yield* exec(f.body, { ...env, ...local, dt: env && env.dt });
      return 1;
    }
    return 0;
  }

  function fmt(v) {
    if (v === null || v === undefined) return '';
    if (Array.isArray(v)) return v.map((x) => Math.round(x * 100) / 100).join(', ');
    if (typeof v === 'number') return String(Math.round(v * 1000) / 1000);
    return String(v);
  }

  function budgetErr() {
    err = 'WTD: лимит итераций — похоже на бесконечный цикл без break WTD (код «каждый кадр» пишите в @E.OnUpdate)';
    if (!warned) { warned = true; if (hooks.print) hooks.print('HGS: ' + err); }
  }

  function* exec(stmts, env) {
    for (const s of stmts) {
      if (budget-- <= 0) { budgetErr(); return 'break'; }
      switch (s.k) {
        case 'block': {
          const r = yield* exec(s.body, env);
          if (r === 'break') return 'break';
          break;
        }
        case 'if': {
          if (s.nested) {
            const r = yield* exec([s.nested], env);
            if (r === 'break') return 'break';
            break;
          }
          const c = num(yield* evalE(s.cond, env), 0);
          const r = c ? yield* exec(s.body, env) : yield* exec(s.els, env);
          if (r === 'break') return 'break';
          break;
        }
        case 'wtd': {
          while (budget > 0) {
            const r = yield* exec(s.body, env);
            if (r === 'break') break;
          }
          break;
        }
        case 'break': return 'break';
        case 'assign': {
          const cur = getPath(s.path);
          const val = yield* evalE(s.e, env);
          if (s.op) {
            const c0 = num(cur, 0), x = num(val, 0);
            const r2 = s.op === '+=' ? c0 + x : s.op === '-=' ? c0 - x : s.op === '*=' ? c0 * x : (x !== 0 ? c0 / x : c0);
            setPath(s.path, r2);
          } else {
            setPath(s.path, val);
          }
          break;
        }
        case 'bind': {
          const src = s.e.k === 'ref' ? s.e.path : null;
          if (src) B[strip(s.path)] = src;
          else setPath(s.path, yield* evalE(s.e, env));
          break;
        }
        case 'attach': {
          const aid = nameToId(s.path);
          let bid;
          if (s.e && s.e.k === 'ref') bid = nameToId(s.e.path);
          else bid = nameToId(String(yield* evalE(s.e, env) ?? ''));
          if (aid !== undefined && bid !== undefined && aid !== bid) {
            try { engine.set_parent(aid, bid); } catch (e) { /* нет API */ }
          }
          break;
        }
        case 'wset': {
          const nm = s.path.slice(2);
          const props = { pos: [0, 0, 0], size: [1, 1, 1], color: [0.8, 0.8, 0.8], rot: [0, 0, 0], alpha: 1, mat: 0, neon: 0, shape: 0, rough: 0.35, water: 0 };
          const explicit = {};
          const ordered = [];
          for (const pr of s.props) {
            const vals = [];
            for (const a of pr.args) vals.push(yield* evalE(a.e, env));
            ordered.push([pr.name, vals]);
            explicit[pr.name] = true;
          }
          for (const [pn, vals] of ordered) {
            if (pn !== 'material') continue;
            const m = MATERIALS[String(vals[0] ?? '').toLowerCase()];
            if (m) {
              if (m.mat !== undefined) props.mat = m.mat;
              if (m.water !== undefined) props.water = m.water;
              if (m.neon !== undefined && !explicit.glow) props.neon = m.neon;
              if (m.alpha !== undefined && !explicit.alpha) props.alpha = m.alpha;
              if (m.color !== undefined && !explicit.color) props.color = m.color.slice();
              if (m.rough !== undefined && !explicit.rough) props.rough = m.rough;
            }
          }
          for (const [pn, vals] of ordered) {
            if (pn === 'pos') props.pos = vals.map((v, i) => num(v, props.pos[i] || 0));
            else if (pn === 'size') props.size = vals.map((v, i) => num(v, props.size[i] || 1));
            else if (pn === 'color') {
              if (Array.isArray(vals[0])) props.color = [0, 1, 2].map((i) => num(vals[0][i], 0.8));
              else {
                const named = typeof vals[0] === 'string' ? COLOR_NAMES[String(vals[0]).toLowerCase()] : null;
                props.color = [0, 1, 2].map((i) => (named ? named[i] : num(vals[i], 0.8)));
              }
            }
            else if (pn === 'rot') props.rot = vals.map((v, i) => num(v, props.rot[i] || 0));
            else if (pn === 'alpha') props.alpha = num(vals[0], 1);
            else if (pn === 'mat') props.mat = num(vals[0], 0);
            else if (pn === 'neon' || pn === 'glow') props.neon = (/^(true|yes|on|1)$/i.test(String(vals[0])) || num(vals[0], 0) > 0.5) ? 1 : 0;
            else if (pn === 'shape') props.shape = num(vals[0], 0);
            else if (pn === 'rough') props.rough = num(vals[0], 0.35);
          }
          let id = names[nm];
          const arr = new Float32Array([
            ...props.pos, ...props.rot, ...props.size, ...props.color,
            props.neon, props.alpha, props.water, 0, props.mat, 0, props.shape, props.rough,
          ]);
          if (id === undefined || !engine.entity_ids().includes(id)) {
            id = engine.add_entity(nm, arr);
            names[nm] = id;
            created.push(id);
          } else {
            engine.set_props(id, arr);
          }
          if (s.attach) {
            let bid;
            if (s.attach.k === 'ref') bid = nameToId(s.attach.path);
            else bid = nameToId(String(yield* evalE(s.attach, env) ?? ''));
            if (bid !== undefined && bid !== id) {
              try { engine.set_parent(id, bid); } catch (e) { /* нет API */ }
            }
          }
          break;
        }
        case 'call': {
          if (/^(E|S)\./.test(s.path)) break;
          yield* runCall(s.path, s.args, env, false);
          break;
        }
        case 'fdef_head': break;
        case 'end': break;
        case 'libmeta': break;
        case 'exprstmt': yield* evalE(s.e, env); break;
        case 'refstmt': getPath(s.path); break;
      }
    }
    return '';
  }

  /* ---------- твины ---------- */
  const EASINGS = {
    linear: (t) => t,
    ease_in: (t) => t * t,
    ease_out: (t) => 1 - (1 - t) * (1 - t),
    ease_in_out: (t) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2),
    bounce: (t) => {
      const n = 7.5625, d = 2.75;
      if (t < 1 / d) return n * t * t;
      if (t < 2 / d) return n * (t -= 1.5 / d) * t + 0.75;
      if (t < 2.5 / d) return n * (t -= 2.25 / d) * t + 0.9375;
      return n * (t -= 2.625 / d) * t + 0.984375;
    },
    elastic: (t) => (t <= 0 ? 0 : t >= 1 ? 1 : Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * (2 * Math.PI / 3)) + 1),
    back: (t) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); },
  };
  let tweens = [];
  function startTween(name, prop, goal, dur, easeName) {
    const id = names[name];
    if (id === undefined) return;
    const off = { pos: 0, rot: 3, size: 6, color: 9 }[prop];
    let from, to;
    if (prop === 'alpha') {
      const cur = engine.get_props(id);
      from = num(cur[13], 1);
      to = num(goal, from);
    } else if (off !== undefined) {
      const cur = engine.get_props(id);
      from = [cur[off], cur[off + 1], cur[off + 2]];
      if (typeof goal === 'string') {
        const named = COLOR_NAMES[String(goal).toLowerCase()];
        to = named ? named.slice() : from.slice();
      } else if (Array.isArray(goal)) {
        to = [0, 1, 2].map((i) => (goal[i] === undefined ? from[i] : num(goal[i], from[i])));
      } else {
        to = [num(goal, from[0]), num(goal, from[1]), num(goal, from[2])];
      }
    } else return;
    tweens = tweens.filter((t) => !(t.name === name && t.prop === prop));
    tweens.push({ name, prop, from, to, dur: Math.max(0.001, dur), t: 0, ease: EASINGS[easeName] || EASINGS.linear });
  }
  function tickTweens(dt) {
    if (!tweens.length) return;
    for (const tw of tweens) {
      tw.t += dt;
      const e = tw.ease(Math.min(1, tw.t / tw.dur));
      const id = names[tw.name];
      if (id === undefined) continue;
      const cur = Array.from(engine.get_props(id));
      if (tw.prop === 'alpha') {
        cur[13] = tw.from + (tw.to - tw.from) * e;
      } else {
        const off = { pos: 0, rot: 3, size: 6, color: 9 }[tw.prop];
        for (let i = 0; i < 3; i++) cur[off + i] = tw.from[i] + (tw.to[i] - tw.from[i]) * e;
      }
      try { engine.set_props(id, new Float32Array(cur)); } catch (er) { /* ок */ }
    }
    tweens = tweens.filter((t) => t.t < t.dur);
  }

  /* ---------- волокна (wait/события) ---------- */
  let fibers = [];
  let clock = 0;
  function spawn(gen, kind) { fibers.push({ gen, kind: kind || 'x', resumeAt: clock }); }
  function hasFiber(kind) { return fibers.some((f) => f.kind === kind); }
  function tickFibers() {
    if (!fibers.length) return;
    const now = clock;
    const keep = [];
    for (const f of fibers) {
      if (f.resumeAt > now) { keep.push(f); continue; }
      let r;
      try { r = f.gen.next(); } catch (e) { err = String(e); continue; }
      if (!r.done) {
        f.resumeAt = now + Math.max(0, num(r.value, 0));
        keep.push(f);
      }
    }
    fibers = keep;
  }

  /* ---------- функции: разбор аргументов из заголовка ---------- */
  function fixFuncArgs(src) {
    // повторно проходим исходник, чтобы забрать имена аргументов @F.name(a, b)
    const re = /@F\.([\w.]+)\s*\(([^)]*)\)\s*=/g;
    let m;
    while ((m = re.exec(src))) {
      const name = m[1].toLowerCase();
      const args = m[2].split(',').map((x) => x.trim()).filter(Boolean);
      if (F[name] && (!F[name].argNames || !F[name].argNames.length)) F[name].argNames = args;
    }
  }

  /* ---------- публичный API ---------- */
  return {
    _tokens: tokenize,
    load(src) {
      for (const k of Object.keys(V)) delete V[k];
      for (const k of Object.keys(B)) delete B[k];
      for (const k of Object.keys(F)) delete F[k];
      E.start = null; E.update = null; E.click = null; E.key = null; E.draw = null;
      for (const k of Object.keys(names)) delete names[k];
      created = [];
      err = '';
      warned = false;
      tweens = [];
      fibers = [];
      try {
        this._raw = parse(src);
        const flat = assembleEvents(assemble(parse(src)));
        fixFuncArgs(src);
        this._flat = flat;
      } catch (e) {
        err = String(e);
        this._flat = [];
      }
      return err;
    },
    start() {
      budget = 800000;
      err = '';
      clock = 0;
      fibers = [];
      if (this._flat && this._flat.length) spawn(exec(this._flat, {}), 'main');
      if (E.start) spawn(exec(E.start.body, {}), 'main');
      tickFibers();
      applyStats();
    },
    update(dt) {
      budget = 400000;
      err = '';
      clock += num(dt, 0.016);
      tickTweens(num(dt, 0.016));
      if (E.update && !hasFiber('upd')) {
        const env = {};
        if (E.update.args && E.update.args[0]) env[E.update.args[0]] = dt;
        env.dt = dt;
        spawn(exec(E.update.body, env), 'upd');
      }
      if (E.draw && !hasFiber('draw')) {
        const env = { dt };
        spawn(exec(E.draw.body, env), 'draw');
      }
      tickFibers();
      return err;
    },
    event(name, args) {
      const key = String(name || '').toLowerCase();
      const h = E[key];
      if (!h) return;
      const env = { dt: 0.016 };
      if (h.args && h.args[0] && args && args.length) env[h.args[0]] = args[0];
      spawn(exec(h.body, env), 'ev' + key + (Math.random() * 1e9 | 0));
    },
    stop() {
      fibers = [];
      tweens = [];
      for (const id of created) {
        if (engine.entity_ids().includes(id)) engine.remove_entity(id);
      }
      created = [];
    },
    get(p) { return getPath(p); },
    set(p, v) { setPath(p, v); },
    vars() { return V; },
    error() { return err; },
  };
}

// ================= ЛИНТЕР И ФОРМАТТЕР HGS =================
const KNOWN_EVENTS = ['OnStart', 'OnUpdate', 'OnDraw', 'OnKey', 'OnKeyDown', 'OnClick', 'OnHover', 'OnCollide'];

export function lint(src) {
  const errs = [];
  let T;
  try {
    T = tokenizeH(src);
  } catch (e) {
    errs.push({ line: e && e.line ? e.line : 1, msg: String(e && e.message ? e.message : e) });
    return errs;
  }
  let depth = 0;
  const fdefs = [];
  for (let i = 0; i < T.length; i++) {
    const tk = T[i];
    if (tk.t === '{') depth++;
    if (tk.t === '}') { depth--; if (depth < 0) { errs.push({ line: tk.line, msg: 'лишняя }' }); depth = 0; } }
    if (tk.t === 'at' && typeof tk.v === 'string' && tk.v.startsWith('@F.')) {
      const name = tk.v.slice(3);
      // пропускаем (args)
      let j = i + 1;
      let paren = 0;
      if (T[j] && T[j].t === '(') {
        paren = 1; j++;
        while (j < T.length && paren > 0) {
          if (T[j].t === '(') paren++;
          if (T[j].t === ')') paren--;
          j++;
        }
      }
      const nxt = T[j];
      const nx2 = T[j + 1];
      if (nxt && nxt.t === 'op' && nxt.v === '=') {
        fdefs.push({ name, line: tk.line, closed: false });
      } else if (nxt && nxt.t === 'dot' && nx2 && nx2.t === 'kw' && nx2.v === 'end') {
        const m = fdefs.find((f) => f.name === name && !f.closed);
        if (m) m.closed = true;
        else errs.push({ line: tk.line, msg: `@F.${name}.end без определения` });
      }
    }
    if (tk.t === 'kw' && tk.v === 'break') {
      const nx = T[i + 1];
      if (nx && ((nx.t === 'id') || (nx.t === 'kw' && nx.v !== 'WTD')) && nx.v !== 'WTD') {
        errs.push({ line: tk.line, msg: `break ${nx.v}: допустим только break WTD` });
      }
    }
    if (tk.t === 'at' && typeof tk.v === 'string' && !/^@[WPCLFESI]\./.test(tk.v) && tk.v !== '@P') {
      if (!/^@[WPCLFESI](\.|$)/.test(tk.v) && !tk.v.startsWith('@LIB')) {
        errs.push({ line: tk.line, msg: `неизвестная секция ${tk.v}` });
      }
    }
    if (tk.t === 'kw' && tk.v === 'WTD') {
      let d = 0, saw = false, hasBreak = false, j = i;
      while (j < T.length) {
        const q = T[j];
        if (q.t === '{') { d++; saw = true; }
        if (q.t === '}') { d--; if (saw && d <= 0) break; }
        if (saw && q.t === 'kw' && q.v === 'break') hasBreak = true;
        j++;
      }
      if (!hasBreak) errs.push({ line: tk.line, msg: 'WTD без break WTD — бесконечный цикл; код «каждый кадр» пишите в @E.OnUpdate(dt)' });
    }
  }
  if (depth > 0) errs.push({ line: T.length ? T[T.length - 1].line : 1, msg: `незакрытых { : ${depth}` });
  for (const f of fdefs) if (!f.closed) errs.push({ line: f.line, msg: `у @F.${f.name} нет .end` });

  // события @E.X ... @E.End()
  let ev = null;
  for (let i = 0; i < T.length; i++) {
    const tk = T[i];
    if (tk.t === 'at' && typeof tk.v === 'string' && (tk.v.startsWith('@E.') || tk.v.startsWith('@S.'))) {
      const name = tk.v.slice(3);
      if (name === 'End') {
        if (!ev) errs.push({ line: tk.line, msg: '@E.End() без @E.OnStart/OnUpdate' });
        ev = null;
      } else {
        if (ev) errs.push({ line: tk.line, msg: `@E.${name}: событие @E.${ev} не закрыто @E.End()` });
        if (!KNOWN_EVENTS.includes(name)) errs.push({ line: tk.line, msg: `неизвестное событие @E.${name} (есть: ${KNOWN_EVENTS.join(', ')})` });
        ev = name;
      }
    }
  }
  if (ev) errs.push({ line: T.length ? T[T.length - 1].line : 1, msg: `@E.${ev} не закрыто @E.End()` });
  return errs;
}

// Токенайзер, доступный снаружи (для форматтера)
function tokenizeH(src) {
  const rt = createRuntime({}, {});
  return rt._tokens(src);
}

export function format(src) {
  const out = [];
  let ind = 0;
  for (let raw of src.split('\n')) {
    let line = raw.replace(/\s+$/, '').replace(/[ \t]{2,}/g, ' ');
    const t = line.trim();
    if (!t) { out.push(''); continue; }
    if (t.startsWith('}')) ind = Math.max(0, ind - 1);
    if (t.startsWith(']')) ind = Math.max(0, ind - 1);
    let pad = ind;
    if (t.startsWith('@E.') || t.startsWith('@S.') || t.startsWith('@W.') || t.startsWith('@P.') || t.startsWith('@L.') || t.startsWith('@F.') || t.startsWith('@C.')) pad = 0;
    out.push('  '.repeat(pad) + t);
    if (t.endsWith('{')) ind++;
    if (t.endsWith('[')) ind++;
  }
  return out.join('\n');
}
