/* lang.js — интерпретатор языка HolyGGS (@W @P @L @F @C @E).
   Грамматика: см. Readme.txt. Выполняется с бюджетом шагов (защита от WTD). */
export function createRuntime(engine, hooks = {}) {
  const V = {};       // переменные @L / @P (вложенные)
  const B = {};       // живые привязки: путь -> источник
  const F = {};       // функции
  const E = { start: null, update: null };
  const names = {};   // имя объекта @W -> id
  let created = [];   // id, созданные скриптом (для очистки)
  let budget = 0;
  let err = '';

  /* ---------- токенизатор ---------- */
  function tokenize(src) {
    const T = [];
    let i = 0;
    const n = src.length;
    let line = 1;
    const push = (t, v) => T.push({ t, v, line });
    while (i < n) {
      const c = src[i];
      if (c === '\n') { push('nl'); i++; line++; continue; }
      if (c === ' ' || c === '\t' || c === '\r') { i++; continue; }
      if (c === '#') { while (i < n && src[i] !== '\n') i++; continue; }
      if (c === ';') { push('nl'); i++; continue; }
      if ('(){}[],'.includes(c)) { push(c); i++; continue; }
      if (c === '"') {
        let s = ''; i++;
        while (i < n && src[i] !== '"') { if (src[i] === '\\') i++; s += src[i++]; }
        i++; push('str', s); continue;
      }
      if ('=<>!:+-*/'.includes(c)) {
        let op = c; i++;
        if (i < n && '=<>'.includes(src[i]) && (c === '=' || c === '!' || c === '<' || c === '>')) op += src[i++];
        else if (c === '+' && src[i] === '=') op = '+=', i++;
        else if (c === '-' && src[i] === '=') op = '-=', i++;
        else if (c === '*' && src[i] === '=') op = '*=', i++;
        else if (c === '/' && src[i] === '=') op = '/=', i++;
        push('op', op); continue;
      }
      if (c === '.') {
        if (/[0-9]/.test(src[i + 1] || '')) { /* число */ }
        else { push('dot'); i++; continue; }
      }
      if (/[0-9.]/.test(c)) {
        let s = '';
        while (i < n && /[0-9.eE+-]/.test(src[i])) {
          if ((src[i] === '+' || src[i] === '-') && !/[eE]/.test(s[s.length - 1] || '')) break;
          s += src[i++];
        }
        push('num', parseFloat(s)); continue;
      }
      if (/[A-Za-zА-Яа-яЁё_@]/.test(c)) {
        let s = '';
        while (i < n && /[A-Za-zА-Яа-яЁё0-9_.@]/.test(src[i])) s += src[i++];
        if (s.startsWith('@')) push('at', s);
        else if (s === 'if' || s === 'else' || s === 'WTD' || s === 'break' || s === 'end') push('kw', s);
        else push('id', s);
        continue;
      }
      i++;
    }
    return T;
  }

  /* ---------- парсер ---------- */
  function parse(src) {
    const T = tokenize(src);
    let p = 0;
    const peek = (o = 0) => T[p + o];
    const eat = () => T[p++];
    const pt = (o = 0) => (T[p + o] ? T[p + o].t : 'eof');
    const pv = (o = 0) => (T[p + o] ? T[p + o].v : undefined);
    const isOp = (v) => pt() === 'op' && pv() === v;
    const skipNl = () => { while (peek() && pt() === 'nl') p++; };

    function parseExpr() { return parseCmp(); }
    function parseCmp() {
      let a = parseAdd();
      while (pt() === 'op' && ['>', '<', '>=', '<=', '==', '!='].includes(pv())) {
        const op = eat().v; a = { k: 'bin', op, a, b: parseAdd() };
      }
      return a;
    }
    function parseAdd() {
      let a = parseMul();
      while (pt() === 'op' && (pv() === '+' || pv() === '-')) {
        const op = eat().v; a = { k: 'bin', op, a, b: parseMul() };
      }
      return a;
    }
    function parseMul() {
      let a = parseUn();
      while (pt() === 'op' && (pv() === '*' || pv() === '/')) {
        const op = eat().v; a = { k: 'bin', op, a, b: parseUn() };
      }
      return a;
    }
    function parseUn() {
      if (isOp('-')) { eat(); return { k: 'neg', a: parseUn() }; }
      return parseAtom();
    }
    function parseAtom() {
      const t = peek();
      if (!t) return { k: 'num', v: 0 };
      if (t.t === 'num') { eat(); return { k: 'num', v: t.v }; }
      if (t.t === 'str') { eat(); return { k: 'str', v: t.v }; }
      if (t.t === '[') {
        eat();
        let path = '';
        while (peek() && pt() !== ']') path += eat().v ?? '';
        eat();
        return { k: 'ref', path: path.trim() };
      }
      if (t.t === 'at') {
        eat();
        return { k: 'ref', path: t.v.replace(/^@/, '') };
      }
      if (t.t === 'id') {
        eat();
        if (pt() === '(') {
          const args = parseArgs();
          return { k: 'call', path: t.v, args };
        }
        return { k: 'str', v: t.v };
      }
      eat();
      return { k: 'num', v: 0 };
    }
    function parseArgs() {
      eat(); // (
      const args = [];
      while (peek() && pt() !== ')') {
        let key = null;
        if ((pt() === 'id' || pt() === 'at') && pt(1) === 'op' && pv(1) === ':') {
          key = eat().v; eat();
        }
        args.push({ key, e: parseExpr() });
        if (pt() === ',') eat();
      }
      eat(); // )
      return args;
    }

    function parseObj() {
      eat(); // {
      const props = [];
      while (peek() && pt() !== '}') {
        skipNl();
        if (pt() === '}') break;
        const name = eat().v;
        const args = pt() === '(' ? parseArgs() : [];
        props.push({ name, args });
        if (pt() === ',') eat();
        skipNl();
      }
      eat(); // }
      return props;
    }

    function parseBlockStmts(stopKw) {
      const out = [];
      skipNl();
      while (peek()) {
        if (pt() === 'kw' && stopKw.includes(pv())) break;
        if (pt() === '}' || pt() === ']') break;
        const s = parseStmt();
        if (s) out.push(s);
        skipNl();
      }
      return out;
    }

    function parseBraceBlock() {
      // { ... } — блок операторов (условие/код)
      eat(); // {
      const body = parseBlockStmts([]);
      if (pt() === '}') eat();
      return body;
    }

    function parseIfInner() {
      // if COND { ... } else { ... }  |  if { COND; ... } else { ... }
      if (!(pt() === 'kw' && pv() === 'if')) return null;
      eat();
      let cond, body;
      if (pt() === '{') {
        const inner = parseBraceBlock();
        if (inner.length && inner[0].k === 'exprstmt') {
          cond = inner[0].e; body = inner.slice(1);
        } else if (inner.length && inner[0].k === 'cond') {
          cond = inner[0].e; body = inner.slice(1);
        } else {
          cond = { k: 'num', v: 1 }; body = inner;
        }
      } else {
        cond = parseExpr();
        skipNl();
        body = pt() === '{' ? parseBraceBlock() : [];
      }
      let els = [];
      skipNl();
      if (pt() === 'kw' && pv() === 'else') {
        eat(); skipNl();
        if (pt() === 'kw' && pv() === 'if') {
          els = [{ k: 'if', cond: null, body: null, nested: parseIfInner() }];
        } else {
          els = pt() === '{' ? parseBraceBlock() : [];
        }
      }
      return { k: 'if', cond, body, els };
    }

    function parseStmt() {
      skipNl();
      const t = peek();
      if (!t) return null;
      if (t.t === '[') {
        let o = 1;
        while (peek(o) && pt(o) === 'nl') o++;
        const inner = peek(o);
        if (!(inner && inner.t === 'kw' && (inner.v === 'if' || inner.v === 'WTD'))) {
          return { k: 'exprstmt', e: parseExpr() };
        }
        eat();
        skipNl();
        let s = null;
        if (pt() === 'kw' && pv() === 'if') s = parseIfInner();
        else if (pt() === 'kw' && pv() === 'WTD') {
          const body = pt(1) === '{' ? (eat(), parseBraceBlock()) : [];
          s = { k: 'wtd', body };
        } else s = { k: 'block', body: parseBlockStmts([]) };
        skipNl();
        if (pt() === ']') eat();
        return s;
      }
      if (t.t === 'kw' && t.v === 'if') return parseIfInner();
      if (t.t === 'kw' && t.v === 'WTD') {
        eat();
        const body = pt() === '{' ? parseBraceBlock() : [];
        return { k: 'wtd', body };
      }
      if (t.t === 'kw' && t.v === 'break') {
        eat();
        let target = '';
        if (pt() === 'id' || pt() === 'kw') target = eat().v;
        return { k: 'break', target };
      }
      if (t.t === 'at') {
        eat();
        const path = t.v.replace(/^@/, '');
        if (pt() === 'op' && pv() === '=') {
          eat();
          if (path.startsWith('W.') && pt() === '{') {
            return { k: 'wset', path, props: parseObj() };
          }
          return { k: 'assign', path, e: parseExpr() };
        }
        if (pt() === 'op' && ['+=', '-=', '*=', '/='].includes(pv())) {
          const op = eat().v;
          return { k: 'assign', path, op, e: parseExpr() };
        }
        if (pt() === 'op' && pv() === ':') {
          eat();
          return { k: 'bind', path, e: parseExpr() };
        }
        if (pt() === '(') {
          const args = parseArgs();
          if (pt() === 'dot' && pt(1) === 'kw' && pv(1) === 'end') {
            eat(); eat(); // .end
            return { k: 'end', path };
          }
          if (pt() === 'op' && pv() === '=' && path.startsWith('F.')) {
            eat();
            return {
              k: 'fdef_head', path, e: parseExpr(),
              argNames: args.map((a) => (a.e && a.e.k === 'str' ? a.e.v : (a.key || ''))).filter(Boolean),
            };
          }
          return { k: 'call', path, args };
        }
        return { k: 'refstmt', path };
      }
      if (t.t === 'id') {
        eat();
        if (pt() === '(') {
          const args = parseArgs();
          return { k: 'call', path: t.v, args };
        }
        return { k: 'exprstmt', e: { k: 'str', v: t.v } };
      }
      if (t.t === 'num' || t.t === 'str' || t.t === '[') {
        return { k: 'exprstmt', e: parseExpr() };
      }
      eat();
      return null;
    }

    const stmts = parseBlockStmts([]);
    return stmts;
  }

  /* ---------- сборка событий/функций из плоского списка ---------- */
  function assemble(stmts) {
    const out = [];
    let i = 0;
    while (i < stmts.length) {
      const s = stmts[i];
      if (s.k === 'fdef_head' && s.path.startsWith('F.')) {
        // ищем .end с тем же именем
        const name = s.path.slice(2);
        const body = [];
        i++;
        let depth = 1;
        while (i < stmts.length) {
          const t = stmts[i];
          if (t.k === 'end' && t.path.slice(2) === name) { i++; break; }
          if (t.k === 'fdef_head' && t.path.slice(2) === name) depth++;
          body.push(t);
          i++;
        }
        F[name.toLowerCase()] = {
          argNames: s.argNames || [],
          body: [{ k: 'exprstmt', e: s.e }].concat(body),
          head: s,
        };
        continue;
      }
      out.push(s);
      i++;
    }
    return out;
  }

  function assembleEvents(stmts) {
    const out = [];
    let i = 0;
    while (i < stmts.length) {
      const s = stmts[i];
      if (s.k === 'call' && (s.path === 'E.OnStart' || s.path === 'E.OnUpdate' || s.path === 'OnStart' || s.path === 'OnUpdate')) {
        const name = s.path.includes('Update') ? 'update' : 'start';
        const args = s.args.map((a) => a.e.path || '');
        const body = [];
        i++;
        while (i < stmts.length) {
          const t2 = stmts[i];
          const isEnd = (t2.k === 'end' && /On(Start|Update)/.test(t2.path))
            || (t2.k === 'call' && /^(E\.)?End$/i.test(t2.path));
          if (isEnd) break;
          body.push(t2); i++;
        }
        i++; // .end
        E[name] = { args, body };
        continue;
      }
      out.push(s);
      i++;
    }
    return out;
  }

  /* ---------- выполнение ---------- */
  const strip = (path) => path.replace(/^(L|P|W)\.(?=[A-ZА-ЯЁё_])/i, '').replace(/^@/, '');
  function lookup(obj, path) {
    let o = obj;
    for (const k of path.split('.')) {
      if (o == null || typeof o !== 'object' || !(k in o)) return undefined;
      o = o[k];
    }
    return o;
  }
  function getPath(path) {
    if (path in B) return getPath(B[path]);
    const parts = path.split('.');
    if ((parts.length === 1 || (parts.length === 2 && (parts[0] === 'P' || parts[0] === 'Player'))) && parts[parts.length - 1] === 'pos') {
      const p = engine.player_pos();
      return [p[0], p[1], p[2]];
    }
    const direct = lookup(V, path);
    if (direct !== undefined) return direct;
    if (parts.length === 2 && names[parts[0]] !== undefined) {
      const id = names[parts[0]];
      const props = engine.get_props(id);
      const b = parts[1];
      if (b === 'pos') return [props[0], props[1], props[2]];
      if (b === 'size') return [props[6], props[7], props[8]];
      if (b === 'dist') {
        const p = engine.player_pos();
        return Math.hypot(props[0] - p[0], props[1] - p[1], props[2] - p[2]);
      }
    }
    const sp = strip(path);
    if (sp !== path) {
      const v = lookup(V, sp);
      if (v !== undefined) return v;
    }
    return lookup(V.L, path) !== undefined ? lookup(V.L, path) : lookup(V.P, path);
  }
  function setPath(path, val) {
    const sp = strip(path);
    delete B[path]; delete B[sp];
    const parts = sp.split('.');
    let o = V;
    for (let i = 0; i < parts.length - 1; i++) {
      if (typeof o[parts[i]] !== 'object' || o[parts[i]] === null) o[parts[i]] = {};
      o = o[parts[i]];
    }
    o[parts[parts.length - 1]] = val;
    if (['Speed', 'Jump', 'Size', 'P.Speed', 'P.Jump', 'P.Size'].includes(sp)) applyStats();
  }
  function applyStats() {
    if (hooks.setStats) {
      const g = (k, d) => {
        const v = getPath(k);
        return typeof v === 'number' && isFinite(v) ? v : d;
      };
      hooks.setStats(g('Speed', 8), g('Jump', 2.6), g('Size', 1));
    }
  }
  function num(v, d) { return typeof v === 'number' && isFinite(v) ? v : d; }

  function interpStr(s) {
    return String(s).replace(/\[([^\]]+)\]/g, (_, p) => {
      const v = getPath(p.trim());
      return v === undefined ? '' : Array.isArray(v) ? v.map((x) => Math.round(x * 1000) / 1000).join(', ') : String(v);
    });
  }

  function evalE(e, env) {
    switch (e.k) {
      case 'num': return e.v;
      case 'str': return interpStr(e.v);
      case 'neg': return -num(evalE(e.a, env), 0);
      case 'ref': {
        if (env && e.path in env) return env[e.path];
        const v = getPath(e.path);
        return v;
      }
      case 'call': {
        const r = runCall(e.path, e.args, env, true);
        return r;
      }
      case 'bin': {
        const a = evalE(e.a, env);
        const b = evalE(e.b, env);
        if (e.op === '+') {
          if (Array.isArray(a) && Array.isArray(b)) return a.map((x, i) => num(x, 0) + num(b[i], 0));
          const av = a === undefined || a === null || a === '' ? 0 : a;
          const bv = b === undefined || b === null || b === '' ? 0 : b;
          if (typeof av === 'number' && typeof bv === 'number') return av + bv;
          return (a ?? '') + (b ?? '');
        }
        const x = num(a, 0), y = num(b, 0);
        switch (e.op) {
          case '-': return x - y;
          case '*': return x * y;
          case '/': return y !== 0 ? x / y : 0;
          case '>': return x > y ? 1 : 0;
          case '<': return x < y ? 1 : 0;
          case '>=': return x >= y ? 1 : 0;
          case '<=': return x <= y ? 1 : 0;
          case '==': return x === y || String(a) === String(b) ? 1 : 0;
          case '!=': return x === y || String(a) === String(b) ? 0 : 1;
        }
        return 0;
      }
    }
    return 0;
  }

  function argVal(args, key, idx, env, dflt) {
    for (const a of args) {
      if (a.key === key) return evalE(a.e, env);
    }
    if (args[idx] && !args[idx].key) return evalE(args[idx].e, env);
    return dflt;
  }

  function runCall(path, args, env, asExpr) {
    const p = path.replace(/^@/, '');
    const low = p.toLowerCase();
    const lowBare = low.replace(/^(l|p)\./, '');
    if (lowBare === 'text.pr' || lowBare === 'text.print' || lowBare === 'pr') {
      const parts = args.map((a) => {
        const v = evalE(a.e, env);
        return a.key ? `${a.key}: ${fmt(v)}` : fmt(v);
      });
      if (hooks.print) hooks.print(parts.join('  '));
      return 1;
    }
    if (low === 'w.destroy') {
      const a = args.find((x) => x.key === 'obj') || args[0];
      let nm = null;
      let obj = null;
      if (a && a.e && a.e.k === 'ref') {
        nm = a.e.path.split('.').pop();
        obj = names[nm];
      } else {
        obj = argVal(args, 'obj', 0, env, null);
        nm = String(obj ?? '');
      }
      const id = typeof obj === 'number' ? obj : names[nm];
      if (id !== undefined && id >= 0) {
        engine.remove_entity(id);
        for (const k of Object.keys(names)) if (names[k] === id) delete names[k];
      }
      return 1;
    }
    if (p.startsWith('W.')) {
      const rest = p.slice(2);
      const dot = rest.lastIndexOf('.');
      const nm = dot > 0 ? rest.slice(0, dot) : rest;
      const method = dot > 0 ? rest.slice(dot + 1) : '';
      const id = names[nm];
      if (id === undefined) return 0;
      if (method === 'move') {
        const t = argVal(args, 'target', 0, env, null);
        if (Array.isArray(t)) {
          const props = engine.get_props(id);
          const spd = num(getPath(nm + '.Speed'), 5) * num(env && env.dt, 0.016);
          const dx = num(t[0], 0) - props[0], dy = num(t[1], 0) - props[1], dz = num(t[2], 0) - props[2];
          const d = Math.hypot(dx, dy, dz) || 1;
          const k = Math.min(spd / d, 1);
          engine.set_props(id, new Float32Array([
            props[0] + dx * k, props[1] + dy * k, props[2] + dz * k,
            props[3], props[4], props[5], props[6], props[7], props[8],
            props[9], props[10], props[11], props[12], props[13], props[14], props[15], props[16], props[17], props[18] || 0,
          ]));
        }
        return 1;
      }
      if (method === 'tp') {
        const t = argVal(args, 'pos', 0, env, null);
        if (Array.isArray(t)) {
          const props = engine.get_props(id);
          engine.set_props(id, new Float32Array([
            num(t[0], 0), num(t[1], 0), num(t[2], 0),
            props[3], props[4], props[5], props[6], props[7], props[8],
            props[9], props[10], props[11], props[12], props[13], props[14], props[15], props[16], props[17], props[18] || 0,
          ]));
        }
        return 1;
      }
      return 0;
    }
    const fname = low.replace(/^f\./, '');
    if (F[fname]) {
      const f = F[fname];
      const local = {};
      if (f.head && f.head.k === 'fdef_head') {
        // имена параметров из исходного заголовка
      }
      const namesArgs = f.argNames || [];
      namesArgs.forEach((nm, i) => {
        local[nm] = f.head ? argVal(args, nm, i, env, 0) : 0;
      });
      exec(f.body, { ...env, ...local, dt: env && env.dt });
      return 1;
    }
    return 0;
  }

  function fmt(v) {
    if (Array.isArray(v)) return v.map((x) => Math.round(x * 100) / 100).join(', ');
    if (typeof v === 'number') return String(Math.round(v * 1000) / 1000);
    return String(v ?? '');
  }

  function exec(stmts, env) {
    for (const s of stmts) {
      if (budget-- <= 0) { err = 'budget'; return; }
      switch (s.k) {
        case 'block': exec(s.body, env); break;
        case 'if': {
          if (s.nested) { exec([s.nested], env); break; }
          const c = num(evalE(s.cond, env), 0);
          if (c) exec(s.body, env);
          else exec(s.els, env);
          break;
        }
        case 'wtd': {
          let guard = 0;
          while (budget > 0) {
            if (guard++ > 100000) break;
            const r = execLoop(s.body, env);
            if (r === 'break') break;
            if (r === 'budget') break;
          }
          break;
        }
        case 'break': return 'break';
        case 'assign': {
          const cur = getPath(s.path);
          const val = evalE(s.e, env);
          if (s.op) {
            const c = num(cur, 0), x = num(val, 0);
            const r = s.op === '+=' ? c + x : s.op === '-=' ? c - x : s.op === '*=' ? c * x : (x !== 0 ? c / x : c);
            setPath(s.path, r);
          } else {
            setPath(s.path, val);
          }
          break;
        }
        case 'bind': {
          const src = s.e.k === 'ref' ? s.e.path : null;
          if (src) B[strip(s.path)] = src;
          else setPath(s.path, evalE(s.e, env));
          break;
        }
        case 'wset': {
          const nm = s.path.slice(2);
          const props = { pos: [0, 0, 0], size: [1, 1, 1], color: [0.8, 0.8, 0.8], rot: [0, 0, 0], alpha: 1, mat: 0, neon: 0, shape: 0 };
          for (const pr of s.props) {
            const vals = pr.args.map((a) => evalE(a.e, env));
            if (pr.name === 'pos') props.pos = vals;
            else if (pr.name === 'size') props.size = vals;
            else if (pr.name === 'color') props.color = vals;
            else if (pr.name === 'rot') props.rot = vals;
            else if (pr.name === 'alpha') props.alpha = num(vals[0], 1);
            else if (pr.name === 'mat') props.mat = num(vals[0], 0);
            else if (pr.name === 'neon') props.neon = num(vals[0], 0);
            else if (pr.name === 'shape') props.shape = num(vals[0], 0);
          }
          let id = names[nm];
          const arr = new Float32Array([
            ...props.pos, ...props.rot, ...props.size, ...props.color,
            props.neon, props.alpha, 0, 0, props.mat, 0, props.shape,
          ]);
          if (id === undefined || !engine.entity_ids().includes(id)) {
            id = engine.add_entity(nm, arr);
            names[nm] = id;
            created.push(id);
          } else {
            engine.set_props(id, arr);
          }
          break;
        }
        case 'call': {
          if (s.path.startsWith('E.')) break;
          runCall(s.path, s.args, env, false);
          break;
        }
        case 'fdef_head': break;
        case 'end': break;
        case 'exprstmt': evalE(s.e, env); break;
        case 'refstmt': getPath(s.path); break;
      }
    }
    return '';
  }
  function execLoop(stmts, env) {
    for (const s of stmts) {
      if (budget-- <= 0) return 'budget';
      const r = (function () {
        switch (s.k) {
          case 'block': return execLoop(s.body, env);
          case 'if': {
            if (s.nested) return execLoop([s.nested], env);
            const c = num(evalE(s.cond, env), 0);
            return c ? execLoop(s.body, env) : execLoop(s.els, env);
          }
          case 'wtd': {
            while (budget > 0) {
              const rr = execLoop(s.body, env);
              if (rr === 'break' || rr === 'budget') break;
            }
            return '';
          }
          case 'break': return 'break';
          default: {
            exec([s], env);
            return '';
          }
        }
      })();
      if (r === 'break' || r === 'budget') return r;
    }
    return '';
  }

  /* ---------- функции: разбор аргументов из заголовка ---------- */
  function fixFuncArgs(src) {
    // повторно проходим исходник, чтобы забрать имена аргументов @F.name(a, b)
    const re = /@F\.([\w.]+)\s*\(([^)]*)\)\s*=/g;
    let m;
    while ((m = re.exec(src))) {
      const name = m[1].toLowerCase();
      const args = m[2].split(',').map((x) => x.trim()).filter(Boolean);
      if (F[name] && (!F[name].argNames || !F[name].argNames.length)) F[name].argNames = args;
    }
  }

  /* ---------- публичный API ---------- */
  return {
    load(src) {
      for (const k of Object.keys(V)) delete V[k];
      for (const k of Object.keys(B)) delete B[k];
      for (const k of Object.keys(F)) delete F[k];
      E.start = null; E.update = null;
      for (const k of Object.keys(names)) delete names[k];
      created = [];
      err = '';
      try {
        this._raw = parse(src);
        const flat = assembleEvents(assemble(parse(src)));
        fixFuncArgs(src);
        this._flat = flat;
      } catch (e) {
        err = String(e);
        this._flat = [];
      }
      return err;
    },
    start() {
      budget = 800000;
      err = '';
      if (this._flat) exec(this._flat, {});
      if (E.start) exec(E.start.body, {});
      applyStats();
    },
    update(dt) {
      budget = 400000;
      err = '';
      if (E.update) {
        const env = {};
        if (E.update.args && E.update.args[0]) env[E.update.args[0]] = dt;
        env.dt = dt;
        exec(E.update.body, env);
      }
      if (this._flat && !E.start && !E.update) {
        // одноразовый скрипт уже выполнен
      }
      return err;
    },
    stop() {
      for (const id of created) {
        if (engine.entity_ids().includes(id)) engine.remove_entity(id);
      }
      created = [];
    },
    get(p) { return getPath(p); },
    set(p, v) { setPath(p, v); },
    vars() { return V; },
    error() { return err; },
  };
}
