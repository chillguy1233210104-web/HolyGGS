import init, { Engine, run_self_test, version, gfx_defaults } from './pkg/engine.js';
import { t, getLang, setLang, applyDom } from './i18n.js';
import { createRuntime, lint as lintHgs, format as fmtHgs } from './lang.js';
import { buildGameApk, getExportKey } from './builder.js';
import { UIMgr, uiDef, UI_TYPES } from './ui.js';

const $ = (id) => document.getElementById(id);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const clamp = (v) => Math.max(-1, Math.min(1, v));

/* ================= хранилище ================= */
const DEFAULT_SCRIPT = `# Скрипт игрока — язык HolyGGS
@E.OnStart()
    @L.HP = 100
    @P.Speed = 8
    @P.Jump = 2.6
    @P.Size = 1
    Text.pr(привет!)
@E.End()

@E.OnUpdate(dt)
    # [HP], [P.pos], @W.имя.move(...) и т.д.
@E.End()`;

let scriptText = '';
let rt = null;
const objRts = [];
const srvRts = [];
const objScripts = {};
const srvScripts = {};
let uiSel = null;
const uiMgr = new UIMgr($('uiRoot'), {
  edit: true,
  onSelect: (name) => selectUI(name),
  onMutate: () => { scheduleSave(); buildTree(); fillUIProps(); },
  onEvent: (d, ev, val) => {
    const handler = ev === 'change' ? d.onChange : d.onClick;
    if (handler) uiFire(handler, [d.name, ev, val]);
  },
});
let editMode = false;
let brushOn = false, brushP = null, editMirror = 0, etTool = 'tap', blenderOn = false;
let editHist = [], editRedo = [], editDir = 1, editColor = 0xe74c3c, boxStart = null;
let ceCtx = null;

const DEFAULT_SRV = `# Серверный скрипт — язык HolyGGS
@S.OnStart()
    Text.pr(server запущен)
@S.End()

@S.OnUpdate(dt)

@S.End()`;

const DEFAULT_OBJ_SCRIPT = `# Скрипт объекта — Self.pos / Self.size / Self.dist / Self.name
@E.OnStart()
    Text.pr(объект запущен)
@E.End()

@E.OnUpdate(dt)
    
@E.End()`;

const store = {
  projects() { try { return JSON.parse(localStorage.getItem('eng.projects') || '[]'); } catch { return []; } },
  saveProjects(p) { try { localStorage.setItem('eng.projects', JSON.stringify(p)); } catch (e) { alert(t('saveFail', e)); } },
  scene(id) { try { return JSON.parse(localStorage.getItem('eng.scene.' + id) || 'null'); } catch { return null; } },
  saveScene(id, s) { try { localStorage.setItem('eng.scene.' + id, JSON.stringify(s)); } catch (e) { console.warn(e); } },
  delScene(id) { localStorage.removeItem('eng.scene.' + id); },
};

/* ================= схема настроек графики (индексы = как в Rust) ================= */
const GFX = [
  { k: 'g_time', min: 0, max: 24, step: 0.05, fmt: 'time' }, // 0
  { k: 'g_contrast', min: 0.5, max: 2, step: 0.01 },         // 1
  { k: 'g_exposure', min: 0.3, max: 2.5, step: 0.01 },       // 2
  { k: 'g_sat', min: 0, max: 2, step: 0.01 },                // 3
  { k: 'g_rays', min: 0, max: 2, step: 0.01 },               // 4
  { k: 'g_neon', min: 0, max: 8, step: 0.1 },                // 5
  { k: 'g_bloom', min: 0, max: 2, step: 0.01 },              // 6
  { k: 'g_bthr', min: 0, max: 3, step: 0.01 },               // 7
  { k: 'g_fogd', min: 0, max: 0.1, step: 0.001 },            // 8
  { k: 'g_fogs', min: 0, max: 300, step: 1 },                // 9
  { k: 'g_skyb', min: 0.2, max: 2, step: 0.01 },             // 10
  { k: 'g_sun', min: 0.3, max: 4, step: 0.05 },              // 11
  { k: 'g_vig', min: 0, max: 1, step: 0.01 },                // 12
  { k: 'g_amb', min: 0, max: 2, step: 0.01 },
  { k: 'g_shadow', min: 0, max: 1, step: 0.01 },
  { k: 'g_nlight', min: 0, max: 3, step: 0.01 },
  { k: 'g_waveh', min: 0, max: 2, step: 0.01 },   // 16
  { k: 'g_waves', min: 0, max: 3, step: 0.01 },   // 17
  { k: 'g_bump', min: 0, max: 3, step: 0.01 },    // 18
  { k: 'g_fov', min: 30, max: 110, step: 1 },     // 19
  { k: 'g_sens', min: 0.2, max: 3, step: 0.01 },
  { k: 'g_fogn', min: 0, max: 2, step: 0.01 },   // 21
  { k: 'g_mie', min: 0, max: 3, step: 0.01 },    // 22
  { k: 'g_clouds', min: 0, max: 2, step: 0.01 },  // 26
  { k: 'g_texq', min: 0, max: 2, step: 1, fmt: 'qual' }, // 23
  { k: 'g_shq', min: 0, max: 2, step: 1, fmt: 'qual' },  // 24
  { k: 'g_wq', min: 0, max: 2, step: 1, fmt: 'qual' },   // 25
];
const GROUPS = [
  { id: 'time', icon: 'sun', k: 'grp_time', items: [0, 10, 11, 26, 13, 14] },
  { id: 'fx', icon: 'fx', k: 'grp_fx', items: [4, 6, 7, 5, 15, 12, 18] },
  { id: 'col', icon: 'col', k: 'grp_col', items: [2, 1, 3] },
  { id: 'fog', icon: 'fog', k: 'grp_fog', items: [8, 9, 21, 22] },
  { id: 'wat', icon: 'wat', k: 'grp_water', items: [16, 17] },
  { id: 'cam', icon: 'cam', k: 'grp_cam', items: [19, 20] },
  { id: 'q', icon: 'q', k: 'grp_qual', items: [23, 24, 25] },
  { id: 'ui', icon: 'q', k: 'grp_sysui', items: [] },
];

/* ================= wasm ================= */
let wasmErr = null;
let verText = 'Engine';
const setVer = () => { $('ver').textContent = verText; };
const wasmReady = init().then(() => true).catch((e) => { wasmErr = e; return false; });
wasmReady.then((ok) => { if (ok) { verText = 'Engine core v' + version(); setVer(); } });

/* ================= список проектов ================= */
/* ================= формат .mapp: экспорт / импорт ================= */
function b64enc(str) {
  const bytes = new TextEncoder().encode(str);
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) {
    bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  }
  return btoa(bin);
}

function exportProject(p) {
  const scene = store.scene(p.id) || { v: 2, entities: [], gfx: [], script: '', objScripts: {}, pmRoot: -1 };
  const data = {
    mapp: 1,
    name: p.name,
    icon: p.icon || '',
    created: p.created || Date.now(),
    scene,
  };
  const json = JSON.stringify(data);
  const fname = (p.name || 'project').replace(/[\\/:*?"<>|]+/g, '_') + '.mapp';
  try {
    if (window.Android && Android.saveFile) {
      Android.saveFile(fname, b64enc(json));
      alert(t('mappSaved') + '\n' + fname);
      return;
    }
  } catch (e) { /* падаем в blob-скачивание */ }
  const blob = new Blob([json], { type: 'application/octet-stream' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = fname;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
}

function b64bytes(u8) {
  let bin = '';
  for (let i = 0; i < u8.length; i += 0x8000) bin += String.fromCharCode(...u8.subarray(i, i + 0x8000));
  return btoa(bin);
}

async function iconToPngBytes(dataUrl) {
  const img = new Image();
  await new Promise((res, rej) => { img.onload = res; img.onerror = rej; img.src = dataUrl; });
  const s = 192, c = document.createElement('canvas');
  c.width = c.height = s;
  const ctx = c.getContext('2d');
  ctx.imageSmoothingQuality = 'high';
  const m = Math.min(img.width, img.height) || s;
  ctx.drawImage(img, (img.width - m) / 2, (img.height - m) / 2, m, m, 0, 0, s, s);
  const png = c.toDataURL('image/png');
  const bin = atob(png.slice(png.indexOf(',') + 1));
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8;
}

async function exportApk(p) {
  if (!(await wasmReady)) { alert(t('coreNotLoaded', wasmErr)); return; }
  try {
    const scene = store.scene(p.id) || { v: 2, entities: [], gfx: [], script: '', objScripts: {}, srvScripts: {}, pmRoot: -1 };
    const gameJson = JSON.stringify({ mapp: 1, name: p.name, icon: p.icon || '', created: p.created || Date.now(), scene });
    // модули игры (как в Godot: редактор в игру не попадает):
    // player.html -> index.html, player.js, lang.js (рантайм языка), pkg/engine.js+wasm (Rust-движок)
    const names = [
      ['player.html', 'index.html'],
      ['player.js', 'player.js'],
      ['lang.js', 'lang.js'],
      ['ui.js', 'ui.js'],
      ['pkg/engine.js', 'pkg/engine.js'],
      ['pkg/engine_bg.wasm', 'pkg/engine_bg.wasm'],
    ];
    const engineFiles = [];
    for (const [n, out] of names) {
      const r = await fetch(n);
      if (!r.ok) throw new Error(n);
      engineFiles.push({ name: out, data: new Uint8Array(await r.arrayBuffer()) });
    }
    const tr = await fetch('template.apk');
    if (!tr.ok) throw new Error('template.apk');
    const templateBytes = new Uint8Array(await tr.arrayBuffer());
    let iconPng = null;
    try {
      if (p.icon && p.icon.startsWith('data:')) iconPng = await iconToPngBytes(p.icon);
    } catch (e) { iconPng = null; }
    if (!iconPng) {
      try { iconPng = new Uint8Array(await (await fetch('blockicon.png')).arrayBuffer()); } catch (e) { iconPng = null; }
    }
    const apk = buildGameApk({ templateBytes, engineFiles, gameJson, iconPng, label: p.name || 'HolyGGS Game', key: getExportKey() });
    const fname = (p.name || 'game').replace(/[\\/:*?"<>|]+/g, '_') + '.apk';
    const sizeKb = Math.round(apk.length / 1024) + ' КБ';
    if (window.Android && Android.saveFile) {
      Android.saveFile(fname, b64bytes(apk));
      alert(t('apkSaved') + '\n' + fname + ' (' + sizeKb + ')');
      return;
    }
    const blob = new Blob([apk], { type: 'application/octet-stream' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = fname;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
    alert(t('apkSaved') + '\n' + fname + ' (' + sizeKb + ')');
  } catch (e) {
    alert(t('apkFail') + ': ' + e);
  }
}

function importMappText(text, silent) {
  let d;
  try { d = JSON.parse(String(text).replace(/^\uFEFF/, '').trim()); } catch (e) { alert(t('mappBad') + ': JSON'); return; }
  let scene = null;
  if (d && d.mapp === 1 && d.scene && Array.isArray(d.scene.entities)) scene = d.scene;
  else if (d && Array.isArray(d.entities)) {
    scene = {
      v: d.v || 2, entities: d.entities,
      gfx: Array.isArray(d.gfx) ? d.gfx : [],
      script: typeof d.script === 'string' ? d.script : '',
      objScripts: d.objScripts && typeof d.objScripts === 'object' ? d.objScripts : {},
      srvScripts: d.srvScripts && typeof d.srvScripts === 'object' ? d.srvScripts : {},
      sysUI: d.sysUI && typeof d.sysUI === 'object' ? d.sysUI : {},
      pmRoot: Number.isInteger(d.pmRoot) ? d.pmRoot : -1,
    };
  }
  if (!scene) { if (!silent) alert(t('mappBad')); return null; }
  const list = store.projects();
  let name = String(d.name || t('newProject')).slice(0, 40);
  const names = new Set(list.map((x) => x.name));
  let i = 2;
  while (names.has(name)) name = String(d.name || t('newProject')).slice(0, 34) + ' (' + (i++) + ')';
  const p = { id: 'p' + Date.now() + Math.floor(Math.random() * 999), name, created: Date.now(), icon: d.icon || '' };
  store.saveProjects([p, ...list]);
  store.saveScene(p.id, scene);
  renderProjects();
  if (!silent) alert(t('mappImported') + ': ' + name);
  return p;
}

$('mappFile').addEventListener('change', () => {
  const f = $('mappFile').files && $('mappFile').files[0];
  $('mappFile').value = '';
  if (!f) return;
  const r = new FileReader();
  r.onload = () => importMappText(String(r.result));
  r.onerror = () => alert(t('mappBad'));
  r.readAsText(f);
});
$('mappImport').onclick = () => $('mappFile').click();

let selProj = null, pmFilterStr = '', pmSortMode = 'date', pmMenuEl = null;
function closePmMenu() { if (pmMenuEl) { pmMenuEl.remove(); pmMenuEl = null; } }
addEventListener('pointerdown', (e) => { if (pmMenuEl && !pmMenuEl.contains(e.target)) closePmMenu(); }, true);
function pmDelete(p) {
  $('delText').textContent = t('confirmDel', p.name);
  const bg = $('delBg');
  bg.classList.remove('hidden', 'show');
  requestAnimationFrame(() => requestAnimationFrame(() => bg.classList.add('show')));
  const close = () => {
    bg.classList.remove('show');
    setTimeout(() => bg.classList.add('hidden'), 230);
    $('delOk').onclick = null;
  };
  $('delCancel').onclick = close;
  bg.onclick = (e) => { if (e.target === bg) close(); };
  $('delOk').onclick = () => {
    close();
    store.saveProjects(store.projects().filter((x) => x.id !== p.id));
    store.delScene(p.id);
    if (selProj === p.id) selProj = null;
    renderProjects();
  };
}
function pmMenu(anchor, p) {
  closePmMenu();
  const m = document.createElement('div');
  m.className = 'pmMenu';
  const item = (label, cls, fn) => {
    const b = document.createElement('button');
    if (cls) b.className = cls;
    b.textContent = label;
    b.onclick = (e) => { e.stopPropagation(); closePmMenu(); fn(); };
    m.appendChild(b);
  };
  item(t('pm_fav'), '', () => { p.fav = p.fav ? 0 : 1; store.saveProjects(store.projects().map((x) => x.id === p.id ? p : x)); renderProjects(); });
  item(t('pm_rename'), '', () => pmRename(p));
  item(t('pm_dup'), '', () => pmDup(p));
  item(t('pm_export'), '', () => exportProject(p));
  item(t('pm_export_apk'), '', () => exportApk(p));
  item(t('pm_del'), 'danger', () => pmDelete(p));
  document.body.appendChild(m);
  const r = anchor.getBoundingClientRect();
  m.style.left = Math.min(r.left, innerWidth - 190) + 'px';
  m.style.top = Math.min(r.bottom + 6, innerHeight - 260) + 'px';
  pmMenuEl = m;
}
function pmRename(p) {
  const name = prompt(t('pm_rename_q'), p.name);
  if (!name || !name.trim()) return;
  p.name = name.trim().slice(0, 40);
  store.saveProjects(store.projects().map((x) => x.id === p.id ? p : x));
  renderProjects();
}
function pmDup(p) {
  const list = store.projects();
  const np = { id: 'p' + Date.now() + Math.floor(Math.random() * 999), name: (p.name + ' ' + t('pm_dup_name')).slice(0, 40), icon: p.icon || '', created: Date.now(), fav: 0 };
  store.saveProjects([np, ...list]);
  const s = store.scene(p.id);
  if (s) store.saveScene(np.id, JSON.parse(JSON.stringify(s)));
  selProj = np.id;
  renderProjects();
}
$('pRename').onclick = () => {
  const id = engine.selected();
  if (id < 0) return;
  const nm = prompt(t('pm_rename_q'), engine.entity_name(id));
  if (!nm || !nm.trim()) return;
  engine.set_entity_name(id, nm.trim().slice(0, 40));
  buildTree(); fillProps(id); scheduleSave();
};
function syncPmSide() {
  const p = store.projects().find((x) => x.id === selProj);
  for (const id of ['pmEdit', 'pmPlay', 'pmRename', 'pmDup', 'pmExport', 'pmDel']) $(id).disabled = !p;
}
function renderProjects() {
  let list = store.projects().slice();
  if (pmFilterStr) list = list.filter((p) => (p.name || '').toLowerCase().includes(pmFilterStr));
  list.sort((a, b) => (pmSortMode === 'name'
    ? (a.name || '').localeCompare(b.name || '')
    : ((b.modified || b.created || 0) - (a.modified || a.created || 0))));
  list.sort((a, b) => (b.fav ? 1 : 0) - (a.fav ? 1 : 0));
  const box = $('projects');
  box.innerHTML = '';
  $('empty').classList.toggle('hidden', list.length > 0);
  for (const p of list) {
    const r = document.createElement('div');
    r.className = 'pmRow' + (selProj === p.id ? ' sel' : '');
    const star = document.createElement('button');
    star.className = 'pmStar' + (p.fav ? ' on' : '');
    star.textContent = p.fav ? '★' : '☆';
    star.onclick = (e) => { e.stopPropagation(); p.fav = p.fav ? 0 : 1; store.saveProjects(store.projects().map((x) => x.id === p.id ? p : x)); renderProjects(); };
    const ico = document.createElement('div'); ico.className = 'pmIco';
    if (p.icon) ico.style.backgroundImage = `url(${p.icon})`; else ico.textContent = (p.name[0] || '?').toUpperCase();
    const mid = document.createElement('div'); mid.className = 'pmMid';
    const nm = document.createElement('div'); nm.className = 'pmName'; nm.textContent = p.name;
    const sub = document.createElement('div'); sub.className = 'pmSub';
    sub.textContent = 'Documents/HolyGGS/' + (p.name || 'project').replace(/[\/:*?"<>|]+/g, '_');
    mid.append(nm, sub);
    const dt = document.createElement('div'); dt.className = 'pmDate';
    dt.textContent = new Date(p.modified || p.created || Date.now()).toLocaleDateString(getLang() === 'ru' ? 'ru-RU' : 'en-US');
    const dots = document.createElement('button');
    dots.className = 'pmDots'; dots.textContent = '⋮';
    dots.onclick = (e) => { e.stopPropagation(); pmMenu(dots, p); };
    r.append(star, ico, mid, dt, dots);
    r.addEventListener('click', () => {
      if (selProj === p.id) { openProject(p); return; }
      selProj = p.id;
      renderProjects();
      syncPmSide();
    });
    box.appendChild(r);
  }
  syncPmSide();
}

$('pmEdit').onclick = () => { const p = store.projects().find((x) => x.id === selProj); if (p) openProject(p); };
$('pmPlay').onclick = () => {
  const p = store.projects().find((x) => x.id === selProj);
  if (p) openProject(p).then(() => { try { setPlay(true); } catch (e) { consolePrint('play: ' + e); } });
};
$('pmRename').onclick = () => { const p = store.projects().find((x) => x.id === selProj); if (p) pmRename(p); };
$('pmDup').onclick = () => { const p = store.projects().find((x) => x.id === selProj); if (p) pmDup(p); };
$('pmExport').onclick = () => { const p = store.projects().find((x) => x.id === selProj); if (p) exportProject(p); };
$('pmDel').onclick = () => { const p = store.projects().find((x) => x.id === selProj); if (p) pmDelete(p); };
$('pmAbout').onclick = () => alert('HolyGGS Engine\n' + verText + '\n© 2026');
$('pmFilter').addEventListener('input', () => {
  pmFilterStr = $('pmFilter').value.trim().toLowerCase();
  renderProjects();
});
$('pmSortSel').addEventListener('change', () => {
  pmSortMode = $('pmSortSel').value;
  renderProjects();
});

/* ================= настройки ================= */
function updSeg() {
  document.querySelectorAll('.seg button').forEach((b) => b.classList.toggle('on', b.dataset.lang === getLang()));
}
$('settingsBtn').onclick = () => { updSeg(); $('setBg').classList.remove('hidden'); };
$('setClose').onclick = () => $('setBg').classList.add('hidden');
$('setBg').addEventListener('click', (e) => { if (e.target === $('setBg')) $('setBg').classList.add('hidden'); });
document.querySelectorAll('.seg button').forEach((b) => {
  b.onclick = () => { setLang(b.dataset.lang); updSeg(); setVer(); renderProjects(); };
});

/* ================= шторка: проверки -> форма ================= */
let runId = 0;
let fullLog = [];
let newIcon = null;

const openSheet = () => { $('shade').classList.add('on'); $('sheet').classList.add('on'); };
const closeSheet = () => { runId++; $('shade').classList.remove('on'); $('sheet').classList.remove('on'); };

function logLine(level, msg) {
  const tag = { ok: '[ OK ] ', warn: '[WARN] ', fail: '[FAIL] ', info: '[ .. ] ' }[level] || '';
  const d = document.createElement('div');
  d.className = 'l ' + level;
  d.textContent = tag + msg;
  $('log').appendChild(d);
  $('log').scrollTop = $('log').scrollHeight;
  fullLog.push(tag + msg);
}

async function runChecks(token) {
  let ok = true;
  const L = async (level, msg) => {
    if (token !== runId) throw new Error('cancel');
    if (level === 'fail') ok = false;
    logLine(level, msg);
    await sleep(110);
  };

  await L('info', t('log_start'));
  await L(typeof WebAssembly === 'object' ? 'ok' : 'fail', 'WebAssembly');

  if (!(await wasmReady)) {
    await L('fail', t('log_core_fail', wasmErr));
    return false;
  }
  await L('ok', t('log_core_ok', version()));

  for (const line of run_self_test(getLang() === 'en').split('\n')) {
    const m = line.match(/^(OK|WARN|FAIL) (.*)$/);
    if (m) await L(m[1].toLowerCase(), m[2]); else if (line) await L('info', line);
  }

  try {
    const cv = document.createElement('canvas');
    const gl = cv.getContext('webgl2');
    if (!gl) throw new Error('webgl2 unavailable');
    const dbg = gl.getExtension('WEBGL_debug_renderer_info');
    const gpu = dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : '?';
    await L('ok', t('log_webgl', gpu));
    await L('ok', t('log_tex', gl.getParameter(gl.MAX_TEXTURE_SIZE)));
    const hdr = !!(gl.getExtension('EXT_color_buffer_float') || gl.getExtension('EXT_color_buffer_half_float'));
    await L(hdr ? 'ok' : 'warn', 'HDR: ' + (hdr ? 'on' : 'off (LDR fallback)'));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
  } catch (e) {
    await L('fail', t('log_webgl_fail', e.message));
  }

  try {
    localStorage.setItem('eng.test', '1');
    if (localStorage.getItem('eng.test') !== '1') throw new Error('read mismatch');
    localStorage.removeItem('eng.test');
    await L('ok', t('log_store_ok'));
  } catch (e) {
    await L('fail', t('log_store_fail', e.message));
  }

  const thr = self.crossOriginIsolated && typeof SharedArrayBuffer !== 'undefined';
  await L(thr ? 'ok' : 'warn', t('log_threads', t(thr ? 'thr_yes' : 'thr_no')));
  await L('info', t('log_physics'));
  await L(ok ? 'ok' : 'fail', t(ok ? 'log_all_ok' : 'log_some_fail'));
  return ok;
}

async function startNew() {
  const token = ++runId;
  fullLog = [];
  newIcon = null;
  $('log').innerHTML = '';
  $('ldTitle').textContent = 'Loading. . .';
  $('cubes').classList.remove('stop');
  $('ldBtns').classList.add('hidden');
  $('copyLog').textContent = t('copyLog');
  $('ld').classList.remove('hidden');
  $('form').classList.add('hidden');
  $('iconBtn').style.backgroundImage = '';
  $('iconBtn').classList.remove('has');
  $('nameIn').value = '';
  openSheet();

  let ok = false;
  try {
    const t0 = performance.now();
    ok = await runChecks(token);
    const left = 1400 - (performance.now() - t0);
    if (left > 0) await sleep(left);
  } catch (e) {
    if (token !== runId) return;
    logLine('fail', t('log_exc', e));
  }
  if (token !== runId) return;

  if (ok) {
    $('ld').classList.add('hidden');
    $('form').classList.remove('hidden');
  } else {
    $('ldTitle').textContent = t('checkFail');
    $('cubes').classList.add('stop');
    $('ldBtns').classList.remove('hidden');
  }
}

$('plus').onclick = startNew;
$('shade').onclick = closeSheet;
$('closeLd').onclick = closeSheet;
$('copyLog').onclick = async () => {
  const txt = fullLog.join('\n');
  try { await navigator.clipboard.writeText(txt); $('copyLog').textContent = t('copied'); }
  catch { alert(txt); }
};

function toIcon(file) {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const s = 192, c = document.createElement('canvas');
      c.width = c.height = s;
      const m = Math.min(img.width, img.height);
      c.getContext('2d').drawImage(img, (img.width - m) / 2, (img.height - m) / 2, m, m, 0, 0, s, s);
      URL.revokeObjectURL(url);
      res(c.toDataURL('image/png'));
    };
    img.onerror = rej;
    img.src = url;
  });
}
$('iconBtn').onclick = () => $('file').click();
$('file').onchange = async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  try {
    newIcon = await toIcon(f);
    $('iconBtn').style.backgroundImage = `url(${newIcon})`;
    $('iconBtn').classList.add('has');
  } catch { alert(t('imgFail')); }
  e.target.value = '';
};

$('create').onclick = () => {
  const p = {
    id: Date.now().toString(36),
    name: $('nameIn').value.trim() || t('newProject'),
    icon: newIcon,
    created: Date.now(),
  };
  store.saveProjects([p, ...store.projects()]);
  closeSheet();
  renderProjects();
  openProject(p);
};

/* ================= воркспейс ================= */
let engine = null, cur = null, raf = 0, lastT = 0, saveTimer = 0;
let frames = 0, fpsAcc = 0;
let gfxDefs = [], gfxVals = [], gfxGroup = null;

const PLATE_COLOR = [0.62, 0.62, 0.64];
const defaultPlate = () => ({
  name: t('plate'),
  props: [0, -0.5, 0, 0, 0, 0, 40, 1, 40, ...PLATE_COLOR, 0],
});

async function lockLandscape() {
  if (!matchMedia('(pointer:coarse)').matches) return;
  try { if (!document.fullscreenElement) await document.documentElement.requestFullscreen(); } catch {}
  try { await screen.orientation.lock('landscape'); } catch {}
}
function unlockOrientation() {
  try { screen.orientation.unlock(); } catch {}
  try { if (document.fullscreenElement) document.exitFullscreen(); } catch {}
}

function fadeOutEl(el, ms) {
  return new Promise((res) => {
    el.classList.add('fading');
    setTimeout(() => { el.classList.add('hidden'); el.classList.remove('fading'); res(); }, ms || 240);
  });
}
function fadeInEl(el) {
  el.classList.remove('hidden');
  el.classList.add('fading');
  requestAnimationFrame(() => requestAnimationFrame(() => el.classList.remove('fading')));
}
let splashT0 = 0;
function showSplash() {
  splashT0 = performance.now();
  const el = $('splash');
  $('spTip').textContent = t('tip' + (1 + Math.floor(Math.random() * 4)));
  $('spBar').classList.remove('run');
  el.classList.remove('hidden', 'show');
  requestAnimationFrame(() => requestAnimationFrame(() => {
    el.classList.add('show');
    $('spBar').classList.add('run');
  }));
}
function hideSplash() {
  const el = $('splash');
  el.classList.remove('show');
  setTimeout(() => el.classList.add('hidden'), 420);
}

async function openProject(p) {
  cur = p;
  showSplash();
  await fadeOutEl($('menu'), 230);
  fadeInEl($('work'));
  document.body.classList.add('work-on');
  $('rot').classList.remove('dismissed');
  $('projName').textContent = p.name;
  await lockLandscape();

  if (!(await wasmReady)) { alert(t('coreNotLoaded', wasmErr)); backToMenu(); return; }
  if (!engine) {
    try { engine = new Engine('c'); }
    catch (e) { alert(t('engineFail', e)); backToMenu(); return; }
  }
  gfxDefs = Array.from(gfx_defaults());
  engine.set_mode(mode);
  setPlay(false);
  resizeCanvas();
  try {
    loadScene(p.id);
    buildTree();
    syncSelection();
  } catch (e) {
    consolePrint('load: ' + e);
    try { buildTree(); } catch {}
  }
  lastT = performance.now();
  cancelAnimationFrame(raf);
  raf = requestAnimationFrame(loop);
  const wait = Math.max(0, 850 - (performance.now() - splashT0));
  if (wait) await sleep(wait);
  hideSplash();
}

async function backToMenu() {
  setPlay(false);
  cancelAnimationFrame(raf);
  flushSave();
  if (engine) engine.set_move(0, 0, 0);
  joy.x = joy.z = joy.y = 0;
  await fadeOutEl($('work'), 220);
  fadeInEl($('menu'));
  document.body.classList.remove('work-on');
  unlockOrientation();
  cur = null;
  renderProjects();
}
$('back').onclick = backToMenu;
$('rot').addEventListener('click', () => $('rot').classList.add('dismissed'));

let wdCount = 0;
function loop(ts) {
  const dt = Math.min((ts - lastT) / 1000, 0.1);
  lastT = ts;
  if (play) {
    if (rt) rt.update(dt);
    for (const o of objRts) { try { o.rt.update(dt); } catch (e) { consolePrint(o.nm + ': ' + e); } }
    for (const o of srvRts) { try { o.rt.update(dt); } catch (e) { consolePrint(o.nm + ': ' + e); } }
  }
  if (++wdCount >= 30) { wdCount = 0; resizeCanvas(); }
  try { engine.frame(dt); } catch (e) { consolePrint('frame: ' + e); }
  frames++; fpsAcc += dt;
  if (fpsAcc >= 0.5) {
    $('fps').textContent = 'FPS ' + Math.round(frames / fpsAcc) + (engine.hdr() ? ' · HDR' : '');
    frames = 0; fpsAcc = 0;
  }
  raf = requestAnimationFrame(loop);
}

let rsRetry = 0;
function resizeCanvas() {
  if (!engine) return;
  const v = $('view');
  const w = v.clientWidth, h = v.clientHeight;
  if (w < 32 || h < 32) {
    // переходы (клавиатура, фуллскрин, поворот) дают крошечный размер — не портим FBO
    if (!rsRetry) rsRetry = setTimeout(() => { rsRetry = 0; resizeCanvas(); }, 300);
    return;
  }
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const W = Math.floor(w * dpr), H = Math.floor(h * dpr);
  const cvv = $('c');
  if (Math.abs(cvv.width - W) <= 2 && Math.abs(cvv.height - H) <= 2) return;
  engine.resize(W, H);
}
new ResizeObserver(resizeCanvas).observe($('view'));
for (const ev of ['resize', 'fullscreenchange', 'orientationchange']) {
  addEventListener(ev, () => { setTimeout(resizeCanvas, 120); setTimeout(resizeCanvas, 500); });
}
// самовосстановление графики при потере WebGL-контекста
$('c').addEventListener('webglcontextlost', (e) => {
  e.preventDefault();
  try { flushSave(); } catch {}
  const now = Date.now();
  let last = 0;
  try { last = +sessionStorage.getItem('ctxReload') || 0; } catch {}
  if (now - last > 15000) {
    try { sessionStorage.setItem('ctxReload', String(now)); } catch {}
    setTimeout(() => location.reload(), 300);
  }
});

/* ---------- сцена ---------- */
function loadScene(id) {
  engine.clear();
  applyScene(store.scene(id));
}
function applyScene(s) {
  const ents = s && Array.isArray(s.entities) && s.entities.length ? s.entities : [defaultPlate()];
  if (s && (s.v || 1) < 2) {
    // миграция: старая зелёная плита -> серая
    for (const e of ents) {
      const p = e.props;
      if (p && Math.abs(p[9] - 0.45) < 0.01 && Math.abs(p[10] - 0.70) < 0.01 && Math.abs(p[11] - 0.40) < 0.01) {
        p[9] = PLATE_COLOR[0]; p[10] = PLATE_COLOR[1]; p[11] = PLATE_COLOR[2];
      }
    }
  }
  const newIds = ents.map((e) => engine.add_entity(e.name, new Float32Array(e.props)));
  ents.forEach((e, i) => {
    if (Number.isInteger(e.parent) && e.parent >= 0 && e.parent < newIds.length && e.parent !== i) {
      engine.set_parent(newIds[i], newIds[e.parent]);
    }
    if (e.edit && e.edit.cells) {
      engine.set_edit(newIds[i], e.edit.sub | 0, e.edit.round || 0, e.edit.cells);
      if (e.edit.colors) engine.set_edit_colors(newIds[i], e.edit.colors);
    }
  });
  gfxVals = gfxDefs.map((d, i) => (s && Array.isArray(s.gfx) && Number.isFinite(s.gfx[i]) ? s.gfx[i] : d));
  gfxVals.forEach((v, i) => engine.set_gfx(i, v));
  gfxGroup = null;
  scriptText = s && typeof s.script === 'string' ? s.script : DEFAULT_SCRIPT;
  for (const k of Object.keys(objScripts)) delete objScripts[k];
  if (s && s.objScripts && typeof s.objScripts === 'object') Object.assign(objScripts, s.objScripts);
  for (const k of Object.keys(srvScripts)) delete srvScripts[k];
  if (s && s.srvScripts && typeof s.srvScripts === 'object') Object.assign(srvScripts, s.srvScripts);
  engine.set_pm_root(s && Number.isInteger(s.pmRoot) && s.pmRoot >= 0 && s.pmRoot < newIds.length ? newIds[s.pmRoot] : -1);
  engine.reset_camera();
  const rawUI = (s && s.sysUI) || {};
  const uiFlag = (v) => (v === 0 || v === false ? 0 : 1);
  sysUI = { joy: uiFlag(rawUI.joy), cam: uiFlag(rawUI.cam), jump: uiFlag(rawUI.jump), fps: uiFlag(rawUI.fps) };
  applySysUI();
  if (uiMgr) { uiMgr.load((s && s.ui) || []); uiSel = null; fillUIProps(); }
}
function collectScene() {
  const ids = Array.from(engine.entity_ids());
  const entities = ids.map((id) => {
    const ed = engine.get_edit(id);
    return {
      name: engine.entity_name(id),
      props: Array.from(engine.get_props(id)),
      parent: ids.indexOf(engine.parent_of(id)),
      edit: ed.length ? {
        sub: Math.round(ed[0]), round: ed[1] || 0,
        cells: engine.edit_cells_hex(id), colors: engine.edit_colors_hex(id),
      } : undefined,
    };
  });
  return { v: 2, entities, gfx: gfxVals.slice(), script: scriptText, objScripts: { ...objScripts }, srvScripts: { ...srvScripts }, sysUI: { ...sysUI }, ui: uiMgr ? uiMgr.collect() : [], pmRoot: ids.indexOf(engine.pm_root()) };
}
function flushSave() {
  clearTimeout(saveTimer);
  if (cur && engine) {
    store.saveScene(cur.id, collectScene());
    const list = store.projects();
    const p = list.find((x) => x.id === cur.id);
    if (p && !p.modified) { p.modified = Date.now(); store.saveProjects(list); }
  }
}
const scheduleSave = () => { clearTimeout(saveTimer); saveTimer = setTimeout(flushSave, 500); };
document.addEventListener('visibilitychange', () => { if (document.hidden) flushSave(); });
addEventListener('pagehide', flushSave);

/* ---------- дерево ---------- */
function blockIcon() {
  const img = new Image();
  img.src = 'blockicon.png';
  img.className = 'bico';
  img.alt = '';
  img.draggable = false;
  img.onerror = () => img.replaceWith(document.createTextNode('■'));
  return img;
}
const IC_PATHS = {
  user: '<circle cx="12" cy="8" r="3.4"/><path d="M5.5 20c0-3.4 2.9-5.6 6.5-5.6s6.5 2.2 6.5 5.6"/>',
  sphere: '<circle cx="12" cy="12" r="7.5"/><path d="M4.8 9.5c2 2.2 4.4 3.2 7.2 3.2s5.4-1 7.2-3.2"/>',
  script: '<path d="M7 3h8l4 4v14H7z"/><path d="M15 3v4h4"/><path d="M10 12h6M10 16h6"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2.6M12 19.4V22M2 12h2.6M19.4 12H22M4.9 4.9l1.9 1.9M17.2 17.2l1.9 1.9M19.1 4.9l-1.9 1.9M6.8 17.2l-1.9 1.9"/>',
  fx: '<path d="M12 5c.7 3.2 1.8 4.3 5 5-3.2.7-4.3 1.8-5 5-.7-3.2-1.8-4.3-5-5 3.2-.7 4.3-1.8 5-5z"/><path d="M18.5 3.5v3M17 5h3"/>',
  col: '<circle cx="12" cy="12" r="7.5"/><path d="M12 4.5a7.5 7.5 0 010 15z" fill="currentColor" stroke="none"/>',
  fog: '<path d="M6.5 17.5h10a3.5 3.5 0 000-7 5.2 5.2 0 00-9.8 1.4 2.9 2.9 0 00-.2 5.6z"/>',
  wat: '<path d="M3 9c2-2 4-2 6 0s4 2 6 0 4-2 6 0M3 15c2-2 4-2 6 0s4 2 6 0 4-2 6 0"/>',
  cam: '<circle cx="12" cy="12" r="7.5"/><circle cx="12" cy="12" r="3"/>',
  q: '<path d="M4 8h8M16 8h4M4 16h4M12 16h8"/><circle cx="14" cy="8" r="2"/><circle cx="10" cy="16" r="2"/>',
  fire: '<path d="M12 22c3.3 0 6-2.3 6-5.5 0-4.6-4-6.4-5-11.5-3 3-7 5.3-7 10.1 0 3.9 2.7 6.9 6 6.9z"/>',
  out: '<path d="M4 5h16v12H8l-4 3z"/><path d="M8 9h8M8 12.5h5"/>',
  pencil: '<path d="M4 20l1.2-4.2L16 5l3 3L8.2 18.8z"/><path d="M13.2 7.8l3 3"/>',
  find: '<circle cx="10.5" cy="10.5" r="6"/><path d="M15 15l5 5"/>',
};
function ic(name) {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24');
  s.setAttribute('class', 'ic');
  s.innerHTML = IC_PATHS[name] || '';
  return s;
}
function kindOf(id) {
  const p = engine.get_props(id);
  return p[15] > 0.5 ? 'fire' : p[14] > 0.5 ? 'water' : 'block';
}
function entIcon(id) {
  const k = kindOf(id);
  return k === 'fire' ? ic('fire') : k === 'water' ? ic('wat') : blockIcon();
}
function mkRow(icon, name, sub, depth, plusFor) {
  const r = document.createElement('div');
  r.className = 'row';
  r.style.paddingLeft = 10 + depth * 18 + 'px';
  const i = document.createElement('span'); i.className = 'ri';
  if (typeof icon === 'string') i.textContent = icon; else i.appendChild(icon);
  const n = document.createElement('span'); n.className = 'rn'; n.textContent = name;
  r.append(i, n);
  if (sub) { const sm = document.createElement('small'); sm.textContent = sub; r.append(sm); }
  if (plusFor !== undefined) {
    const b = document.createElement('button');
    b.className = 'rowplus'; b.textContent = '+'; b.setAttribute('aria-label', 'Add');
    b.onclick = (e) => { e.stopPropagation(); openSpawnMenu(b, plusFor); };
    r.append(b);
  }
  return r;
}
function folder(label, sub, depth, plusFor, build) {
  const root = mkRow('▾', label, sub, depth, plusFor);
  const kids = document.createElement('div');
  build(kids);
  root.onclick = () => {
    kids.classList.toggle('hidden');
    root.firstChild.textContent = kids.classList.contains('hidden') ? '▸' : '▾';
  };
  return [root, kids];
}
function buildTree() {
  const tb = $('treeBody');
  tb.innerHTML = '';
  const ids = Array.from(engine.entity_ids());
  const byParent = new Map();
  for (const id of ids) {
    let par = engine.parent_of(id);
    if (!ids.includes(par)) par = -1;
    if (!byParent.has(par)) byParent.set(par, []);
    byParent.get(par).push(id);
  }
  const add = (box, parent, depth, skip = null) => {
    for (const id of byParent.get(parent) || []) {
      if (skip && skip.has(id)) continue;
      const r = mkRow(entIcon(id), engine.entity_name(id), '', depth, id);
      r.dataset.id = id;
      const kidsAll = byParent.get(id) || [];
      const hasKids = kidsAll.some((k) => !skip || !skip.has(k));
      if (hasKids) {
        const tw = document.createElement('span');
        tw.className = 'tw'; tw.textContent = '▾';
        r.prepend(tw);
        const sub = document.createElement('div');
        sub.className = 'kids';
        r.addEventListener('click', (e) => {
          if (e.target === tw) {
            sub.classList.toggle('hidden');
            tw.textContent = sub.classList.contains('hidden') ? '▸' : '▾';
            return;
          }
          engine.select(id); syncSelection();
        });
        box.appendChild(r);
        add(sub, id, depth + 1, skip);
        box.appendChild(sub);
      } else {
        if (depth > 0) r.classList.add('leafkid');
        r.addEventListener('click', () => { engine.select(id); syncSelection(); });
        box.appendChild(r);
      }
    }
  };
  const pmRoot = engine.pm_root();
  const pmSet = new Set();
  if (pmRoot >= 0) { pmSet.add(pmRoot); for (const d of engine.descendants_of(pmRoot)) pmSet.add(d); }
  tb.append(...folder('@P', t('player'), 0, undefined, (box) => {
    const rModel = mkRow(ic('user'), t('player_model'), pmRoot >= 0 ? engine.entity_name(pmRoot) : t('player_model_none'), 1);
    rModel.onclick = () => {
      const sel = engine.selected();
      if (sel >= 0 && sel !== pmRoot) {
        engine.set_pm_root(sel);
        buildTree(); scheduleSave();
      } else if (pmRoot >= 0) {
        engine.select(pmRoot); syncSelection();
      }
    };
    box.appendChild(rModel);
    if (pmRoot < 0) {
      const rNew = mkRow('＋', t('player_create'), '', 1);
      rNew.onclick = () => { createPlayerModel(); };
      box.appendChild(rNew);
    }
    const rSph = mkRow(ic('sphere'), t('player_sphere'), pmRoot < 0 ? '✓' : '', 1);
    rSph.onclick = () => { engine.set_pm_root(-1); buildTree(); scheduleSave(); };
    box.appendChild(rSph);
    const rHum = mkRow(ic('user'), t('player_human'), pmRoot >= 0 ? '✓' : '', 1);
    rHum.onclick = () => { if (engine.pm_root() < 0) createPlayerModel(); };
    box.appendChild(rHum);
    const rScript = mkRow(ic('script'), 'player.hgs', '', 1);
    rScript.onclick = () => openScriptFor('player');
    box.appendChild(rScript);
  }));
  tb.append(...folder('@W', 'Workspace', 0, -1, (box) => add(box, -1, 1, pmSet)));
  tb.append(...folder('@UI', 'UI', 0, undefined, (box) => {
    const rNew = mkRow('＋', t('ui_new'), '', 1);
    rNew.onclick = (e) => { e.stopPropagation(); openUIMenu(rNew); };
    box.appendChild(rNew);
    for (const d of uiMgr.list) {
      const ico = d.type === 'frame' ? '▢' : d.type === 'label' ? 'T' : d.type === 'button' ? '⬚' : '⌨';
      const r = mkRow(ico, d.name, d.type, 1);
      r.classList.add('uiRow');
      r.addEventListener('click', () => selectUI(d.name));
      if (uiSel === d.name) r.classList.add('on');
      box.appendChild(r);
    }
  }));
  tb.append(...folder('@A', t('graphics'), 0, undefined, (box) => {
    for (const g of GROUPS) {
      const r = mkRow(ic(g.icon), t(g.k), '', 1);
      r.dataset.g = g.id;
      r.onclick = () => openGfx(g.id);
      box.appendChild(r);
    }
  }));
  tb.append(...folder('@S', t('server'), 0, undefined, (box) => {
    for (const nm of Object.keys(srvScripts)) {
      const r = mkRow(ic('script'), nm + '.hgs', '', 1);
      r.onclick = () => openScriptFor('server', nm);
      const del = document.createElement('button');
      del.className = 'rowplus'; del.textContent = '✕'; del.setAttribute('aria-label', 'Delete');
      del.onclick = (e) => { e.stopPropagation(); delete srvScripts[nm]; buildTree(); scheduleSave(); };
      r.append(del);
      box.appendChild(r);
    }
    const rNew = mkRow('＋', t('server_new'), '', 1);
    rNew.onclick = () => {
      let i = 1, nm;
      do { nm = 'server' + (i++); } while (srvScripts[nm] !== undefined);
      srvScripts[nm] = DEFAULT_SRV;
      buildTree(); scheduleSave();
      openScriptFor('server', nm);
    };
    box.appendChild(rNew);
  }));
}

/* ---------- мини-меню "+" ---------- */
let menuEl = null;
function closeSpawnMenu() { if (menuEl) { menuEl.remove(); menuEl = null; } }
addEventListener('pointerdown', (e) => {
  if (menuEl && !menuEl.contains(e.target) && !(e.target.classList && e.target.classList.contains('rowplus'))) closeSpawnMenu();
}, true);
function openSpawnMenu(anchor, parentId) {
  closeSpawnMenu();
  const m = document.createElement('div');
  m.id = 'spawnMenu';
  for (const [kind, ico] of [['block', '■'], ['water', '≈'], ['fire', '🔥']]) {
    const b = document.createElement('button');
    const i = document.createElement('span'); i.className = 'mi'; i.textContent = ico;
    const n = document.createElement('span'); n.textContent = t(kind);
    b.append(i, n);
    b.onclick = () => { closeSpawnMenu(); spawn(kind, parentId); };
    m.appendChild(b);
  }
  document.body.appendChild(m);
  const r = anchor.getBoundingClientRect();
  m.style.left = Math.max(8, r.left - m.offsetWidth - 6) + 'px';
  m.style.top = Math.max(8, Math.min(r.top, innerHeight - m.offsetHeight - 8)) + 'px';
  menuEl = m;
}

function spawn(kind, parentId) {
  if (!engine) return;
  const ids = Array.from(engine.entity_ids());
  const par = ids.includes(parentId) ? engine.get_props(parentId) : null;
  const size = kind === 'block' ? [4, 4, 4] : kind === 'water' ? [16, 2, 16] : [1.6, 2.8, 1.6];
  const color = kind === 'block' ? [0.30, 0.62, 0.95] : kind === 'water' ? [0.05, 0.28, 0.38] : [1.0, 0.5, 0.12];
  const alpha = kind === 'water' ? 0.78 : 1;
  let pos;
  if (par) {
    const top = par[1] + par[7] * 0.5;
    pos = [par[0], kind === 'water' ? top - size[1] * 0.5 : top + size[1] * 0.5, par[2]];
  } else {
    const f = engine.camera_front(kind === 'block' ? 12 : 16);
    pos = kind === 'block' ? [f[0], Math.max(f[1], 2), f[2]]
        : kind === 'water' ? [f[0], -0.5, f[2]]
        : [f[0], size[1] / 2, f[2]];
  }
  const props = [...pos, 0, 0, 0, ...size, ...color, 0, alpha, kind === 'water' ? 1 : 0, kind === 'fire' ? 1 : 0, 0, 0];
  const id = engine.add_entity(uniqueName(t(kind)), new Float32Array(props));
  if (par) engine.set_parent(id, parentId);
  buildTree();
  engine.select(id);
  syncSelection();
  scheduleSave();
}


function uniqueName(base) {
  const used = new Set(engine.entity_ids().map((i) => engine.entity_name(i)));
  let n = 1;
  while (used.has(`${base} ${n}`)) n++;
  return `${base} ${n}`;
}

/* ---------- свойства блока ---------- */
const fmt = (v) => String(Math.round(v * 1000) / 1000);
const h2 = (v) => Math.round(Math.min(1, Math.max(0, v)) * 255).toString(16).padStart(2, '0');
const toHex = (r, g, b) => '#' + h2(r) + h2(g) + h2(b);
const vecRows = [
  [$('iPosX'), $('iPosY'), $('iPosZ')],
  [$('iRotX'), $('iRotY'), $('iRotZ')],
  [$('iSizeX'), $('iSizeY'), $('iSizeZ')],
];
const parseNum = (str) => {
  const v = parseFloat(String(str).replace(',', '.'));
  return Number.isFinite(v) ? v : null;
};

function fillProps(id) {
  const p = engine.get_props(id);
  if (p.length < 13) return;
  const put = (row, a, b, c) => {
    row[0].value = fmt(a); row[1].value = fmt(b); row[2].value = fmt(c);
    row.forEach((i) => i.classList.remove('bad'));
  };
  put(vecRows[0], p[0], p[1], p[2]);
  put(vecRows[1], p[3], p[4], p[5]);
  put(vecRows[2], p[6], p[7], p[8]);
  $('pColor').value = toHex(p[9], p[10], p[11]);
  if (typeof cp !== 'undefined') cp.loadFromInput();
  $('pNeon').checked = p[12] > 0.5;
  $('pAlpha').value = p.length > 13 ? p[13] : 1;
  const k = kindOf(id);
  $('matRow').style.display = k === 'block' ? '' : 'none';
  $('wtexRow').style.display = k === 'water' ? '' : 'none';
  $('shapeRow').style.display = k === 'block' ? '' : 'none';
  $('editRow').style.display = k === 'block' && Math.round(p[18] || 0) === 0 ? '' : 'none';
  $('objScriptRow').style.display = '';
  $('pObjScript').onclick = () => openScriptFor('object', engine.entity_name(id));
  if (k === 'block') {
    $('pMat').value = String(Math.min(5, Math.max(0, Math.round(p[16] || 0))));
    $('pShape').value = String(Math.min(4, Math.max(0, Math.round(p[18] || 0))));
  }
  if (k === 'water') $('pWtex').value = (p[17] || 0) > 0.5 ? '1' : '0';
}
function onEdit() {
  const id = engine.selected();
  if (id < 0) return;
  const v = vecRows.map((row) => row.map((i) => parseNum(i.value)));
  vecRows.forEach((row, k) => row.forEach((i, j) => i.classList.toggle('bad', v[k][j] === null)));
  if (v.some((r) => r.some((x) => x === null))) return;
  const hex = $('pColor').value;
  const c = [1, 3, 5].map((k) => parseInt(hex.slice(k, k + 2), 16) / 255);
  const cur = Array.from(engine.get_props(id));
  const kind = kindOf(id);
  const mat = kind === 'block' ? (parseFloat($('pMat').value) || 0) : (cur[16] || 0);
  const wt = kind === 'water' ? (parseFloat($('pWtex').value) || 0) : (cur[17] || 0);
  const shp = kind === 'block' ? (parseFloat($('pShape').value) || 0) : (cur[18] || 0);
  engine.set_props(id, new Float32Array([...v[0], ...v[1], ...v[2], ...c,
    $('pNeon').checked ? 1 : 0, parseFloat($('pAlpha').value),
    cur[14] || 0, cur[15] || 0, mat, wt, shp, cur[19] === undefined ? 0.35 : cur[19]]));
  offsetSubtree(id, cur, v[0]);
  scheduleSave();
}
vecRows.flat().forEach((i) => {
  i.addEventListener('input', onEdit);
  i.addEventListener('keydown', (e) => { if (e.key === 'Enter') i.blur(); });
  i.addEventListener('blur', () => { const id = engine.selected(); if (id >= 0) fillProps(id); });
});
$('pColor').addEventListener('input', onEdit);
$('pNeon').addEventListener('change', onEdit);
$('pAlpha').addEventListener('input', onEdit);

/* ---------- палитра цвета (вместо системного пикера) ---------- */
const cp = {
  h: 0, s: 0.7, v: 0.7,
  hexToHsv(hex) {
    const r = parseInt(hex.slice(1, 3), 16) / 255, g = parseInt(hex.slice(3, 5), 16) / 255, b = parseInt(hex.slice(5, 7), 16) / 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
    let h = 0;
    if (d > 0) {
      if (mx === r) h = ((g - b) / d + 6) % 6;
      else if (mx === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60;
    }
    return [h, mx ? d / mx : 0, mx];
  },
  hsvToHex(h, sv, vv) {
    const f = (n) => {
      const k = (n + h / 60) % 6;
      const x = vv - vv * sv * Math.max(0, Math.min(k, 4 - k, 1));
      return Math.round(x * 255).toString(16).padStart(2, '0');
    };
    return '#' + f(5) + f(3) + f(1);
  },
  sync() {
    const hex = this.hsvToHex(this.h, this.s, this.v);
    $('pColor').value = hex;
    $('pColorSw').style.background = hex;
    $('cpCur').style.background = hex;
    $('cpHex').value = hex;
    $('cpHue').value = String(Math.round(this.h));
    $('cpSV').style.background = this.hsvToHex(this.h, 1, 1);
    const cur = $('cpCursor');
    cur.style.left = (this.s * 100) + '%';
    cur.style.top = ((1 - this.v) * 100) + '%';
    onEdit();
  },
  loadFromInput() {
    const hex = $('pColor').value;
    if (!/^#[0-9a-f]{6}$/i.test(hex)) return;
    const [h, s, v] = this.hexToHsv(hex);
    this.h = h; this.s = s; this.v = v;
    $('pColorSw').style.background = hex;
    $('cpCur').style.background = hex;
    $('cpHex').value = hex;
    $('cpHue').value = String(Math.round(h));
    $('cpSV').style.background = this.hsvToHex(h, 1, 1);
    $('cpCursor').style.left = (s * 100) + '%';
    $('cpCursor').style.top = ((1 - v) * 100) + '%';
  },
};
const CP_SWATCHES = ['#e74c3c','#e67e22','#f1c40f','#73b366','#2ecc71','#1abc9c','#3498db','#5b6ee1',
  '#9b59b6','#e84393','#ffffff','#bdc3c7','#7f8c8d','#34495e','#8b5a2b','#2c3e50'];
CP_SWATCHES.forEach((col) => {
  const b = document.createElement('button');
  b.type = 'button';
  b.style.background = col;
  b.addEventListener('click', () => {
    $('pColor').value = col;
    cp.loadFromInput();
    cp.sync();
  });
  $('cpSwatches').appendChild(b);
});
function cpOpen() {
  cp.loadFromInput();
  $('colorPop').classList.add('on');
}
function cpClose() { $('colorPop').classList.remove('on'); }
$('pColorBtn').addEventListener('click', cpOpen);
$('cpClose').addEventListener('click', cpClose);
$('colorPop').addEventListener('click', (e) => { if (e.target === $('colorPop')) cpClose(); });
$('cpHue').addEventListener('input', () => { cp.h = parseFloat($('cpHue').value); cp.sync(); });
$('cpHex').addEventListener('change', () => {
  let v = $('cpHex').value.trim();
  if (!v.startsWith('#')) v = '#' + v;
  if (/^#[0-9a-f]{6}$/i.test(v)) { $('pColor').value = v.toLowerCase(); cp.loadFromInput(); cp.sync(); }
  else cp.loadFromInput();
});
(function cpSVBind() {
  const el = $('cpSV');
  let on = false;
  const pick = (e) => {
    const r = el.getBoundingClientRect();
    cp.s = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
    cp.v = 1 - Math.min(1, Math.max(0, (e.clientY - r.top) / r.height));
    cp.sync();
  };
  el.addEventListener('pointerdown', (e) => { on = true; el.setPointerCapture(e.pointerId); pick(e); });
  el.addEventListener('pointermove', (e) => { if (on) pick(e); });
  el.addEventListener('pointerup', () => { on = false; });
  el.addEventListener('pointercancel', () => { on = false; });
})();
cp.loadFromInput();

/* ---------- материалы и текстуры из галереи ---------- */
let texTarget = 'mat';
function pickTexture(target) {
  texTarget = target;
  $('texFile').value = '';
  $('texFile').click();
}
$('pMat').addEventListener('change', () => {
  if (engine.selected() < 0) return;
  if ($('pMat').value === '5') pickTexture('mat');
  else onEdit();
});
$('pWtex').addEventListener('change', () => {
  if (engine.selected() < 0) return;
  if ($('pWtex').value === '1') pickTexture('water');
  else onEdit();
});
$('pShape').addEventListener('change', () => {
  if (engine.selected() < 0) return;
  onEdit();
  if (editMode) closeEdit();
  buildTree();
});

/* ---------- режим правки (Blender-like) ---------- */
function snapEdit() {
  const id = engine.edit_id();
  const ed = engine.get_edit(id);
  return { sub: ed.length ? Math.round(ed[0]) : 0, round: ed.length > 1 ? ed[1] : 0, cells: engine.edit_cells_hex(id), colors: engine.edit_colors_hex(id) };
}
function restoreEdit(s) {
  const id = engine.edit_id();
  if (id < 0) return;
  engine.set_edit(id, s.sub, s.round, s.cells);
  engine.set_edit_colors(id, s.colors || '');
}
function pushHist(label) {
  editHist.push({ label: label || 'правка', snap: snapEdit() });
  if (editHist.length > 40) editHist.shift();
  editRedo.length = 0;
  renderHist();
}
function renderHist() {
  const box = $('histList');
  if (!box) return;
  box.innerHTML = '';
  editHist.forEach((h, i) => {
    const d = document.createElement('div');
    d.textContent = (i + 1) + '. ' + h.label;
    d.onclick = () => {
      const cur = { label: 'сейчас', snap: snapEdit() };
      for (let k = editHist.length - 1; k > i; k--) editRedo.push(editHist.pop());
      editRedo.push(cur);
      restoreEdit(editHist.pop().snap);
      renderHist();
      scheduleSave();
    };
    box.appendChild(d);
  });
}
function doUndo() {
  if (!editHist.length) return;
  editRedo.push({ label: 'сейчас', snap: snapEdit() });
  restoreEdit(editHist.pop().snap);
  renderHist();
  scheduleSave();
}
function doRedo() {
  if (!editRedo.length) return;
  editHist.push({ label: 'сейчас', snap: snapEdit() });
  restoreEdit(editRedo.pop().snap);
  renderHist();
  scheduleSave();
}
function openEdit() {
  const id = engine.selected();
  if (id < 0) return;
  editMode = true;
  editHist = []; editRedo = [];
  engine.set_edit_id(id);
  engine.set_edit_iso($('etIso').checked);
  const ed = engine.get_edit(id);
  const sub = ed.length > 0 ? Math.round(ed[0]) : 0;
  $('etRound').value = String(ed.length > 1 ? ed[1] : 0);
  document.querySelectorAll('#etSubBtns button').forEach((b) => b.classList.toggle('on', +b.dataset.grid === sub));
  initPal(); fillBoolT();
  engine.set_edit_mirror(editMirror);
  syncToolProps();
  document.querySelectorAll('#etMirX,#etMirY,#etMirZ').forEach((b, i) => b.classList.toggle('on', (editMirror >> i & 1) === 1));
  $('etName').textContent = engine.entity_name(id);
  $('editTools').classList.remove('hidden');
  $('insp').classList.remove('on');
  const p = engine.get_props(id);
  const d = Math.max(3, Math.hypot(p[6], p[7], p[8]) * 2.4);
  engine.focus_on(p[0], p[1], p[2], d);
}
function closeEdit() {
  editMode = false;
  brushP = null;
  if (blenderOn) {
    blenderOn = false;
    if (engine) engine.set_blender(false);
    $('work').classList.remove('blender');
    $('etBlender').classList.remove('on');
  }
  engine.set_edit_id(-1);
  engine.set_edit_iso(false);
  $('editTools').classList.add('hidden');
  scheduleSave();
}
$('pEdit').onclick = () => (editMode ? closeEdit() : openEdit());
$('etExit').onclick = closeEdit;
document.querySelectorAll('#etSubBtns button').forEach((b) => {
  b.onclick = () => {
    const id = engine.edit_id();
    if (id < 0) return;
    document.querySelectorAll('#etSubBtns button').forEach((x) => x.classList.toggle('on', x === b));
    pushHist('сетка');
    engine.set_edit(id, +b.dataset.grid, parseFloat($('etRound').value) || 0, '');
    scheduleSave();
  };
});
$('etRound').addEventListener('input', () => {
  const id = engine.edit_id();
  if (id < 0) return;
  const ed = engine.get_edit(id);
  engine.set_edit(id, ed.length ? Math.round(ed[0]) : 0, parseFloat($('etRound').value) || 0, engine.edit_cells_hex(id));
  scheduleSave();
});
$('etReset').onclick = () => {
  const id = engine.edit_id();
  if (id < 0) return;
  pushHist('правка');
  engine.edit_reset_cells(id);
  scheduleSave();
};
$('etUndo').onclick = doUndo;
$('etRedo').onclick = doRedo;
$('etHist').onclick = () => { $('histPop').classList.toggle('on'); renderHist(); };
$('etIso').onchange = () => { if (engine) engine.set_edit_iso($('etIso').checked); };

/* ---------- утилиты меша (кисть, зеркало, инверт, поворот, выдавливание) ---------- */
function brushApply(cell) {
  if (!brushP || cell < 0 || cell === brushP.last) return;
  const id = engine.edit_id();
  if (id < 0) return;
  if (!brushP.hist) { pushHist('правка'); brushP.hist = true; }
  engine.edit_set_cell(id, cell, brushP.add);
  brushP.last = cell;
  engine.set_edit_hover(cell);
  scheduleSave();
}
function setTool(t) {
  etTool = (etTool === t && t !== 'tap') ? 'tap' : t;
  brushOn = etTool === 'brush';
  $('etBrush').classList.toggle('on', etTool === 'brush');
  $('etFace').classList.toggle('on', etTool === 'face');
  $('etHole').classList.toggle('on', etTool === 'hole');
  setTool2();
}
function syncToolProps() {
  const id = engine.edit_id();
  if (id < 0) return;
  const p = engine.get_props(id);
  $('etMat').value = String(Math.min(5, Math.max(0, Math.round(p[16] || 0))));
  $('etRough').value = String(p[19] === undefined ? 0.35 : p[19]);
}
function applyToolProps(patch) {
  const id = engine.edit_id();
  if (id < 0) return;
  const p = Array.from(engine.get_props(id));
  for (const k of Object.keys(patch)) p[+k] = patch[k];
  engine.set_props(id, new Float32Array(p));
  scheduleSave();
}
$('etBrush').onclick = () => setTool('brush');
$('etFace').onclick = () => setTool('face');
$('etHole').onclick = () => setTool('hole');
$('etFlood').onclick = () => setTool('flood');
$('etBox').onclick = () => setTool('box');
$('etPaintT').onclick = () => setTool('paint');
$('etDropper').onclick = () => setTool('dropper');
function setTool2() {
  $('etFlood').classList.toggle('on', etTool === 'flood');
  $('etBox').classList.toggle('on', etTool === 'box');
  $('etPaintT').classList.toggle('on', etTool === 'paint');
  $('etDropper').classList.toggle('on', etTool === 'dropper');
}
$('etHollow').onclick = () => {
  const id = engine.edit_id();
  if (id < 0) return;
  pushHist('правка');
  engine.edit_hollow(id);
  scheduleSave();
};
$('etOrganic').onclick = () => {
  const id = engine.edit_id();
  if (id < 0) return;
  pushHist('правка');
  engine.edit_organic(id);
  scheduleSave();
};
$('etMat').onchange = () => {
  applyToolProps({ 16: Math.min(5, Math.max(0, parseFloat($('etMat').value) || 0)) });
  fillProps(engine.edit_id());
};
$('etRough').addEventListener('input', () => {
  applyToolProps({ 19: Math.min(1, Math.max(0, parseFloat($('etRough').value) || 0)) });
});
$('etTex').onclick = () => pickTexture('mat');
/* палитра */
const PAL = ['#e74c3c', '#e67e22', '#f1c40f', '#73b366', '#2ecc71', '#1abc9c', '#3498db', '#5b6ee1', '#9b59b6', '#ffffff', '#7f8c8d', '#2c3e50'];
function hex2rgb(h) { return parseInt(h.slice(1), 16); }
function initPal() {
  const box = $('etPal');
  if (!box || box.childElementCount) return;
  PAL.forEach((h) => {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'palChip'; b.style.background = h;
    b.onclick = () => { editColor = hex2rgb(h); $('etPalCur').style.background = h; };
    box.appendChild(b);
  });
  $('etPalCur').style.background = '#e74c3c';
}
/* операции выделения/копий/массива/булев */
$('etSelClear').onclick = () => { const id = engine.edit_id(); if (id >= 0) { engine.sel_clear(id); scheduleSave(); } };
$('etSelDel').onclick = () => {
  const id = engine.edit_id(); if (id < 0) return;
  pushHist('удалить выделение'); engine.sel_delete(id); scheduleSave();
};
$('etDir').onclick = () => {
  editDir = -editDir;
  $('etDir').textContent = editDir > 0 ? '→' : '←';
};
document.querySelectorAll('#editTools button[data-move]').forEach((b) => {
  b.onclick = () => {
    const id = engine.edit_id(); if (id < 0) return;
    pushHist('сдвиг'); engine.edit_move(id, +b.dataset.move, editDir); scheduleSave();
  };
});
document.querySelectorAll('#editTools button[data-copy]').forEach((b) => {
  b.onclick = () => {
    const id = engine.edit_id(); if (id < 0) return;
    pushHist('копия'); engine.edit_copy(id, +b.dataset.copy, editDir); scheduleSave();
  };
});
document.querySelectorAll('#editTools button[data-shape]').forEach((b) => {
  b.onclick = () => {
    const id = engine.edit_id(); if (id < 0) return;
    pushHist('форма'); engine.edit_shape(id, +b.dataset.shape); scheduleSave();
  };
});
document.querySelectorAll('#editTools button[data-arr]').forEach((b) => {
  b.onclick = () => {
    const id = engine.edit_id(); if (id < 0) return;
    const n = Math.max(1, Math.min(16, parseInt($('etArrN').value) || 3));
    const st = Math.max(1, parseInt($('etArrS').value) || 1);
    pushHist('массив'); engine.edit_array(id, +b.dataset.arr, n, st); scheduleSave();
  };
});
function fillBoolT() {
  const id = engine.edit_id();
  const sel = $('etBoolT');
  if (!sel) return;
  sel.innerHTML = '';
  for (const x of engine.entity_ids()) {
    if (x === id) continue;
    const o = document.createElement('option');
    o.value = String(x); o.textContent = engine.entity_name(x);
    sel.appendChild(o);
  }
}
document.querySelectorAll('#editTools button[data-bool]').forEach((b) => {
  b.onclick = () => {
    const id = engine.edit_id(); if (id < 0) return;
    const t = parseInt($('etBoolT').value);
    if (!Number.isInteger(t)) return;
    pushHist('булева');
    engine.edit_bool(id, +b.dataset.bool, t);
    fillProps(id); buildTree(); scheduleSave();
  };
});
$('etBlender').onclick = () => {
  const id = engine.edit_id();
  blenderOn = !blenderOn;
  engine.set_blender(blenderOn);
  $('work').classList.toggle('blender', blenderOn);
  $('etBlender').classList.toggle('on', blenderOn);
  if (blenderOn) {
    $('etIso').checked = true;
    engine.set_edit_iso(true);
    if (id >= 0) {
      const p = engine.get_props(id);
      const d = Math.max(3, Math.hypot(p[6], p[7], p[8]) * 2.2);
      engine.focus_on(p[0], p[1], p[2], d);
    }
  } else {
    engine.set_edit_iso($('etIso').checked);
  }
};
$('etInvert').onclick = () => {
  const id = engine.edit_id();
  if (id < 0) return;
  pushHist('правка');
  engine.edit_invert(id);
  scheduleSave();
};
['etMirX', 'etMirY', 'etMirZ'].forEach((el, i) => {
  $(el).onclick = () => {
    const id = engine.edit_id();
    if (id < 0) return;
    const bit = 1 << i;
    const on = !(editMirror & bit);
    editMirror = on ? (editMirror | bit) : (editMirror & ~bit);
    engine.set_edit_mirror(editMirror);
    if (on) { pushHist('правка'); engine.edit_mirror_fill(id, bit); scheduleSave(); }
    document.querySelectorAll('#etMirX,#etMirY,#etMirZ').forEach((b, k) => b.classList.toggle('on', (editMirror >> k & 1) === 1));
  };
});
document.querySelectorAll('#editTools button[data-rot]').forEach((b) => {
  b.onclick = () => {
    const id = engine.edit_id();
    if (id < 0) return;
    pushHist('правка');
    engine.edit_rot(id, +b.dataset.rot);
    scheduleSave();
  };
});
document.querySelectorAll('#editTools button[data-ext]').forEach((b) => {
  b.onclick = () => {
    const id = engine.edit_id();
    if (id < 0) return;
    pushHist('правка');
    engine.edit_extrude(id, +b.dataset.ext);
    scheduleSave();
  };
});

/* ---------- папка игрока: модель и скрипт ---------- */
function createPlayerModel() {
  const base = [0, 0, 0];
  const cam = engine.camera_front(3);
  const mk = (name, pos, size, color, parent) => {
    const id = engine.add_entity(name, new Float32Array([
      ...pos, 0, 0, 0, ...size, ...color, 0, 1, 0, 0, 0, 0, 0,
    ]));
    if (parent >= 0) engine.set_parent(id, parent);
    return id;
  };
  const root = mk('Player', [cam[0], cam[1], cam[2]], [0.7, 1.0, 0.4], [0.55, 0.56, 0.58], -1);
  mk('Head', [cam[0], cam[1] + 0.75, cam[2]], [0.5, 0.5, 0.5], [0.85, 0.72, 0.58], root);
  mk('LegL', [cam[0] - 0.2, cam[1] - 0.85, cam[2]], [0.25, 0.7, 0.3], [0.3, 0.32, 0.36], root);
  mk('LegR', [cam[0] + 0.2, cam[1] - 0.85, cam[2]], [0.25, 0.7, 0.3], [0.3, 0.32, 0.36], root);
  mk('ArmL', [cam[0] - 0.55, cam[1] + 0.15, cam[2]], [0.22, 0.85, 0.25], [0.55, 0.56, 0.58], root);
  mk('ArmR', [cam[0] + 0.55, cam[1] + 0.15, cam[2]], [0.22, 0.85, 0.25], [0.55, 0.56, 0.58], root);
  engine.set_pm_root(root);
  buildTree();
  syncSelection();
  scheduleSave();
}
function openScript() { openScriptFor('player'); }
function copyText(txt, okMsg) {
  const s = String(txt ?? '');
  const done = () => consolePrint('📋 ' + (okMsg || 'ok'));
  const fallback = () => {
    const ta = document.createElement('textarea');
    ta.value = s;
    ta.style.cssText = 'position:fixed;top:-100px;left:-100px;opacity:0';
    document.body.appendChild(ta);
    ta.focus(); ta.select();
    let okc = false;
    try { okc = document.execCommand('copy'); } catch (e) { okc = false; }
    document.body.removeChild(ta);
    if (okc) done(); else consolePrint('copy: не удалось скопировать');
  };
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(s).then(done, fallback);
  } else fallback();
}
function consolePrint(msg) {
  const c = $('console');
  const d = document.createElement('div');
  d.textContent = msg;
  c.appendChild(d);
  while (c.children.length > 50) c.removeChild(c.firstChild);
  c.scrollTop = c.scrollHeight;
  if (!c.classList.contains('on')) $('outDot').classList.add('on');
}
$('outChip').addEventListener('click', () => {
  const c = $('console');
  const open = c.classList.toggle('on');
  if (open) { $('outDot').classList.remove('on'); c.scrollTop = c.scrollHeight; }
});
$('texFile').addEventListener('change', async () => {
  const f = $('texFile').files && $('texFile').files[0];
  if (!f) { syncSelection(); return; }
  try {
    const bmp = await createImageBitmap(f);
    const c2 = document.createElement('canvas');
    c2.width = c2.height = 256;
    const ctx = c2.getContext('2d');
    const s = Math.min(bmp.width, bmp.height);
    ctx.drawImage(bmp, (bmp.width - s) / 2, (bmp.height - s) / 2, s, s, 0, 0, 256, 256);
    const d = ctx.getImageData(0, 0, 256, 256);
    const px = new Uint8Array(d.data.buffer);
    if (texTarget === 'water') engine.set_custom_water(px, 256, 256);
    else engine.set_custom_mat(px, 256, 256);
    onEdit();
  } catch (e) {
    alert(t('imgFail'));
    syncSelection();
  }
});

$('pDel').onclick = () => {
  const id = engine.selected();
  if (id < 0) return;
  engine.remove_entity(id);
  buildTree();
  syncSelection();
  scheduleSave();
};

/* ---------- панель графики (@A) ---------- */
function fmtTime(v) {
  let h = Math.floor(v), m = Math.round((v - h) * 60);
  if (m === 60) { h = (h + 1) % 24; m = 0; }
  return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
}
const QUAL_NAMES = ['q_low', 'q_med', 'q_high'];
const fmtG = (it, v) => (it.fmt === 'time' ? fmtTime(v)
  : it.fmt === 'qual' ? t(QUAL_NAMES[Math.max(0, Math.min(2, Math.round(v)))])
  : v.toFixed(it.step < 0.01 ? 3 : it.step < 1 ? 2 : 0));

function buildGfx(gid) {
  const g = GROUPS.find((x) => x.id === gid);
  $('gfxTitle').textContent = t(g.k);
  const body = $('gfxBody');
  body.innerHTML = '';
  if (g.id === 'ui') {
    for (const k of ['joy', 'cam', 'jump', 'fps']) {
      const row = document.createElement('div'); row.className = 'gr';
      const lb = document.createElement('label'); lb.textContent = t('sysui_' + k);
      const inp = document.createElement('input'); inp.type = 'checkbox'; inp.checked = !!sysUI[k];
      inp.onchange = () => { sysUI[k] = inp.checked ? 1 : 0; applySysUI(); scheduleSave(); };
      row.append(lb, inp); body.appendChild(row);
    }
    return;
  }
  for (const i of g.items) {
    const it = GFX[i];
    const row = document.createElement('div'); row.className = 'gr';
    const lb = document.createElement('label'); lb.textContent = t(it.k);
    const inp = document.createElement('input');
    inp.type = 'range'; inp.min = it.min; inp.max = it.max; inp.step = it.step; inp.value = gfxVals[i];
    const val = document.createElement('span'); val.textContent = fmtG(it, gfxVals[i]);
    inp.oninput = () => {
      const v = parseFloat(inp.value);
      gfxVals[i] = v;
      engine.set_gfx(i, v);
      val.textContent = fmtG(it, v);
      scheduleSave();
    };
    row.append(lb, inp, val);
    body.appendChild(row);
  }
}
function openGfx(gid) {
  gfxGroup = gfxGroup === gid ? null : gid;
  if (gfxGroup !== null) { engine.select(-1); buildGfx(gfxGroup); }
  syncSelection();
}
$('gClose').onclick = () => { gfxGroup = null; syncSelection(); };
$('gfxReset').onclick = () => {
  if (gfxGroup === null) return;
  const g = GROUPS.find((x) => x.id === gfxGroup);
  for (const i of g.items) { gfxVals[i] = gfxDefs[i]; engine.set_gfx(i, gfxDefs[i]); }
  buildGfx(gfxGroup);
  scheduleSave();
};

/* ---------- выделение / панели ---------- */
function offsetSubtree(id, oldProps, newPos) {
  const dx = newPos[0] - oldProps[0], dy = newPos[1] - oldProps[1], dz = newPos[2] - oldProps[2];
  if (!dx && !dy && !dz) return;
  for (const c of engine.descendants_of(id)) {
    const p = Array.from(engine.get_props(c));
    p[0] += dx; p[1] += dy; p[2] += dz;
    engine.set_props(c, new Float32Array(p));
  }
}
function syncSelection() {
  const id = engine.selected();
  if (id >= 0) { gfxGroup = null; uiSel = null; }
  document.querySelectorAll('#treeBody .row[data-id]').forEach((r) => r.classList.toggle('sel', +r.dataset.id === id));
  document.querySelectorAll('#treeBody .row[data-g]').forEach((r) => r.classList.toggle('sel', r.dataset.g === gfxGroup));
  const pOpen = id >= 0 && !uiSel, gOpen = gfxGroup !== null;
  $('insp').classList.toggle('on', pOpen);
  $('gfxp').classList.toggle('on', gOpen);
  $('uiInsp').classList.toggle('on', !!uiSel);
  if (pOpen) { $('pTitle').textContent = engine.entity_name(id); fillProps(id); }
}

/* ---------- UI (@UI): элементы экрана ---------- */
function uiFire(handler, args) {
  const name = String(handler || '').trim().replace(/^@F\.?/, '');
  if (!name) return;
  for (const r of [rt, ...objRts.map((o) => o.rt), ...srvRts.map((o) => o.rt)]) {
    if (r && typeof r.call === 'function') {
      let v;
      try { v = r.call(name, args); } catch (e) { consolePrint(name + '(): ' + e); return; }
      if (v !== undefined) return v;
    }
  }
}
function openUIMenu(anchor) {
  closeSpawnMenu();
  const m = document.createElement('div');
  m.id = 'spawnMenu';
  for (const ty of UI_TYPES) {
    const b = document.createElement('button');
    const i = document.createElement('span'); i.className = 'mi';
    i.textContent = ty === 'frame' ? '▢' : ty === 'label' ? 'T' : ty === 'button' ? '⬚' : '⌨';
    const n = document.createElement('span'); n.textContent = t('ui_' + ty);
    b.append(i, n);
    b.onclick = () => { closeSpawnMenu(); const nm = uiMgr.add(uiDef(ty)); selectUI(nm); };
    m.appendChild(b);
  }
  document.body.appendChild(m);
  const r = anchor.getBoundingClientRect();
  m.style.left = Math.max(8, r.left - m.offsetWidth - 6) + 'px';
  m.style.top = Math.max(8, Math.min(r.top, innerHeight - m.offsetHeight - 8)) + 'px';
  menuEl = m;
}
function selectUI(name) {
  uiSel = name;
  if (engine) engine.select(-1);
  syncSelection();
  buildTree();
  fillUIProps();
}
function isUiDescendant(name, of) {
  let p = uiMgr.find(name) && uiMgr.find(name).parent, guard = 0;
  while (p && guard++ < 64) {
    if (p === of) return true;
    p = uiMgr.find(p) && uiMgr.find(p).parent;
  }
  return false;
}
function rgbHex(c) {
  const h = (v) => Math.max(0, Math.min(255, Math.round(v || 0))).toString(16).padStart(2, '0');
  return '#' + h(c[0]) + h(c[1]) + h(c[2]);
}
function fillUIProps() {
  const d = uiSel && uiMgr.find(uiSel);
  $('uiInsp').classList.toggle('on', !!d);
  if (!d) return;
  $('uiTitle').textContent = d.name + ' · ' + t('ui_' + d.type);
  $('uiName').value = d.name;
  const ps = $('uiParent');
  ps.innerHTML = '';
  const o0 = document.createElement('option'); o0.value = ''; o0.textContent = '— ' + t('ui_screen') + ' —';
  ps.append(o0);
  for (const e of uiMgr.list) {
    if (e.name === d.name || e.type !== 'frame' || isUiDescendant(e.name, d.name)) continue;
    const o = document.createElement('option'); o.value = e.name; o.textContent = e.name; ps.append(o);
  }
  ps.value = d.parent || '';
  $('uiText').value = d.text || '';
  $('uiPh').value = d.placeholder || '';
  $('uiXpx').value = d.x.px; $('uiXpr').value = d.x.pr;
  $('uiYpx').value = d.y.px; $('uiYpr').value = d.y.pr;
  $('uiWpx').value = d.w.px; $('uiWpr').value = d.w.pr;
  $('uiHpx').value = d.h.px; $('uiHpr').value = d.h.pr;
  $('uiFg').value = rgbHex(d.fg); $('uiFgA').value = d.fg[3] === undefined ? 255 : d.fg[3];
  $('uiBg').value = rgbHex(d.bg); $('uiBgA').value = d.bg[3] === undefined ? 255 : d.bg[3];
  $('uiBr').value = rgbHex(d.border); $('uiBrA').value = d.border[3] === undefined ? 255 : d.border[3];
  $('uiBrW').value = d.borderW;
  $('uiRadius').value = d.radius;
  $('uiFont').value = d.fontSize;
  $('uiAlign').value = d.align || 'left';
  $('uiZ').value = d.zIndex;
  $('uiVis').checked = !!d.visible;
  $('uiOnClick').value = d.onClick || '';
  $('uiOnChange').value = d.onChange || '';
}
function uiTouch() {
  uiMgr.render();
  scheduleSave();
  buildTree();
}
function uiBind(id, fn, ev) {
  $(id).addEventListener(ev || 'input', () => {
    const d = uiSel && uiMgr.find(uiSel);
    if (!d) return;
    fn(d, $(id));
    uiTouch();
  });
}
uiBind('uiName', (d, el) => {
  const old = d.name;
  const nm = el.value.trim();
  if (!nm || nm === old) return;
  d.name = uiMgr.uniqueName(nm);
  for (const e of uiMgr.list) if (e.parent === old) e.parent = d.name;
  uiSel = d.name;
  $('uiTitle').textContent = d.name + ' · ' + t('ui_' + d.type);
}, 'change');
uiBind('uiParent', (d, el) => { d.parent = el.value; }, 'change');
uiBind('uiText', (d, el) => { d.text = el.value; });
uiBind('uiPh', (d, el) => { d.placeholder = el.value; });
for (const [id, k, u] of [['uiXpx', 'x', 'px'], ['uiXpr', 'x', 'pr'], ['uiYpx', 'y', 'px'], ['uiYpr', 'y', 'pr'],
  ['uiWpx', 'w', 'px'], ['uiWpr', 'w', 'pr'], ['uiHpx', 'h', 'px'], ['uiHpr', 'h', 'pr']]) {
  uiBind(id, (d, el) => { d[k][u] = parseFloat(el.value) || 0; });
}
const colBind = (id, idA, key) => {
  uiBind(id, (d, el) => {
    const h = el.value.replace('#', '');
    d[key][0] = parseInt(h.slice(0, 2), 16); d[key][1] = parseInt(h.slice(2, 4), 16); d[key][2] = parseInt(h.slice(4, 6), 16);
  }, 'change');
  uiBind(idA, (d, el) => { d[key][3] = Math.max(0, Math.min(255, parseInt(el.value) || 0)); });
};
colBind('uiFg', 'uiFgA', 'fg');
colBind('uiBg', 'uiBgA', 'bg');
colBind('uiBr', 'uiBrA', 'border');
uiBind('uiBrW', (d, el) => { d.borderW = parseFloat(el.value) || 0; }, 'change');
uiBind('uiRadius', (d, el) => { d.radius = parseFloat(el.value) || 0; }, 'change');
uiBind('uiFont', (d, el) => { d.fontSize = parseFloat(el.value) || 16; });
uiBind('uiAlign', (d, el) => { d.align = el.value; }, 'change');
uiBind('uiZ', (d, el) => { d.zIndex = parseInt(el.value) || 0; });
uiBind('uiVis', (d, el) => { d.visible = el.checked ? 1 : 0; }, 'change');
uiBind('uiOnClick', (d, el) => { d.onClick = el.value.trim(); });
uiBind('uiOnChange', (d, el) => { d.onChange = el.value.trim(); });
$('uiDel').onclick = () => {
  if (!uiSel) return;
  uiMgr.remove(uiSel);
  uiSel = null;
  syncSelection(); buildTree(); fillUIProps(); scheduleSave();
};
$('uiDup').onclick = () => {
  const d = uiSel && uiMgr.find(uiSel);
  if (!d) return;
  const c = JSON.parse(JSON.stringify(d));
  c.x.px += 12; c.y.px += 12;
  const nm = uiMgr.add(c);
  selectUI(nm);
};
$('uiClose').onclick = () => { uiSel = null; syncSelection(); fillUIProps(); };
function groupIntoModel() {
  if (!engine) return;
  const id = engine.selected();
  if (id < 0) return;
  const name = prompt(t('group_name'), '');
  if (!name) return;
  const ids = Array.from(engine.entity_ids());
  let gid = ids.find((x) => engine.entity_name(x) === name);
  if (gid === undefined) {
    const pr = Array.from(engine.get_props(id));
    gid = engine.add_entity(name, new Float32Array([
      pr[0], pr[1], pr[2], 0, 0, 0, 0.01, 0.01, 0.01,
      0.5, 0.5, 0.5, 0, 1, 0, 0, 0, 0, 0, 0.35, 0]));
  }
  if (gid === id) return;
  engine.set_parent(id, gid);
  buildTree(); scheduleSave();
}
$('pDup').onclick = () => {
  if (!engine) return;
  const root = engine.selected();
  if (root < 0) return;
  const ids = Array.from(engine.entity_ids());
  const group = [root];
  for (let i = 0; i < group.length; i++) {
    for (const c of ids) if (engine.parent_of(c) === group[i] && !group.includes(c)) group.push(c);
  }
  const map = new Map();
  for (const old of group) {
    const pr = Array.from(engine.get_props(old));
    pr[0] += 1; pr[2] += 1;
    const nm = engine.entity_name(old);
    const base = nm.replace(/\s*\d+$/, '') || nm;
    map.set(old, engine.add_entity(uniqueName(base), new Float32Array(pr)));
  }
  for (const old of group) {
    const par = engine.parent_of(old);
    if (map.has(par)) engine.set_parent(map.get(old), map.get(par));
    else if (old === root && par >= 0) engine.set_parent(map.get(old), par);
  }
  buildTree();
  engine.select(map.get(root));
  syncSelection();
  scheduleSave();
};
$('pGroup').onclick = groupIntoModel;
$('pClose').onclick = () => { engine.select(-1); syncSelection(); };
$('camReset').onclick = () => engine.reset_camera();

/* ---------- управление: камера, выбор, гизмо ---------- */
const cv = $('c');
let lookP = null, gizmoP = null;
let mode = 0; // 0 выбор, 1 перемещение, 2 масштаб

function setMode(m) {
  mode = m;
  if (engine) engine.set_mode(m);
  document.querySelectorAll('#tools button[data-mode]').forEach((b) => b.classList.toggle('on', +b.dataset.mode === m));
}
document.querySelectorAll('#tools button[data-mode]').forEach((b) => { b.onclick = () => setMode(+b.dataset.mode); });
setMode(0);

let play = false, third = false, playSnap = null;
function setPlay(on) {
  play = !!on;
  try {
  if (engine) {
    if (play) {
      if (editMode) closeEdit();
      playSnap = collectScene();
      $('console').innerHTML = '';
      $('outDot').classList.remove('on');
      rt = createRuntime(engine, {
        print: consolePrint,
        setStats: (s, j, z) => engine.set_player_stats(s, j, z),
        ui: uiMgr,
      });
      rt.load(scriptText);
      objRts.length = 0;
      const ids = Array.from(engine.entity_ids());
      for (const [nm, txt] of Object.entries(objScripts)) {
        if (!txt || !String(txt).trim()) continue;
        const id = ids.find((x) => engine.entity_name(x) === nm);
        if (id === undefined) continue;
        const o = createRuntime(engine, { print: consolePrint, selfId: id, ui: uiMgr });
        const er = o.load(txt);
        if (er) consolePrint(nm + '.hgs: ' + er);
        objRts.push({ nm, rt: o });
      }
      srvRts.length = 0;
      for (const [nm, txt] of Object.entries(srvScripts)) {
        if (!txt || !String(txt).trim()) continue;
        const o = createRuntime(engine, { print: consolePrint, ui: uiMgr });
        const er = o.load(txt);
        if (er) consolePrint(nm + '.hgs: ' + er);
        srvRts.push({ nm, rt: o });
      }
    }
    engine.set_play(play);
    if (play) {
      engine.select(-1); gfxGroup = null; syncSelection();
      try { rt.start(); } catch (e) { consolePrint('script: ' + e); }
      for (const o of objRts) { try { o.rt.start(); } catch (e) { consolePrint(o.nm + ': ' + e); } }
      for (const o of srvRts) { try { o.rt.start(); } catch (e) { consolePrint(o.nm + ': ' + e); } }
    } else {
      if (rt) { rt.stop(); rt = null; }
      for (const o of objRts) { try { o.rt.stop(); } catch (e) { /* ok */ } }
      objRts.length = 0;
      for (const o of srvRts) { try { o.rt.stop(); } catch (e) { /* ok */ } }
      srvRts.length = 0;
      if (playSnap) { engine.clear(); applyScene(playSnap); playSnap = null; }
      third = false; engine.set_third(false);
    }
  }
  } finally {
  $('playBtn').classList.toggle('on', play);
  $('viewBtn').classList.toggle('hidden', !play);
  if (!play) $('viewBtn').classList.remove('on');
  document.querySelectorAll('#tools button[data-mode]').forEach((b) => b.classList.toggle('hidden', play));
  $('work').classList.toggle('playing', play);
  if (uiMgr) uiMgr.setEdit(!play);
  const pb = $('playBar');
  if (play) {
    pb.classList.remove('hidden');
    requestAnimationFrame(() => requestAnimationFrame(() => pb.classList.add('show')));
    $('pbView').classList.toggle('on', third);
  } else {
    pb.classList.remove('show');
    setTimeout(() => pb.classList.add('hidden'), 300);
  }
  }
}
$('playBtn').onclick = () => setPlay(!play);
$('pbStop').onclick = () => setPlay(false);
$('pbView').onclick = () => {
  third = !third;
  if (engine) engine.set_third(third);
  $('viewBtn').classList.toggle('on', third);
  $('pbView').classList.toggle('on', third);
};
$('viewBtn').onclick = () => {
  third = !third;
  if (engine) engine.set_third(third);
  $('viewBtn').classList.toggle('on', third);
};

const ndc = (e) => {
  const r = cv.getBoundingClientRect();
  return [((e.clientX - r.left) / r.width) * 2 - 1, 1 - ((e.clientY - r.top) / r.height) * 2];
};

cv.addEventListener('pointerdown', (e) => {
  if (lookP || gizmoP) return;
  if (e.pointerType === 'mouse' && e.button !== 0 && e.button !== 2) return;
  if (!play && !editMode && mode > 0 && e.button === 0 && engine && engine.selected() >= 0) {
    const [nx, ny] = ndc(e);
    if (engine.gizmo_begin(nx, ny)) {
      gizmoP = { id: e.pointerId };
      cv.setPointerCapture(e.pointerId);
      e.preventDefault();
      return;
    }
  }
  if (editMode && engine && !play && etTool === 'box') {
    const [nx, ny] = ndc(e);
    boxStart = [nx, ny];
    cv.setPointerCapture(e.pointerId);
    e.preventDefault();
    return;
  }
  if (editMode && engine && !play && etTool === 'paint') {
    const [nx, ny] = ndc(e);
    const cell = engine.pick_cell(nx, ny);
    const id = engine.edit_id();
    if (cell >= 0 && id >= 0) {
      brushP = { id: e.pointerId, last: cell, paint: true, hist: false };
      cv.setPointerCapture(e.pointerId);
      e.preventDefault();
    }
    return;
  }
  if (editMode && engine && !play && brushOn) {
    const [nx, ny] = ndc(e);
    const cell = engine.pick_cell(nx, ny);
    if (cell >= 0) {
      const id = engine.edit_id();
      brushP = { id: e.pointerId, last: -2, add: !engine.edit_cell_on(id, cell), hist: false };
      cv.setPointerCapture(e.pointerId);
      e.preventDefault();
      brushApply(cell);
      return;
    }
  }
  lookP = { id: e.pointerId, x: e.clientX, y: e.clientY, t: performance.now(), moved: 0, btn: e.button };
  cv.setPointerCapture(e.pointerId);
  e.preventDefault();
});
cv.addEventListener('pointermove', (e) => {
  if (brushP && e.pointerId === brushP.id) {
    const [nx, ny] = ndc(e);
    const cell = engine.pick_cell(nx, ny);
    if (brushP.paint) {
      if (cell >= 0 && cell !== brushP.last) {
        if (!brushP.hist) { pushHist('краска'); brushP.hist = true; }
        engine.edit_paint(engine.edit_id(), cell, editColor);
        brushP.last = cell;
        scheduleSave();
      }
    } else {
      brushApply(cell);
    }
    return;
  }
  if (boxStart && etTool === 'box') return;
  if (editMode && engine && !play) {
    const [nx, ny] = ndc(e);
    engine.set_edit_hover(engine.pick_cell(nx, ny));
    return;
  }
  if (gizmoP && e.pointerId === gizmoP.id) {
    const [nx, ny] = ndc(e);
    if (engine.gizmo_drag(nx, ny)) { fillProps(engine.selected()); scheduleSave(); }
    return;
  }
  if (!lookP || e.pointerId !== lookP.id) return;
  const dx = e.clientX - lookP.x, dy = e.clientY - lookP.y;
  lookP.x = e.clientX; lookP.y = e.clientY;
  lookP.moved += Math.abs(dx) + Math.abs(dy);
  if (play && !sysUI.cam) { /* поворот камеры выключен */ } else if (e.pointerType !== 'mouse' || (e.buttons & 2)) engine.look(dx, dy);
});
const endGizmo = (e) => {
  if (!gizmoP || e.pointerId !== gizmoP.id) return false;
  engine.gizmo_end();
  gizmoP = null;
  return true;
};
cv.addEventListener('pointerup', (e) => {
  if (boxStart && etTool === 'box') {
    const [nx, ny] = ndc(e);
    const id = engine.edit_id();
    if (id >= 0) {
      engine.sel_box(id, boxStart[0], boxStart[1], nx, ny);
      scheduleSave();
    }
    boxStart = null;
    return;
  }
  if (brushP && e.pointerId === brushP.id) { brushP = null; return; }
  if (endGizmo(e)) return;
  if (!lookP || e.pointerId !== lookP.id) return;
  const p = lookP; lookP = null;
  if (p.btn === 0 && p.moved < 10 && performance.now() - p.t < 500) {
    const [nx, ny] = ndc(e);
    if (!play && editMode) {
      const id = engine.edit_id();
      if (etTool === 'face' || etTool === 'hole') {
        const v = engine.pick_face(nx, ny);
        if (v >= 0) {
          pushHist(etTool === 'face' ? 'грань+' : 'дыра');
          if (etTool === 'face') engine.edit_grow_face(id, v >> 3, v & 7);
          else engine.edit_hole(id, v >> 3, v & 7);
          scheduleSave();
        }
      } else if (etTool === 'flood') {
        const cell = engine.pick_cell(nx, ny);
        if (cell >= 0) { engine.sel_flood(id, cell); scheduleSave(); }
      } else if (etTool === 'dropper') {
        const cell = engine.pick_cell(nx, ny);
        const c = cell >= 0 ? engine.edit_color_at(id, cell) : -1;
        if (c >= 0) {
          editColor = c >>> 0;
          $('etPalCur').style.background = '#' + editColor.toString(16).padStart(6, '0');
        }
        setTool('tap');
      } else if (etTool === 'paint') {
        const cell = engine.pick_cell(nx, ny);
        if (cell >= 0) { pushHist('краска'); engine.edit_paint(id, cell, editColor); scheduleSave(); }
      } else {
        const cell = engine.pick_cell(nx, ny);
        if (cell >= 0) { pushHist('правка'); engine.edit_toggle(id, cell); scheduleSave(); }
      }
    } else if (!play) engine.pick(nx, ny);
    else {
      const cid = engine.pick(nx, ny);
      if (cid >= 0) {
        const nm = engine.entity_name(cid);
        const fire = (o) => { try { o.rt.event('Click', [nm]); } catch (e) { consolePrint(o.nm + ': ' + e); } };
        if (rt) fire({ rt, nm: 'script' });
        objRts.forEach(fire);
        srvRts.forEach(fire);
        engine.select(-1);
      }
    }
    syncSelection();
  }
});
cv.addEventListener('pointercancel', (e) => { if (brushP) brushP = null; endGizmo(e); lookP = null; });
cv.addEventListener('contextmenu', (e) => e.preventDefault());
addEventListener('keydown', (e) => {
  if (!play) return;
  const fire = (o) => { try { o.rt.event('Key', [e.key]); } catch (er) { consolePrint(o.nm + ': ' + er); } };
  if (rt) fire({ rt, nm: 'script' });
  objRts.forEach(fire);
  srvRts.forEach(fire);
});

/* ---------- управление: джойстики и клавиатура ---------- */
const joy = { x: 0, z: 0, y: 0 };
const kb = { x: 0, z: 0, y: 0 };
const touch = { jump: 0 };
let sysUI = { joy: 1, cam: 1, jump: 1, fps: 1 };
function applySysUI() {
  // «Системный интерфейс» настраивает ТОЛЬКО экспортированную игру (game.mapp → player.js).
  // В редакторе джойстики и кнопка прыжка видны всегда — иначе нечем тестировать проект.
  const set = (id, on) => { const el = $(id); if (el) el.classList.toggle('sys-off', !on); };
  set('fps', sysUI.fps);
}
function pushMove() {
  if (engine) engine.set_move(clamp(joy.x + kb.x), clamp(joy.z + kb.z), clamp(joy.y + kb.y + touch.jump));
}

function makeJoy(el, onChange, lockX = false) {
  const knob = el.querySelector('.knob');
  let pid = null;
  const upd = (e) => {
    const r = el.getBoundingClientRect();
    let dx = e.clientX - (r.left + r.width / 2);
    let dy = e.clientY - (r.top + r.height / 2);
    if (lockX) dx = 0;
    const max = (lockX ? r.height : r.width) / 2 - 20;
    const len = Math.hypot(dx, dy);
    if (len > max) { dx *= max / len; dy *= max / len; }
    knob.style.transform = `translate(${dx}px,${dy}px)`;
    onChange(dx / max, dy / max);
  };
  const end = (e) => {
    if (e.pointerId !== pid) return;
    pid = null;
    knob.style.transform = '';
    onChange(0, 0);
  };
  el.addEventListener('pointerdown', (e) => {
    if (pid !== null) return;
    pid = e.pointerId;
    el.setPointerCapture(pid);
    upd(e);
    e.preventDefault();
  });
  el.addEventListener('pointermove', (e) => { if (e.pointerId === pid) upd(e); });
  el.addEventListener('pointerup', end);
  el.addEventListener('pointercancel', end);
  el.addEventListener('lostpointercapture', end);
}
makeJoy($('joyL'), (x, y) => { joy.x = x; joy.z = -y; pushMove(); });
makeJoy($('joyR'), (x, y) => { joy.y = -y; pushMove(); }, true);
if ($('jumpB')) {
  const jEnd = () => { touch.jump = 0; pushMove(); };
  $('jumpB').addEventListener('pointerdown', (e) => { e.preventDefault(); touch.jump = 1; pushMove(); });
  $('jumpB').addEventListener('pointerup', jEnd);
  $('jumpB').addEventListener('pointercancel', jEnd);
  $('jumpB').addEventListener('lostpointercapture', jEnd);
}

const keys = new Set();
function updKeys() {
  const k = (c) => (keys.has(c) ? 1 : 0);
  kb.x = k('KeyD') - k('KeyA');
  kb.z = k('KeyW') - k('KeyS');
  kb.y = Math.max(k('Space'), k('KeyE')) - Math.max(k('ShiftLeft'), k('KeyQ'));
  pushMove();
}
addEventListener('keydown', (e) => {
  if (!cur || e.target.tagName === 'INPUT') return;
  if (e.code === 'Space') e.preventDefault();
  keys.add(e.code); updKeys();
});
addEventListener('keyup', (e) => { keys.delete(e.code); updKeys(); });
addEventListener('blur', () => { keys.clear(); updKeys(); });

/* ================= старт ================= */
applyDom();
renderProjects();

/* ================= ПОЛНОЭКРАННЫЙ РЕДАКТОР КОДА HGS ================= */
const ceArea = $('ceArea');
const ceHigh = $('ceHigh');
const ceGutter = $('ceGutter');

function escH(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

function hlSrc(src) {
  let out = '';
  let i = 0;
  const n = src.length;
  while (i < n) {
    const c = src[i];
    if (c === '#') { let j = i; while (j < n && src[j] !== '\n') j++; out += `<span class="com">${escH(src.slice(i, j))}</span>`; i = j; continue; }
    if (c === '"') { let j = i + 1; while (j < n && src[j] !== '"') { if (src[j] === '\\') j++; j++; } out += `<span class="str">${escH(src.slice(i, Math.min(j + 1, n)))}</span>`; i = j + 1; continue; }
    if (c === '[') { let j = i + 1; let d = 1; while (j < n && d > 0) { if (src[j] === '[') d++; else if (src[j] === ']') d--; if (src[j] === '\n') break; j++; } out += `<span class="var">${escH(src.slice(i, j))}</span>`; i = j; continue; }
    if (c === '@') { let j = i; while (j < n && /[\wА-Яа-яЁё.@]/.test(src[j])) j++; out += `<span class="sec">${escH(src.slice(i, j))}</span>`; i = j; continue; }
    if (/[A-Za-zА-Яа-яЁё_]/.test(c)) {
      let j = i; while (j < n && /[\wА-Яа-яЁё.]/.test(src[j])) j++;
      const w = src.slice(i, j);
      let cls = '';
      if (w === 'if' || w === 'else' || w === 'WTD' || w === 'break' || w === 'end') cls = 'kw';
      else if (w.includes('.') || w === 'Text') cls = 'fn';
      out += cls ? `<span class="${cls}">${escH(w)}</span>` : escH(w);
      i = j; continue;
    }
    if (/[0-9]/.test(c)) { let j = i; while (j < n && /[0-9.]/.test(src[j])) j++; out += `<span class="num">${escH(src.slice(i, j))}</span>`; i = j; continue; }
    if ('+-*/=<>!'.includes(c)) { out += `<span class="op">${escH(c)}</span>`; i++; continue; }
    if ('(){},'.includes(c)) { out += `<span class="br">${escH(c)}</span>`; i++; continue; }
    out += escH(c); i++;
  }
  return out;
}

let ceErrs = [];
function ceRefresh() {
  const src = ceArea.value;
  ceHigh.innerHTML = hlSrc(src) + '\n';
  const lines = src.split('\n');
  ceGutter.innerHTML = lines.map((_, i) => {
    const bad = ceErrs.some((e) => e.line === i + 1);
    return `<div${bad ? ' style="color:#ff7b72;font-weight:700"' : ''}>${i + 1}</div>`;
  }).join('');
  $('ceStat').textContent = `${lines.length} строк · ${src.length} симв.`;
  ceArea.style.height = 'auto';
  ceArea.style.height = Math.max(ceArea.scrollHeight, 200) + 'px';
}

function ceLint() {
  try {
    ceErrs = lintHgs(ceArea.value) || [];
  } catch (e) {
    ceErrs = [{ line: 1, msg: String(e) }];
  }
  const box = $('ceErrors');
  const copyBtn = `<button id="ceErrCopy" class="mini">⧉ ${escH(t('err_copy'))}</button>`;
  if (!ceErrs.length) {
    box.innerHTML = `<div class="ok">✓ Ошибок не найдено ${copyBtn}</div>`;
  } else {
    box.innerHTML = ceErrs.map((e, i) => `<div class="er" data-i="${i}">Строка ${e.line}: ${escH(e.msg)}</div>`).join('') + `<div class="erBar">${copyBtn}</div>`;
    box.querySelectorAll('.er').forEach((el) => {
      el.onclick = () => {
        const er = ceErrs[+el.dataset.i];
        ceGotoLine(er.line);
      };
    });
  }
  const cb = $('ceErrCopy');
  if (cb) cb.onclick = (ev) => {
    ev.stopPropagation();
    copyText(ceErrs.map((e) => `Строка ${e.line}: ${e.msg}`).join('\n'), t('cop_ok'));
  };
  ceRefresh();
}

function ceGotoLine(line) {
  const src = ceArea.value.split('\n');
  let pos = 0;
  for (let i = 0; i < Math.min(line - 1, src.length); i++) pos += src[i].length + 1;
  ceArea.focus();
  ceArea.setSelectionRange(pos, pos + (src[line - 1] || '').length);
}

function ceSave(run) {
  const v = ceArea.value;
  if (ceCtx && ceCtx.kind === 'player') scriptText = v;
  else if (ceCtx && ceCtx.kind === 'server') srvScripts[ceCtx.name] = v;
  else if (ceCtx) objScripts[ceCtx.name] = v;
  scheduleSave();
  if (run) {
    if (play) setPlay(false);
    setPlay(true);
  }
}

function openScriptFor(kind, name) {
  ceCtx = { kind, name: name || '' };
  if (kind === 'player') {
    ceArea.value = scriptText;
    $('ceTitle').textContent = 'player.hgs';
  } else if (kind === 'server') {
    if (srvScripts[name] === undefined) srvScripts[name] = DEFAULT_SRV;
    ceArea.value = srvScripts[name];
    $('ceTitle').textContent = name + '.hgs';
  } else {
    ceArea.value = objScripts[name] !== undefined ? objScripts[name] : DEFAULT_OBJ_SCRIPT;
    $('ceTitle').textContent = name + '.hgs';
  }
  ceErrs = [];
  $('ceErrors').innerHTML = '';
  $('codeEditor').classList.remove('hidden');
  ceRefresh();
}
window.openScriptFor = openScriptFor;

$('ceClose').onclick = () => { $('codeEditor').classList.add('hidden'); $('ceAC').classList.add('hidden'); };
$('ceRun').onclick = () => ceSave(true);
$('ceSaveBtn').onclick = () => {
  ceSave(false);
  $('ceErrors').innerHTML = '<div class="ok">✓ ' + escH(t('saved_ok')) + '</div>';
};
$('outCopy').onclick = () => {
  const c = $('console');
  copyText([...c.children].map((d) => d.textContent).join('\n'), t('cop_ok'));
};
$('ceLint').onclick = ceLint;
$('ceFmt').onclick = () => {
  try {
    ceArea.value = fmtHgs(ceArea.value);
    ceRefresh();
    $('ceErrors').innerHTML = '<div class="ok">✓ Отформатировано</div>';
  } catch (e) {
    $('ceErrors').innerHTML = `<div class="er">${escH(String(e))}</div>`;
  }
};

/* поиск */
function ceFindOpen() { $('ceFind').classList.remove('hidden'); $('ceFindIn').focus(); ceFindCount(); }
function ceFindClose() { $('ceFind').classList.add('hidden'); ceArea.focus(); }
function ceMatches() {
  const q = $('ceFindIn').value;
  if (!q) return [];
  const src = ceArea.value.toLowerCase();
  const qq = q.toLowerCase();
  const out = [];
  let i = 0;
  while ((i = src.indexOf(qq, i)) >= 0) { out.push(i); i += Math.max(1, qq.length); }
  return out;
}
function ceFindCount() {
  const ms = ceMatches();
  $('ceFindN').textContent = ms.length ? `1/${ms.length}` : '0/0';
  return ms;
}
function ceFindGo(dir) {
  const ms = ceMatches();
  if (!ms.length) return;
  const cur = ceArea.selectionStart;
  let idx = ms.findIndex((m) => m > cur);
  if (dir < 0) idx = idx <= 0 ? ms.length - 1 : idx - 1;
  if (idx < 0) idx = 0;
  const pos = ms[idx];
  ceArea.focus();
  ceArea.setSelectionRange(pos, pos + $('ceFindIn').value.length);
  $('ceFindN').textContent = `${idx + 1}/${ms.length}`;
}
$('ceFindBtn').onclick = ceFindOpen;
$('ceFindClose').onclick = ceFindClose;
$('ceFindNext').onclick = () => ceFindGo(1);
$('ceFindPrev').onclick = () => ceFindGo(-1);
$('ceFindIn').addEventListener('input', ceFindCount);
$('ceFindIn').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') { e.preventDefault(); ceFindGo(e.shiftKey ? -1 : 1); }
  if (e.key === 'Escape') ceFindClose();
});

/* подсказки (автодополнение) */
const CE_SNIPPETS = [
  ['@E.OnStart()', 'событие старта'],
  ['@E.OnUpdate(dt)', 'каждый кадр'],
  ['@E.End()', 'конец события'],
  ['@L.', 'переменная'],
  ['@P.Speed', 'скорость игрока'],
  ['@P.Jump', 'сила прыжка'],
  ['@P.Size', 'размер игрока'],
  ['@W.', 'объект мира'],
  ['@F.name(a)=', 'функция'],
  ['Text.pr()', 'печать в консоль'],
  ['WTD {', 'цикл'],
  ['break WTD', 'выход из цикла'],
  ['[if {', 'условие if/else'],
  ['[Var]', 'подстановка переменной'],
  ['[Name.dist]', 'дистанция до объекта'],
  ['Self.pos', 'позиция объекта'],
  ['Self.size', 'размер объекта'],
  ['Self.name', 'имя объекта'],
  ['@W.Destroy(obj: ', 'удалить объект'],
];
let ceACSel = 0;
function ceACOpen() {
  const box = $('ceAC');
  const pos = ceArea.selectionStart;
  const before = ceArea.value.slice(0, pos);
  const word = (before.match(/[@\wА-Яа-яЁё._\[]+$/) || [''])[0];
  const items = CE_SNIPPETS.filter(([s]) => !word || s.toLowerCase().includes(word.toLowerCase().replace(/^\[/, '')));
  if (!items.length) { box.classList.add('hidden'); return; }
  ceACSel = 0;
  box.innerHTML = items.map((it, i) => `<div class="ai${i === 0 ? ' sel' : ''}" data-i="${i}"><span>${escH(it[0])}</span><span class="d">${escH(it[1])}</span></div>`).join('');
  const r = ceArea.getBoundingClientRect();
  const lines = before.split('\n');
  const lh = 19.5;
  box.style.left = Math.min(r.left + 14 + (lines[lines.length - 1].length * 7.4), r.right - 210) + 'px';
  box.style.top = (r.top + 10 + lines.length * lh + 24) + 'px';
  box.classList.remove('hidden');
  box.querySelectorAll('.ai').forEach((el) => {
    el.onclick = () => ceACApply(items[+el.dataset.i][0], word);
  });
}
function ceACApply(snip, word) {
  const pos = ceArea.selectionStart;
  const before = ceArea.value.slice(0, pos);
  const after = ceArea.value.slice(pos);
  const start = before.length - word.length;
  let ins = snip;
  if (snip.endsWith('(')) ins += ')';
  if (snip.endsWith('{')) ins += ' }';
  if (snip.endsWith('[')) ins += ']';
  ceArea.value = before.slice(0, start) + ins + after;
  const np = start + ins.length - (ins.endsWith(' )') || ins.endsWith(' }') ? 2 : ins.endsWith(']') ? 1 : 0);
  ceArea.setSelectionRange(np, np);
  $('ceAC').classList.add('hidden');
  ceRefresh();
}
function ceACHide() { $('ceAC').classList.add('hidden'); }

/* события редактора */
ceArea.addEventListener('input', () => { ceRefresh(); ceACHide(); });
ceArea.addEventListener('scroll', ceRefresh);
$('ceCode').addEventListener('scroll', () => {
  ceGutter.scrollTop = $('ceCode').scrollTop;
});
ceArea.addEventListener('keydown', (e) => {
  if (e.key === 'Tab') {
    e.preventDefault();
    const p = ceArea.selectionStart;
    ceArea.value = ceArea.value.slice(0, p) + '  ' + ceArea.value.slice(ceArea.selectionEnd);
    ceArea.setSelectionRange(p + 2, p + 2);
    ceRefresh();
    return;
  }
  if (e.key === 'Enter' && e.ctrlKey) { e.preventDefault(); ceLint(); return; }
  if (e.key === ' ' && e.ctrlKey) { e.preventDefault(); ceACOpen(); return; }
  if (e.key === 'f' && e.ctrlKey) { e.preventDefault(); ceFindOpen(); return; }
  if (e.key === 's' && e.ctrlKey) { e.preventDefault(); ceSave(false); $('ceErrors').innerHTML = '<div class="ok">✓ Сохранено</div>'; return; }
  if (e.key === 'Escape') {
    if (!$('ceAC').classList.contains('hidden')) { ceACHide(); return; }
    if (!$('ceFind').classList.contains('hidden')) { ceFindClose(); return; }
    $('codeEditor').classList.add('hidden');
    return;
  }
  if (!$('ceAC').classList.contains('hidden')) {
    const items = $('ceAC').querySelectorAll('.ai');
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      ceACSel = (ceACSel + (e.key === 'ArrowDown' ? 1 : items.length - 1)) % items.length;
      items.forEach((el, i) => el.classList.toggle('sel', i === ceACSel));
      return;
    }
    if (e.key === 'Enter') {
      e.preventDefault();
      const el = items[ceACSel];
      if (el) el.onclick();
      return;
    }
    if (e.key === 'Escape') { ceACHide(); return; }
  }
  if (e.key === 'Enter') {
    // умный отступ
    const p = ceArea.selectionStart;
    const before = ceArea.value.slice(0, p);
    const line = before.slice(before.lastIndexOf('\n') + 1);
    const ind = (line.match(/^ */) || [''])[0].length + (line.trimEnd().endsWith('{') ? 2 : 0);
    if (ind > 0) {
      e.preventDefault();
      ceArea.value = before + '\n' + ' '.repeat(ind) + ceArea.value.slice(p);
      ceArea.setSelectionRange(p + 1 + ind, p + 1 + ind);
      ceRefresh();
    }
  }
});

/* ================= ПК: горячие клавиши ================= */
function hgsTyping(e) {
  const t = e.target;
  if (!t) return false;
  const tag = (t.tagName || '').toUpperCase();
  return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || t.isContentEditable;
}
function hgsRunToggle() {
  if (typeof play !== 'undefined' && play) { setPlay(false); return; }
  if (typeof cur !== 'undefined' && cur) setPlay(true);
}
addEventListener('keydown', (e) => {
  if (e.key === 'F5' || (e.key === 'Enter' && (e.ctrlKey || e.metaKey))) {
    if (hgsTyping(e) && !(e.ctrlKey || e.metaKey)) return;
    e.preventDefault();
    hgsRunToggle();
    return;
  }
  if (e.key === 'Escape') {
    const vis = (id) => { const el = $(id); return el && !el.classList.contains('hidden'); };
    if (vis('delBg')) { const c = $('delCancel'); if (c) c.click(); e.preventDefault(); return; }
    if (vis('codeEditor')) { const c = $('ceClose'); if (c) c.click(); e.preventDefault(); return; }
    if (vis('setBg')) { const c = $('setClose'); if (c) c.click(); e.preventDefault(); return; }
    const sheet = $('sheet');
    if (sheet && sheet.classList.contains('on')) { closeSheet(); e.preventDefault(); return; }
    if (typeof play !== 'undefined' && play) { setPlay(false); e.preventDefault(); return; }
    if (hgsTyping(e) && e.target.blur) e.target.blur();
  }
});

/* ================= перехват фатальных ошибок (видимая диагностика) ================= */
function showFatal(msg) {
  try {
    let el = document.getElementById('fatal');
    if (!el) {
      el = document.createElement('div');
      el.id = 'fatal';
      el.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#170c0c;color:#ffb3b3;font:12px/1.55 ui-monospace,monospace;padding:18px;overflow:auto;white-space:pre-wrap';
      const btn = document.createElement('button');
      btn.textContent = '\u2715';
      btn.style.cssText = 'position:fixed;top:10px;right:10px;font:16px sans-serif;background:#333;color:#fff;border:0;border-radius:8px;padding:6px 12px';
      btn.onclick = () => { el.remove(); btn.remove(); };
      document.body.appendChild(el);
      document.body.appendChild(btn);
    }
    el.textContent += msg + '\n\n';
  } catch (e) { /* ok */ }
}
addEventListener('error', (e) => showFatal('Ошибка: ' + (e.message || e.filename || '?') + '\n' + ((e.error && e.error.stack) || '')));
addEventListener('unhandledrejection', (e) => {
  const r = e.reason;
  showFatal('Promise: ' + ((r && (r.stack || r.message)) || String(r)));
});

/* ================= standalone: автозапуск экспортированной игры ================= */
(async () => {
  let d = null;
  try {
    const r = await fetch('game.mapp', { cache: 'no-store' });
    if (!r.ok) return;
    d = await r.json();
    if (!d || d.mapp !== 1 || !d.scene || !Array.isArray(d.scene.entities)) return;
    const ok = await wasmReady;
    if (!ok) return;
    let p = store.projects().find((x) => x.name === String(d.name || '').slice(0, 40));
    if (p) { store.saveScene(p.id, d.scene); renderProjects(); }
    else p = importMappText(JSON.stringify(d), true);
    if (!p) return;
    await openProject(p);
    setPlay(true);
  } catch (e) {
    if (d) {
      showFatal('Не удалось запустить игру: ' + ((e && (e.stack || e.message)) || e));
      try { hideSplash(); } catch (err) { /* ok */ }
    }
    /* нет game.mapp — обычный режим редактора */
  }
})();
