import init, { Engine, run_self_test, version, gfx_defaults } from './pkg/engine.js';
import { t, getLang, setLang, applyDom } from './i18n.js';
import { createRuntime, lint as lintHgs, format as fmtHgs } from './lang.js';

const $ = (id) => document.getElementById(id);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const clamp = (v) => Math.max(-1, Math.min(1, v));

/* ================= хранилище ================= */
const DEFAULT_SCRIPT = `# Скрипт игрока — язык HolyGGS
@E.OnStart()
    @L.HP = 100
    @P.Speed = 8
    @P.Jump = 2.6
    @P.Size = 1
    Text.pr(привет!)
@E.End()

@E.OnUpdate(dt)
    # [HP], [P.pos], @W.имя.move(...) и т.д.
@E.End()`;

let scriptText = '';
let rt = null;
const objRts = [];
const objScripts = {};
let editMode = false;
let editHist = [];
let ceCtx = null;

const DEFAULT_OBJ_SCRIPT = `# Скрипт объекта — Self.pos / Self.size / Self.dist / Self.name
@E.OnStart()
    Text.pr(объект запущен)
@E.End()

@E.OnUpdate(dt)
    
@E.End()`;

const store = {
  projects() { try { return JSON.parse(localStorage.getItem('eng.projects') || '[]'); } catch { return []; } },
  saveProjects(p) { try { localStorage.setItem('eng.projects', JSON.stringify(p)); } catch (e) { alert(t('saveFail', e)); } },
  scene(id) { try { return JSON.parse(localStorage.getItem('eng.scene.' + id) || 'null'); } catch { return null; } },
  saveScene(id, s) { try { localStorage.setItem('eng.scene.' + id, JSON.stringify(s)); } catch (e) { console.warn(e); } },
  delScene(id) { localStorage.removeItem('eng.scene.' + id); },
};

/* ================= схема настроек графики (индексы = как в Rust) ================= */
const GFX = [
  { k: 'g_time', min: 0, max: 24, step: 0.05, fmt: 'time' }, // 0
  { k: 'g_contrast', min: 0.5, max: 2, step: 0.01 },         // 1
  { k: 'g_exposure', min: 0.3, max: 2.5, step: 0.01 },       // 2
  { k: 'g_sat', min: 0, max: 2, step: 0.01 },                // 3
  { k: 'g_rays', min: 0, max: 2, step: 0.01 },               // 4
  { k: 'g_neon', min: 0, max: 8, step: 0.1 },                // 5
  { k: 'g_bloom', min: 0, max: 2, step: 0.01 },              // 6
  { k: 'g_bthr', min: 0, max: 3, step: 0.01 },               // 7
  { k: 'g_fogd', min: 0, max: 0.1, step: 0.001 },            // 8
  { k: 'g_fogs', min: 0, max: 300, step: 1 },                // 9
  { k: 'g_skyb', min: 0.2, max: 2, step: 0.01 },             // 10
  { k: 'g_sun', min: 0.3, max: 4, step: 0.05 },              // 11
  { k: 'g_vig', min: 0, max: 1, step: 0.01 },                // 12
  { k: 'g_amb', min: 0, max: 2, step: 0.01 },
  { k: 'g_shadow', min: 0, max: 1, step: 0.01 },
  { k: 'g_nlight', min: 0, max: 3, step: 0.01 },
  { k: 'g_waveh', min: 0, max: 2, step: 0.01 },   // 16
  { k: 'g_waves', min: 0, max: 3, step: 0.01 },   // 17
  { k: 'g_bump', min: 0, max: 3, step: 0.01 },    // 18
  { k: 'g_fov', min: 30, max: 110, step: 1 },     // 19
  { k: 'g_sens', min: 0.2, max: 3, step: 0.01 },
  { k: 'g_fogn', min: 0, max: 2, step: 0.01 },   // 21
  { k: 'g_mie', min: 0, max: 3, step: 0.01 },    // 22
  { k: 'g_texq', min: 0, max: 2, step: 1, fmt: 'qual' }, // 23
  { k: 'g_shq', min: 0, max: 2, step: 1, fmt: 'qual' },  // 24
  { k: 'g_wq', min: 0, max: 2, step: 1, fmt: 'qual' },   // 25
];
const GROUPS = [
  { id: 'time', icon: '☀', k: 'grp_time', items: [0, 10, 11, 13, 14] },
  { id: 'fx', icon: '✦', k: 'grp_fx', items: [4, 6, 7, 5, 15, 12, 18] },
  { id: 'col', icon: '◑', k: 'grp_col', items: [2, 1, 3] },
  { id: 'fog', icon: '☁', k: 'grp_fog', items: [8, 9, 21, 22] },
  { id: 'wat', icon: '≈', k: 'grp_water', items: [16, 17] },
  { id: 'cam', icon: '◉', k: 'grp_cam', items: [19, 20] },
  { id: 'q', icon: '⚙', k: 'grp_qual', items: [23, 24, 25] },
];

/* ================= wasm ================= */
let wasmErr = null;
let verText = 'Engine';
const setVer = () => { $('ver').textContent = verText; };
const wasmReady = init().then(() => true).catch((e) => { wasmErr = e; return false; });
wasmReady.then((ok) => { if (ok) { verText = 'Engine core v' + version(); setVer(); } });

/* ================= список проектов ================= */
function renderProjects() {
  const list = store.projects();
  const box = $('projects');
  box.innerHTML = '';
  $('empty').classList.toggle('hidden', list.length > 0);
  for (const p of list) {
    const c = document.createElement('div'); c.className = 'card';
    const ico = document.createElement('div'); ico.className = 'ico';
    if (p.icon) ico.style.backgroundImage = `url(${p.icon})`; else ico.textContent = (p.name[0] || '?').toUpperCase();
    const nm = document.createElement('div'); nm.className = 'nm'; nm.textContent = p.name;
    const dt = document.createElement('div'); dt.className = 'dt'; dt.textContent = new Date(p.created).toLocaleDateString(getLang() === 'ru' ? 'ru-RU' : 'en-US');
    c.append(ico, nm, dt);

    let timer = 0, long = false;
    c.addEventListener('pointerdown', () => {
      long = false;
      timer = setTimeout(() => {
        long = true;
        if (confirm(t('confirmDel', p.name))) {
          store.saveProjects(store.projects().filter((x) => x.id !== p.id));
          store.delScene(p.id);
          renderProjects();
        }
      }, 650);
    });
    const cancel = () => clearTimeout(timer);
    c.addEventListener('pointerup', cancel);
    c.addEventListener('pointerleave', cancel);
    c.addEventListener('pointercancel', cancel);
    c.addEventListener('click', () => { if (!long) openProject(p); });
    box.appendChild(c);
  }
}

/* ================= настройки ================= */
function updSeg() {
  document.querySelectorAll('.seg button').forEach((b) => b.classList.toggle('on', b.dataset.lang === getLang()));
}
$('settingsBtn').onclick = () => { updSeg(); $('setBg').classList.remove('hidden'); };
$('setClose').onclick = () => $('setBg').classList.add('hidden');
$('setBg').addEventListener('click', (e) => { if (e.target === $('setBg')) $('setBg').classList.add('hidden'); });
document.querySelectorAll('.seg button').forEach((b) => {
  b.onclick = () => { setLang(b.dataset.lang); updSeg(); setVer(); renderProjects(); };
});

/* ================= шторка: проверки -> форма ================= */
let runId = 0;
let fullLog = [];
let newIcon = null;

const openSheet = () => { $('shade').classList.add('on'); $('sheet').classList.add('on'); };
const closeSheet = () => { runId++; $('shade').classList.remove('on'); $('sheet').classList.remove('on'); };

function logLine(level, msg) {
  const tag = { ok: '[ OK ] ', warn: '[WARN] ', fail: '[FAIL] ', info: '[ .. ] ' }[level] || '';
  const d = document.createElement('div');
  d.className = 'l ' + level;
  d.textContent = tag + msg;
  $('log').appendChild(d);
  $('log').scrollTop = $('log').scrollHeight;
  fullLog.push(tag + msg);
}

async function runChecks(token) {
  let ok = true;
  const L = async (level, msg) => {
    if (token !== runId) throw new Error('cancel');
    if (level === 'fail') ok = false;
    logLine(level, msg);
    await sleep(110);
  };

  await L('info', t('log_start'));
  await L(typeof WebAssembly === 'object' ? 'ok' : 'fail', 'WebAssembly');

  if (!(await wasmReady)) {
    await L('fail', t('log_core_fail', wasmErr));
    return false;
  }
  await L('ok', t('log_core_ok', version()));

  for (const line of run_self_test(getLang() === 'en').split('\n')) {
    const m = line.match(/^(OK|WARN|FAIL) (.*)$/);
    if (m) await L(m[1].toLowerCase(), m[2]); else if (line) await L('info', line);
  }

  try {
    const cv = document.createElement('canvas');
    const gl = cv.getContext('webgl2');
    if (!gl) throw new Error('webgl2 unavailable');
    const dbg = gl.getExtension('WEBGL_debug_renderer_info');
    const gpu = dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : '?';
    await L('ok', t('log_webgl', gpu));
    await L('ok', t('log_tex', gl.getParameter(gl.MAX_TEXTURE_SIZE)));
    const hdr = !!(gl.getExtension('EXT_color_buffer_float') || gl.getExtension('EXT_color_buffer_half_float'));
    await L(hdr ? 'ok' : 'warn', 'HDR: ' + (hdr ? 'on' : 'off (LDR fallback)'));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
  } catch (e) {
    await L('fail', t('log_webgl_fail', e.message));
  }

  try {
    localStorage.setItem('eng.test', '1');
    if (localStorage.getItem('eng.test') !== '1') throw new Error('read mismatch');
    localStorage.removeItem('eng.test');
    await L('ok', t('log_store_ok'));
  } catch (e) {
    await L('fail', t('log_store_fail', e.message));
  }

  const thr = self.crossOriginIsolated && typeof SharedArrayBuffer !== 'undefined';
  await L(thr ? 'ok' : 'warn', t('log_threads', t(thr ? 'thr_yes' : 'thr_no')));
  await L('info', t('log_physics'));
  await L(ok ? 'ok' : 'fail', t(ok ? 'log_all_ok' : 'log_some_fail'));
  return ok;
}

async function startNew() {
  const token = ++runId;
  fullLog = [];
  newIcon = null;
  $('log').innerHTML = '';
  $('ldTitle').textContent = 'Loading. . .';
  $('cubes').classList.remove('stop');
  $('ldBtns').classList.add('hidden');
  $('copyLog').textContent = t('copyLog');
  $('ld').classList.remove('hidden');
  $('form').classList.add('hidden');
  $('iconBtn').style.backgroundImage = '';
  $('iconBtn').classList.remove('has');
  $('nameIn').value = '';
  openSheet();

  let ok = false;
  try {
    const t0 = performance.now();
    ok = await runChecks(token);
    const left = 1400 - (performance.now() - t0);
    if (left > 0) await sleep(left);
  } catch (e) {
    if (token !== runId) return;
    logLine('fail', t('log_exc', e));
  }
  if (token !== runId) return;

  if (ok) {
    $('ld').classList.add('hidden');
    $('form').classList.remove('hidden');
  } else {
    $('ldTitle').textContent = t('checkFail');
    $('cubes').classList.add('stop');
    $('ldBtns').classList.remove('hidden');
  }
}

$('plus').onclick = startNew;
$('shade').onclick = closeSheet;
$('closeLd').onclick = closeSheet;
$('copyLog').onclick = async () => {
  const txt = fullLog.join('\n');
  try { await navigator.clipboard.writeText(txt); $('copyLog').textContent = t('copied'); }
  catch { alert(txt); }
};

function toIcon(file) {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const s = 192, c = document.createElement('canvas');
      c.width = c.height = s;
      const m = Math.min(img.width, img.height);
      c.getContext('2d').drawImage(img, (img.width - m) / 2, (img.height - m) / 2, m, m, 0, 0, s, s);
      URL.revokeObjectURL(url);
      res(c.toDataURL('image/jpeg', 0.85));
    };
    img.onerror = rej;
    img.src = url;
  });
}
$('iconBtn').onclick = () => $('file').click();
$('file').onchange = async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  try {
    newIcon = await toIcon(f);
    $('iconBtn').style.backgroundImage = `url(${newIcon})`;
    $('iconBtn').classList.add('has');
  } catch { alert(t('imgFail')); }
  e.target.value = '';
};

$('create').onclick = () => {
  const p = {
    id: Date.now().toString(36),
    name: $('nameIn').value.trim() || t('newProject'),
    icon: newIcon,
    created: Date.now(),
  };
  store.saveProjects([p, ...store.projects()]);
  closeSheet();
  renderProjects();
  openProject(p);
};

/* ================= воркспейс ================= */
let engine = null, cur = null, raf = 0, lastT = 0, saveTimer = 0;
let frames = 0, fpsAcc = 0;
let gfxDefs = [], gfxVals = [], gfxGroup = null;

const PLATE_COLOR = [0.62, 0.62, 0.64];
const defaultPlate = () => ({
  name: t('plate'),
  props: [0, -0.5, 0, 0, 0, 0, 40, 1, 40, ...PLATE_COLOR, 0],
});

async function lockLandscape() {
  if (!matchMedia('(pointer:coarse)').matches) return;
  try { if (!document.fullscreenElement) await document.documentElement.requestFullscreen(); } catch {}
  try { await screen.orientation.lock('landscape'); } catch {}
}
function unlockOrientation() {
  try { screen.orientation.unlock(); } catch {}
  try { if (document.fullscreenElement) document.exitFullscreen(); } catch {}
}

async function openProject(p) {
  cur = p;
  $('menu').classList.add('hidden');
  $('work').classList.remove('hidden');
  document.body.classList.add('work-on');
  $('projName').textContent = p.name;
  await lockLandscape();

  if (!(await wasmReady)) { alert(t('coreNotLoaded', wasmErr)); backToMenu(); return; }
  if (!engine) {
    try { engine = new Engine('c'); }
    catch (e) { alert(t('engineFail', e)); backToMenu(); return; }
  }
  gfxDefs = Array.from(gfx_defaults());
  engine.set_mode(mode);
  setPlay(false);
  resizeCanvas();
  loadScene(p.id);
  buildTree();
  syncSelection();
  lastT = performance.now();
  cancelAnimationFrame(raf);
  raf = requestAnimationFrame(loop);
}

function backToMenu() {
  setPlay(false);
  cancelAnimationFrame(raf);
  flushSave();
  if (engine) engine.set_move(0, 0, 0);
  joy.x = joy.z = joy.y = 0;
  $('work').classList.add('hidden');
  $('menu').classList.remove('hidden');
  document.body.classList.remove('work-on');
  unlockOrientation();
  cur = null;
  renderProjects();
}
$('back').onclick = backToMenu;

function loop(ts) {
  const dt = Math.min((ts - lastT) / 1000, 0.1);
  lastT = ts;
  if (play) {
    if (rt) rt.update(dt);
    for (const o of objRts) { try { o.rt.update(dt); } catch (e) { consolePrint(o.nm + ': ' + e); } }
  }
  engine.frame(dt);
  frames++; fpsAcc += dt;
  if (fpsAcc >= 0.5) {
    $('fps').textContent = 'FPS ' + Math.round(frames / fpsAcc) + (engine.hdr() ? ' · HDR' : '');
    frames = 0; fpsAcc = 0;
  }
  raf = requestAnimationFrame(loop);
}

function resizeCanvas() {
  if (!engine) return;
  const v = $('view');
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  engine.resize(Math.max(1, Math.floor(v.clientWidth * dpr)), Math.max(1, Math.floor(v.clientHeight * dpr)));
}
new ResizeObserver(resizeCanvas).observe($('view'));

/* ---------- сцена ---------- */
function loadScene(id) {
  engine.clear();
  const s = store.scene(id);
  const ents = s && Array.isArray(s.entities) && s.entities.length ? s.entities : [defaultPlate()];
  if (s && (s.v || 1) < 2) {
    // миграция: старая зелёная плита -> серая
    for (const e of ents) {
      const p = e.props;
      if (p && Math.abs(p[9] - 0.45) < 0.01 && Math.abs(p[10] - 0.70) < 0.01 && Math.abs(p[11] - 0.40) < 0.01) {
        p[9] = PLATE_COLOR[0]; p[10] = PLATE_COLOR[1]; p[11] = PLATE_COLOR[2];
      }
    }
  }
  const newIds = ents.map((e) => engine.add_entity(e.name, new Float32Array(e.props)));
  ents.forEach((e, i) => {
    if (Number.isInteger(e.parent) && e.parent >= 0 && e.parent < newIds.length && e.parent !== i) {
      engine.set_parent(newIds[i], newIds[e.parent]);
    }
  });
  gfxVals = gfxDefs.map((d, i) => (s && Array.isArray(s.gfx) && Number.isFinite(s.gfx[i]) ? s.gfx[i] : d));
  gfxVals.forEach((v, i) => engine.set_gfx(i, v));
  gfxGroup = null;
  scriptText = typeof s.script === 'string' ? s.script : DEFAULT_SCRIPT;
  for (const k of Object.keys(objScripts)) delete objScripts[k];
  if (s && s.objScripts && typeof s.objScripts === 'object') Object.assign(objScripts, s.objScripts);
  engine.set_pm_root(Number.isInteger(s.pmRoot) && s.pmRoot >= 0 && s.pmRoot < newIds.length ? newIds[s.pmRoot] : -1);
  engine.reset_camera();
}
function collectScene() {
  const ids = Array.from(engine.entity_ids());
  const entities = ids.map((id) => ({
    name: engine.entity_name(id),
    props: Array.from(engine.get_props(id)),
    parent: ids.indexOf(engine.parent_of(id)),
  }));
  return { v: 2, entities, gfx: gfxVals.slice(), script: scriptText, objScripts: { ...objScripts }, pmRoot: ids.indexOf(engine.pm_root()) };
}
function flushSave() {
  clearTimeout(saveTimer);
  if (cur && engine) store.saveScene(cur.id, collectScene());
}
const scheduleSave = () => { clearTimeout(saveTimer); saveTimer = setTimeout(flushSave, 500); };
document.addEventListener('visibilitychange', () => { if (document.hidden) flushSave(); });
addEventListener('pagehide', flushSave);

/* ---------- дерево ---------- */
function blockIcon() {
  const img = new Image();
  img.src = 'blockicon.png';
  img.className = 'bico';
  img.alt = '';
  img.draggable = false;
  img.onerror = () => img.replaceWith(document.createTextNode('■'));
  return img;
}
function kindOf(id) {
  const p = engine.get_props(id);
  return p[15] > 0.5 ? 'fire' : p[14] > 0.5 ? 'water' : 'block';
}
function entIcon(id) {
  const k = kindOf(id);
  return k === 'fire' ? '🔥' : k === 'water' ? '≈' : blockIcon();
}
function mkRow(icon, name, sub, depth, plusFor) {
  const r = document.createElement('div');
  r.className = 'row';
  r.style.paddingLeft = 10 + depth * 14 + 'px';
  const i = document.createElement('span'); i.className = 'ri';
  if (typeof icon === 'string') i.textContent = icon; else i.appendChild(icon);
  const n = document.createElement('span'); n.className = 'rn'; n.textContent = name;
  r.append(i, n);
  if (sub) { const sm = document.createElement('small'); sm.textContent = sub; r.append(sm); }
  if (plusFor !== undefined) {
    const b = document.createElement('button');
    b.className = 'rowplus'; b.textContent = '+'; b.setAttribute('aria-label', 'Add');
    b.onclick = (e) => { e.stopPropagation(); openSpawnMenu(b, plusFor); };
    r.append(b);
  }
  return r;
}
function folder(label, sub, depth, plusFor, build) {
  const root = mkRow('▾', label, sub, depth, plusFor);
  const kids = document.createElement('div');
  build(kids);
  root.onclick = () => {
    kids.classList.toggle('hidden');
    root.firstChild.textContent = kids.classList.contains('hidden') ? '▸' : '▾';
  };
  return [root, kids];
}
function buildTree() {
  const tb = $('treeBody');
  tb.innerHTML = '';
  const ids = Array.from(engine.entity_ids());
  const byParent = new Map();
  for (const id of ids) {
    let par = engine.parent_of(id);
    if (!ids.includes(par)) par = -1;
    if (!byParent.has(par)) byParent.set(par, []);
    byParent.get(par).push(id);
  }
  const add = (box, parent, depth, skip = null) => {
    for (const id of byParent.get(parent) || []) {
      if (skip && skip.has(id)) continue;
      const r = mkRow(entIcon(id), engine.entity_name(id), '', depth, id);
      r.dataset.id = id;
      r.onclick = () => { engine.select(id); syncSelection(); };
      box.appendChild(r);
      add(box, id, depth + 1, skip);
    }
  };
  const pmRoot = engine.pm_root();
  const pmSet = new Set();
  if (pmRoot >= 0) { pmSet.add(pmRoot); for (const d of engine.descendants_of(pmRoot)) pmSet.add(d); }
  tb.append(...folder('@P', t('player'), 0, undefined, (box) => {
    const rModel = mkRow('👤', t('player_model'), pmRoot >= 0 ? engine.entity_name(pmRoot) : t('player_model_none'), 1);
    rModel.onclick = () => {
      const sel = engine.selected();
      if (sel >= 0 && sel !== pmRoot) {
        engine.set_pm_root(sel);
        buildTree(); scheduleSave();
      } else if (pmRoot >= 0) {
        engine.select(pmRoot); syncSelection();
      }
    };
    box.appendChild(rModel);
    if (pmRoot < 0) {
      const rNew = mkRow('＋', t('player_create'), '', 1);
      rNew.onclick = () => { createPlayerModel(); };
      box.appendChild(rNew);
    }
    const rSph = mkRow('⚪', t('player_sphere'), pmRoot < 0 ? '✓' : '', 1);
    rSph.onclick = () => { engine.set_pm_root(-1); buildTree(); scheduleSave(); };
    box.appendChild(rSph);
    const rHum = mkRow('👤', t('player_human'), pmRoot >= 0 ? '✓' : '', 1);
    rHum.onclick = () => { if (engine.pm_root() < 0) createPlayerModel(); };
    box.appendChild(rHum);
    const rScript = mkRow('📜', 'player.hgs', '', 1);
    rScript.onclick = () => openScriptFor('player');
    box.appendChild(rScript);
  }));
  tb.append(...folder('@W', 'Workspace', 0, -1, (box) => add(box, -1, 1, pmSet)));
  tb.append(...folder('@A', t('graphics'), 0, undefined, (box) => {
    for (const g of GROUPS) {
      const r = mkRow(g.icon, t(g.k), '', 1);
      r.dataset.g = g.id;
      r.onclick = () => openGfx(g.id);
      box.appendChild(r);
    }
  }));
}

/* ---------- мини-меню "+" ---------- */
let menuEl = null;
function closeSpawnMenu() { if (menuEl) { menuEl.remove(); menuEl = null; } }
addEventListener('pointerdown', (e) => {
  if (menuEl && !menuEl.contains(e.target) && !(e.target.classList && e.target.classList.contains('rowplus'))) closeSpawnMenu();
}, true);
function openSpawnMenu(anchor, parentId) {
  closeSpawnMenu();
  const m = document.createElement('div');
  m.id = 'spawnMenu';
  for (const [kind, ico] of [['block', '■'], ['water', '≈'], ['fire', '🔥']]) {
    const b = document.createElement('button');
    const i = document.createElement('span'); i.className = 'mi'; i.textContent = ico;
    const n = document.createElement('span'); n.textContent = t(kind);
    b.append(i, n);
    b.onclick = () => { closeSpawnMenu(); spawn(kind, parentId); };
    m.appendChild(b);
  }
  document.body.appendChild(m);
  const r = anchor.getBoundingClientRect();
  m.style.left = Math.max(8, r.left - m.offsetWidth - 6) + 'px';
  m.style.top = Math.max(8, Math.min(r.top, innerHeight - m.offsetHeight - 8)) + 'px';
  menuEl = m;
}

function spawn(kind, parentId) {
  if (!engine) return;
  const ids = Array.from(engine.entity_ids());
  const par = ids.includes(parentId) ? engine.get_props(parentId) : null;
  const size = kind === 'block' ? [4, 4, 4] : kind === 'water' ? [16, 2, 16] : [1.6, 2.8, 1.6];
  const color = kind === 'block' ? [0.30, 0.62, 0.95] : kind === 'water' ? [0.05, 0.28, 0.38] : [1.0, 0.5, 0.12];
  const alpha = kind === 'water' ? 0.78 : 1;
  let pos;
  if (par) {
    const top = par[1] + par[7] * 0.5;
    pos = [par[0], kind === 'water' ? top - size[1] * 0.5 : top + size[1] * 0.5, par[2]];
  } else {
    const f = engine.camera_front(kind === 'block' ? 12 : 16);
    pos = kind === 'block' ? [f[0], Math.max(f[1], 2), f[2]]
        : kind === 'water' ? [f[0], -0.5, f[2]]
        : [f[0], size[1] / 2, f[2]];
  }
  const props = [...pos, 0, 0, 0, ...size, ...color, 0, alpha, kind === 'water' ? 1 : 0, kind === 'fire' ? 1 : 0, 0, 0];
  const id = engine.add_entity(uniqueName(t(kind)), new Float32Array(props));
  if (par) engine.set_parent(id, parentId);
  buildTree();
  engine.select(id);
  syncSelection();
  scheduleSave();
}


function uniqueName(base) {
  const used = new Set(engine.entity_ids().map((i) => engine.entity_name(i)));
  let n = 1;
  while (used.has(`${base} ${n}`)) n++;
  return `${base} ${n}`;
}

/* ---------- свойства блока ---------- */
const fmt = (v) => String(Math.round(v * 1000) / 1000);
const h2 = (v) => Math.round(Math.min(1, Math.max(0, v)) * 255).toString(16).padStart(2, '0');
const toHex = (r, g, b) => '#' + h2(r) + h2(g) + h2(b);
const vecIn = [$('iPos'), $('iRot'), $('iSize')];
const parseVec = (str) => {
  const p = str.split(/[\s,;]+/).filter(Boolean).map(Number);
  return p.length === 3 && p.every(Number.isFinite) ? p : null;
};

function fillProps(id) {
  const p = engine.get_props(id);
  if (p.length < 13) return;
  vecIn[0].value = [p[0], p[1], p[2]].map(fmt).join(', ');
  vecIn[1].value = [p[3], p[4], p[5]].map(fmt).join(', ');
  vecIn[2].value = [p[6], p[7], p[8]].map(fmt).join(', ');
  vecIn.forEach((i) => i.classList.remove('bad'));
  $('pColor').value = toHex(p[9], p[10], p[11]);
  $('pNeon').checked = p[12] > 0.5;
  $('pAlpha').value = p.length > 13 ? p[13] : 1;
  const k = kindOf(id);
  $('matRow').style.display = k === 'block' ? '' : 'none';
  $('wtexRow').style.display = k === 'water' ? '' : 'none';
  $('shapeRow').style.display = k === 'block' ? '' : 'none';
  $('editRow').style.display = k === 'block' && Math.round(p[18] || 0) === 0 ? '' : 'none';
  $('objScriptRow').style.display = '';
  $('pObjScript').onclick = () => openScriptFor('object', engine.entity_name(id));
  if (k === 'block') {
    $('pMat').value = String(Math.min(5, Math.max(0, Math.round(p[16] || 0))));
    $('pShape').value = String(Math.min(4, Math.max(0, Math.round(p[18] || 0))));
  }
  if (k === 'water') $('pWtex').value = (p[17] || 0) > 0.5 ? '1' : '0';
}
function onEdit() {
  const id = engine.selected();
  if (id < 0) return;
  const v = vecIn.map((i) => parseVec(i.value));
  vecIn.forEach((i, k) => i.classList.toggle('bad', !v[k]));
  if (v.some((x) => !x)) return;
  const hex = $('pColor').value;
  const c = [1, 3, 5].map((k) => parseInt(hex.slice(k, k + 2), 16) / 255);
  const cur = Array.from(engine.get_props(id));
  const kind = kindOf(id);
  const mat = kind === 'block' ? (parseFloat($('pMat').value) || 0) : (cur[16] || 0);
  const wt = kind === 'water' ? (parseFloat($('pWtex').value) || 0) : (cur[17] || 0);
  const shp = kind === 'block' ? (parseFloat($('pShape').value) || 0) : (cur[18] || 0);
  engine.set_props(id, new Float32Array([...v[0], ...v[1], ...v[2], ...c,
    $('pNeon').checked ? 1 : 0, parseFloat($('pAlpha').value),
    cur[14] || 0, cur[15] || 0, mat, wt, shp]));
  scheduleSave();
}
vecIn.forEach((i) => {
  i.addEventListener('input', onEdit);
  i.addEventListener('keydown', (e) => { if (e.key === 'Enter') i.blur(); });
  i.addEventListener('blur', () => { const id = engine.selected(); if (id >= 0) fillProps(id); });
});
$('pColor').addEventListener('input', onEdit);
$('pNeon').addEventListener('change', onEdit);
$('pAlpha').addEventListener('input', onEdit);

/* ---------- материалы и текстуры из галереи ---------- */
let texTarget = 'mat';
function pickTexture(target) {
  texTarget = target;
  $('texFile').value = '';
  $('texFile').click();
}
$('pMat').addEventListener('change', () => {
  if (engine.selected() < 0) return;
  if ($('pMat').value === '5') pickTexture('mat');
  else onEdit();
});
$('pWtex').addEventListener('change', () => {
  if (engine.selected() < 0) return;
  if ($('pWtex').value === '1') pickTexture('water');
  else onEdit();
});
$('pShape').addEventListener('change', () => {
  if (engine.selected() < 0) return;
  onEdit();
  if (editMode) closeEdit();
  buildTree();
});

/* ---------- режим правки (Blender-like) ---------- */
function pushHist(id) {
  editHist.push(engine.edit_cells_hex(id));
  if (editHist.length > 40) editHist.shift();
}
function openEdit() {
  const id = engine.selected();
  if (id < 0) return;
  editMode = true;
  editHist = [];
  engine.set_edit_id(id);
  engine.set_edit_iso($('etIso').checked);
  const ed = engine.get_edit(id);
  const sub = ed.length > 0 ? Math.round(ed[0]) : 0;
  $('etRound').value = String(ed.length > 1 ? ed[1] : 0);
  document.querySelectorAll('#etSubBtns button').forEach((b) => b.classList.toggle('on', +b.dataset.sub === sub));
  $('etName').textContent = engine.entity_name(id);
  $('editTools').classList.remove('hidden');
  $('insp').classList.remove('on');
  const p = engine.get_props(id);
  const d = Math.max(3, Math.hypot(p[6], p[7], p[8]) * 2.4);
  engine.focus_on(p[0], p[1], p[2], d);
}
function closeEdit() {
  editMode = false;
  engine.set_edit_id(-1);
  engine.set_edit_iso(false);
  $('editTools').classList.add('hidden');
  scheduleSave();
}
$('pEdit').onclick = () => (editMode ? closeEdit() : openEdit());
$('etExit').onclick = closeEdit;
document.querySelectorAll('#etSubBtns button').forEach((b) => {
  b.onclick = () => {
    const id = engine.edit_id();
    if (id < 0) return;
    document.querySelectorAll('#etSubBtns button').forEach((x) => x.classList.toggle('on', x === b));
    pushHist(id);
    engine.set_edit(id, +b.dataset.sub, parseFloat($('etRound').value) || 0, 'ffffffffffffffff');
    scheduleSave();
  };
});
$('etRound').addEventListener('input', () => {
  const id = engine.edit_id();
  if (id < 0) return;
  const ed = engine.get_edit(id);
  engine.set_edit(id, ed.length ? Math.round(ed[0]) : 0, parseFloat($('etRound').value) || 0, engine.edit_cells_hex(id));
  scheduleSave();
});
$('etReset').onclick = () => {
  const id = engine.edit_id();
  if (id < 0) return;
  pushHist(id);
  engine.edit_reset_cells(id);
  scheduleSave();
};
$('etUndo').onclick = () => {
  const id = engine.edit_id();
  if (id < 0 || !editHist.length) return;
  const ed = engine.get_edit(id);
  engine.set_edit(id, ed.length ? Math.round(ed[0]) : 0, ed.length > 1 ? ed[1] : 0, editHist.pop());
  scheduleSave();
};
$('etIso').onchange = () => { if (engine) engine.set_edit_iso($('etIso').checked); };

/* ---------- папка игрока: модель и скрипт ---------- */
function createPlayerModel() {
  const base = [0, 0, 0];
  const cam = engine.camera_front(3);
  const mk = (name, pos, size, color, parent) => {
    const id = engine.add_entity(name, new Float32Array([
      ...pos, 0, 0, 0, ...size, ...color, 0, 1, 0, 0, 0, 0, 0,
    ]));
    if (parent >= 0) engine.set_parent(id, parent);
    return id;
  };
  const root = mk('Player', [cam[0], cam[1], cam[2]], [0.7, 1.0, 0.4], [0.55, 0.56, 0.58], -1);
  mk('Head', [cam[0], cam[1] + 0.75, cam[2]], [0.5, 0.5, 0.5], [0.85, 0.72, 0.58], root);
  mk('LegL', [cam[0] - 0.2, cam[1] - 0.85, cam[2]], [0.25, 0.7, 0.3], [0.3, 0.32, 0.36], root);
  mk('LegR', [cam[0] + 0.2, cam[1] - 0.85, cam[2]], [0.25, 0.7, 0.3], [0.3, 0.32, 0.36], root);
  mk('ArmL', [cam[0] - 0.55, cam[1] + 0.15, cam[2]], [0.22, 0.85, 0.25], [0.55, 0.56, 0.58], root);
  mk('ArmR', [cam[0] + 0.55, cam[1] + 0.15, cam[2]], [0.22, 0.85, 0.25], [0.55, 0.56, 0.58], root);
  engine.set_pm_root(root);
  buildTree();
  syncSelection();
  scheduleSave();
}
function openScript() { openScriptFor('player'); }
function consolePrint(msg) {
  const c = $('console');
  c.classList.add('on');
  const d = document.createElement('div');
  d.textContent = msg;
  c.appendChild(d);
  while (c.children.length > 6) c.removeChild(c.firstChild);
  clearTimeout(c._t);
  c._t = setTimeout(() => c.classList.remove('on'), 6000);
}
$('texFile').addEventListener('change', async () => {
  const f = $('texFile').files && $('texFile').files[0];
  if (!f) { syncSelection(); return; }
  try {
    const bmp = await createImageBitmap(f);
    const c2 = document.createElement('canvas');
    c2.width = c2.height = 256;
    const ctx = c2.getContext('2d');
    const s = Math.min(bmp.width, bmp.height);
    ctx.drawImage(bmp, (bmp.width - s) / 2, (bmp.height - s) / 2, s, s, 0, 0, 256, 256);
    const d = ctx.getImageData(0, 0, 256, 256);
    const px = new Uint8Array(d.data.buffer);
    if (texTarget === 'water') engine.set_custom_water(px, 256, 256);
    else engine.set_custom_mat(px, 256, 256);
    onEdit();
  } catch (e) {
    alert(t('imgFail'));
    syncSelection();
  }
});

$('pDel').onclick = () => {
  const id = engine.selected();
  if (id < 0) return;
  engine.remove_entity(id);
  buildTree();
  syncSelection();
  scheduleSave();
};

/* ---------- панель графики (@A) ---------- */
function fmtTime(v) {
  let h = Math.floor(v), m = Math.round((v - h) * 60);
  if (m === 60) { h = (h + 1) % 24; m = 0; }
  return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
}
const QUAL_NAMES = ['q_low', 'q_med', 'q_high'];
const fmtG = (it, v) => (it.fmt === 'time' ? fmtTime(v)
  : it.fmt === 'qual' ? t(QUAL_NAMES[Math.max(0, Math.min(2, Math.round(v)))])
  : v.toFixed(it.step < 0.01 ? 3 : it.step < 1 ? 2 : 0));

function buildGfx(gid) {
  const g = GROUPS.find((x) => x.id === gid);
  $('gfxTitle').textContent = t(g.k);
  const body = $('gfxBody');
  body.innerHTML = '';
  for (const i of g.items) {
    const it = GFX[i];
    const row = document.createElement('div'); row.className = 'gr';
    const lb = document.createElement('label'); lb.textContent = t(it.k);
    const inp = document.createElement('input');
    inp.type = 'range'; inp.min = it.min; inp.max = it.max; inp.step = it.step; inp.value = gfxVals[i];
    const val = document.createElement('span'); val.textContent = fmtG(it, gfxVals[i]);
    inp.oninput = () => {
      const v = parseFloat(inp.value);
      gfxVals[i] = v;
      engine.set_gfx(i, v);
      val.textContent = fmtG(it, v);
      scheduleSave();
    };
    row.append(lb, inp, val);
    body.appendChild(row);
  }
}
function openGfx(gid) {
  gfxGroup = gfxGroup === gid ? null : gid;
  if (gfxGroup !== null) { engine.select(-1); buildGfx(gfxGroup); }
  syncSelection();
}
$('gClose').onclick = () => { gfxGroup = null; syncSelection(); };
$('gfxReset').onclick = () => {
  if (gfxGroup === null) return;
  const g = GROUPS.find((x) => x.id === gfxGroup);
  for (const i of g.items) { gfxVals[i] = gfxDefs[i]; engine.set_gfx(i, gfxDefs[i]); }
  buildGfx(gfxGroup);
  scheduleSave();
};

/* ---------- выделение / панели ---------- */
function syncSelection() {
  const id = engine.selected();
  if (id >= 0) gfxGroup = null;
  document.querySelectorAll('#treeBody .row[data-id]').forEach((r) => r.classList.toggle('sel', +r.dataset.id === id));
  document.querySelectorAll('#treeBody .row[data-g]').forEach((r) => r.classList.toggle('sel', r.dataset.g === gfxGroup));
  const pOpen = id >= 0, gOpen = gfxGroup !== null;
  $('insp').classList.toggle('on', pOpen);
  $('gfxp').classList.toggle('on', gOpen);
  if (pOpen) { $('pTitle').textContent = engine.entity_name(id); fillProps(id); }
}
$('pDup').onclick = () => {
  if (!engine) return;
  const root = engine.selected();
  if (root < 0) return;
  const ids = Array.from(engine.entity_ids());
  const group = [root];
  for (let i = 0; i < group.length; i++) {
    for (const c of ids) if (engine.parent_of(c) === group[i] && !group.includes(c)) group.push(c);
  }
  const map = new Map();
  for (const old of group) {
    const pr = Array.from(engine.get_props(old));
    pr[0] += 1; pr[2] += 1;
    const nm = engine.entity_name(old);
    const base = nm.replace(/\s*\d+$/, '') || nm;
    map.set(old, engine.add_entity(uniqueName(base), new Float32Array(pr)));
  }
  for (const old of group) {
    const par = engine.parent_of(old);
    if (map.has(par)) engine.set_parent(map.get(old), map.get(par));
    else if (old === root && par >= 0) engine.set_parent(map.get(old), par);
  }
  buildTree();
  engine.select(map.get(root));
  syncSelection();
  scheduleSave();
};
$('pClose').onclick = () => { engine.select(-1); syncSelection(); };
$('camReset').onclick = () => engine.reset_camera();

/* ---------- управление: камера, выбор, гизмо ---------- */
const cv = $('c');
let lookP = null, gizmoP = null;
let mode = 0; // 0 выбор, 1 перемещение, 2 масштаб

function setMode(m) {
  mode = m;
  if (engine) engine.set_mode(m);
  document.querySelectorAll('#tools button[data-mode]').forEach((b) => b.classList.toggle('on', +b.dataset.mode === m));
}
document.querySelectorAll('#tools button[data-mode]').forEach((b) => { b.onclick = () => setMode(+b.dataset.mode); });
setMode(0);

let play = false, third = false;
function setPlay(on) {
  play = !!on;
  if (engine) {
    if (play) {
      if (editMode) closeEdit();
      rt = createRuntime(engine, {
        print: consolePrint,
        setStats: (s, j, z) => engine.set_player_stats(s, j, z),
      });
      rt.load(scriptText);
      objRts.length = 0;
      const ids = Array.from(engine.entity_ids());
      for (const [nm, txt] of Object.entries(objScripts)) {
        if (!txt || !String(txt).trim()) continue;
        const id = ids.find((x) => engine.entity_name(x) === nm);
        if (id === undefined) continue;
        const o = createRuntime(engine, { print: consolePrint, selfId: id });
        const er = o.load(txt);
        if (er) consolePrint(nm + '.hgs: ' + er);
        objRts.push({ nm, rt: o });
      }
    }
    engine.set_play(play);
    if (play) {
      engine.select(-1); gfxGroup = null; syncSelection();
      try { rt.start(); } catch (e) { consolePrint('script: ' + e); }
      for (const o of objRts) { try { o.rt.start(); } catch (e) { consolePrint(o.nm + ': ' + e); } }
    } else {
      if (rt) { rt.stop(); rt = null; }
      for (const o of objRts) { try { o.rt.stop(); } catch (e) { /* ok */ } }
      objRts.length = 0;
      third = false; engine.set_third(false);
    }
  }
  $('playBtn').classList.toggle('on', play);
  $('viewBtn').classList.toggle('hidden', !play);
  if (!play) $('viewBtn').classList.remove('on');
  document.querySelectorAll('#tools button[data-mode]').forEach((b) => b.classList.toggle('hidden', play));
  $('work').classList.toggle('playing', play);
}
$('playBtn').onclick = () => setPlay(!play);
$('viewBtn').onclick = () => {
  third = !third;
  if (engine) engine.set_third(third);
  $('viewBtn').classList.toggle('on', third);
};

const ndc = (e) => {
  const r = cv.getBoundingClientRect();
  return [((e.clientX - r.left) / r.width) * 2 - 1, 1 - ((e.clientY - r.top) / r.height) * 2];
};

cv.addEventListener('pointerdown', (e) => {
  if (lookP || gizmoP) return;
  if (e.pointerType === 'mouse' && e.button !== 0 && e.button !== 2) return;
  if (!play && !editMode && mode > 0 && e.button === 0 && engine && engine.selected() >= 0) {
    const [nx, ny] = ndc(e);
    if (engine.gizmo_begin(nx, ny)) {
      gizmoP = { id: e.pointerId };
      cv.setPointerCapture(e.pointerId);
      e.preventDefault();
      return;
    }
  }
  lookP = { id: e.pointerId, x: e.clientX, y: e.clientY, t: performance.now(), moved: 0, btn: e.button };
  cv.setPointerCapture(e.pointerId);
  e.preventDefault();
});
cv.addEventListener('pointermove', (e) => {
  if (editMode && engine && !play) {
    const [nx, ny] = ndc(e);
    engine.set_edit_hover(engine.pick_cell(nx, ny));
    return;
  }
  if (gizmoP && e.pointerId === gizmoP.id) {
    const [nx, ny] = ndc(e);
    if (engine.gizmo_drag(nx, ny)) { fillProps(engine.selected()); scheduleSave(); }
    return;
  }
  if (!lookP || e.pointerId !== lookP.id) return;
  const dx = e.clientX - lookP.x, dy = e.clientY - lookP.y;
  lookP.x = e.clientX; lookP.y = e.clientY;
  lookP.moved += Math.abs(dx) + Math.abs(dy);
  if (e.pointerType !== 'mouse' || (e.buttons & 2)) engine.look(dx, dy);
});
const endGizmo = (e) => {
  if (!gizmoP || e.pointerId !== gizmoP.id) return false;
  engine.gizmo_end();
  gizmoP = null;
  return true;
};
cv.addEventListener('pointerup', (e) => {
  if (endGizmo(e)) return;
  if (!lookP || e.pointerId !== lookP.id) return;
  const p = lookP; lookP = null;
  if (p.btn === 0 && p.moved < 10 && performance.now() - p.t < 500) {
    const [nx, ny] = ndc(e);
    if (!play && editMode) {
      const cell = engine.pick_cell(nx, ny);
      if (cell >= 0) { pushHist(engine.edit_id()); engine.edit_toggle(engine.edit_id(), cell); scheduleSave(); }
    } else if (!play) engine.pick(nx, ny);
    syncSelection();
  }
});
cv.addEventListener('pointercancel', (e) => { endGizmo(e); lookP = null; });
cv.addEventListener('contextmenu', (e) => e.preventDefault());

/* ---------- управление: джойстики и клавиатура ---------- */
const joy = { x: 0, z: 0, y: 0 };
const kb = { x: 0, z: 0, y: 0 };
function pushMove() {
  if (engine) engine.set_move(clamp(joy.x + kb.x), clamp(joy.z + kb.z), clamp(joy.y + kb.y));
}

function makeJoy(el, onChange, lockX = false) {
  const knob = el.querySelector('.knob');
  let pid = null;
  const upd = (e) => {
    const r = el.getBoundingClientRect();
    let dx = e.clientX - (r.left + r.width / 2);
    let dy = e.clientY - (r.top + r.height / 2);
    if (lockX) dx = 0;
    const max = (lockX ? r.height : r.width) / 2 - 20;
    const len = Math.hypot(dx, dy);
    if (len > max) { dx *= max / len; dy *= max / len; }
    knob.style.transform = `translate(${dx}px,${dy}px)`;
    onChange(dx / max, dy / max);
  };
  const end = (e) => {
    if (e.pointerId !== pid) return;
    pid = null;
    knob.style.transform = '';
    onChange(0, 0);
  };
  el.addEventListener('pointerdown', (e) => {
    if (pid !== null) return;
    pid = e.pointerId;
    el.setPointerCapture(pid);
    upd(e);
    e.preventDefault();
  });
  el.addEventListener('pointermove', (e) => { if (e.pointerId === pid) upd(e); });
  el.addEventListener('pointerup', end);
  el.addEventListener('pointercancel', end);
  el.addEventListener('lostpointercapture', end);
}
makeJoy($('joyL'), (x, y) => { joy.x = x; joy.z = -y; pushMove(); });
makeJoy($('joyR'), (x, y) => { joy.y = -y; pushMove(); }, true);

const keys = new Set();
function updKeys() {
  const k = (c) => (keys.has(c) ? 1 : 0);
  kb.x = k('KeyD') - k('KeyA');
  kb.z = k('KeyW') - k('KeyS');
  kb.y = Math.max(k('Space'), k('KeyE')) - Math.max(k('ShiftLeft'), k('KeyQ'));
  pushMove();
}
addEventListener('keydown', (e) => {
  if (!cur || e.target.tagName === 'INPUT') return;
  if (e.code === 'Space') e.preventDefault();
  keys.add(e.code); updKeys();
});
addEventListener('keyup', (e) => { keys.delete(e.code); updKeys(); });
addEventListener('blur', () => { keys.clear(); updKeys(); });

/* ================= старт ================= */
applyDom();
renderProjects();

/* ================= ПОЛНОЭКРАННЫЙ РЕДАКТОР КОДА HGS ================= */
const ceArea = $('ceArea');
const ceHigh = $('ceHigh');
const ceGutter = $('ceGutter');

function escH(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

function hlSrc(src) {
  let out = '';
  let i = 0;
  const n = src.length;
  while (i < n) {
    const c = src[i];
    if (c === '#') { let j = i; while (j < n && src[j] !== '\n') j++; out += `<span class="com">${escH(src.slice(i, j))}</span>`; i = j; continue; }
    if (c === '"') { let j = i + 1; while (j < n && src[j] !== '"') { if (src[j] === '\\') j++; j++; } out += `<span class="str">${escH(src.slice(i, Math.min(j + 1, n)))}</span>`; i = j + 1; continue; }
    if (c === '[') { let j = i + 1; let d = 1; while (j < n && d > 0) { if (src[j] === '[') d++; else if (src[j] === ']') d--; if (src[j] === '\n') break; j++; } out += `<span class="var">${escH(src.slice(i, j))}</span>`; i = j; continue; }
    if (c === '@') { let j = i; while (j < n && /[\wА-Яа-яЁё.@]/.test(src[j])) j++; out += `<span class="sec">${escH(src.slice(i, j))}</span>`; i = j; continue; }
    if (/[A-Za-zА-Яа-яЁё_]/.test(c)) {
      let j = i; while (j < n && /[\wА-Яа-яЁё.]/.test(src[j])) j++;
      const w = src.slice(i, j);
      let cls = '';
      if (w === 'if' || w === 'else' || w === 'WTD' || w === 'break' || w === 'end') cls = 'kw';
      else if (w.includes('.') || w === 'Text') cls = 'fn';
      out += cls ? `<span class="${cls}">${escH(w)}</span>` : escH(w);
      i = j; continue;
    }
    if (/[0-9]/.test(c)) { let j = i; while (j < n && /[0-9.]/.test(src[j])) j++; out += `<span class="num">${escH(src.slice(i, j))}</span>`; i = j; continue; }
    if ('+-*/=<>!'.includes(c)) { out += `<span class="op">${escH(c)}</span>`; i++; continue; }
    if ('(){},'.includes(c)) { out += `<span class="br">${escH(c)}</span>`; i++; continue; }
    out += escH(c); i++;
  }
  return out;
}

let ceErrs = [];
function ceRefresh() {
  const src = ceArea.value;
  ceHigh.innerHTML = hlSrc(src) + '\n';
  const lines = src.split('\n');
  ceGutter.innerHTML = lines.map((_, i) => {
    const bad = ceErrs.some((e) => e.line === i + 1);
    return `<div${bad ? ' style="color:#ff7b72;font-weight:700"' : ''}>${i + 1}</div>`;
  }).join('');
  $('ceStat').textContent = `${lines.length} строк · ${src.length} симв.`;
  ceArea.style.height = 'auto';
  ceArea.style.height = Math.max(ceArea.scrollHeight, 200) + 'px';
}

function ceLint() {
  try {
    ceErrs = lintHgs(ceArea.value) || [];
  } catch (e) {
    ceErrs = [{ line: 1, msg: String(e) }];
  }
  const box = $('ceErrors');
  if (!ceErrs.length) {
    box.innerHTML = '<div class="ok">✓ Ошибок не найдено</div>';
  } else {
    box.innerHTML = ceErrs.map((e, i) => `<div class="er" data-i="${i}">Строка ${e.line}: ${escH(e.msg)}</div>`).join('');
    box.querySelectorAll('.er').forEach((el) => {
      el.onclick = () => {
        const er = ceErrs[+el.dataset.i];
        ceGotoLine(er.line);
      };
    });
  }
  ceRefresh();
}

function ceGotoLine(line) {
  const src = ceArea.value.split('\n');
  let pos = 0;
  for (let i = 0; i < Math.min(line - 1, src.length); i++) pos += src[i].length + 1;
  ceArea.focus();
  ceArea.setSelectionRange(pos, pos + (src[line - 1] || '').length);
}

function ceSave(run) {
  const v = ceArea.value;
  if (ceCtx && ceCtx.kind === 'player') scriptText = v;
  else if (ceCtx) objScripts[ceCtx.name] = v;
  scheduleSave();
  if (run) {
    if (play) setPlay(false);
    setPlay(true);
  }
}

function openScriptFor(kind, name) {
  ceCtx = { kind, name: name || '' };
  ceArea.value = kind === 'player' ? scriptText : (objScripts[name] !== undefined ? objScripts[name] : DEFAULT_OBJ_SCRIPT);
  $('ceTitle').textContent = kind === 'player' ? '📜 player.hgs' : `📜 ${name}.hgs`;
  ceErrs = [];
  $('ceErrors').innerHTML = '';
  $('codeEditor').classList.remove('hidden');
  ceRefresh();
}
window.openScriptFor = openScriptFor;

$('ceClose').onclick = () => { $('codeEditor').classList.add('hidden'); $('ceAC').classList.add('hidden'); };
$('ceRun').onclick = () => ceSave(true);
$('ceLint').onclick = ceLint;
$('ceFmt').onclick = () => {
  try {
    ceArea.value = fmtHgs(ceArea.value);
    ceRefresh();
    $('ceErrors').innerHTML = '<div class="ok">✓ Отформатировано</div>';
  } catch (e) {
    $('ceErrors').innerHTML = `<div class="er">${escH(String(e))}</div>`;
  }
};

/* поиск */
function ceFindOpen() { $('ceFind').classList.remove('hidden'); $('ceFindIn').focus(); ceFindCount(); }
function ceFindClose() { $('ceFind').classList.add('hidden'); ceArea.focus(); }
function ceMatches() {
  const q = $('ceFindIn').value;
  if (!q) return [];
  const src = ceArea.value.toLowerCase();
  const qq = q.toLowerCase();
  const out = [];
  let i = 0;
  while ((i = src.indexOf(qq, i)) >= 0) { out.push(i); i += Math.max(1, qq.length); }
  return out;
}
function ceFindCount() {
  const ms = ceMatches();
  $('ceFindN').textContent = ms.length ? `1/${ms.length}` : '0/0';
  return ms;
}
function ceFindGo(dir) {
  const ms = ceMatches();
  if (!ms.length) return;
  const cur = ceArea.selectionStart;
  let idx = ms.findIndex((m) => m > cur);
  if (dir < 0) idx = idx <= 0 ? ms.length - 1 : idx - 1;
  if (idx < 0) idx = 0;
  const pos = ms[idx];
  ceArea.focus();
  ceArea.setSelectionRange(pos, pos + $('ceFindIn').value.length);
  $('ceFindN').textContent = `${idx + 1}/${ms.length}`;
}
$('ceFindBtn').onclick = ceFindOpen;
$('ceFindClose').onclick = ceFindClose;
$('ceFindNext').onclick = () => ceFindGo(1);
$('ceFindPrev').onclick = () => ceFindGo(-1);
$('ceFindIn').addEventListener('input', ceFindCount);
$('ceFindIn').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') { e.preventDefault(); ceFindGo(e.shiftKey ? -1 : 1); }
  if (e.key === 'Escape') ceFindClose();
});

/* подсказки (автодополнение) */
const CE_SNIPPETS = [
  ['@E.OnStart()', 'событие старта'],
  ['@E.OnUpdate(dt)', 'каждый кадр'],
  ['@E.End()', 'конец события'],
  ['@L.', 'переменная'],
  ['@P.Speed', 'скорость игрока'],
  ['@P.Jump', 'сила прыжка'],
  ['@P.Size', 'размер игрока'],
  ['@W.', 'объект мира'],
  ['@F.name(a)=', 'функция'],
  ['Text.pr()', 'печать в консоль'],
  ['WTD {', 'цикл'],
  ['break WTD', 'выход из цикла'],
  ['[if {', 'условие if/else'],
  ['[Var]', 'подстановка переменной'],
  ['[Name.dist]', 'дистанция до объекта'],
  ['Self.pos', 'позиция объекта'],
  ['Self.size', 'размер объекта'],
  ['Self.name', 'имя объекта'],
  ['@W.Destroy(obj: ', 'удалить объект'],
];
let ceACSel = 0;
function ceACOpen() {
  const box = $('ceAC');
  const pos = ceArea.selectionStart;
  const before = ceArea.value.slice(0, pos);
  const word = (before.match(/[@\wА-Яа-яЁё._\[]+$/) || [''])[0];
  const items = CE_SNIPPETS.filter(([s]) => !word || s.toLowerCase().includes(word.toLowerCase().replace(/^\[/, '')));
  if (!items.length) { box.classList.add('hidden'); return; }
  ceACSel = 0;
  box.innerHTML = items.map((it, i) => `<div class="ai${i === 0 ? ' sel' : ''}" data-i="${i}"><span>${escH(it[0])}</span><span class="d">${escH(it[1])}</span></div>`).join('');
  const r = ceArea.getBoundingClientRect();
  const lines = before.split('\n');
  const lh = 19.5;
  box.style.left = Math.min(r.left + 14 + (lines[lines.length - 1].length * 7.4), r.right - 210) + 'px';
  box.style.top = (r.top + 10 + lines.length * lh + 24) + 'px';
  box.classList.remove('hidden');
  box.querySelectorAll('.ai').forEach((el) => {
    el.onclick = () => ceACApply(items[+el.dataset.i][0], word);
  });
}
function ceACApply(snip, word) {
  const pos = ceArea.selectionStart;
  const before = ceArea.value.slice(0, pos);
  const after = ceArea.value.slice(pos);
  const start = before.length - word.length;
  let ins = snip;
  if (snip.endsWith('(')) ins += ')';
  if (snip.endsWith('{')) ins += ' }';
  if (snip.endsWith('[')) ins += ']';
  ceArea.value = before.slice(0, start) + ins + after;
  const np = start + ins.length - (ins.endsWith(' )') || ins.endsWith(' }') ? 2 : ins.endsWith(']') ? 1 : 0);
  ceArea.setSelectionRange(np, np);
  $('ceAC').classList.add('hidden');
  ceRefresh();
}
function ceACHide() { $('ceAC').classList.add('hidden'); }

/* события редактора */
ceArea.addEventListener('input', () => { ceRefresh(); ceACHide(); });
ceArea.addEventListener('scroll', ceRefresh);
$('ceCode').addEventListener('scroll', () => {
  ceGutter.scrollTop = $('ceCode').scrollTop;
});
ceArea.addEventListener('keydown', (e) => {
  if (e.key === 'Tab') {
    e.preventDefault();
    const p = ceArea.selectionStart;
    ceArea.value = ceArea.value.slice(0, p) + '  ' + ceArea.value.slice(ceArea.selectionEnd);
    ceArea.setSelectionRange(p + 2, p + 2);
    ceRefresh();
    return;
  }
  if (e.key === 'Enter' && e.ctrlKey) { e.preventDefault(); ceLint(); return; }
  if (e.key === ' ' && e.ctrlKey) { e.preventDefault(); ceACOpen(); return; }
  if (e.key === 'f' && e.ctrlKey) { e.preventDefault(); ceFindOpen(); return; }
  if (e.key === 's' && e.ctrlKey) { e.preventDefault(); ceSave(false); $('ceErrors').innerHTML = '<div class="ok">✓ Сохранено</div>'; return; }
  if (e.key === 'Escape') {
    if (!$('ceAC').classList.contains('hidden')) { ceACHide(); return; }
    if (!$('ceFind').classList.contains('hidden')) { ceFindClose(); return; }
    $('codeEditor').classList.add('hidden');
    return;
  }
  if (!$('ceAC').classList.contains('hidden')) {
    const items = $('ceAC').querySelectorAll('.ai');
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      ceACSel = (ceACSel + (e.key === 'ArrowDown' ? 1 : items.length - 1)) % items.length;
      items.forEach((el, i) => el.classList.toggle('sel', i === ceACSel));
      return;
    }
    if (e.key === 'Enter') {
      e.preventDefault();
      const el = items[ceACSel];
      if (el) el.onclick();
      return;
    }
    if (e.key === 'Escape') { ceACHide(); return; }
  }
  if (e.key === 'Enter') {
    // умный отступ
    const p = ceArea.selectionStart;
    const before = ceArea.value.slice(0, p);
    const line = before.slice(before.lastIndexOf('\n') + 1);
    const ind = (line.match(/^ */) || [''])[0].length + (line.trimEnd().endsWith('{') ? 2 : 0);
    if (ind > 0) {
      e.preventDefault();
      ceArea.value = before + '\n' + ' '.repeat(ind) + ceArea.value.slice(p);
      ceArea.setSelectionRange(p + 1 + ind, p + 1 + ind);
      ceRefresh();
    }
  }
});
