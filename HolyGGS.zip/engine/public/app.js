import init, { Engine, run_self_test, version, gfx_defaults } from './pkg/engine.js';
import { t, getLang, setLang, applyDom } from './i18n.js';

const $ = (id) => document.getElementById(id);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const clamp = (v) => Math.max(-1, Math.min(1, v));

/* ================= хранилище ================= */
const store = {
  projects() { try { return JSON.parse(localStorage.getItem('eng.projects') || '[]'); } catch { return []; } },
  saveProjects(p) { try { localStorage.setItem('eng.projects', JSON.stringify(p)); } catch (e) { alert(t('saveFail', e)); } },
  scene(id) { try { return JSON.parse(localStorage.getItem('eng.scene.' + id) || 'null'); } catch { return null; } },
  saveScene(id, s) { try { localStorage.setItem('eng.scene.' + id, JSON.stringify(s)); } catch (e) { console.warn(e); } },
  delScene(id) { localStorage.removeItem('eng.scene.' + id); },
};

/* ================= схема настроек графики (индексы = как в Rust) ================= */
const GFX = [
  { k: 'g_time', min: 0, max: 24, step: 0.05, fmt: 'time' }, // 0
  { k: 'g_contrast', min: 0.5, max: 2, step: 0.01 },         // 1
  { k: 'g_exposure', min: 0.3, max: 2.5, step: 0.01 },       // 2
  { k: 'g_sat', min: 0, max: 2, step: 0.01 },                // 3
  { k: 'g_rays', min: 0, max: 2, step: 0.01 },               // 4
  { k: 'g_neon', min: 0, max: 8, step: 0.1 },                // 5
  { k: 'g_bloom', min: 0, max: 2, step: 0.01 },              // 6
  { k: 'g_bthr', min: 0, max: 3, step: 0.01 },               // 7
  { k: 'g_fogd', min: 0, max: 0.1, step: 0.001 },            // 8
  { k: 'g_fogs', min: 0, max: 300, step: 1 },                // 9
  { k: 'g_skyb', min: 0.2, max: 2, step: 0.01 },             // 10
  { k: 'g_sun', min: 0.3, max: 4, step: 0.05 },              // 11
  { k: 'g_vig', min: 0, max: 1, step: 0.01 },                // 12
  { k: 'g_amb', min: 0, max: 2, step: 0.01 },
  { k: 'g_shadow', min: 0, max: 1, step: 0.01 },
  { k: 'g_nlight', min: 0, max: 3, step: 0.01 },
  { k: 'g_waveh', min: 0, max: 2, step: 0.01 },   // 16
  { k: 'g_waves', min: 0, max: 3, step: 0.01 },   // 17
  { k: 'g_bump', min: 0, max: 3, step: 0.01 },    // 18
  { k: 'g_fov', min: 30, max: 110, step: 1 },     // 19
  { k: 'g_sens', min: 0.2, max: 3, step: 0.01 },
  { k: 'g_fogn', min: 0, max: 2, step: 0.01 },   // 21
  { k: 'g_mie', min: 0, max: 3, step: 0.01 },    // 22
  { k: 'g_texq', min: 0, max: 2, step: 1, fmt: 'qual' }, // 23
  { k: 'g_shq', min: 0, max: 2, step: 1, fmt: 'qual' },  // 24
  { k: 'g_wq', min: 0, max: 2, step: 1, fmt: 'qual' },   // 25
];
const GROUPS = [
  { id: 'time', icon: '☀', k: 'grp_time', items: [0, 10, 11, 13, 14] },
  { id: 'fx', icon: '✦', k: 'grp_fx', items: [4, 6, 7, 5, 15, 12, 18] },
  { id: 'col', icon: '◑', k: 'grp_col', items: [2, 1, 3] },
  { id: 'fog', icon: '☁', k: 'grp_fog', items: [8, 9, 21, 22] },
  { id: 'wat', icon: '≈', k: 'grp_water', items: [16, 17] },
  { id: 'cam', icon: '◉', k: 'grp_cam', items: [19, 20] },
  { id: 'q', icon: '⚙', k: 'grp_qual', items: [23, 24, 25] },
];

/* ================= wasm ================= */
let wasmErr = null;
let verText = 'Engine';
const setVer = () => { $('ver').textContent = verText; };
const wasmReady = init().then(() => true).catch((e) => { wasmErr = e; return false; });
wasmReady.then((ok) => { if (ok) { verText = 'Engine core v' + version(); setVer(); } });

/* ================= список проектов ================= */
function renderProjects() {
  const list = store.projects();
  const box = $('projects');
  box.innerHTML = '';
  $('empty').classList.toggle('hidden', list.length > 0);
  for (const p of list) {
    const c = document.createElement('div'); c.className = 'card';
    const ico = document.createElement('div'); ico.className = 'ico';
    if (p.icon) ico.style.backgroundImage = `url(${p.icon})`; else ico.textContent = (p.name[0] || '?').toUpperCase();
    const nm = document.createElement('div'); nm.className = 'nm'; nm.textContent = p.name;
    const dt = document.createElement('div'); dt.className = 'dt'; dt.textContent = new Date(p.created).toLocaleDateString(getLang() === 'ru' ? 'ru-RU' : 'en-US');
    c.append(ico, nm, dt);

    let timer = 0, long = false;
    c.addEventListener('pointerdown', () => {
      long = false;
      timer = setTimeout(() => {
        long = true;
        if (confirm(t('confirmDel', p.name))) {
          store.saveProjects(store.projects().filter((x) => x.id !== p.id));
          store.delScene(p.id);
          renderProjects();
        }
      }, 650);
    });
    const cancel = () => clearTimeout(timer);
    c.addEventListener('pointerup', cancel);
    c.addEventListener('pointerleave', cancel);
    c.addEventListener('pointercancel', cancel);
    c.addEventListener('click', () => { if (!long) openProject(p); });
    box.appendChild(c);
  }
}

/* ================= настройки ================= */
function updSeg() {
  document.querySelectorAll('.seg button').forEach((b) => b.classList.toggle('on', b.dataset.lang === getLang()));
}
$('settingsBtn').onclick = () => { updSeg(); $('setBg').classList.remove('hidden'); };
$('setClose').onclick = () => $('setBg').classList.add('hidden');
$('setBg').addEventListener('click', (e) => { if (e.target === $('setBg')) $('setBg').classList.add('hidden'); });
document.querySelectorAll('.seg button').forEach((b) => {
  b.onclick = () => { setLang(b.dataset.lang); updSeg(); setVer(); renderProjects(); };
});

/* ================= шторка: проверки -> форма ================= */
let runId = 0;
let fullLog = [];
let newIcon = null;

const openSheet = () => { $('shade').classList.add('on'); $('sheet').classList.add('on'); };
const closeSheet = () => { runId++; $('shade').classList.remove('on'); $('sheet').classList.remove('on'); };

function logLine(level, msg) {
  const tag = { ok: '[ OK ] ', warn: '[WARN] ', fail: '[FAIL] ', info: '[ .. ] ' }[level] || '';
  const d = document.createElement('div');
  d.className = 'l ' + level;
  d.textContent = tag + msg;
  $('log').appendChild(d);
  $('log').scrollTop = $('log').scrollHeight;
  fullLog.push(tag + msg);
}

async function runChecks(token) {
  let ok = true;
  const L = async (level, msg) => {
    if (token !== runId) throw new Error('cancel');
    if (level === 'fail') ok = false;
    logLine(level, msg);
    await sleep(110);
  };

  await L('info', t('log_start'));
  await L(typeof WebAssembly === 'object' ? 'ok' : 'fail', 'WebAssembly');

  if (!(await wasmReady)) {
    await L('fail', t('log_core_fail', wasmErr));
    return false;
  }
  await L('ok', t('log_core_ok', version()));

  for (const line of run_self_test(getLang() === 'en').split('\n')) {
    const m = line.match(/^(OK|WARN|FAIL) (.*)$/);
    if (m) await L(m[1].toLowerCase(), m[2]); else if (line) await L('info', line);
  }

  try {
    const cv = document.createElement('canvas');
    const gl = cv.getContext('webgl2');
    if (!gl) throw new Error('webgl2 unavailable');
    const dbg = gl.getExtension('WEBGL_debug_renderer_info');
    const gpu = dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : '?';
    await L('ok', t('log_webgl', gpu));
    await L('ok', t('log_tex', gl.getParameter(gl.MAX_TEXTURE_SIZE)));
    const hdr = !!(gl.getExtension('EXT_color_buffer_float') || gl.getExtension('EXT_color_buffer_half_float'));
    await L(hdr ? 'ok' : 'warn', 'HDR: ' + (hdr ? 'on' : 'off (LDR fallback)'));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
  } catch (e) {
    await L('fail', t('log_webgl_fail', e.message));
  }

  try {
    localStorage.setItem('eng.test', '1');
    if (localStorage.getItem('eng.test') !== '1') throw new Error('read mismatch');
    localStorage.removeItem('eng.test');
    await L('ok', t('log_store_ok'));
  } catch (e) {
    await L('fail', t('log_store_fail', e.message));
  }

  const thr = self.crossOriginIsolated && typeof SharedArrayBuffer !== 'undefined';
  await L(thr ? 'ok' : 'warn', t('log_threads', t(thr ? 'thr_yes' : 'thr_no')));
  await L('info', t('log_physics'));
  await L(ok ? 'ok' : 'fail', t(ok ? 'log_all_ok' : 'log_some_fail'));
  return ok;
}

async function startNew() {
  const token = ++runId;
  fullLog = [];
  newIcon = null;
  $('log').innerHTML = '';
  $('ldTitle').textContent = 'Loading. . .';
  $('cubes').classList.remove('stop');
  $('ldBtns').classList.add('hidden');
  $('copyLog').textContent = t('copyLog');
  $('ld').classList.remove('hidden');
  $('form').classList.add('hidden');
  $('iconBtn').style.backgroundImage = '';
  $('iconBtn').classList.remove('has');
  $('nameIn').value = '';
  openSheet();

  let ok = false;
  try {
    const t0 = performance.now();
    ok = await runChecks(token);
    const left = 1400 - (performance.now() - t0);
    if (left > 0) await sleep(left);
  } catch (e) {
    if (token !== runId) return;
    logLine('fail', t('log_exc', e));
  }
  if (token !== runId) return;

  if (ok) {
    $('ld').classList.add('hidden');
    $('form').classList.remove('hidden');
  } else {
    $('ldTitle').textContent = t('checkFail');
    $('cubes').classList.add('stop');
    $('ldBtns').classList.remove('hidden');
  }
}

$('plus').onclick = startNew;
$('shade').onclick = closeSheet;
$('closeLd').onclick = closeSheet;
$('copyLog').onclick = async () => {
  const txt = fullLog.join('\n');
  try { await navigator.clipboard.writeText(txt); $('copyLog').textContent = t('copied'); }
  catch { alert(txt); }
};

function toIcon(file) {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const s = 192, c = document.createElement('canvas');
      c.width = c.height = s;
      const m = Math.min(img.width, img.height);
      c.getContext('2d').drawImage(img, (img.width - m) / 2, (img.height - m) / 2, m, m, 0, 0, s, s);
      URL.revokeObjectURL(url);
      res(c.toDataURL('image/jpeg', 0.85));
    };
    img.onerror = rej;
    img.src = url;
  });
}
$('iconBtn').onclick = () => $('file').click();
$('file').onchange = async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  try {
    newIcon = await toIcon(f);
    $('iconBtn').style.backgroundImage = `url(${newIcon})`;
    $('iconBtn').classList.add('has');
  } catch { alert(t('imgFail')); }
  e.target.value = '';
};

$('create').onclick = () => {
  const p = {
    id: Date.now().toString(36),
    name: $('nameIn').value.trim() || t('newProject'),
    icon: newIcon,
    created: Date.now(),
  };
  store.saveProjects([p, ...store.projects()]);
  closeSheet();
  renderProjects();
  openProject(p);
};

/* ================= воркспейс ================= */
let engine = null, cur = null, raf = 0, lastT = 0, saveTimer = 0;
let frames = 0, fpsAcc = 0;
let gfxDefs = [], gfxVals = [], gfxGroup = null;

const PLATE_COLOR = [0.62, 0.62, 0.64];
const defaultPlate = () => ({
  name: t('plate'),
  props: [0, -0.5, 0, 0, 0, 0, 40, 1, 40, ...PLATE_COLOR, 0],
});

async function lockLandscape() {
  if (!matchMedia('(pointer:coarse)').matches) return;
  try { if (!document.fullscreenElement) await document.documentElement.requestFullscreen(); } catch {}
  try { await screen.orientation.lock('landscape'); } catch {}
}
function unlockOrientation() {
  try { screen.orientation.unlock(); } catch {}
  try { if (document.fullscreenElement) document.exitFullscreen(); } catch {}
}

async function openProject(p) {
  cur = p;
  $('menu').classList.add('hidden');
  $('work').classList.remove('hidden');
  document.body.classList.add('work-on');
  $('projName').textContent = p.name;
  await lockLandscape();

  if (!(await wasmReady)) { alert(t('coreNotLoaded', wasmErr)); backToMenu(); return; }
  if (!engine) {
    try { engine = new Engine('c'); }
    catch (e) { alert(t('engineFail', e)); backToMenu(); return; }
  }
  gfxDefs = Array.from(gfx_defaults());
  engine.set_mode(mode);
  setPlay(false);
  resizeCanvas();
  loadScene(p.id);
  buildTree();
  syncSelection();
  lastT = performance.now();
  cancelAnimationFrame(raf);
  raf = requestAnimationFrame(loop);
}

function backToMenu() {
  setPlay(false);
  cancelAnimationFrame(raf);
  flushSave();
  if (engine) engine.set_move(0, 0, 0);
  joy.x = joy.z = joy.y = 0;
  $('work').classList.add('hidden');
  $('menu').classList.remove('hidden');
  document.body.classList.remove('work-on');
  unlockOrientation();
  cur = null;
  renderProjects();
}
$('back').onclick = backToMenu;

function loop(ts) {
  const dt = Math.min((ts - lastT) / 1000, 0.1);
  lastT = ts;
  engine.frame(dt);
  frames++; fpsAcc += dt;
  if (fpsAcc >= 0.5) {
    $('fps').textContent = 'FPS ' + Math.round(frames / fpsAcc) + (engine.hdr() ? ' · HDR' : '');
    frames = 0; fpsAcc = 0;
  }
  raf = requestAnimationFrame(loop);
}

function resizeCanvas() {
  if (!engine) return;
  const v = $('view');
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  engine.resize(Math.max(1, Math.floor(v.clientWidth * dpr)), Math.max(1, Math.floor(v.clientHeight * dpr)));
}
new ResizeObserver(resizeCanvas).observe($('view'));

/* ---------- сцена ---------- */
function loadScene(id) {
  engine.clear();
  const s = store.scene(id);
  const ents = s && Array.isArray(s.entities) && s.entities.length ? s.entities : [defaultPlate()];
  if (s && (s.v || 1) < 2) {
    // миграция: старая зелёная плита -> серая
    for (const e of ents) {
      const p = e.props;
      if (p && Math.abs(p[9] - 0.45) < 0.01 && Math.abs(p[10] - 0.70) < 0.01 && Math.abs(p[11] - 0.40) < 0.01) {
        p[9] = PLATE_COLOR[0]; p[10] = PLATE_COLOR[1]; p[11] = PLATE_COLOR[2];
      }
    }
  }
  const newIds = ents.map((e) => engine.add_entity(e.name, new Float32Array(e.props)));
  ents.forEach((e, i) => {
    if (Number.isInteger(e.parent) && e.parent >= 0 && e.parent < newIds.length && e.parent !== i) {
      engine.set_parent(newIds[i], newIds[e.parent]);
    }
  });
  gfxVals = gfxDefs.map((d, i) => (s && Array.isArray(s.gfx) && Number.isFinite(s.gfx[i]) ? s.gfx[i] : d));
  gfxVals.forEach((v, i) => engine.set_gfx(i, v));
  gfxGroup = null;
  engine.reset_camera();
}
function collectScene() {
  const ids = Array.from(engine.entity_ids());
  const entities = ids.map((id) => ({
    name: engine.entity_name(id),
    props: Array.from(engine.get_props(id)),
    parent: ids.indexOf(engine.parent_of(id)),
  }));
  return { v: 2, entities, gfx: gfxVals.slice() };
}
function flushSave() {
  clearTimeout(saveTimer);
  if (cur && engine) store.saveScene(cur.id, collectScene());
}
const scheduleSave = () => { clearTimeout(saveTimer); saveTimer = setTimeout(flushSave, 500); };
document.addEventListener('visibilitychange', () => { if (document.hidden) flushSave(); });
addEventListener('pagehide', flushSave);

/* ---------- дерево ---------- */
function blockIcon() {
  const img = new Image();
  img.src = 'blockicon.png';
  img.className = 'bico';
  img.alt = '';
  img.draggable = false;
  img.onerror = () => img.replaceWith(document.createTextNode('■'));
  return img;
}
function kindOf(id) {
  const p = engine.get_props(id);
  return p[15] > 0.5 ? 'fire' : p[14] > 0.5 ? 'water' : 'block';
}
function entIcon(id) {
  const k = kindOf(id);
  return k === 'fire' ? '🔥' : k === 'water' ? '≈' : blockIcon();
}
function mkRow(icon, name, sub, depth, plusFor) {
  const r = document.createElement('div');
  r.className = 'row';
  r.style.paddingLeft = 10 + depth * 14 + 'px';
  const i = document.createElement('span'); i.className = 'ri';
  if (typeof icon === 'string') i.textContent = icon; else i.appendChild(icon);
  const n = document.createElement('span'); n.className = 'rn'; n.textContent = name;
  r.append(i, n);
  if (sub) { const sm = document.createElement('small'); sm.textContent = sub; r.append(sm); }
  if (plusFor !== undefined) {
    const b = document.createElement('button');
    b.className = 'rowplus'; b.textContent = '+'; b.setAttribute('aria-label', 'Add');
    b.onclick = (e) => { e.stopPropagation(); openSpawnMenu(b, plusFor); };
    r.append(b);
  }
  return r;
}
function folder(label, sub, depth, plusFor, build) {
  const root = mkRow('▾', label, sub, depth, plusFor);
  const kids = document.createElement('div');
  build(kids);
  root.onclick = () => {
    kids.classList.toggle('hidden');
    root.firstChild.textContent = kids.classList.contains('hidden') ? '▸' : '▾';
  };
  return [root, kids];
}
function buildTree() {
  const tb = $('treeBody');
  tb.innerHTML = '';
  const ids = Array.from(engine.entity_ids());
  const byParent = new Map();
  for (const id of ids) {
    let par = engine.parent_of(id);
    if (!ids.includes(par)) par = -1;
    if (!byParent.has(par)) byParent.set(par, []);
    byParent.get(par).push(id);
  }
  const add = (box, parent, depth) => {
    for (const id of byParent.get(parent) || []) {
      const r = mkRow(entIcon(id), engine.entity_name(id), '', depth, id);
      r.dataset.id = id;
      r.onclick = () => { engine.select(id); syncSelection(); };
      box.appendChild(r);
      add(box, id, depth + 1);
    }
  };
  tb.append(...folder('@W', 'Workspace', 0, -1, (box) => add(box, -1, 1)));
  tb.append(...folder('@A', t('graphics'), 0, undefined, (box) => {
    for (const g of GROUPS) {
      const r = mkRow(g.icon, t(g.k), '', 1);
      r.dataset.g = g.id;
      r.onclick = () => openGfx(g.id);
      box.appendChild(r);
    }
  }));
}

/* ---------- мини-меню "+" ---------- */
let menuEl = null;
function closeSpawnMenu() { if (menuEl) { menuEl.remove(); menuEl = null; } }
addEventListener('pointerdown', (e) => {
  if (menuEl && !menuEl.contains(e.target) && !(e.target.classList && e.target.classList.contains('rowplus'))) closeSpawnMenu();
}, true);
function openSpawnMenu(anchor, parentId) {
  closeSpawnMenu();
  const m = document.createElement('div');
  m.id = 'spawnMenu';
  for (const [kind, ico] of [['block', '■'], ['water', '≈'], ['fire', '🔥']]) {
    const b = document.createElement('button');
    const i = document.createElement('span'); i.className = 'mi'; i.textContent = ico;
    const n = document.createElement('span'); n.textContent = t(kind);
    b.append(i, n);
    b.onclick = () => { closeSpawnMenu(); spawn(kind, parentId); };
    m.appendChild(b);
  }
  document.body.appendChild(m);
  const r = anchor.getBoundingClientRect();
  m.style.left = Math.max(8, r.left - m.offsetWidth - 6) + 'px';
  m.style.top = Math.max(8, Math.min(r.top, innerHeight - m.offsetHeight - 8)) + 'px';
  menuEl = m;
}

function spawn(kind, parentId) {
  if (!engine) return;
  const ids = Array.from(engine.entity_ids());
  const par = ids.includes(parentId) ? engine.get_props(parentId) : null;
  const size = kind === 'block' ? [4, 4, 4] : kind === 'water' ? [16, 2, 16] : [1.6, 2.8, 1.6];
  const color = kind === 'block' ? [0.30, 0.62, 0.95] : kind === 'water' ? [0.05, 0.28, 0.38] : [1.0, 0.5, 0.12];
  const alpha = kind === 'water' ? 0.78 : 1;
  let pos;
  if (par) {
    const top = par[1] + par[7] * 0.5;
    pos = [par[0], kind === 'water' ? top - size[1] * 0.5 : top + size[1] * 0.5, par[2]];
  } else {
    const f = engine.camera_front(kind === 'block' ? 12 : 16);
    pos = kind === 'block' ? [f[0], Math.max(f[1], 2), f[2]]
        : kind === 'water' ? [f[0], -0.5, f[2]]
        : [f[0], size[1] / 2, f[2]];
  }
  const props = [...pos, 0, 0, 0, ...size, ...color, 0, alpha, kind === 'water' ? 1 : 0, kind === 'fire' ? 1 : 0, 0, 0];
  const id = engine.add_entity(uniqueName(t(kind)), new Float32Array(props));
  if (par) engine.set_parent(id, parentId);
  buildTree();
  engine.select(id);
  syncSelection();
  scheduleSave();
}


function uniqueName(base) {
  const used = new Set(engine.entity_ids().map((i) => engine.entity_name(i)));
  let n = 1;
  while (used.has(`${base} ${n}`)) n++;
  return `${base} ${n}`;
}

/* ---------- свойства блока ---------- */
const fmt = (v) => String(Math.round(v * 1000) / 1000);
const h2 = (v) => Math.round(Math.min(1, Math.max(0, v)) * 255).toString(16).padStart(2, '0');
const toHex = (r, g, b) => '#' + h2(r) + h2(g) + h2(b);
const vecIn = [$('iPos'), $('iRot'), $('iSize')];
const parseVec = (str) => {
  const p = str.split(/[\s,;]+/).filter(Boolean).map(Number);
  return p.length === 3 && p.every(Number.isFinite) ? p : null;
};

function fillProps(id) {
  const p = engine.get_props(id);
  if (p.length < 13) return;
  vecIn[0].value = [p[0], p[1], p[2]].map(fmt).join(', ');
  vecIn[1].value = [p[3], p[4], p[5]].map(fmt).join(', ');
  vecIn[2].value = [p[6], p[7], p[8]].map(fmt).join(', ');
  vecIn.forEach((i) => i.classList.remove('bad'));
  $('pColor').value = toHex(p[9], p[10], p[11]);
  $('pNeon').checked = p[12] > 0.5;
  $('pAlpha').value = p.length > 13 ? p[13] : 1;
  const k = kindOf(id);
  $('matRow').style.display = k === 'block' ? '' : 'none';
  $('wtexRow').style.display = k === 'water' ? '' : 'none';
  if (k === 'block') $('pMat').value = String(Math.min(5, Math.max(0, Math.round(p[16] || 0))));
  if (k === 'water') $('pWtex').value = (p[17] || 0) > 0.5 ? '1' : '0';
}
function onEdit() {
  const id = engine.selected();
  if (id < 0) return;
  const v = vecIn.map((i) => parseVec(i.value));
  vecIn.forEach((i, k) => i.classList.toggle('bad', !v[k]));
  if (v.some((x) => !x)) return;
  const hex = $('pColor').value;
  const c = [1, 3, 5].map((k) => parseInt(hex.slice(k, k + 2), 16) / 255);
  const cur = Array.from(engine.get_props(id));
  const kind = kindOf(id);
  const mat = kind === 'block' ? (parseFloat($('pMat').value) || 0) : (cur[16] || 0);
  const wt = kind === 'water' ? (parseFloat($('pWtex').value) || 0) : (cur[17] || 0);
  engine.set_props(id, new Float32Array([...v[0], ...v[1], ...v[2], ...c,
    $('pNeon').checked ? 1 : 0, parseFloat($('pAlpha').value),
    cur[14] || 0, cur[15] || 0, mat, wt]));
  scheduleSave();
}
vecIn.forEach((i) => {
  i.addEventListener('input', onEdit);
  i.addEventListener('keydown', (e) => { if (e.key === 'Enter') i.blur(); });
  i.addEventListener('blur', () => { const id = engine.selected(); if (id >= 0) fillProps(id); });
});
$('pColor').addEventListener('input', onEdit);
$('pNeon').addEventListener('change', onEdit);
$('pAlpha').addEventListener('input', onEdit);

/* ---------- материалы и текстуры из галереи ---------- */
let texTarget = 'mat';
function pickTexture(target) {
  texTarget = target;
  $('texFile').value = '';
  $('texFile').click();
}
$('pMat').addEventListener('change', () => {
  if (engine.selected() < 0) return;
  if ($('pMat').value === '5') pickTexture('mat');
  else onEdit();
});
$('pWtex').addEventListener('change', () => {
  if (engine.selected() < 0) return;
  if ($('pWtex').value === '1') pickTexture('water');
  else onEdit();
});
$('texFile').addEventListener('change', async () => {
  const f = $('texFile').files && $('texFile').files[0];
  if (!f) { syncSelection(); return; }
  try {
    const bmp = await createImageBitmap(f);
    const c2 = document.createElement('canvas');
    c2.width = c2.height = 256;
    const ctx = c2.getContext('2d');
    const s = Math.min(bmp.width, bmp.height);
    ctx.drawImage(bmp, (bmp.width - s) / 2, (bmp.height - s) / 2, s, s, 0, 0, 256, 256);
    const d = ctx.getImageData(0, 0, 256, 256);
    const px = new Uint8Array(d.data.buffer);
    if (texTarget === 'water') engine.set_custom_water(px, 256, 256);
    else engine.set_custom_mat(px, 256, 256);
    onEdit();
  } catch (e) {
    alert(t('imgFail'));
    syncSelection();
  }
});

$('pDel').onclick = () => {
  const id = engine.selected();
  if (id < 0) return;
  engine.remove_entity(id);
  buildTree();
  syncSelection();
  scheduleSave();
};

/* ---------- панель графики (@A) ---------- */
function fmtTime(v) {
  let h = Math.floor(v), m = Math.round((v - h) * 60);
  if (m === 60) { h = (h + 1) % 24; m = 0; }
  return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
}
const QUAL_NAMES = ['q_low', 'q_med', 'q_high'];
const fmtG = (it, v) => (it.fmt === 'time' ? fmtTime(v)
  : it.fmt === 'qual' ? t(QUAL_NAMES[Math.max(0, Math.min(2, Math.round(v)))])
  : v.toFixed(it.step < 0.01 ? 3 : it.step < 1 ? 2 : 0));

function buildGfx(gid) {
  const g = GROUPS.find((x) => x.id === gid);
  $('gfxTitle').textContent = t(g.k);
  const body = $('gfxBody');
  body.innerHTML = '';
  for (const i of g.items) {
    const it = GFX[i];
    const row = document.createElement('div'); row.className = 'gr';
    const lb = document.createElement('label'); lb.textContent = t(it.k);
    const inp = document.createElement('input');
    inp.type = 'range'; inp.min = it.min; inp.max = it.max; inp.step = it.step; inp.value = gfxVals[i];
    const val = document.createElement('span'); val.textContent = fmtG(it, gfxVals[i]);
    inp.oninput = () => {
      const v = parseFloat(inp.value);
      gfxVals[i] = v;
      engine.set_gfx(i, v);
      val.textContent = fmtG(it, v);
      scheduleSave();
    };
    row.append(lb, inp, val);
    body.appendChild(row);
  }
}
function openGfx(gid) {
  gfxGroup = gfxGroup === gid ? null : gid;
  if (gfxGroup !== null) { engine.select(-1); buildGfx(gfxGroup); }
  syncSelection();
}
$('gClose').onclick = () => { gfxGroup = null; syncSelection(); };
$('gfxReset').onclick = () => {
  if (gfxGroup === null) return;
  const g = GROUPS.find((x) => x.id === gfxGroup);
  for (const i of g.items) { gfxVals[i] = gfxDefs[i]; engine.set_gfx(i, gfxDefs[i]); }
  buildGfx(gfxGroup);
  scheduleSave();
};

/* ---------- выделение / панели ---------- */
function syncSelection() {
  const id = engine.selected();
  if (id >= 0) gfxGroup = null;
  document.querySelectorAll('#treeBody .row[data-id]').forEach((r) => r.classList.toggle('sel', +r.dataset.id === id));
  document.querySelectorAll('#treeBody .row[data-g]').forEach((r) => r.classList.toggle('sel', r.dataset.g === gfxGroup));
  const pOpen = id >= 0, gOpen = gfxGroup !== null;
  $('insp').classList.toggle('on', pOpen);
  $('gfxp').classList.toggle('on', gOpen);
  if (pOpen) { $('pTitle').textContent = engine.entity_name(id); fillProps(id); }
}
$('pDup').onclick = () => {
  if (!engine) return;
  const root = engine.selected();
  if (root < 0) return;
  const ids = Array.from(engine.entity_ids());
  const group = [root];
  for (let i = 0; i < group.length; i++) {
    for (const c of ids) if (engine.parent_of(c) === group[i] && !group.includes(c)) group.push(c);
  }
  const map = new Map();
  for (const old of group) {
    const pr = Array.from(engine.get_props(old));
    pr[0] += 1; pr[2] += 1;
    const nm = engine.entity_name(old);
    const base = nm.replace(/\s*\d+$/, '') || nm;
    map.set(old, engine.add_entity(uniqueName(base), new Float32Array(pr)));
  }
  for (const old of group) {
    const par = engine.parent_of(old);
    if (map.has(par)) engine.set_parent(map.get(old), map.get(par));
    else if (old === root && par >= 0) engine.set_parent(map.get(old), par);
  }
  buildTree();
  engine.select(map.get(root));
  syncSelection();
  scheduleSave();
};
$('pClose').onclick = () => { engine.select(-1); syncSelection(); };
$('camReset').onclick = () => engine.reset_camera();

/* ---------- управление: камера, выбор, гизмо ---------- */
const cv = $('c');
let lookP = null, gizmoP = null;
let mode = 0; // 0 выбор, 1 перемещение, 2 масштаб

function setMode(m) {
  mode = m;
  if (engine) engine.set_mode(m);
  document.querySelectorAll('#tools button[data-mode]').forEach((b) => b.classList.toggle('on', +b.dataset.mode === m));
}
document.querySelectorAll('#tools button[data-mode]').forEach((b) => { b.onclick = () => setMode(+b.dataset.mode); });
setMode(0);

let play = false, third = false;
function setPlay(on) {
  play = !!on;
  if (engine) {
    engine.set_play(play);
    if (play) { engine.select(-1); gfxGroup = null; syncSelection(); }
    else { third = false; engine.set_third(false); }
  }
  $('playBtn').classList.toggle('on', play);
  $('viewBtn').classList.toggle('hidden', !play);
  if (!play) $('viewBtn').classList.remove('on');
  document.querySelectorAll('#tools button[data-mode]').forEach((b) => b.classList.toggle('hidden', play));
  $('work').classList.toggle('playing', play);
}
$('playBtn').onclick = () => setPlay(!play);
$('viewBtn').onclick = () => {
  third = !third;
  if (engine) engine.set_third(third);
  $('viewBtn').classList.toggle('on', third);
};

const ndc = (e) => {
  const r = cv.getBoundingClientRect();
  return [((e.clientX - r.left) / r.width) * 2 - 1, 1 - ((e.clientY - r.top) / r.height) * 2];
};

cv.addEventListener('pointerdown', (e) => {
  if (lookP || gizmoP) return;
  if (e.pointerType === 'mouse' && e.button !== 0 && e.button !== 2) return;
  if (!play && mode > 0 && e.button === 0 && engine && engine.selected() >= 0) {
    const [nx, ny] = ndc(e);
    if (engine.gizmo_begin(nx, ny)) {
      gizmoP = { id: e.pointerId };
      cv.setPointerCapture(e.pointerId);
      e.preventDefault();
      return;
    }
  }
  lookP = { id: e.pointerId, x: e.clientX, y: e.clientY, t: performance.now(), moved: 0, btn: e.button };
  cv.setPointerCapture(e.pointerId);
  e.preventDefault();
});
cv.addEventListener('pointermove', (e) => {
  if (gizmoP && e.pointerId === gizmoP.id) {
    const [nx, ny] = ndc(e);
    if (engine.gizmo_drag(nx, ny)) { fillProps(engine.selected()); scheduleSave(); }
    return;
  }
  if (!lookP || e.pointerId !== lookP.id) return;
  const dx = e.clientX - lookP.x, dy = e.clientY - lookP.y;
  lookP.x = e.clientX; lookP.y = e.clientY;
  lookP.moved += Math.abs(dx) + Math.abs(dy);
  if (e.pointerType !== 'mouse' || (e.buttons & 2)) engine.look(dx, dy);
});
const endGizmo = (e) => {
  if (!gizmoP || e.pointerId !== gizmoP.id) return false;
  engine.gizmo_end();
  gizmoP = null;
  return true;
};
cv.addEventListener('pointerup', (e) => {
  if (endGizmo(e)) return;
  if (!lookP || e.pointerId !== lookP.id) return;
  const p = lookP; lookP = null;
  if (p.btn === 0 && p.moved < 10 && performance.now() - p.t < 500) {
    const [nx, ny] = ndc(e);
    if (!play) engine.pick(nx, ny);
    syncSelection();
  }
});
cv.addEventListener('pointercancel', (e) => { endGizmo(e); lookP = null; });
cv.addEventListener('contextmenu', (e) => e.preventDefault());

/* ---------- управление: джойстики и клавиатура ---------- */
const joy = { x: 0, z: 0, y: 0 };
const kb = { x: 0, z: 0, y: 0 };
function pushMove() {
  if (engine) engine.set_move(clamp(joy.x + kb.x), clamp(joy.z + kb.z), clamp(joy.y + kb.y));
}

function makeJoy(el, onChange, lockX = false) {
  const knob = el.querySelector('.knob');
  let pid = null;
  const upd = (e) => {
    const r = el.getBoundingClientRect();
    let dx = e.clientX - (r.left + r.width / 2);
    let dy = e.clientY - (r.top + r.height / 2);
    if (lockX) dx = 0;
    const max = (lockX ? r.height : r.width) / 2 - 20;
    const len = Math.hypot(dx, dy);
    if (len > max) { dx *= max / len; dy *= max / len; }
    knob.style.transform = `translate(${dx}px,${dy}px)`;
    onChange(dx / max, dy / max);
  };
  const end = (e) => {
    if (e.pointerId !== pid) return;
    pid = null;
    knob.style.transform = '';
    onChange(0, 0);
  };
  el.addEventListener('pointerdown', (e) => {
    if (pid !== null) return;
    pid = e.pointerId;
    el.setPointerCapture(pid);
    upd(e);
    e.preventDefault();
  });
  el.addEventListener('pointermove', (e) => { if (e.pointerId === pid) upd(e); });
  el.addEventListener('pointerup', end);
  el.addEventListener('pointercancel', end);
  el.addEventListener('lostpointercapture', end);
}
makeJoy($('joyL'), (x, y) => { joy.x = x; joy.z = -y; pushMove(); });
makeJoy($('joyR'), (x, y) => { joy.y = -y; pushMove(); }, true);

const keys = new Set();
function updKeys() {
  const k = (c) => (keys.has(c) ? 1 : 0);
  kb.x = k('KeyD') - k('KeyA');
  kb.z = k('KeyW') - k('KeyS');
  kb.y = Math.max(k('Space'), k('KeyE')) - Math.max(k('ShiftLeft'), k('KeyQ'));
  pushMove();
}
addEventListener('keydown', (e) => {
  if (!cur || e.target.tagName === 'INPUT') return;
  if (e.code === 'Space') e.preventDefault();
  keys.add(e.code); updKeys();
});
addEventListener('keyup', (e) => { keys.delete(e.code); updKeys(); });
addEventListener('blur', () => { keys.clear(); updKeys(); });

/* ================= старт ================= */
applyDom();
renderProjects();
