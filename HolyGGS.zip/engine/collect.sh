#!/data/data/com.termux/files/usr/bin/bash
# Сбор статистики и всего кода из Downloads/engine
# Использование: bash collect.sh [путь_к_engine] [папка_вывода]

set -u

# ---------- Настройки ----------
ENGINE_DIR="${1:-$HOME/storage/downloads/engine}"
[ -d "$ENGINE_DIR" ] || ENGINE_DIR="/sdcard/Download/engine"

OUT_DIR="${2:-$(dirname "$ENGINE_DIR")/engine_dump}"   # вне engine, чтобы не склеить самих себя
EXTS=(rs toml wgsl glsl vert frag html css js)         # порядок = порядок в общем файле
EXCLUDE_DIRS=(.git target node_modules dist build pkg .idea .vscode)
MAX_FILE_KB=500                                        # файлы больше этого пропускаем

# ---------- Проверки ----------
if [ ! -d "$ENGINE_DIR" ]; then
    echo "❌ Папка не найдена: $ENGINE_DIR"
    echo "   Если не делал: termux-setup-storage"
    exit 1
fi

mkdir -p "$OUT_DIR" || { echo "❌ Не могу создать $OUT_DIR"; exit 1; }
STATS_FILE="$OUT_DIR/stats.txt"
CODE_FILE="$OUT_DIR/all_code.txt"
: > "$STATS_FILE"
: > "$CODE_FILE"

# ---------- Поиск файлов ----------
find_files() {
    local ext="$1"
    local prune=()
    for d in "${EXCLUDE_DIRS[@]}"; do
        prune+=(-name "$d" -o)
    done
    unset 'prune[${#prune[@]}-1]'   # убрать последний -o

    find "$ENGINE_DIR" \( "${prune[@]}" \) -prune -o \
        -type f -name "*.${ext}" ! -name "*.min.js" \
        -size "-${MAX_FILE_KB}k" -print0 | sort -z
}

# ---------- 1. СТАТИСТИКА ----------
declare -A CNT LINES CODE BYTES
ALL_FILES=()   # "lines<TAB>path"
total_f=0; total_l=0; total_c=0; total_b=0

for ext in "${EXTS[@]}"; do
    CNT[$ext]=0; LINES[$ext]=0; CODE[$ext]=0; BYTES[$ext]=0
    while IFS= read -r -d '' f; do
        l=$(wc -l < "$f")
        c=$(grep -c '[^[:space:]]' "$f")
        b=$(wc -c < "$f")
        CNT[$ext]=$(( ${CNT[$ext]} + 1 ))
        LINES[$ext]=$(( ${LINES[$ext]} + l ))
        CODE[$ext]=$(( ${CODE[$ext]} + c ))
        BYTES[$ext]=$(( ${BYTES[$ext]} + b ))
        ALL_FILES+=("$l"$'\t'"${f#$ENGINE_DIR/}")
    done < <(find_files "$ext")

    total_f=$(( total_f + ${CNT[$ext]} ))
    total_l=$(( total_l + ${LINES[$ext]} ))
    total_c=$(( total_c + ${CODE[$ext]} ))
    total_b=$(( total_b + ${BYTES[$ext]} ))
done

{
    echo "════════════════════════════════════════════"
    echo " СТАТИСТИКА ПРОЕКТА"
    echo " Папка: $ENGINE_DIR"
    echo " Дата:  $(date '+%Y-%m-%d %H:%M:%S')"
    echo "════════════════════════════════════════════"
    printf "%-8s %7s %9s %9s %10s\n" "Тип" "Файлов" "Строк" "Непустых" "КБ"
    echo "--------------------------------------------"
    for ext in "${EXTS[@]}"; do
        [ "${CNT[$ext]}" -eq 0 ] && continue
        printf "%-8s %7d %9d %9d %10d\n" ".$ext" \
            "${CNT[$ext]}" "${LINES[$ext]}" "${CODE[$ext]}" "$(( ${BYTES[$ext]} / 1024 ))"
    done
    echo "--------------------------------------------"
    printf "%-8s %7d %9d %9d %10d\n" "ИТОГО" \
        "$total_f" "$total_l" "$total_c" "$(( total_b / 1024 ))"
    echo
    echo "ТОП-10 самых больших файлов (по строкам):"
    printf '%s\n' "${ALL_FILES[@]}" | sort -rn | head -10 | \
        awk -F'\t' '{ printf "  %6d  %s\n", $1, $2 }'
    echo
    echo "Дерево папок (2 уровня):"
    (cd "$ENGINE_DIR" && find . -maxdepth 2 \
        \( -name .git -o -name target -o -name node_modules \) -prune -o -print \
        | sort | sed 's|^\./||; /^\.$/d; s|^|  |')
} | tee "$STATS_FILE"

# ---------- 2. ОДИН ФАЙЛ С КОДОМ ----------
{
    echo "# ENGINE CODE DUMP — $(date '+%Y-%m-%d %H:%M:%S')"
    echo "# Файлов: $total_f, строк: $total_l"
    echo
    echo "# ОГЛАВЛЕНИЕ:"
    for ext in "${EXTS[@]}"; do
        while IFS= read -r -d '' f; do
            echo "#  - ${f#$ENGINE_DIR/}"
        done < <(find_files "$ext")
    done
    echo
} >> "$CODE_FILE"

for ext in "${EXTS[@]}"; do
    while IFS= read -r -d '' f; do
        rel="${f#$ENGINE_DIR/}"
        {
            echo
            echo "////////////////////////////////////////////////////////////"
            echo "// FILE: $rel"
            echo "////////////////////////////////////////////////////////////"
            cat "$f"
            echo
        } >> "$CODE_FILE"
    done < <(find_files "$ext")
done

echo
echo "✅ Готово"
echo "   Статистика: $STATS_FILE"
echo "   Весь код:   $CODE_FILE ($(( $(wc -c < "$CODE_FILE") / 1024 )) КБ)"
