use std::f32::consts::TAU;

fn hash(x: i32, y: i32, seed: u32) -> u32 {
    let mut h = (x as u32).wrapping_mul(374_761_393)
        ^ (y as u32).wrapping_mul(668_265_263)
        ^ seed.wrapping_mul(2_246_822_519);
    h = (h ^ (h >> 13)).wrapping_mul(1_274_126_177);
    h ^ (h >> 16)
}

fn grad(ix: i32, iy: i32, seed: u32, dx: f32, dy: f32) -> f32 {
    let a = (hash(ix, iy, seed) & 0xFFFF) as f32 / 65535.0 * TAU;
    a.cos() * dx + a.sin() * dy
}

fn fade(t: f32) -> f32 {
    t * t * t * (t * (t * 6.0 - 15.0) + 10.0)
}

fn lerp(a: f32, b: f32, t: f32) -> f32 {
    a + (b - a) * t
}

/// Перлин с периодом `period` (решётка зациклена -> текстура бесшовная)
pub fn perlin(x: f32, y: f32, period: i32, seed: u32) -> f32 {
    let x0 = x.floor();
    let y0 = y.floor();
    let fx = x - x0;
    let fy = y - y0;
    let xi = (x0 as i32).rem_euclid(period);
    let yi = (y0 as i32).rem_euclid(period);
    let xj = (xi + 1).rem_euclid(period);
    let yj = (yi + 1).rem_euclid(period);
    let n00 = grad(xi, yi, seed, fx, fy);
    let n10 = grad(xj, yi, seed, fx - 1.0, fy);
    let n01 = grad(xi, yj, seed, fx, fy - 1.0);
    let n11 = grad(xj, yj, seed, fx - 1.0, fy - 1.0);
    let u = fade(fx);
    let v = fade(fy);
    lerp(lerp(n00, n10, u), lerp(n01, n11, u), v)
}

/// RGBA8 серая бесшовная текстура: 5 октав шума Перлина
pub fn fbm_texture(size: usize, seed: u32) -> Vec<u8> {
    let mut out = Vec::with_capacity(size * size * 4);
    for py in 0..size {
        for px in 0..size {
            let fx = px as f32 / size as f32;
            let fy = py as f32 / size as f32;
            let mut v = 0.0;
            let mut amp = 0.5;
            for o in 0..5u32 {
                let period = 4i32 << o;
                v += amp * perlin(fx * period as f32, fy * period as f32, period, seed + o);
                amp *= 0.5;
            }
            let g = ((0.5 + v * 1.2).clamp(0.0, 1.0) * 255.0) as u8;
            out.extend_from_slice(&[g, g, g, 255]);
        }
    }
    out
}

/// Бесшовная карта высот 0..1 (fbm или «ridged»).
pub fn height_map(size: usize, seed: u32, base: i32, octaves: u32, gain: f32, ridged: bool) -> Vec<f32> {
    let mut h = vec![0.0f32; size * size];
    for py in 0..size {
        for px in 0..size {
            let fx = px as f32 / size as f32;
            let fy = py as f32 / size as f32;
            let mut v = 0.0;
            let mut amp = 1.0;
            for o in 0..octaves {
                let period = base << o;
                let mut n = perlin(fx * period as f32, fy * period as f32, period, seed + o);
                if ridged {
                    n = 1.0 - n.abs() * 2.0;
                }
                v += amp * n;
                amp *= gain;
            }
            h[py * size + px] = v;
        }
    }
    let (mn, mx) = h.iter().fold((f32::MAX, f32::MIN), |(a, b), &x| (a.min(x), b.max(x)));
    let r = (mx - mn).max(1e-6);
    for x in h.iter_mut() {
        *x = (*x - mn) / r;
    }
    h
}

/// Высота поверхности блоков: склоны, зерно, царапины, выбоины (бесшовно).
pub fn surface_height(size: usize, seed: u32) -> Vec<f32> {
    let mut h = height_map(size, seed, 4, 5, 0.5, false);
    for py in 0..size {
        for px in 0..size {
            let fx = px as f32 / size as f32;
            let fy = py as f32 / size as f32;
            let sc = (1.0 - perlin(fx * 24.0, fy * 24.0, 24, seed + 101).abs() * 14.0).clamp(0.0, 1.0);
            let pit = ((perlin(fx * 48.0, fy * 48.0, 48, seed + 202) - 0.25) * 6.0).clamp(0.0, 1.0);
            let i = py * size + px;
            h[i] = (h[i] - 0.14 * sc * sc - 0.12 * pit).clamp(0.0, 1.0);
        }
    }
    h
}

/// RGBA8: rgb = нормаль в касательном пространстве, a = высота.
pub fn normal_map(h: &[f32], size: usize, strength: f32) -> Vec<u8> {
    let n = size as i32;
    let at = |x: i32, y: i32| h[(y.rem_euclid(n) as usize) * size + x.rem_euclid(n) as usize];
    let mut out = Vec::with_capacity(size * size * 4);
    for py in 0..n {
        for px in 0..n {
            let nx = -(at(px + 1, py) - at(px - 1, py)) * strength;
            let ny = -(at(px, py + 1) - at(px, py - 1)) * strength;
            let l = (nx * nx + ny * ny + 1.0).sqrt();
            let enc = |v: f32| ((v / l * 0.5 + 0.5).clamp(0.0, 1.0) * 255.0) as u8;
            out.extend_from_slice(&[enc(nx), enc(ny), enc(1.0), (at(px, py).clamp(0.0, 1.0) * 255.0) as u8]);
        }
    }
    out
}

// ---------- материалы блоков ----------
// 0 камень · 1 стекло · 2 песок · 3 древесина · 4 доски
// Альбедо центрировано вокруг ~0.5 (мешается с цветом сущности),
// нормали — как normal_map: rgb = нормаль, a = высота.

fn plaster(size: usize, f: impl Fn(usize, usize) -> (f32, f32, f32)) -> Vec<u8> {
    let mut out = Vec::with_capacity(size * size * 4);
    for py in 0..size {
        for px in 0..size {
            let (r, g, b) = f(px, py);
            out.extend_from_slice(&[
                (r.clamp(0.0, 1.0) * 255.0) as u8,
                (g.clamp(0.0, 1.0) * 255.0) as u8,
                (b.clamp(0.0, 1.0) * 255.0) as u8,
                255,
            ]);
        }
    }
    out
}

/// (albedo, normal) для материала `kind`.
pub fn material(kind: u8, size: usize) -> (Vec<u8>, Vec<u8>) {
    let n = size as f32;
    match kind {
        // --- стекло: почти гладкое, светлые разводы ---
        1 => {
            let mut h = height_map(size, 31, 2, 3, 0.5, false);
            for x in h.iter_mut() {
                *x = 0.5 + (*x - 0.5) * 0.18;
            }
            let nrm = normal_map(&h, size, 3.0);
            let alb = plaster(size, |px, py| {
                let (fx, fy) = (px as f32 / n, py as f32 / n);
                let streak = perlin(fx * 8.0, fy * 2.0, 8, 55);
                let g = 0.56 + streak * 0.07;
                (g, g + 0.02, g + 0.055)
            });
            (alb, nrm)
        }
        // --- песок: мелкое зерно, тёплый оттенок ---
        2 => {
            let mut h = height_map(size, 777, 16, 3, 0.5, false);
            for x in h.iter_mut() {
                *x = 0.5 + (*x - 0.5) * 0.55;
            }
            let nrm = normal_map(&h, size, 7.0);
            let alb = plaster(size, |px, py| {
                let (fx, fy) = (px as f32 / n, py as f32 / n);
                let grain = perlin(fx * 32.0, fy * 32.0, 32, 90) * 0.5
                    + perlin(fx * 8.0, fy * 8.0, 8, 91) * 0.5;
                let k = grain * 0.16;
                (0.60 + k, 0.52 + k * 0.85, 0.36 + k * 0.6)
            });
            (alb, nrm)
        }
        // --- древесина: кора с вертикальными бороздами ---
        3 => {
            let mut h = vec![0.0f32; size * size];
            for py in 0..size {
                for px in 0..size {
                    let (fx, fy) = (px as f32 / n, py as f32 / n);
                    let warp = perlin(fx * 8.0, fy * 8.0, 8, 130);
                    let s = fx * 4.0 + warp * 0.30;
                    let stripe = (s - s.round()).abs() * 2.0; // 0 у борозды
                    let fine = perlin(fx * 24.0, fy * 24.0, 24, 131);
                    h[py * size + px] =
                        (1.0 - stripe.powf(0.65)) * 0.72 + fine * 0.18 + 0.05;
                }
            }
            let (mn, mx) = h.iter().fold((f32::MAX, f32::MIN), |(a, b), &x| (a.min(x), b.max(x)));
            let r = (mx - mn).max(1e-6);
            for x in h.iter_mut() {
                *x = (*x - mn) / r;
            }
            let nrm = normal_map(&h, size, 9.0);
            let alb = plaster(size, |px, py| {
                let (fx, fy) = (px as f32 / n, py as f32 / n);
                let warp = perlin(fx * 8.0, fy * 8.0, 8, 130);
                let s = fx * 4.0 + warp * 0.30;
                let stripe = (s - s.round()).abs() * 2.0;
                let fine = perlin(fx * 24.0, fy * 24.0, 24, 131);
                let k = (1.0 - stripe) * 0.14 + fine * 0.07;
                (0.50 + k, 0.38 + k * 0.8, 0.25 + k * 0.55)
            });
            (alb, nrm)
        }
        // --- доски: ряды со швами и разным тоном ---
        4 => {
            let mut h = vec![0.0f32; size * size];
            for py in 0..size {
                for px in 0..size {
                    let (fx, fy) = (px as f32 / n, py as f32 / n);
                    let row = (fy * 4.0).fract();
                    let edge = (row.min(1.0 - row) * 24.0).min(1.0);
                    let off = ((fy * 4.0).floor()) * 0.5;
                    let col = ((fx * 2.0) + off).fract();
                    let cedge = (col.min(1.0 - col) * 20.0).min(1.0);
                    let grain = perlin(fx * 24.0, fy * 24.0, 24, 210);
                    h[py * size + px] =
                        (edge * cedge) * 0.72 + grain * 0.16 + 0.12;
                }
            }
            let (mn, mx) = h.iter().fold((f32::MAX, f32::MIN), |(a, b), &x| (a.min(x), b.max(x)));
            let r = (mx - mn).max(1e-6);
            for x in h.iter_mut() {
                *x = (*x - mn) / r;
            }
            let nrm = normal_map(&h, size, 10.0);
            let alb = plaster(size, |px, py| {
                let (fx, fy) = (px as f32 / n, py as f32 / n);
                let row = (fy * 4.0).fract();
                let edge = (row.min(1.0 - row) * 24.0).min(1.0);
                let off = ((fy * 4.0).floor()) * 0.5;
                let col = ((fx * 2.0) + off).fract();
                let cedge = (col.min(1.0 - col) * 20.0).min(1.0);
                let plank = perlin((fx * 2.0) + 0.25, (fy * 4.0) + 0.5, 4, 211);
                let grain = perlin(fx * 24.0, fy * 24.0, 24, 210);
                let k = plank * 0.10 + grain * 0.06 + (1.0 - edge * cedge) * -0.12;
                (0.52 + k, 0.41 + k * 0.85, 0.28 + k * 0.6)
            });
            (alb, nrm)
        }
        // --- камень (по умолчанию): как текущий вид движка ---
        _ => {
            let h = surface_height(size, 4242);
            let nrm = normal_map(&h, size, 10.0);
            let fbm = fbm_texture(size, 1337);
            let alb = plaster(size, |px, py| {
                let g = fbm[(py * size + px) * 4] as f32 / 255.0;
                let hh = h[py * size + px];
                let k = 0.50 + (g - 0.5) * 0.30 + (hh - 0.5) * 0.10;
                (k, k * 0.99, k * 1.01)
            });
            (alb, nrm)
        }
    }
}
