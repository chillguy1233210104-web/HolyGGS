mod noise;

use glam::{EulerRot, Mat3, Mat4, Quat, Vec3, Vec4};
use std::collections::HashMap;
use std::f32::consts::PI;
use wasm_bindgen::prelude::*;
use wasm_bindgen::JsCast;
use web_sys::{
    HtmlCanvasElement, WebGl2RenderingContext as GL, WebGlBuffer, WebGlFramebuffer, WebGlProgram,
    WebGlRenderbuffer, WebGlShader, WebGlTexture, WebGlUniformLocation, WebGlVertexArrayObject,
};



// ---------- индексы настроек графики ----------
const GFX_N: usize = 26;
const G_TIME: usize = 0;
const G_CONTRAST: usize = 1;
const G_EXPOSURE: usize = 2;
const G_SAT: usize = 3;
const G_RAYS: usize = 4;
const G_NEON: usize = 5;
const G_BLOOM: usize = 6;
const G_BTHR: usize = 7;
const G_FOGD: usize = 8;
const G_FOGS: usize = 9;
const G_SKYB: usize = 10;
const G_SUN: usize = 11;
const G_VIG: usize = 12;
const G_AMB: usize = 13;
const G_SHADOW: usize = 14;
const G_NLIGHT: usize = 15;
const G_WAVEH: usize = 16;
const G_WAVES: usize = 17;
const G_BUMP: usize = 18;
const G_FOV: usize = 19;
const G_SENS: usize = 20;
const G_FOGN: usize = 21;
const G_MIE: usize = 22;
const G_TEXQ: usize = 23;
const G_SHQ: usize = 24;
const G_WQ: usize = 25;
const GFX_DEF: [f32; GFX_N] = [
    14.0, 1.0, 1.0, 1.0, 0.35, 3.0, 0.5, 0.9, 0.010, 10.0, 1.0, 1.0, 0.25, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 60.0, 1.0, 0.6, 1.0,
    1.0, 1.0, 1.0,
];

// материалы: 0 камень · 1 стекло · 2 песок · 3 древесина · 4 доски · 5 из галереи
// K — доля цвета текстуры, P — затемнение впадин, B — сила нормалей, S — масштаб uv
const MAT_K: [f32; 6] = [0.15, 0.30, 0.35, 0.35, 0.35, 0.85];
const MAT_P: [f32; 6] = [1.0, 0.25, 0.70, 1.0, 1.1, 0.45];
const MAT_B: [f32; 6] = [1.0, 0.30, 0.75, 1.15, 1.10, 0.70];
const MAT_S: [f32; 6] = [0.125, 0.125, 0.25, 0.125, 0.125, 0.125];

// ---------- шейдеры ----------
const VS: &str = r#"#version 300 es
precision highp float;
precision highp int;
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNor;
uniform mat4 uVP;
uniform vec3 uPos;
uniform mat3 uRot;
uniform vec3 uSize;
uniform vec3 uCam;
uniform float uOutline;
uniform int uMode;
out vec3 vN;
out vec3 vT;
out vec3 vB;
out vec2 vUV;
out vec2 vH;
out float vDist;
out vec3 vW;
out vec3 vNo;
out vec3 vL;
void main(){
  vec3 local = aPos * uSize;
  vec3 w = uRot * local + uPos;
  if (uMode == 1) {
    float d = length(w - uCam);
    w += uRot * normalize(sign(aPos)) * (uOutline * d);
  }
  vec3 an = abs(aNor);
  vec3 t;
  vec3 b;
  if (an.y > 0.5) { t = vec3(1.0, 0.0, 0.0); b = vec3(0.0, 0.0, 1.0); }
  else if (an.x > 0.5) { t = vec3(0.0, 0.0, 1.0); b = vec3(0.0, 1.0, 0.0); }
  else { t = vec3(1.0, 0.0, 0.0); b = vec3(0.0, 1.0, 0.0); }
  vN = uRot * aNor;
  vT = uRot * t;
  vB = uRot * b;
  vUV = an.y > 0.5 ? local.xz : (an.x > 0.5 ? local.zy : local.xy);
  vH = an.y > 0.5 ? 0.5 * uSize.xz : (an.x > 0.5 ? 0.5 * uSize.zy : 0.5 * uSize.xy);
  vW = w;
  vNo = aNor;
  vL = local;
  vDist = length(w - uCam);
  gl_Position = uVP * vec4(w, 1.0);
}"#;

const FS: &str = r#"#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
precision highp sampler2DShadow;
in vec3 vN;
in vec3 vT;
in vec3 vB;
in vec2 vUV;
in vec2 vH;
in float vDist;
in vec3 vW;
in vec3 vNo;
in vec3 vL;
uniform sampler2D uTex;
uniform sampler2D uNrm;
uniform sampler2DShadow uShadow;
uniform mat4 uLVP;
uniform float uShOn;
uniform float uBump;
uniform float uOpa;
uniform vec3 uColor;
uniform int uMode;
uniform float uNeon;
uniform float uNeonB;
uniform vec3 uAmb;
uniform vec3 uLightCol;
uniform vec3 uLightDir;
uniform vec3 uCam;
uniform vec3 uFogCol;
uniform float uFogDen;
uniform float uFogStart;
uniform vec4 uNLp[16];
uniform vec4 uNLc[16];
uniform int uNLn;
uniform sampler2D uNoise;
uniform float uRays;
uniform float uUnder;
uniform float uMatK;
uniform float uMatP;
uniform float uMatB;
uniform float uMatS;
out vec4 o;

// трипланарная выборка: текстура тайлится в мировых единицах и НЕ растягивается
vec3 triW(){
  vec3 w = abs(vNo);
  w = w * w * w;
  float s = w.x + w.y + w.z;
  if (s < 1e-6) return vec3(0.3333333);
  return w / s;
}
float shadowAt(vec3 n, vec3 l){
  if (uShOn < 0.01) return 1.0;
  float nl = clamp(dot(n, l), 0.0, 1.0);
  vec3 p = vW + n * (0.04 + 0.12 * (1.0 - nl));
  vec4 q = uLVP * vec4(p, 1.0);
  vec3 s = q.xyz / q.w * 0.5 + 0.5;
  if (s.z > 1.0) return 1.0;
  float edge = min(min(s.x, 1.0 - s.x), min(s.y, 1.0 - s.y));
  if (edge < 0.0) return 1.0;
  s.z -= 0.0003;
  float t = 1.0 / 2048.0;
  float r = 0.0;
  for (int i = -1; i <= 1; i++) {
    for (int j = -1; j <= 1; j++) {
      r += textureLod(uShadow, vec3(s.xy + vec2(float(i), float(j)) * t * 1.3, s.z), 0.0);
    }
  }
  r /= 9.0;
  return mix(1.0, r, uShOn * smoothstep(0.0, 0.04, edge));
}

uniform vec3 uZenith;
uniform vec3 uSunDir;
uniform float uSkyB;
uniform float uSunset;
uniform float uFogN;
uniform float uMie;
uniform float uTime;
float hgPhase(float c){
  float g = 0.74;
  float d = 1.0 + g * g - 2.0 * g * c;
  return (1.0 - g * g) / (12.566371 * d * sqrt(d));
}
vec3 mieGlow(vec3 vd){
  float w = 1.0 - clamp(vd.y, 0.0, 1.0);
  w = w * w * w;
  float ph = 0.04 + hgPhase(dot(vd, normalize(uLightDir)));
  return uLightCol * (ph * w * uMie * 0.35);
}
vec3 applyFog(vec3 c){
  float fd = length(vW - uCam);
  vec3 vd = (vW - uCam) / max(fd, 0.0001);
  float t = clamp(vd.y, 0.0, 1.0);
  vec3 base = mix(uFogCol, uZenith * uSkyB, pow(t, 0.55));
  base += vec3(1.0, 0.45, 0.15) * pow(max(dot(vd, uSunDir), 0.0), 5.0) * uSunset * (1.0 - 0.6 * t) * uSkyB;
  vec3 fc = base + mieGlow(vd);
  vec3 uw = vec3(0.02, 0.115, 0.155) * (0.45 + 0.55 * uSkyB) + mieGlow(vd) * 0.25;
  fc = mix(fc, uw, uUnder);
  float t0 = min(uFogStart, fd);
  float len = fd - t0;
  float tau = 0.0;
  float shaft = 0.0;
  if (len > 0.0 && (uFogDen > 0.00001 || uRays > 0.001)) {
    float jit = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    float dt = len / 8.0;
    vec2 wind = vec2(2.0, 0.9) * uTime;
    for (int i = 0; i < 8; i++) {
      vec3 p = uCam + vd * (t0 + (float(i) + jit) * dt);
      float n = textureLod(uNoise, (p.xz + wind) * 0.0062 + p.y * 0.0041, 1.5).r;
      float dens = max(1.0 + uFogN * (n - 0.5) * 5.0, 0.0);
      float hf = mix(exp(-max(p.y, 0.0) * 0.01), 0.35, uUnder);
      tau += dens * hf * dt;
      if (uRays > 0.001) {
        vec4 q = uLVP * vec4(p, 1.0);
        vec3 sh = q.xyz / q.w * 0.5 + 0.5;
        float lit = 1.0;
        if (sh.x > 0.0 && sh.x < 1.0 && sh.y > 0.0 && sh.y < 1.0 && sh.z > 0.0 && sh.z < 1.0) {
          lit = textureLod(uShadow, vec3(sh.xy, sh.z - 0.0015), 0.0);
        }
        shaft += lit * max(dens, 0.25) * hf * dt;
      }
    }
    tau *= uFogDen * (1.0 + uUnder * 2.2);
  }
  float T = exp(-tau) * (1.0 - smoothstep(1600.0, 2600.0, fd));
  vec3 res = mix(fc, c, T);
  if (uRays > 0.001 && uShOn > 0.01) {
    float ph = 0.22 + 0.78 * pow(max(dot(vd, normalize(uLightDir)), 0.0), 1.6);
    res += uLightCol * (1.0 - T) * shaft * 0.012 * ph * uRays * (0.3 + 0.7 * uSkyB) * (1.0 - 0.7 * uUnder);
  }
  return res;
}


// самозатенение рельефа: луч по карте высот к источнику света
float bumpShadow(vec2 uv, vec3 Lt, float k){
  float len = max(length(Lt.xy), 0.001);
  vec2 dh = Lt.xy / len;
  float slope = Lt.z / len;
  float hs = 0.05 * k;
  float h0 = textureLod(uNrm, uv * 0.25, 0.0).a * hs;
  float occ = 0.0;
  for (int i = 1; i <= 6; i++) {
    float d = float(i) * 0.022;
    float h = textureLod(uNrm, (uv + dh * d) * 0.25, 0.0).a * hs;
    occ = max(occ, h - (h0 + d * slope));
  }
  return 1.0 - clamp(occ * 45.0, 0.0, 0.85);
}

void main(){
  if (uMode == 1) { o = vec4(1.0, 0.62, 0.10, 0.0); return; }
  vec3 tw = triW();
  vec4 alb = texture(uTex, vL.zy * uMatS) * tw.x
           + texture(uTex, vL.xz * uMatS) * tw.y
           + texture(uTex, vL.xy * uMatS) * tw.z;
  float n0 = alb.r;
  float dark = 1.0 - smoothstep(0.30, 0.52, n0);
  vec3 base = uColor * mix(vec3(1.0), alb.rgb * 2.0, uMatK) * (1.0 - 0.20 * dark * uMatP);

  float sgn = gl_FrontFacing ? 1.0 : -1.0;
  vec3 ng = normalize(vN) * sgn;
  vec3 T = normalize(vT) * sgn;
  vec3 B = normalize(vB) * sgn;

  // потёртые скошенные рёбра
  float du = vH.x - abs(vUV.x);
  float dv = vH.y - abs(vUV.y);
  float edge;
  vec3 bd;
  if (du < dv) { edge = du; bd = T * sign(vUV.x); }
  else { edge = dv; bd = B * sign(vUV.y); }
  edge += (n0 - 0.5) * 0.06;
  float bw = min(0.09, 0.5 * min(vH.x, vH.y));
  float bk1 = min(uBump * uMatB, 1.0);
  float wear = (1.0 - smoothstep(0.0, bw, edge)) * bk1;

  // карта нормалей (два масштаба) + затемнение впадин
  float fade = 1.0 - smoothstep(30.0, 90.0, vDist);
  float bk = uBump * uMatB * fade;
  vec4 t1 = texture(uNrm, vL.zy * 0.25) * tw.x
          + texture(uNrm, vL.xz * 0.25) * tw.y
          + texture(uNrm, vL.xy * 0.25) * tw.z;
  vec4 t2 = texture(uNrm, vL.zy * 1.37 + 0.31) * tw.x
          + texture(uNrm, vL.xz * 1.37 + 0.31) * tw.y
          + texture(uNrm, vL.xy * 1.37 + 0.31) * tw.z;
  vec2 gr = ((t1.xy * 2.0 - 1.0) + (t2.xy * 2.0 - 1.0) * 0.6) * bk;
  vec3 nb = normalize(ng + bd * wear * 0.7);
  nb = normalize(nb + T * gr.x + B * gr.y);
  float ao = 1.0 - 0.35 * min(uBump * uMatB, 2.0) * fade * (1.0 - smoothstep(0.2, 0.55, t1.a));
  base = mix(base, base * 1.2 + 0.02, wear * 0.7);

  vec3 c;
  if (uNeon > 0.5) {
    c = uColor * uNeonB;
  } else {
    vec3 L = normalize(uLightDir);
    float dg = dot(ng, L);
    float sunT = 0.0;
    float spec = 0.0;
    if (dg > 0.0) {
      float sh = shadowAt(ng, L);
      vec3 Lt = vec3(dot(L, T), dot(L, B), dg);
      float bs = mix(1.0, bumpShadow(vUV, Lt, uBump), fade);
      float lf = smoothstep(0.0, 0.12, dg);
      float vis = sh * bs * lf;
      sunT = max(dot(nb, L), 0.0) * vis;
      vec3 H = normalize(L + normalize(uCam - vW));
      spec = pow(max(dot(nb, H), 0.0), 40.0) * 0.18 * vis * bk1;
    }
    vec3 lit = uAmb * ao + uLightCol * sunT * mix(1.0, ao, 0.5);
    for (int i = 0; i < 16; i++) {
      if (i >= uNLn) break;
      vec3 tl = uNLp[i].xyz - vW;
      float dist = length(tl);
      float a = clamp(1.0 - max(dist - uNLc[i].w, 0.0) / uNLp[i].w, 0.0, 1.0);
      float nd = mix(max(dot(nb, tl / max(dist, 0.001)), 0.0), 1.0, 0.12);
      lit += uNLc[i].rgb * (a * a) * nd;
    }
    c = base * lit + uLightCol * spec;
  }
  c = applyFog(c);
  if (isnan(c.r) || isnan(c.g) || isnan(c.b)) c = uColor;
  o = vec4(c, uOpa);
}"#;

const FS_VS: &str = r#"#version 300 es
precision highp float;
precision highp int;
out vec2 vUV;
void main(){
  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
  vUV = p;
  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}"#;

const SKY_FS: &str = r#"#version 300 es
precision highp float;
precision highp int;
in vec2 vUV;
uniform mat4 uInvVP;
uniform vec3 uCam;
uniform vec3 uZenith;
uniform vec3 uHorizon;
uniform vec3 uSunDir;
uniform vec3 uSunCol;
uniform float uSkyB;
uniform float uSunSize;
uniform float uNight;
uniform float uSunset;
uniform float uSunVis;
uniform float uUnder;
out vec4 o;
uniform vec3 uLightDir;
uniform vec3 uLightCol;
uniform float uMie;
float hgPhase(float c){
  float g = 0.74;
  float d = 1.0 + g * g - 2.0 * g * c;
  return (1.0 - g * g) / (12.566371 * d * sqrt(d));
}
vec3 mieGlow(vec3 vd){
  float w = 1.0 - clamp(vd.y, 0.0, 1.0);
  w = w * w * w;
  float ph = 0.04 + hgPhase(dot(vd, normalize(uLightDir)));
  return uLightCol * (ph * w * uMie * 0.35);
}
float h13(vec3 p){ return fract(sin(dot(p, vec3(12.9898, 78.233, 37.719))) * 43758.5453); }
void main(){
  vec4 p = uInvVP * vec4(vUV * 2.0 - 1.0, 1.0, 1.0);
  vec3 dir = normalize(p.xyz / p.w - uCam);
  float t = clamp(dir.y, 0.0, 1.0);
  vec3 col = mix(uHorizon, uZenith, pow(t, 0.55));
  float sd = max(dot(dir, uSunDir), 0.0);
  col += vec3(1.0, 0.45, 0.15) * pow(sd, 5.0) * uSunset * (1.0 - 0.6 * t);
  if (dir.y > 0.0) {
    float s = step(0.9965, h13(floor(dir * 180.0)));
    col += vec3(s) * uNight * smoothstep(0.0, 0.25, dir.y);
  }
  col *= uSkyB;
  col += mieGlow(dir);
  float ang = acos(clamp(dot(dir, uSunDir), -1.0, 1.0));
  float disc = 1.0 - smoothstep(0.030 * uSunSize, 0.036 * uSunSize, ang);
  float halo = exp(-ang * 5.0 / uSunSize);
  vec3 sun = uSunCol * (disc * 8.0 + halo * 0.6) * uSunVis;
  float am = acos(clamp(dot(dir, -uSunDir), -1.0, 1.0));
  float moon = (1.0 - smoothstep(0.028, 0.033, am)) * uNight;
  vec3 res = col + sun + vec3(0.8, 0.85, 1.0) * moon * 1.5;
  o = vec4(res, clamp((disc + halo * 0.9 + pow(sd, 14.0) * 0.6) * uSunVis, 0.0, 1.0));
}"#;

const BRIGHT_FS: &str = r#"#version 300 es
precision highp float;
precision highp int;
in vec2 vUV;
uniform sampler2D uSrc;
uniform vec2 uTexel;
uniform float uThr;
out vec4 o;
void main(){
  vec3 c = texture(uSrc, vUV + uTexel * vec2(-1.0, -1.0)).rgb
         + texture(uSrc, vUV + uTexel * vec2( 1.0, -1.0)).rgb
         + texture(uSrc, vUV + uTexel * vec2(-1.0,  1.0)).rgb
         + texture(uSrc, vUV + uTexel * vec2( 1.0,  1.0)).rgb;
  c *= 0.25;
  float l = max(max(c.r, c.g), c.b);
  float k = max(l - uThr, 0.0) / max(l, 0.0001);
  o = vec4(c * k, 1.0);
}"#;

const BLUR_FS: &str = r#"#version 300 es
precision highp float;
precision highp int;
in vec2 vUV;
uniform sampler2D uSrc;
uniform vec2 uStep;
out vec4 o;
void main(){
  vec3 c = texture(uSrc, vUV).rgb * 0.227027;
  c += (texture(uSrc, vUV + uStep).rgb       + texture(uSrc, vUV - uStep).rgb)       * 0.1945946;
  c += (texture(uSrc, vUV + uStep * 2.0).rgb + texture(uSrc, vUV - uStep * 2.0).rgb) * 0.1216216;
  c += (texture(uSrc, vUV + uStep * 3.0).rgb + texture(uSrc, vUV - uStep * 3.0).rgb) * 0.054054;
  c += (texture(uSrc, vUV + uStep * 4.0).rgb + texture(uSrc, vUV - uStep * 4.0).rgb) * 0.016216;
  o = vec4(c, 1.0);
}"#;

const POST_FS: &str = r#"#version 300 es
precision highp float;
precision highp int;
in vec2 vUV;
uniform sampler2D uScene;
uniform sampler2D uBloom;
uniform sampler2D uDepthTex;
uniform vec2 uSun;
uniform float uSunOn;
uniform vec3 uRayCol;
uniform float uRays;
uniform float uBloomS;
uniform float uExposure;
uniform float uContrast;
uniform float uSat;
uniform float uVig;
uniform float uAsp;
uniform float uUnder;
uniform float uTime;
out vec4 o;

// шум Перлина (value-noise, 2 октавы) — «рваные» лучи вместо плоских
float h21(vec2 p){
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}
float pnoise(vec2 p){
  vec2 i = floor(p);
  vec2 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  return mix(mix(h21(i), h21(i + vec2(1.0, 0.0)), f.x),
             mix(h21(i + vec2(0.0, 1.0)), h21(i + vec2(1.0, 1.0)), f.x), f.y);
}
float perlin(vec2 p){ return pnoise(p) * 0.65 + pnoise(p * 2.13 + 7.7) * 0.35; }

void main(){
  vec4 s = texture(uScene, vUV);
  vec3 c = s.rgb + texture(uBloom, vUV).rgb * uBloomS;
  if (uRays > 0.001 && uSunOn > 0.001) {
    vec2 toSun = uSun - vUV;
    float tl = length(toSun);
    toSun *= min(1.0, 1.6 / max(tl, 0.0001));
    vec2 d = toSun * (1.0 / 48.0);
    float jit = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    vec2 p = vUV + d * jit;
    float acc = 0.0;
    float decay = 1.0;
    // мягкий шум по углу: лучи становятся «объёмными», а не плоскими
    vec2 rr0 = (vUV - uSun) * vec2(uAsp, 1.0);
    float ang0 = atan(rr0.y, rr0.x + 1e-4);
    float wob = clamp(perlin(vec2(ang0 * 1.9, uTime * 0.11)) * 0.55 + 0.72, 0.2, 1.8);
    float blocked = 0.0;
    for (int i = 0; i < 48; i++) {
      p += d;
      float inside = step(0.0, p.x) * step(p.x, 1.0) * step(0.0, p.y) * step(p.y, 1.0);
      float glow = texture(uScene, p).a * inside;
      // геометрия (глубина < 1) обрывает луч: солнце не светит сквозь стены
      float z = texture(uDepthTex, p).x;
      float hit = step(z, 0.9995) * step(0.5, inside);
      acc += glow * decay * (1.0 - blocked);
      blocked = max(blocked, hit);
      decay *= 0.972;
      if (blocked > 0.5) break;
    }
    vec2 rr = (vUV - uSun) * vec2(uAsp, 1.0);
    float r = length(rr);
    float shaft = acc / 20.0;
    shaft *= (0.45 + 1.0 * exp(-r * 1.4)) * wob * (1.0 - blocked);
    // туман вокруг лучей (шумный, слабый — солнце/яркость не задирает)
    float hazeN = clamp(perlin(vUV * vec2(uAsp, 1.0) * 3.1 + vec2(uTime * 0.021, -uTime * 0.013)), 0.0, 1.0);
    float haze = exp(-r * 3.4) * (0.045 + 0.05 * hazeN) * (1.0 - blocked);
    float em = max(max(s.r, s.g), s.b);
    float rk = 1.0 / (1.0 + max(em - 1.0, 0.0) * 1.5 * (1.0 - s.a));
    c += uRayCol * (shaft + haze) * uRays * uSunOn * 1.3 * rk;
  }
  if (uUnder > 0.001) {
    c = mix(c, c * vec3(0.50, 0.88, 1.05) + vec3(0.0, 0.045, 0.075), uUnder * 0.55);
    c = mix(c, vec3(dot(c, vec3(0.333))), uUnder * 0.12);
  }
  c *= uExposure;
  vec3 hi = 0.8 + 0.2 * (1.0 - exp(-(c - 0.8) / 0.2));
  c = mix(c, hi, step(0.8, c));
  float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
  c = mix(vec3(l), c, uSat);
  c = (c - 0.5) * uContrast + 0.5;
  vec2 q = vUV - 0.5;
  c *= 1.0 - uVig * dot(q, q) * 1.8;
  if (isnan(c.r) || isnan(c.g) || isnan(c.b)) c = s.rgb;
  o = vec4(clamp(c, 0.0, 1.0), 1.0);
}"#;

// ---------- тени / неоновые огни / гизмо ----------
const SH_SIZE: i32 = 2048;
const SH_R: f32 = 60.0;
const NL_MAX: usize = 16;
const PLAYER_H: f32 = 1.8;
const PLAYER_R: f32 = 0.4;
const EYE_H: f32 = 1.62;
const WALK: f32 = 6.0;

struct RotDrag {
    id: i32,
    k: usize,
    axis: Vec3,
    u: Vec3,
    v: Vec3,
    q0: Quat,
    last: f32,
    total: f32,
}

const SH_VS: &str = r#"#version 300 es
precision highp float;
layout(location=0) in vec3 aPos;
uniform mat4 uLVP;
uniform vec3 uPos;
uniform mat3 uRot;
uniform vec3 uSize;
void main(){
  gl_Position = uLVP * vec4(uRot * (aPos * uSize) + uPos, 1.0);
}"#;

const SH_FS: &str = r#"#version 300 es
precision highp float;
uniform float uAlpha;
out vec4 o;
void main(){
  if (uAlpha < 0.999) {
    vec2 p = floor(gl_FragCoord.xy);
    float h = fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
    if (uAlpha < h) discard;
  }
  o = vec4(0.0);
}"#;

const GZ_VS: &str = r#"#version 300 es
precision highp float;
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNor;
uniform mat4 uVP;
uniform vec3 uC;
uniform float uR;
uniform mat3 uM;
out vec3 vN;
out vec3 vW;
void main(){
  vN = uM * aNor;
  vW = uC + uM * (aPos * uR);
  gl_Position = uVP * vec4(vW, 1.0);
}"#;

const GZ_FS: &str = r#"#version 300 es
precision highp float;
in vec3 vN;
in vec3 vW;
uniform vec3 uCam;
uniform vec3 uColor;
uniform float uHot;
out vec4 o;
void main(){
  vec3 n = normalize(vN);
  vec3 v = normalize(uCam - vW);
  float k = max(dot(n, v), 0.0);
  vec3 c = uColor * (0.40 + 0.60 * k) + pow(1.0 - k, 3.0) * 0.25;
  c = mix(c, vec3(1.0), uHot * 0.5);
  o = vec4(c, 1.0);
}"#;

struct Drag {
    id: i32,
    handle: usize,
    axis: Vec3,
    s0: f32,
    pos0: Vec3,
    size0: Vec3,
}

fn make_mesh(gl: &GL, data: &[f32]) -> Result<WebGlVertexArrayObject, JsValue> {
    let vao = gl.create_vertex_array().ok_or("vao")?;
    gl.bind_vertex_array(Some(&vao));
    let buf = gl.create_buffer().ok_or("buf")?;
    gl.bind_buffer(GL::ARRAY_BUFFER, Some(&buf));
    unsafe {
        let view = js_sys::Float32Array::view(data);
        gl.buffer_data_with_array_buffer_view(GL::ARRAY_BUFFER, &view, GL::STATIC_DRAW);
    }
    gl.enable_vertex_attrib_array(0);
    gl.vertex_attrib_pointer_with_i32(0, 3, GL::FLOAT, false, 24, 0);
    gl.enable_vertex_attrib_array(1);
    gl.vertex_attrib_pointer_with_i32(1, 3, GL::FLOAT, false, 24, 12);
    gl.bind_vertex_array(None);
    Ok(vao)
}

fn make_shadow(gl: &GL, size: i32) -> Result<(WebGlFramebuffer, WebGlTexture), JsValue> {
    let tex = gl.create_texture().ok_or("shadow texture")?;
    gl.bind_texture(GL::TEXTURE_2D, Some(&tex));
    gl.tex_image_2d_with_i32_and_i32_and_i32_and_format_and_type_and_opt_u8_array(
        GL::TEXTURE_2D, 0, GL::DEPTH_COMPONENT24 as i32, size, size, 0,
        GL::DEPTH_COMPONENT, GL::UNSIGNED_INT, None,
    )?;
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_MIN_FILTER, GL::LINEAR as i32);
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_MAG_FILTER, GL::LINEAR as i32);
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_WRAP_S, GL::CLAMP_TO_EDGE as i32);
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_WRAP_T, GL::CLAMP_TO_EDGE as i32);
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_COMPARE_MODE, GL::COMPARE_REF_TO_TEXTURE as i32);
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_COMPARE_FUNC, GL::LEQUAL as i32);
    let fbo = gl.create_framebuffer().ok_or("shadow fbo")?;
    gl.bind_framebuffer(GL::FRAMEBUFFER, Some(&fbo));
    gl.framebuffer_texture_2d(GL::FRAMEBUFFER, GL::DEPTH_ATTACHMENT, GL::TEXTURE_2D, Some(&tex), 0);
    gl.draw_buffers(&js_sys::Array::of1(&JsValue::from(GL::NONE)));
    gl.read_buffer(GL::NONE);
    let status = gl.check_framebuffer_status(GL::FRAMEBUFFER);
    gl.bind_framebuffer(GL::FRAMEBUFFER, None);
    if status != GL::FRAMEBUFFER_COMPLETE {
        return Err("shadow fbo incomplete".into());
    }
    Ok((fbo, tex))
}

// ---------- вода ----------
// [dir.x, dir.z, длина волны, амплитуда] (одна таблица и для шейдера, и для CPU)
const WAVES: [[f32; 4]; 8] = [
    [1.0, 0.25, 17.0, 0.20],
    [0.62, 0.85, 11.3, 0.115],
    [-0.45, 0.90, 7.9, 0.07],
    [0.30, -0.95, 5.3, 0.045],
    [0.90, -0.55, 3.7, 0.028],
    [-0.80, -0.40, 2.6, 0.017],
    [0.15, 1.0, 1.9, 0.011],
    [-0.95, 0.30, 1.35, 0.007],
];

/// Высота волн Герстнера (дисперсия ω = √(g·k)) без горизонтального сдвига.
fn wave_height(x: f32, z: f32, t: f32, h: f32, sp: f32) -> f32 {
    let mut y = 0.0;
    for (i, w) in WAVES.iter().enumerate() {
        let d = glam::Vec2::new(w[0], w[1]).normalize();
        let k = 2.0 * PI / w[2];
        let om = (9.81 * k).sqrt() * sp;
        let ph = k * (d.x * x + d.y * z) - om * t + i as f32 * 2.399;
        y += w[3] * h * ph.sin();
    }
    y
}

const WATER_VS: &str = r#"#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
layout(location=0) in vec2 aG;
uniform mat4 uVP;
uniform vec3 uPos;
uniform vec3 uSize;
uniform vec3 uCam;
uniform float uTime;
uniform float uWaveH;
uniform float uWaveS;
uniform vec4 uWv[8];
uniform vec4 uPatch;
uniform vec4 uRect;
uniform sampler2D uW1;
uniform sampler2D uW2;
uniform int uWaveN;
out vec3 vW;
out vec3 vN;
out float vDist;
out float vFoam;
out float vCrest;
void main(){
  vec2 u = aG * 2.0;
  vec2 a = abs(u);
  vec2 ov = max(a - 0.7, 0.0);
  vec2 off = sign(u) * (a + 8.0 * ov * ov);
  vec2 q = uPatch.xy + off * (uPatch.w * 0.5 * uPatch.z);
  q = clamp(q, uRect.xy, uRect.zw);
  vec2 sm = 1.0 + 16.0 * ov;
  float spacing = uPatch.z * max(sm.x, sm.y);

  float lowA = textureLod(uW2, q * 0.011, 0.0).a;
  float lowB = textureLod(uW1, q * 0.017 + 0.37, 0.0).a;
  float modul = 0.55 + 0.9 * lowA;
  vec2 qw = q + (vec2(lowA, lowB) - 0.5) * 6.0;

  float qk = 0.09 * min(uWaveH, 1.5);
  float dy = 0.0;
  float sumA = 0.0;
  vec2 dxz = vec2(0.0);
  vec3 n = vec3(0.0, 1.0, 0.0);
  for (int i = 0; i < 8; i++) {
    if (i >= uWaveN) break;
    vec2 d = normalize(uWv[i].xy);
    float L = uWv[i].z;
    float k = 6.2831853 / L;
    float att = (1.0 - smoothstep(L * 0.125, L * 0.34, spacing)) * modul;
    float A = uWv[i].w * uWaveH * att;
    float om = sqrt(9.81 * k) * uWaveS;
    float ph = k * dot(d, qw) - om * uTime + float(i) * 2.399;
    float sn = sin(ph);
    float cs = cos(ph);
    dxz += d * (qk * att / k) * cs;
    dy += A * sn;
    n.xz -= d * (k * A * cs);
    n.y -= qk * att * sn;
    sumA += A;
  }
  vec3 w = vec3(q.x + dxz.x, uPos.y + uSize.y * 0.5 + dy, q.y + dxz.y);
  vN = normalize(n);
  vFoam = sumA > 0.0001 ? smoothstep(0.55, 0.95, dy / sumA) : 0.0;
  vCrest = sumA > 0.0001 ? dy / sumA : 0.0;
  vW = w;
  vDist = length(w - uCam);
  gl_Position = uVP * vec4(w, 1.0);
}"#;

const WATER_FS: &str = r#"#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
precision highp sampler2DShadow;
in vec3 vW;
in vec3 vN;
in float vDist;
in float vFoam;
in float vCrest;
uniform sampler2D uW1;
uniform sampler2D uW2;
uniform sampler2D uTex;
uniform sampler2DShadow uShadow;
uniform mat4 uLVP;
uniform float uShOn;
uniform float uTime;
uniform float uWaveS;
uniform float uBump;
uniform vec3 uCam;
uniform vec3 uPos;
uniform vec3 uSize;
uniform vec3 uColor;
uniform float uAlpha;
uniform vec3 uZenith;
uniform vec3 uHorizon;
uniform float uSkyB;
uniform vec3 uSunDir;
uniform vec3 uSunCol;
uniform float uSunVis;
uniform float uSunset;
uniform vec3 uLightDir;
uniform vec3 uLightCol;
uniform vec3 uAmb;
uniform vec3 uFogCol;
uniform float uFogDen;
uniform float uFogStart;
uniform float uFogN;
uniform float uMie;
uniform sampler2D uNoise;
uniform float uRays;
uniform float uUnder;
uniform int uWaveN;
uniform float uWQual;
uniform sampler2D uWImg;
uniform float uWtex;
uniform sampler2D uDepthTex;
uniform float uShoreOn;
out vec4 o;

float hgPhase(float c){
  float g = 0.74;
  float d = 1.0 + g * g - 2.0 * g * c;
  return (1.0 - g * g) / (12.566371 * d * sqrt(d));
}
vec3 mieGlow(vec3 vd){
  float w = 1.0 - clamp(vd.y, 0.0, 1.0);
  w = w * w * w;
  float ph = 0.04 + hgPhase(dot(vd, normalize(uLightDir)));
  return uLightCol * (ph * w * uMie * 0.35);
}
vec3 applyFog(vec3 c){
  float fd = length(vW - uCam);
  vec3 vd = (vW - uCam) / max(fd, 0.0001);
  float t = clamp(vd.y, 0.0, 1.0);
  vec3 base = mix(uFogCol, uZenith * uSkyB, pow(t, 0.55));
  base += vec3(1.0, 0.45, 0.15) * pow(max(dot(vd, uSunDir), 0.0), 5.0) * uSunset * (1.0 - 0.6 * t) * uSkyB;
  vec3 fc = base + mieGlow(vd);
  vec3 uw = vec3(0.02, 0.115, 0.155) * (0.45 + 0.55 * uSkyB) + mieGlow(vd) * 0.25;
  fc = mix(fc, uw, uUnder);
  float t0 = min(uFogStart, fd);
  float len = fd - t0;
  float tau = 0.0;
  float shaft = 0.0;
  if (len > 0.0 && (uFogDen > 0.00001 || uRays > 0.001)) {
    float jit = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    float dt = len / 8.0;
    vec2 wind = vec2(2.0, 0.9) * uTime;
    for (int i = 0; i < 8; i++) {
      vec3 p = uCam + vd * (t0 + (float(i) + jit) * dt);
      float n = textureLod(uNoise, (p.xz + wind) * 0.0062 + p.y * 0.0041, 1.5).r;
      float dens = max(1.0 + uFogN * (n - 0.5) * 5.0, 0.0);
      float hf = mix(exp(-max(p.y, 0.0) * 0.01), 0.35, uUnder);
      tau += dens * hf * dt;
      if (uRays > 0.001) {
        vec4 q = uLVP * vec4(p, 1.0);
        vec3 sh = q.xyz / q.w * 0.5 + 0.5;
        float lit = 1.0;
        if (sh.x > 0.0 && sh.x < 1.0 && sh.y > 0.0 && sh.y < 1.0 && sh.z > 0.0 && sh.z < 1.0) {
          lit = textureLod(uShadow, vec3(sh.xy, sh.z - 0.0015), 0.0);
        }
        shaft += lit * max(dens, 0.25) * hf * dt;
      }
    }
    tau *= uFogDen * (1.0 + uUnder * 2.2);
  }
  float T = exp(-tau) * (1.0 - smoothstep(1600.0, 2600.0, fd));
  vec3 res = mix(fc, c, T);
  if (uRays > 0.001 && uShOn > 0.01) {
    float ph = 0.22 + 0.78 * pow(max(dot(vd, normalize(uLightDir)), 0.0), 1.6);
    res += uLightCol * (1.0 - T) * shaft * 0.012 * ph * uRays * (0.3 + 0.7 * uSkyB) * (1.0 - 0.7 * uUnder);
  }
  return res;
}


float shadowAt(vec3 n, vec3 l){
  if (uShOn < 0.01) return 1.0;
  float nl = clamp(dot(n, l), 0.0, 1.0);
  vec3 p = vW + n * (0.04 + 0.12 * (1.0 - nl));
  vec4 q = uLVP * vec4(p, 1.0);
  vec3 s = q.xyz / q.w * 0.5 + 0.5;
  if (s.z > 1.0) return 1.0;
  float edge = min(min(s.x, 1.0 - s.x), min(s.y, 1.0 - s.y));
  if (edge < 0.0) return 1.0;
  s.z -= 0.0003;
  float t = 1.0 / 2048.0;
  float r = 0.0;
  for (int i = -1; i <= 1; i++) {
    for (int j = -1; j <= 1; j++) {
      r += textureLod(uShadow, vec3(s.xy + vec2(float(i), float(j)) * t * 1.3, s.z), 0.0);
    }
  }
  r /= 9.0;
  return mix(1.0, r, uShOn * smoothstep(0.0, 0.04, edge));
}

vec3 skyCol(vec3 d){
  float t = clamp(d.y, 0.0, 1.0);
  vec3 col = mix(uHorizon, uZenith, pow(t, 0.55));
  float sd = max(dot(d, uSunDir), 0.0);
  col += vec3(1.0, 0.45, 0.15) * pow(sd, 5.0) * uSunset * (1.0 - 0.6 * t);
  col *= uSkyB;
  col += mieGlow(d);
  float ang = acos(clamp(dot(d, uSunDir), -1.0, 1.0));
  col += uSunCol * (1.0 - smoothstep(0.03, 0.04, ang)) * 4.0 * uSunVis;
  return col;
}

void main(){
  vec3 V = normalize(uCam - vW);
  vec3 N0 = normalize(vN);
  bool under = uCam.y < uPos.y + uSize.y * 0.5;
  float t = uTime * uWaveS;
  float fade = 1.0 - 0.72 * smoothstep(50.0, 230.0, vDist);
  float fade2 = 1.0 - smoothstep(25.0, 110.0, vDist);

  // ===== каскады нормалей: крупная зыбь + средняя + мелкая рябь + микро-искры =====
  mat2 rot1 = mat2(0.8, -0.6, 0.6, 0.8);
  mat2 rot2 = mat2(0.94, -0.34, 0.34, 0.94);
  vec2 wp = vW.xz;
  vec4 s1 = texture(uW1, rot1 * wp * 0.045 + vec2(0.031, 0.017) * t);
  vec4 s2 = texture(uW2, wp * 0.16 + vec2(-0.022, 0.036) * t);
  vec4 s3 = texture(uW1, transpose(rot1) * wp * 0.62 + vec2(0.055, -0.048) * t);
  vec4 s4 = vec4(0.5);
  if (uWQual > 0.5) s4 = texture(uW2, rot2 * wp * 1.9 + vec2(-0.11, 0.13) * t);
  vec2 n1 = s1.xy * 2.0 - 1.0;
  vec2 n2 = s2.xy * 2.0 - 1.0;
  vec2 n3 = s3.xy * 2.0 - 1.0;
  vec2 n4 = s4.xy * 2.0 - 1.0;
  vec2 g = (n1 * 0.85 + n2 * 0.70 + n3 * 0.55 * fade + n4 * 0.40 * fade2) * (0.6 * uBump * (0.45 + 0.55 * fade));
  vec3 n = normalize(N0 + vec3(g.x, 0.0, g.y));
  if (under) n = -n;

  // ===== Френель по Шлику: сверху ~2% (видна толща), у горизонта зеркало =====
  float ndvM = clamp(dot(N0, V), 0.0, 1.0);
  float F = 0.02 + 0.98 * pow(1.0 - ndvM, 5.0);
  vec3 L = normalize(uLightDir);
  float sh = shadowAt(vec3(0.0, 1.0, 0.0), L);

  // ===== цвет толщи: изумрудная глубина (без чёрных провалов) =====
  float patchN = texture(uW1, vW.xz * 0.012 + 0.2).a;
  vec3 sssTint = uColor * vec3(0.5, 1.25, 0.9) + vec3(0.02, 0.11, 0.07);
  vec3 deepC = uColor * 0.55 + sssTint * 0.85;
  vec3 shalC = uColor * 1.30 + sssTint * 1.45;
  vec3 wcol = mix(deepC, shalC, smoothstep(0.25, 0.75, patchN));
  if (uWtex > 0.5) {
    vec3 img = texture(uWImg, vW.xz * 0.045 + vec2(0.0, 0.013) * t).rgb;
    wcol = mix(wcol, img * 1.25, 0.82);
  }

  // свет: полусфера неба + ambient + солнце по склону волны
  vec3 skyAmb = mix(uHorizon, uZenith, 0.5) * uSkyB;
  float nl = max(dot(n, L), 0.0);
  vec3 irr = skyAmb * 0.85 + uAmb * 0.55 + uLightCol * (0.12 + 0.88 * nl) * sh * 0.75;
  vec3 body = wcol * irr;

  // ===== подповерхностное рассеивание: свет внутри воды окрашивает впадины изумрудом =====
  float wrap = clamp(dot(n, L) * 0.55 + 0.45, 0.0, 1.0);
  float back = pow(clamp(dot(V, -L) * 0.5 + 0.5, 0.0, 1.0), 3.0);
  float thick = mix(1.15, 0.45, smoothstep(-0.5, 1.0, vCrest));
  body += sssTint * uLightCol * (wrap * 0.5 + back * 1.25) * thick * sh;
  body += sssTint * (0.10 + 0.22 * uSkyB) * thick;

  vec3 col;
  float alpha;
  if (!under) {
    vec3 R = reflect(-V, n);
    R.y = abs(R.y);
    col = mix(body, skyCol(R), F);
    // ===== острые блики-искорки: узкий глит + широкий блик + мягкая дымка =====
    vec3 H = normalize(L + V);
    float nh = max(dot(n, H), 0.0);
    float glint = pow(nh, 1200.0) * 26.0;
    float sheen = pow(nh, 120.0) * 2.2;
    float mid = pow(nh, 26.0) * 0.32;
    float spec = (glint + sheen + mid) * sh;
    col += uLightCol * spec * (0.35 + 0.65 * F);
    alpha = mix(uAlpha * 0.9, 1.0, F);
    alpha = min(1.0, alpha + spec * 0.5);
    // пена у берега: суша почти вплотную к поверхности воды
    float shore = 0.0;
    if (uShoreOn > 0.5) {
      vec2 dsz = vec2(textureSize(uDepthTex, 0));
      if (dsz.x > 1.0) {
        vec2 suv = gl_FragCoord.xy / dsz;
        float sz = texture(uDepthTex, suv).x;
        float ndcZ = sz * 2.0 - 1.0;
        float linZ = (2.0 * 0.1 * 3200.0) / (3200.0 + 0.1 - ndcZ * (3200.0 - 0.1));
        float gap = vDist - linZ;
        float broken = 0.55 + 0.45 * (s2.a * 0.55 + s3.a * 0.45);
        shore = (1.0 - smoothstep(0.03, 0.28, gap)) * step(0.0, gap) * broken * (0.65 + 0.35 * fade);
      }
    }
    float foam = max(vFoam * smoothstep(0.45, 0.75, s2.a * 0.6 + s3.a * 0.4), shore);
    vec3 fc = vec3(0.92, 0.96, 1.0) * clamp(dot(uAmb, vec3(0.33)) + 0.5 * length(uLightCol) * sh, 0.05, 1.0);
    col = mix(col, fc, foam);
    alpha = max(alpha, foam * 0.85);
  } else {
    vec3 Rf = refract(-V, n, 1.33);
    vec3 tr = dot(Rf, Rf) > 0.0 ? skyCol(Rf) * 0.8 : body * 0.2;
    col = mix(tr, body * 0.25, clamp(F + 0.2, 0.0, 1.0));
    alpha = min(1.0, uAlpha + 0.15);
  }
  col = applyFog(col);
  if (isnan(col.r) || isnan(col.g) || isnan(col.b)) col = uColor;
  o = vec4(col, alpha);
}"#;

const WATER_N: usize = 192;

const FIRE_VS: &str = r#"#version 300 es
precision highp float;
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNor;
uniform mat4 uVP;
uniform vec3 uPos;
uniform vec3 uSize;
out vec3 vW;
void main(){
  vec3 w = aPos * uSize + uPos;
  vW = w;
  gl_Position = uVP * vec4(w, 1.0);
}"#;

const FIRE_FS: &str = r#"#version 300 es
precision highp float;
precision highp sampler2D;
in vec3 vW;
uniform sampler2D uTex;
uniform vec3 uPos;
uniform vec3 uSize;
uniform vec3 uCam;
uniform float uTime;
uniform vec3 uColor;
uniform float uInt;
out vec4 o;

float hash3(vec3 p){
  p = fract(p * 0.1031);
  p += dot(p, p.yzx + 33.33);
  return fract((p.x + p.y) * p.z);
}

// псевдо-3D шум из двух слоёв 2D-текстуры
float n3(vec3 p){
  float iz = floor(p.z);
  float fz = fract(p.z);
  fz = fz * fz * (3.0 - 2.0 * fz);
  vec2 k = vec2(0.317, 0.571);
  float a = textureLod(uTex, p.xy * 0.17 + k * iz, 0.0).r;
  float b = textureLod(uTex, p.xy * 0.17 + k * (iz + 1.0), 0.0).r;
  return mix(a, b, fz);
}

float dens(vec3 p, float sd, out float heat){
  heat = 0.0;
  vec3 l = p - vec3(uPos.x, uPos.y - uSize.y * 0.5, uPos.z);
  float h = l.y / uSize.y;
  if (h < 0.0 || h > 1.0) return 0.0;
  vec2 xz = l.xz / (0.5 * min(uSize.x, uSize.z));
  float R = 0.62 * pow(1.0 - h, 0.65) + 0.05;
  if (length(xz) > R + 0.9) return 0.0;
  float t = uTime;
  // два шума: крупный медленно искажает быстрый по горизонтали — пламя извивается
  float wob = n3(vec3(xz.x * 0.8 + sd, t * 0.42, xz.y * 0.8 - t * 0.13)) * 2.0 - 1.0;
  float wob2 = n3(vec3(xz.x * 0.55 + sd * 1.7 + 7.0, t * 0.31 + 3.0, xz.y * 0.55)) * 2.0 - 1.0;
  vec2 warp = vec2(wob, wob2) * (0.22 + 0.62 * h);
  vec2 xzw = xz + warp;
  vec3 q1 = vec3(xzw.x * 1.2, h * 2.0 - t * 1.05, xzw.y * 1.2 + t * 0.2) * 1.6 + sd;
  float n = n3(q1) * 0.65 + n3(q1 * 2.1 + 4.7) * 0.35;
  vec3 q2 = vec3(xzw.x * 2.0 + 3.0, h * 3.4 - t * 1.7, xzw.y * 2.0 + t * 0.3) * 1.6 + sd * 1.3;
  float n2 = n3(q2);
  vec2 w = xzw + (vec2(n, n2) - 0.5) * (0.2 + h);
  float r = length(w);
  float body = 1.0 - smoothstep(R * 0.3, R, r);
  float tip = 1.0 - smoothstep(0.5, 1.0, h + (n - 0.5) * 0.7);
  float d = body * tip * smoothstep(0.0, 0.05, h);
  d *= 0.6 + 0.8 * n2;
  // жёсткий контраст: рваные чёткие края пламени вместо дымки
  d = smoothstep(0.16, 0.52, d);
  heat = clamp(d * 1.5 * (1.15 - 0.8 * h), 0.0, 1.0);
  return d;
}

// искры: мелкие светящиеся точки, отрывающиеся от пламени и летящие вверх
float sparks(vec3 l, float sd, float h){
  float fade = (1.0 - smoothstep(0.35, 1.8, h)) * smoothstep(-0.02, 0.14, h);
  if (fade <= 0.001) return 0.0;
  float s = 0.0;
  for (int k = 0; k < 2; k++) {
    float sc = 6.0 + float(k) * 5.0;
    float sp = 1.5 + float(k) * 1.1;
    vec3 q = vec3(l.x, l.y - uTime * sp, l.z) * sc + sd * (3.0 + float(k));
    vec3 cell = floor(q);
    vec3 f = fract(q) - 0.5;
    float id = hash3(cell + float(k) * 17.0);
    if (id > 0.86) {
      vec3 j = vec3(hash3(cell + 1.7), hash3(cell + 3.1), hash3(cell + 5.3)) - 0.5;
      float d = length(f - j * 0.42);
      float tw = 0.55 + 0.45 * sin(uTime * (7.0 + id * 9.0) + id * 40.0);
      s += smoothstep(0.17, 0.03, d) * tw * smoothstep(0.86, 0.97, id);
    }
  }
  return s * fade;
}

vec3 ramp(float x){
  vec3 c = mix(vec3(0.35, 0.02, 0.0), vec3(1.0, 0.28, 0.02), smoothstep(0.0, 0.35, x));
  c = mix(c, vec3(1.0, 0.65, 0.12), smoothstep(0.3, 0.65, x));
  c = mix(c, vec3(1.0, 0.95, 0.7), smoothstep(0.65, 1.0, x));
  return c;
}

void main(){
  vec3 ro = uCam;
  vec3 rd = normalize(vW - uCam);
  vec3 hb = uSize * 0.5;
  vec3 rds = max(abs(rd), vec3(1e-4)) * (step(vec3(0.0), rd) * 2.0 - 1.0);
  vec3 inv = 1.0 / rds;
  vec3 t0 = (uPos - hb - ro) * inv;
  vec3 t1 = (uPos + hb - ro) * inv;
  vec3 tmn = min(t0, t1);
  vec3 tmx = max(t0, t1);
  float tn = max(max(tmn.x, tmn.y), max(tmn.z, 0.0));
  float tf = min(min(tmx.x, tmx.y), tmx.z);
  if (tf <= tn) discard;
  float rs = 0.5 * min(uSize.x, uSize.z);
  int N = int(clamp((tf - tn) / rs * 14.0, 8.0, 28.0));
  float dt = (tf - tn) / float(N);
  float jit = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
  float sd = uPos.x * 0.37 + uPos.z * 0.61;
  vec3 acc = vec3(0.0);
  vec3 spAcc = vec3(0.0);
  float occ = 0.0;
  for (int i = 0; i < N; i++) {
    vec3 p = ro + rd * (tn + (float(i) + jit) * dt);
    float heat;
    float d = dens(p, sd, heat);
    acc += ramp(heat) * d * (0.5 + 1.8 * heat) * dt;
    occ += d * dt;
    vec3 l = p - vec3(uPos.x, uPos.y - uSize.y * 0.5, uPos.z);
    spAcc += vec3(1.0, 0.72, 0.32) * sparks(l, sd, l.y / max(uSize.y, 0.001)) * dt;
  }
  acc *= 1.0 / rs;
  spAcc *= 1.0 / rs;
  vec3 tint = clamp(uColor / vec3(1.0, 0.5, 0.12), 0.0, 2.0);
  float fl = 0.92 + 0.08 * sin(uTime * 13.0 + uPos.x) + 0.04 * sin(uTime * 29.0);
  float cov = (1.0 - exp(-occ * 1.5 / rs)) * 0.85 * clamp(uInt, 0.0, 1.0);
  // жёсткий контраст по альфе: пламя с рваными краями
  cov = smoothstep(0.06, 0.42, cov);
  vec3 col = acc * tint * uInt * fl + spAcc * uInt * 1.6;
  float scov = clamp(length(spAcc) * 1.4, 0.0, 1.0) * clamp(uInt, 0.0, 1.0);
  o = vec4(col, clamp(cov + scov, 0.0, 1.0));
}"#;

fn upload_tex(gl: &GL, tex: &WebGlTexture, px: &[u8], size: i32) -> Result<(), JsValue> {
    gl.bind_texture(GL::TEXTURE_2D, Some(tex));
    gl.tex_image_2d_with_i32_and_i32_and_i32_and_format_and_type_and_opt_u8_array(
        GL::TEXTURE_2D, 0, GL::RGBA as i32, size, size, 0, GL::RGBA, GL::UNSIGNED_BYTE, Some(px),
    )?;
    gl.generate_mipmap(GL::TEXTURE_2D);
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_MIN_FILTER, GL::LINEAR_MIPMAP_LINEAR as i32);
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_MAG_FILTER, GL::LINEAR as i32);
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_WRAP_S, GL::REPEAT as i32);
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_WRAP_T, GL::REPEAT as i32);
    Ok(())
}

fn make_tex(gl: &GL, px: &[u8], size: i32) -> Result<WebGlTexture, JsValue> {
    let tex = gl.create_texture().ok_or("texture")?;
    gl.bind_texture(GL::TEXTURE_2D, Some(&tex));
    gl.tex_image_2d_with_i32_and_i32_and_i32_and_format_and_type_and_opt_u8_array(
        GL::TEXTURE_2D, 0, GL::RGBA as i32, size, size, 0, GL::RGBA, GL::UNSIGNED_BYTE, Some(px),
    )?;
    gl.generate_mipmap(GL::TEXTURE_2D);
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_MIN_FILTER, GL::LINEAR_MIPMAP_LINEAR as i32);
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_MAG_FILTER, GL::LINEAR as i32);
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_WRAP_S, GL::REPEAT as i32);
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_WRAP_T, GL::REPEAT as i32);
    Ok(tex)
}

/// Плоская индексированная сетка n×n в [-0.5, 0.5]² (вершины vec2).
fn make_grid(gl: &GL, n: usize) -> Result<(WebGlVertexArrayObject, i32), JsValue> {
    let mut v: Vec<f32> = Vec::with_capacity((n + 1) * (n + 1) * 2);
    for j in 0..=n {
        for i in 0..=n {
            v.push(i as f32 / n as f32 - 0.5);
            v.push(j as f32 / n as f32 - 0.5);
        }
    }
    let w = (n + 1) as u32;
    let mut idx: Vec<u32> = Vec::with_capacity(n * n * 6);
    for j in 0..n as u32 {
        for i in 0..n as u32 {
            let a = j * w + i;
            let b = a + 1;
            let c = a + w;
            let d = c + 1;
            idx.extend_from_slice(&[a, b, d, a, d, c]);
        }
    }
    let vao = gl.create_vertex_array().ok_or("vao")?;
    gl.bind_vertex_array(Some(&vao));
    let buf = gl.create_buffer().ok_or("buf")?;
    gl.bind_buffer(GL::ARRAY_BUFFER, Some(&buf));
    unsafe {
        let view = js_sys::Float32Array::view(&v);
        gl.buffer_data_with_array_buffer_view(GL::ARRAY_BUFFER, &view, GL::STATIC_DRAW);
    }
    gl.enable_vertex_attrib_array(0);
    gl.vertex_attrib_pointer_with_i32(0, 2, GL::FLOAT, false, 8, 0);
    let ib = gl.create_buffer().ok_or("ibuf")?;
    gl.bind_buffer(GL::ELEMENT_ARRAY_BUFFER, Some(&ib));
    unsafe {
        let view = js_sys::Uint32Array::view(&idx);
        gl.buffer_data_with_array_buffer_view(GL::ELEMENT_ARRAY_BUFFER, &view, GL::STATIC_DRAW);
    }
    gl.bind_vertex_array(None);
    Ok((vao, idx.len() as i32))
}

/// Вектор выталкивания сферы из повёрнутой коробки (None, если нет контакта).
fn sphere_obb(c: Vec3, r: f32, pos: Vec3, rot: Quat, size: Vec3) -> Option<Vec3> {
    let inv = rot.inverse();
    let l = inv * (c - pos);
    let h = size * 0.5;
    let cl = l.clamp(-h, h);
    let d = l - cl;
    let dist2 = d.length_squared();
    if dist2 > r * r {
        return None;
    }
    let (n, pen) = if dist2 > 1e-10 {
        let dist = dist2.sqrt();
        (d / dist, r - dist)
    } else {
        let dx = h - l.abs();
        let (axis, depth) = if dx.x <= dx.y && dx.x <= dx.z {
            (Vec3::X * l.x.signum(), dx.x)
        } else if dx.y <= dx.z {
            (Vec3::Y * l.y.signum(), dx.y)
        } else {
            (Vec3::Z * l.z.signum(), dx.z)
        };
        (axis, depth + r)
    };
    Some(rot * (n * pen))
}

/// Выталкивание сферы из фигуры с учётом формы (1 призма, 2 сфера, 3 колесо, 4 овал).
fn shape_push(c: Vec3, r: f32, pos: Vec3, rot: Quat, size: Vec3, shape: u32) -> Option<Vec3> {
    let inv = rot.inverse();
    let l = inv * (c - pos);
    let h = (size * 0.5).max(Vec3::splat(1e-3));
    match shape {
        // сфера / овал -> эллипсоид
        2 | 4 => {
            let hy = if shape == 4 { h.y * 0.64 } else { h.y };
            let hs = Vec3::new(h.x, hy.max(1e-3), h.z);
            let s = Vec3::new(l.x / hs.x, l.y / hs.y, l.z / hs.z);
            let k = s.length();
            if k < 1e-5 {
                return Some(rot * Vec3::new(0.0, r + hs.y, 0.0));
            }
            let nloc = Vec3::new(s.x / hs.x, s.y / hs.y, s.z / hs.z).normalize_or_zero();
            let minh = hs.min_element();
            let pen = (1.0 - k) * minh + r;
            if pen <= 0.0 {
                return None;
            }
            Some(rot * (nloc * pen))
        }
        // колесо -> эллиптический цилиндр вдоль Z
        3 => {
            let rx = h.x.max(1e-3);
            let ry = h.y.max(1e-3);
            let qx = l.x / rx;
            let qy = l.y / ry;
            let k = (qx * qx + qy * qy).sqrt();
            let minr = rx.min(ry);
            let zpen = h.z - l.z.abs() + r;
            if k < 1e-5 {
                if zpen > 0.0 {
                    let s = if l.z >= 0.0 { 1.0 } else { -1.0 };
                    return Some(rot * Vec3::new(0.0, 0.0, zpen * s));
                }
                return None;
            }
            let nx = (qx / rx) / (k * (1.0 / rx).max(1e-6));
            let ny = (qy / ry) / (k * (1.0 / ry).max(1e-6));
            let n2 = Vec3::new(nx, ny, 0.0).normalize_or_zero();
            let rpen = (1.0 - k) * minr + r;
            if rpen <= 0.0 && zpen <= 0.0 {
                return None;
            }
            if zpen > 0.0 && (rpen <= 0.0 || zpen < rpen) {
                let s = if l.z >= 0.0 { 1.0 } else { -1.0 };
                Some(rot * Vec3::new(0.0, 0.0, zpen * s))
            } else {
                Some(rot * (n2 * rpen))
            }
        }
        // треугольная призма -> пересечение полупространств (глубокая грань)
        1 => {
            let hz = h.z;
            let a = Vec3::new(-h.x, -h.y, 0.0);
            let b = Vec3::new(h.x, -h.y, 0.0);
            let cc = Vec3::new(0.0, h.y, 0.0);
            let mut planes: Vec<(Vec3, Vec3, Vec3)> = Vec::new();
            // рёбра треугольника (нормаль наружу от третьей вершины)
            for (p0, p1, out) in [(a, cc, b), (cc, b, a), (b, a, cc)] {
                let e = p1 - p0;
                let mut n = Vec3::new(-e.y, e.x, 0.0).normalize_or_zero();
                if (out - p0).dot(n) > 0.0 {
                    n = -n;
                }
                planes.push((p0, n, out));
            }
            let mut best: Option<(f32, Vec3)> = None;
            for (p0, n, _) in &planes {
                let sd = (l - *p0).dot(*n);
                if best.map_or(true, |(s, _)| sd > s) {
                    best = Some((sd, *n));
                }
            }
            for (n, sd0) in [(Vec3::Z, l.z - hz), (Vec3::NEG_Z, -l.z - hz)] {
                if best.map_or(true, |(s, _)| sd0 > s) {
                    best = Some((sd0, n));
                }
            }
            match best {
                Some((sd, n)) if sd < r => Some(rot * (n * (r - sd))),
                _ => None,
            }
        }
        _ => sphere_obb(c, r, pos, rot, size),
    }
}

/// Капсула от y=0 (ступни) до y=h, вершины: позиция + нормаль.
fn capsule_mesh(r: f32, h: f32) -> Vec<f32> {
    let (st, sl) = (8usize, 20usize);
    let mut rings: Vec<(f32, f32)> = Vec::new();
    for i in 0..=st {
        rings.push((PI * 0.5 * i as f32 / st as f32, h - r));
    }
    for i in 0..=st {
        rings.push((PI * 0.5 + PI * 0.5 * i as f32 / st as f32, r));
    }
    let pt = |ri: usize, j: usize| -> (Vec3, Vec3) {
        let (th, yc) = rings[ri];
        let ph = 2.0 * PI * j as f32 / sl as f32;
        let n = Vec3::new(th.sin() * ph.cos(), th.cos(), th.sin() * ph.sin());
        (Vec3::new(n.x * r, yc + n.y * r, n.z * r), n)
    };
    let mut v = Vec::new();
    for ri in 0..rings.len() - 1 {
        for j in 0..sl {
            let (a, b, c, d) = (pt(ri, j), pt(ri + 1, j), pt(ri + 1, j + 1), pt(ri, j + 1));
            for q in [a, b, c, a, c, d] {
                v.extend_from_slice(&[q.0.x, q.0.y, q.0.z, q.1.x, q.1.y, q.1.z]);
            }
        }
    }
    v
}

/// Тор вокруг оси Y: большой радиус 1, малый 0.03.
fn ring_mesh() -> Vec<f32> {
    let (ns, nm) = (64usize, 8usize);
    let m = 0.03f32;
    let pt = |i: usize, j: usize| -> (Vec3, Vec3) {
        let a = 2.0 * PI * i as f32 / ns as f32;
        let b = 2.0 * PI * j as f32 / nm as f32;
        let c = Vec3::new(a.cos(), 0.0, a.sin());
        let n = c * b.cos() + Vec3::Y * b.sin();
        (c + n * m, n)
    };
    let mut v = Vec::new();
    for i in 0..ns {
        for j in 0..nm {
            let (a, b, c, d) = (pt(i, j), pt(i + 1, j), pt(i + 1, j + 1), pt(i, j + 1));
            for q in [a, b, c, a, c, d] {
                v.extend_from_slice(&[q.0.x, q.0.y, q.0.z, q.1.x, q.1.y, q.1.z]);
            }
        }
    }
    v
}

fn sphere_mesh() -> Vec<f32> {
    let (st, sl) = (12usize, 16usize);
    let p = |i: usize, j: usize| {
        let th = PI * i as f32 / st as f32;
        let ph = 2.0 * PI * j as f32 / sl as f32;
        Vec3::new(th.sin() * ph.cos(), th.cos(), th.sin() * ph.sin())
    };
    let mut v = Vec::new();
    for i in 0..st {
        for j in 0..sl {
            let (a, b, c, d) = (p(i, j), p(i + 1, j), p(i + 1, j + 1), p(i, j + 1));
            for q in [a, b, c, a, c, d] {
                v.extend_from_slice(&[q.x, q.y, q.z, q.x, q.y, q.z]);
            }
        }
    }
    v
}


// ---------- фигуры и режим правки ----------
fn tri_n(v: &mut Vec<f32>, a: Vec3, b: Vec3, c: Vec3, n: Vec3) {
    let nn = (b - a).cross(c - a);
    let (b, c) = if nn.dot(n) >= 0.0 { (b, c) } else { (c, b) };
    for q in [a, b, c] {
        v.extend_from_slice(&[q.x, q.y, q.z, n.x, n.y, n.z]);
    }
}

fn all_cells(cps: usize) -> u64 {
    if cps * cps * cps >= 64 { u64::MAX } else { (1u64 << (cps * cps * cps)) - 1 }
}

/// Бокс [bmin,bmax] в единичном пространстве [-0.5,0.5]^3 со скруглением r (0..1 от полу-стороны).
fn rounded_box_mesh(bmin: Vec3, bmax: Vec3, res: usize, r: f32) -> Vec<f32> {
    let ext = bmax - bmin;
    let cen = (bmax + bmin) * 0.5;
    let faces: [(Vec3, Vec3, Vec3); 6] = [
        (Vec3::X, Vec3::Y, Vec3::Z), (Vec3::NEG_X, Vec3::Y, Vec3::NEG_Z),
        (Vec3::Y, Vec3::X, Vec3::NEG_Z), (Vec3::NEG_Y, Vec3::X, Vec3::Z),
        (Vec3::Z, Vec3::Y, Vec3::NEG_X), (Vec3::NEG_Z, Vec3::Y, Vec3::X),
    ];
    let rm = |p: Vec3| -> (Vec3, Vec3) {
        if r < 0.001 {
            let a = p.abs();
            let n = if a.x >= a.y && a.x >= a.z {
                Vec3::X * if p.x < 0.0 { -1.0 } else { 1.0 }
            } else if a.y >= a.z {
                Vec3::Y * if p.y < 0.0 { -1.0 } else { 1.0 }
            } else {
                Vec3::Z * if p.z < 0.0 { -1.0 } else { 1.0 }
            };
            (p, n)
        } else {
            let lim = Vec3::splat(0.5 - r);
            let inner = p.clamp(-lim, lim);
            let d = p - inner;
            let n = d.normalize_or_zero();
            (inner + n * r, n)
        }
    };
    let mut v = Vec::new();
    for (n, u, w) in faces {
        for i in 0..res {
            for j in 0..res {
                let a0 = -1.0 + 2.0 * i as f32 / res as f32;
                let b0 = -1.0 + 2.0 * j as f32 / res as f32;
                let a1 = -1.0 + 2.0 * (i + 1) as f32 / res as f32;
                let b1 = -1.0 + 2.0 * (j + 1) as f32 / res as f32;
                for (a, b) in [(a0, b0), (a1, b0), (a1, b1), (a0, b0), (a1, b1), (a0, b1)] {
                    let p = n * 0.5 + u * (a * 0.5) + w * (b * 0.5);
                    let (q, nr) = rm(p);
                    let pos = cen + q * ext;
                    let nor = (nr / ext).normalize_or_zero();
                    v.extend_from_slice(&[pos.x, pos.y, pos.z, nor.x, nor.y, nor.z]);
                }
            }
        }
    }
    v
}

/// Меш режима правки: сетка ячеек + удалённые ячейки + скругление.
fn edit_mesh(subdiv: u32, round: f32, cells: u64) -> Vec<f32> {
    let cps = [1usize, 2, 4][subdiv.min(2) as usize];
    let all = all_cells(cps);
    let cells = cells & all;
    if cells == all && round < 0.001 {
        return if cps == 1 { cube() } else {
            rounded_box_mesh(Vec3::splat(-0.5), Vec3::splat(0.5), 1, 0.0)
        };
    }
    if cells == all {
        return rounded_box_mesh(Vec3::splat(-0.5), Vec3::splat(0.5), 8, round);
    }
    let idx = |x: usize, y: usize, z: usize| x + y * cps + z * cps * cps;
    let on = |x: usize, y: usize, z: usize| (cells >> idx(x, y, z)) & 1 == 1;
    let mut used = vec![false; cps * cps * cps];
    let mut out = Vec::new();
    let s = cps as f32;
    for z in 0..cps {
        for y in 0..cps {
            for x in 0..cps {
                let i = idx(x, y, z);
                if used[i] || !on(x, y, z) {
                    continue;
                }
                let mut ex = x;
                while ex + 1 < cps && on(ex + 1, y, z) && !used[idx(ex + 1, y, z)] {
                    ex += 1;
                }
                let mut ey = y;
                'yl: while ey + 1 < cps {
                    for xx in x..=ex {
                        if !on(xx, ey + 1, z) || used[idx(xx, ey + 1, z)] {
                            break 'yl;
                        }
                    }
                    ey += 1;
                }
                let mut ez = z;
                'zl: while ez + 1 < cps {
                    for yy in y..=ey {
                        for xx in x..=ex {
                            if !on(xx, yy, ez + 1) || used[idx(xx, yy, ez + 1)] {
                                break 'zl;
                            }
                        }
                    }
                    ez += 1;
                }
                for zz in z..=ez {
                    for yy in y..=ey {
                        for xx in x..=ex {
                            used[idx(xx, yy, zz)] = true;
                        }
                    }
                }
                let bmin = Vec3::new(x as f32 / s - 0.5, y as f32 / s - 0.5, z as f32 / s - 0.5);
                let bmax = Vec3::new((ex + 1) as f32 / s - 0.5, (ey + 1) as f32 / s - 0.5, (ez + 1) as f32 / s - 0.5);
                out.extend_from_slice(&rounded_box_mesh(bmin, bmax, if round > 0.001 { 5 } else { 1 }, round));
            }
        }
    }
    out
}

/// 0 куб, 1 треугольная призма, 2 сфера, 3 колесо (диск+ступица), 4 овал (подушка).
fn shape_mesh(shape: u32) -> Vec<f32> {
    match shape {
        1 => {
            let mut v = Vec::new();
            let a = Vec3::new(-0.5, -0.5, -0.5);
            let b = Vec3::new(0.5, -0.5, -0.5);
            let c = Vec3::new(0.0, 0.5, -0.5);
            let a2 = Vec3::new(-0.5, -0.5, 0.5);
            let b2 = Vec3::new(0.5, -0.5, 0.5);
            let c2 = Vec3::new(0.0, 0.5, 0.5);
            tri_n(&mut v, a2, b2, c2, Vec3::Z);
            tri_n(&mut v, a, b, c, Vec3::NEG_Z);
            tri_n(&mut v, a, b, b2, Vec3::NEG_Y);
            tri_n(&mut v, a, b2, a2, Vec3::NEG_Y);
            let nl = (Vec3::new(0.0, 0.5, 0.0) - Vec3::new(-0.5, -0.5, 0.0))
                .cross(Vec3::new(0.0, 0.0, 1.0))
                .normalize();
            tri_n(&mut v, a, c, c2, nl);
            tri_n(&mut v, a, c2, a2, nl);
            let nr = Vec3::new(-nl.x, nl.y, nl.z);
            tri_n(&mut v, b, c, c2, nr);
            tri_n(&mut v, b, c2, b2, nr);
            v
        }
        2 => sphere_mesh().chunks_exact(6).flat_map(|q| {
            let mut o = [0f32; 6];
            o[..3].copy_from_slice(&[q[0] * 0.5, q[1] * 0.5, q[2] * 0.5]);
            o[3..].copy_from_slice(&[q[3], q[4], q[5]]);
            o
        }).collect(),
        3 => {
            let mut v = Vec::new();
            let seg = 24usize;
            let (rd, zd, rh, zh) = (0.5f32, 0.32f32, 0.17f32, 0.5f32);
            let ring = |r: f32, z: f32, j: usize| -> Vec3 {
                let t = 2.0 * PI * j as f32 / seg as f32;
                Vec3::new(t.cos() * r, t.sin() * r, z)
            };
            for j in 0..seg {
                let (p0, p1) = (ring(rd, -zd, j), ring(rd, -zd, j + 1));
                let (p2, p3) = (ring(rd, zd, j), ring(rd, zd, j + 1));
                let n0 = Vec3::new(p0.x, p0.y, 0.0).normalize();
                let n1 = Vec3::new(p1.x, p1.y, 0.0).normalize();
                tri_n(&mut v, p0, p1, p3, n0);
                tri_n(&mut v, p0, p3, p2, n0);
                let _ = n1;
                let (q0, q1) = (ring(rh, -zh, j), ring(rh, -zh, j + 1));
                let (q2, q3) = (ring(rh, zh, j), ring(rh, zh, j + 1));
                let hn = Vec3::new(q0.x, q0.y, 0.0).normalize();
                tri_n(&mut v, q0, q1, q3, hn);
                tri_n(&mut v, q0, q3, q2, hn);
                let (i0, i1) = (ring(rh, -zd, j), ring(rh, -zd, j + 1));
                let (o0, o1) = (ring(rd, -zd, j), ring(rd, -zd, j + 1));
                tri_n(&mut v, i0, o0, o1, Vec3::NEG_Z);
                tri_n(&mut v, i0, o1, i1, Vec3::NEG_Z);
                let (i2, i3) = (ring(rh, zd, j), ring(rh, zd, j + 1));
                let (o2, o3) = (ring(rd, zd, j), ring(rd, zd, j + 1));
                tri_n(&mut v, i2, o2, o3, Vec3::Z);
                tri_n(&mut v, i2, o3, i3, Vec3::Z);
                let hc = Vec3::new(0.0, 0.0, -zh);
                tri_n(&mut v, hc, ring(rh, -zh, j), ring(rh, -zh, j + 1), Vec3::NEG_Z);
                let hcz = Vec3::new(0.0, 0.0, zh);
                tri_n(&mut v, hcz, ring(rh, zh, j), ring(rh, zh, j + 1), Vec3::Z);
            }
            v
        }
        4 => sphere_mesh().chunks_exact(6).flat_map(|q| {
            let p = Vec3::new(q[0] * 0.5, q[1] * 0.32, q[2] * 0.5);
            let n = (Vec3::new(q[3] / 0.5, q[4] / 0.32, q[5] / 0.5)).normalize_or_zero();
            let mut o = [0f32; 6];
            o[..3].copy_from_slice(&[p.x, p.y, p.z]);
            o[3..].copy_from_slice(&[n.x, n.y, n.z]);
            o
        }).collect(),
        _ => cube(),
    }
}

const EDIT_VS: &str = r#"#version 300 es
precision highp float;
layout(location=0) in vec3 aPos;
uniform mat4 uVP;
void main(){
  gl_Position = uVP * vec4(aPos, 1.0);
}"#;

const EDIT_FS: &str = r#"#version 300 es
precision highp float;
uniform vec4 uColor;
out vec4 o;
void main(){
  o = uColor;
}"#;

/// Параметр точки на прямой (p + s*a), ближайшей к лучу (o, d).
fn axis_param(o: Vec3, d: Vec3, p: Vec3, a: Vec3) -> Option<f32> {
    let w0 = p - o;
    let b = a.dot(d);
    let den = 1.0 - b * b;
    if den < 1e-4 {
        return None;
    }
    Some((b * d.dot(w0) - a.dot(w0)) / den)
}

// ---------- GL-хелперы ----------
fn compile(gl: &GL, kind: u32, src: &str) -> Result<WebGlShader, JsValue> {
    let s = gl.create_shader(kind).ok_or("create_shader")?;
    gl.shader_source(&s, src);
    gl.compile_shader(&s);
    if gl.get_shader_parameter(&s, GL::COMPILE_STATUS).as_bool().unwrap_or(false) {
        Ok(s)
    } else {
        Err(gl.get_shader_info_log(&s).unwrap_or_default().into())
    }
}

struct Prog {
    p: WebGlProgram,
    u: HashMap<String, WebGlUniformLocation>,
}

impl Prog {
    fn new(gl: &GL, vs: &str, fs: &str, names: &[&str]) -> Result<Prog, JsValue> {
        let p = gl.create_program().ok_or("create_program")?;
        gl.attach_shader(&p, &compile(gl, GL::VERTEX_SHADER, vs)?);
        gl.attach_shader(&p, &compile(gl, GL::FRAGMENT_SHADER, fs)?);
        gl.link_program(&p);
        if !gl.get_program_parameter(&p, GL::LINK_STATUS).as_bool().unwrap_or(false) {
            return Err(gl.get_program_info_log(&p).unwrap_or_default().into());
        }
        let mut u = HashMap::new();
        for n in names {
            if let Some(l) = gl.get_uniform_location(&p, n) {
                u.insert(n.to_string(), l);
            }
        }
        Ok(Prog { p, u })
    }

    fn l(&self, n: &str) -> Option<&WebGlUniformLocation> {
        self.u.get(n)
    }
}

fn u3(gl: &GL, l: Option<&WebGlUniformLocation>, v: Vec3) {
    gl.uniform3f(l, v.x, v.y, v.z);
}

struct Target {
    fbo: WebGlFramebuffer,
    tex: WebGlTexture,
    depth: Option<WebGlRenderbuffer>,
    w: i32,
    h: i32,
}

/// Текстура глубины (копия сцены) — нужна воде для пены у берега.
/// (Фиктивный color-аттачмент делает FBO полным без draw_buffers.)
fn make_depth_view(gl: &GL, w: i32, h: i32) -> Result<(WebGlFramebuffer, WebGlTexture, WebGlTexture), JsValue> {
    let tex = gl.create_texture().ok_or("depth tex")?;
    gl.bind_texture(GL::TEXTURE_2D, Some(&tex));
    if gl.tex_image_2d_with_i32_and_i32_and_i32_and_format_and_type_and_opt_u8_array(
        GL::TEXTURE_2D, 0, GL::DEPTH_COMPONENT24 as i32, w, h, 0,
        GL::DEPTH_COMPONENT, GL::UNSIGNED_INT, None,
    ).is_err() {
        gl.tex_image_2d_with_i32_and_i32_and_i32_and_format_and_type_and_opt_u8_array(
            GL::TEXTURE_2D, 0, GL::DEPTH_COMPONENT16 as i32, w, h, 0,
            GL::DEPTH_COMPONENT, GL::UNSIGNED_SHORT, None,
        )?;
    }
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_MIN_FILTER, GL::NEAREST as i32);
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_MAG_FILTER, GL::NEAREST as i32);
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_WRAP_S, GL::CLAMP_TO_EDGE as i32);
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_WRAP_T, GL::CLAMP_TO_EDGE as i32);
    let dummy = gl.create_texture().ok_or("depth dummy")?;
    gl.bind_texture(GL::TEXTURE_2D, Some(&dummy));
    gl.tex_image_2d_with_i32_and_i32_and_i32_and_format_and_type_and_opt_u8_array(
        GL::TEXTURE_2D, 0, GL::RGBA8 as i32, w, h, 0, GL::RGBA, GL::UNSIGNED_BYTE, None,
    )?;
    let fbo = gl.create_framebuffer().ok_or("depth fbo")?;
    gl.bind_framebuffer(GL::FRAMEBUFFER, Some(&fbo));
    gl.framebuffer_texture_2d(GL::FRAMEBUFFER, GL::DEPTH_ATTACHMENT, GL::TEXTURE_2D, Some(&tex), 0);
    gl.framebuffer_texture_2d(GL::FRAMEBUFFER, GL::COLOR_ATTACHMENT0, GL::TEXTURE_2D, Some(&dummy), 0);
    let status = gl.check_framebuffer_status(GL::FRAMEBUFFER);
    gl.bind_framebuffer(GL::FRAMEBUFFER, None);
    if status != GL::FRAMEBUFFER_COMPLETE {
        gl.delete_framebuffer(Some(&fbo));
        gl.delete_texture(Some(&tex));
        gl.delete_texture(Some(&dummy));
        return Err("depth fbo incomplete".into());
    }
    Ok((fbo, tex, dummy))
}

fn free_target(gl: &GL, t: &Target) {
    gl.delete_framebuffer(Some(&t.fbo));
    gl.delete_texture(Some(&t.tex));
    if let Some(d) = &t.depth {
        gl.delete_renderbuffer(Some(d));
    }
}

fn make_target(gl: &GL, w: i32, h: i32, hdr: bool, with_depth: bool) -> Result<Target, JsValue> {
    let tex = gl.create_texture().ok_or("texture")?;
    gl.bind_texture(GL::TEXTURE_2D, Some(&tex));
    let (ifmt, ty) = if hdr { (GL::RGBA16F, GL::HALF_FLOAT) } else { (GL::RGBA8, GL::UNSIGNED_BYTE) };
    gl.tex_image_2d_with_i32_and_i32_and_i32_and_format_and_type_and_opt_u8_array(
        GL::TEXTURE_2D, 0, ifmt as i32, w, h, 0, GL::RGBA, ty, None,
    )?;
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_MIN_FILTER, GL::LINEAR as i32);
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_MAG_FILTER, GL::LINEAR as i32);
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_WRAP_S, GL::CLAMP_TO_EDGE as i32);
    gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_WRAP_T, GL::CLAMP_TO_EDGE as i32);

    let fbo = gl.create_framebuffer().ok_or("framebuffer")?;
    gl.bind_framebuffer(GL::FRAMEBUFFER, Some(&fbo));
    gl.framebuffer_texture_2d(GL::FRAMEBUFFER, GL::COLOR_ATTACHMENT0, GL::TEXTURE_2D, Some(&tex), 0);
    let depth = if with_depth {
        let rb = gl.create_renderbuffer().ok_or("renderbuffer")?;
        gl.bind_renderbuffer(GL::RENDERBUFFER, Some(&rb));
        gl.renderbuffer_storage(GL::RENDERBUFFER, GL::DEPTH_COMPONENT24, w, h);
        gl.framebuffer_renderbuffer(GL::FRAMEBUFFER, GL::DEPTH_ATTACHMENT, GL::RENDERBUFFER, Some(&rb));
        Some(rb)
    } else {
        None
    };
    let status = gl.check_framebuffer_status(GL::FRAMEBUFFER);
    gl.bind_framebuffer(GL::FRAMEBUFFER, None);
    let t = Target { fbo, tex, depth, w, h };
    if status != GL::FRAMEBUFFER_COMPLETE {
        free_target(gl, &t);
        return Err("framebuffer incomplete".into());
    }
    Ok(t)
}

fn make_set(gl: &GL, w: i32, h: i32, hdr: bool) -> Result<(Target, Target, Target), JsValue> {
    let (bw, bh) = ((w / 4).max(1), (h / 4).max(1));
    let s = make_target(gl, w, h, hdr, true)?;
    let a = match make_target(gl, bw, bh, hdr, false) {
        Ok(t) => t,
        Err(e) => {
            free_target(gl, &s);
            return Err(e);
        }
    };
    let b = match make_target(gl, bw, bh, hdr, false) {
        Ok(t) => t,
        Err(e) => {
            free_target(gl, &s);
            free_target(gl, &a);
            return Err(e);
        }
    };
    Ok((s, a, b))
}

// ---------- геометрия ----------
fn cube() -> Vec<f32> {
    let mut v = Vec::new();
    for n in [Vec3::X, Vec3::NEG_X, Vec3::Y, Vec3::NEG_Y, Vec3::Z, Vec3::NEG_Z] {
        let u = n.cross(if n.y != 0.0 { Vec3::X } else { Vec3::Y });
        let w = n.cross(u);
        for (a, b) in [(-1., -1.), (1., -1.), (1., 1.), (-1., -1.), (1., 1.), (-1., 1.)] {
            let p = (n + u * a + w * b) * 0.5;
            v.extend_from_slice(&[p.x, p.y, p.z, n.x, n.y, n.z]);
        }
    }
    v
}

/// Пересечение луча с повёрнутой коробкой.
fn ray_obb(origin: Vec3, dir: Vec3, pos: Vec3, rot: Quat, size: Vec3) -> Option<f32> {
    let inv = rot.inverse();
    let o = inv * (origin - pos);
    let d = inv * dir;
    let h = size * 0.5;
    let mut tmin = f32::NEG_INFINITY;
    let mut tmax = f32::INFINITY;
    for i in 0..3 {
        if d[i].abs() < 1e-8 {
            if o[i] < -h[i] || o[i] > h[i] {
                return None;
            }
        } else {
            let t1 = (-h[i] - o[i]) / d[i];
            let t2 = (h[i] - o[i]) / d[i];
            let (a, b) = if t1 < t2 { (t1, t2) } else { (t2, t1) };
            tmin = tmin.max(a);
            tmax = tmax.min(b);
            if tmin > tmax {
                return None;
            }
        }
    }
    if tmax < 0.0 {
        None
    } else {
        Some(if tmin > 0.0 { tmin } else { tmax })
    }
}

// ---------- небо / время суток ----------
fn sstep(a: f32, b: f32, x: f32) -> f32 {
    let t = ((x - a) / (b - a)).clamp(0.0, 1.0);
    t * t * (3.0 - 2.0 * t)
}

struct SkyState {
    zenith: Vec3,
    horizon: Vec3,
    sun_dir: Vec3,
    sun_col: Vec3,
    sun_vis: f32,
    night: f32,
    sunset: f32,
    light_dir: Vec3,
    light_col: Vec3,
    amb: Vec3,
}

fn sky_state(time: f32, ambient: f32) -> SkyState {
    let a = (time - 6.0) / 12.0 * PI;
    let sun_dir = Vec3::new(a.cos(), a.sin(), 0.35).normalize();
    let sy = sun_dir.y;
    let day = sstep(-0.12, 0.3, sy);
    let night = 1.0 - sstep(-0.25, 0.05, sy);
    let zenith = Vec3::new(0.01, 0.015, 0.05).lerp(Vec3::new(0.22, 0.46, 0.92), day);
    let horizon = Vec3::new(0.03, 0.04, 0.09).lerp(Vec3::new(0.66, 0.80, 0.95), day);
    let sunset = (-sy.abs() * 5.0).exp() * 0.9;
    let sun_vis = sstep(-0.08, 0.03, sy);
    let sun_int = sstep(0.0, 0.2, sy) * 0.8;
    let moon_int = 0.16 * sstep(0.0, 0.2, -sy);
    let sun_col = Vec3::new(1.0, 0.93, 0.8).lerp(Vec3::new(1.0, 0.55, 0.25), 1.0 - sstep(0.0, 0.45, sy));
    let light_col = sun_col * sun_int + Vec3::new(0.45, 0.55, 0.9) * moon_int;
    let light_dir = if sy >= 0.0 { sun_dir } else { -sun_dir };
    let amb = Vec3::new(0.06, 0.08, 0.16).lerp(Vec3::new(0.55, 0.60, 0.68), day) * ambient;
    SkyState { zenith, horizon, sun_dir, sun_col, sun_vis, night, sunset, light_dir, light_col, amb }
}

// ---------- сущности ----------
struct Entity {
    id: i32,
    name: String,
    pos: Vec3,
    rot: Vec3, // градусы
    size: Vec3,
    color: Vec3,
    neon: bool,
    alpha: f32,
    water: bool,
    fire: bool,
    mat: u32,
    wtex: bool,
    parent: i32,
    shape: u32,
    e_sub: u32,
    e_round: f32,
    e_cells: u64,
    mesh: Option<(WebGlVertexArrayObject, i32)>,
}

impl Entity {
    fn quat(&self) -> Quat {
        Quat::from_euler(
            EulerRot::XYZ,
            self.rot.x.to_radians(),
            self.rot.y.to_radians(),
            self.rot.z.to_radians(),
        )
    }
}

#[wasm_bindgen]
pub struct Engine {
    gl: GL,
    canvas: HtmlCanvasElement,
    prog: Prog,
    sky: Prog,
    bright: Prog,
    blur: Prog,
    post: Prog,
    vao: WebGlVertexArrayObject,
    empty_vao: WebGlVertexArrayObject,
    tex: WebGlTexture,
    hdr_ext: bool,
    shprog: Prog,
    water: Prog,
    fire: Prog,
    water_vaos: Vec<(WebGlVertexArrayObject, i32)>,
    ntex: WebGlTexture,
    wtex1: WebGlTexture,
    wtex2: WebGlTexture,
    mats: Vec<(WebGlTexture, WebGlTexture)>,
    wtex_img: Option<WebGlTexture>,
    aniso_ext: bool,
    aniso_max: f32,
    sh_size: i32,
    time: f32,
    gizmo: Prog,
    sphere_vao: WebGlVertexArrayObject,
    sphere_n: i32,
    shadow: Option<(WebGlFramebuffer, WebGlTexture)>,
    mode: u32,
    drag: Option<Drag>,
    rdrag: Option<RotDrag>,
    capsule_vao: WebGlVertexArrayObject,
    capsule_n: i32,
    ball_vao: WebGlVertexArrayObject,
    ball_n: i32,
    ring_vao: WebGlVertexArrayObject,
    ring_n: i32,
    play: bool,
    third: bool,
    p_pos: Vec3,
    p_vel: Vec3,
    p_spawn: Vec3,
    grounded: bool,
    hdr: bool,
    scene: Option<Target>,
    bloom_a: Option<Target>,
    bloom_b: Option<Target>,
    depth_view: Option<(WebGlFramebuffer, WebGlTexture, WebGlTexture)>,
    w: u32,
    h: u32,
    ents: Vec<Entity>,
    next_id: i32,
    selected: i32,
    cam_pos: Vec3,
    yaw: f32,
    pitch: f32,
    mv: Vec3,
    speed: f32,
    gfx: [f32; GFX_N],
    shapes: Vec<(WebGlVertexArrayObject, i32)>,
    eprog: Prog,
    edit_vao: WebGlVertexArrayObject,
    edit_buf: WebGlBuffer,
    edit_id: i32,
    edit_hover: i32,
    edit_iso: bool,
    pm_root: i32,
    pm_yaw: f32,
    pm_base: Vec<(i32, Vec3, Vec3)>,
    p_speed: f32,
    p_jump: f32,
    p_size: f32,
}

#[wasm_bindgen]
impl Engine {
    #[wasm_bindgen(constructor)]
    pub fn new(canvas_id: &str) -> Result<Engine, JsValue> {
        let doc = web_sys::window().ok_or("no window")?.document().ok_or("no document")?;
        let canvas: HtmlCanvasElement =
            doc.get_element_by_id(canvas_id).ok_or("canvas not found")?.dyn_into()?;
        let gl: GL = canvas.get_context("webgl2")?.ok_or("WebGL2 недоступен")?.dyn_into()?;

        let hdr_ext = gl.get_extension("EXT_color_buffer_float").ok().flatten().is_some()
            || gl.get_extension("EXT_color_buffer_half_float").ok().flatten().is_some();

        let prog = Prog::new(
            &gl, VS, FS,
            &["uVP", "uPos", "uRot", "uSize", "uCam", "uOutline", "uMode", "uTex", "uColor",
              "uNeon", "uNeonB", "uAmb", "uLightCol", "uLightDir", "uFogCol", "uFogDen", "uFogStart",
              "uShadow", "uLVP", "uShOn", "uNLp", "uNLc", "uNLn", "uNrm", "uBump", "uOpa", "uZenith", "uSunDir", "uSkyB", "uSunset", "uTime", "uFogN", "uMie", "uNoise", "uRays", "uUnder", "uMatK", "uMatP", "uMatB", "uMatS"],
        )?;
        let sky = Prog::new(
            &gl, FS_VS, SKY_FS,
            &["uInvVP", "uCam", "uZenith", "uHorizon", "uSunDir", "uSunCol", "uSkyB",
              "uSunSize", "uNight", "uSunset", "uSunVis", "uLightDir", "uLightCol", "uMie", "uUnder"],
        )?;
        let shprog = Prog::new(&gl, SH_VS, SH_FS, &["uLVP", "uPos", "uRot", "uSize", "uAlpha"])?;
        let gizmo = Prog::new(&gl, GZ_VS, GZ_FS, &["uVP", "uC", "uR", "uCam", "uColor", "uHot", "uM"])?;
        let water = Prog::new(
            &gl, WATER_VS, WATER_FS,
            &["uVP", "uPos", "uSize", "uCam", "uTime", "uWaveH", "uWaveS", "uWv", "uW1", "uW2",
              "uShadow", "uLVP", "uShOn", "uBump", "uColor", "uAlpha", "uZenith", "uHorizon",
              "uSkyB", "uSunDir", "uSunCol", "uSunVis", "uSunset", "uLightDir", "uLightCol",
              "uAmb", "uFogCol", "uFogDen", "uFogStart", "uPatch", "uRect", "uFogN", "uMie", "uTex", "uNoise", "uRays", "uUnder", "uWaveN", "uWQual", "uWImg", "uWtex"],
        )?;
        let fire = Prog::new(
            &gl, FIRE_VS, FIRE_FS,
            &["uVP", "uPos", "uSize", "uCam", "uTime", "uColor", "uInt", "uTex"],
        )?;
        let bright = Prog::new(&gl, FS_VS, BRIGHT_FS, &["uSrc", "uTexel", "uThr"])?;
        let blur = Prog::new(&gl, FS_VS, BLUR_FS, &["uSrc", "uStep"])?;
        let post = Prog::new(
            &gl, FS_VS, POST_FS,
            &["uScene", "uBloom", "uSun", "uSunOn", "uRayCol", "uRays", "uBloomS",
              "uExposure", "uContrast", "uSat", "uVig", "uAsp", "uUnder", "uTime"],
        )?;

        // меш куба
        let data = cube();
        let vao = gl.create_vertex_array().ok_or("vao")?;
        gl.bind_vertex_array(Some(&vao));
        let buf = gl.create_buffer().ok_or("buf")?;
        gl.bind_buffer(GL::ARRAY_BUFFER, Some(&buf));
        unsafe {
            let view = js_sys::Float32Array::view(&data);
            gl.buffer_data_with_array_buffer_view(GL::ARRAY_BUFFER, &view, GL::STATIC_DRAW);
        }
        gl.enable_vertex_attrib_array(0);
        gl.vertex_attrib_pointer_with_i32(0, 3, GL::FLOAT, false, 24, 0);
        gl.enable_vertex_attrib_array(1);
        gl.vertex_attrib_pointer_with_i32(1, 3, GL::FLOAT, false, 24, 12);
        gl.bind_vertex_array(None);

        let empty_vao = gl.create_vertex_array().ok_or("vao2")?;
        let sphere = sphere_mesh();
        let sphere_n = (sphere.len() / 6) as i32;
        let sphere_vao = make_mesh(&gl, &sphere)?;
        let shadow = make_shadow(&gl, SH_SIZE).ok();
        let ntex = make_tex(&gl, &noise::normal_map(&noise::surface_height(256, 4242), 256, 10.0), 256)?;
        let wtex1 = make_tex(&gl, &noise::normal_map(&noise::height_map(256, 77, 4, 4, 0.5, true), 256, 10.0), 256)?;
        let wtex2 = make_tex(&gl, &noise::normal_map(&noise::height_map(256, 991, 8, 3, 0.55, false), 256, 18.0), 256)?;
        let water_vaos = vec![
            make_grid(&gl, 64)?,
            make_grid(&gl, 128)?,
            make_grid(&gl, WATER_N)?,
        ];
        let mut mats = Vec::with_capacity(6);
        for k in 0..6u8 {
            let (alb, nrm) = noise::material(k, 256);
            mats.push((make_tex(&gl, &alb, 256)?, make_tex(&gl, &nrm, 256)?));
        }
        let aniso_ext = gl
            .get_extension("EXT_texture_filter_anisotropic")
            .ok()
            .flatten()
            .is_some();
        let aniso_max = if aniso_ext {
            gl.get_parameter(0x84FF).ok().and_then(|v| v.as_f64()).unwrap_or(1.0) as f32
        } else {
            1.0
        };
        let cap = capsule_mesh(PLAYER_R, PLAYER_H);
        let capsule_n = (cap.len() / 6) as i32;
        let capsule_vao = make_mesh(&gl, &cap)?;
        let ball: Vec<f32> = sphere_mesh().chunks_exact(6).flat_map(|q| {
            let mut o = [0f32; 6];
            o[..3].copy_from_slice(&[q[0] * 0.72, q[1] * 0.72 + 0.72, q[2] * 0.72]);
            o[3..].copy_from_slice(&[q[3], q[4], q[5]]);
            o
        }).collect();
        let ball_n = (ball.len() / 6) as i32;
        let ball_vao = make_mesh(&gl, &ball)?;
        let ring = ring_mesh();
        let ring_n = (ring.len() / 6) as i32;
        let ring_vao = make_mesh(&gl, &ring)?;

        let mut shapes = Vec::new();
        for s in 0..5u32 {
            let d = shape_mesh(s);
            let n = (d.len() / 6) as i32;
            shapes.push((make_mesh(&gl, &d)?, n));
        }
        let eprog = Prog::new(&gl, EDIT_VS, EDIT_FS, &["uVP", "uColor"])?;
        let edit_vao = gl.create_vertex_array().ok_or("edit vao")?;
        let edit_buf = gl.create_buffer().ok_or("edit buf")?;
        gl.bind_vertex_array(Some(&edit_vao));
        gl.bind_buffer(GL::ARRAY_BUFFER, Some(&edit_buf));
        gl.enable_vertex_attrib_array(0);
        gl.vertex_attrib_pointer_with_i32(0, 3, GL::FLOAT, false, 12, 0);
        gl.bind_vertex_array(None);

        // текстура из шума Перлина
        let tex = gl.create_texture().ok_or("texture")?;
        gl.bind_texture(GL::TEXTURE_2D, Some(&tex));
        let pixels = noise::fbm_texture(256, 1337);
        gl.tex_image_2d_with_i32_and_i32_and_i32_and_format_and_type_and_opt_u8_array(
            GL::TEXTURE_2D, 0, GL::RGBA as i32, 256, 256, 0, GL::RGBA, GL::UNSIGNED_BYTE,
            Some(pixels.as_slice()),
        )?;
        gl.generate_mipmap(GL::TEXTURE_2D);
        gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_MIN_FILTER, GL::LINEAR_MIPMAP_LINEAR as i32);
        gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_MAG_FILTER, GL::LINEAR as i32);
        gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_WRAP_S, GL::REPEAT as i32);
        gl.tex_parameteri(GL::TEXTURE_2D, GL::TEXTURE_WRAP_T, GL::REPEAT as i32);

        let mut e = Engine {
            gl, canvas, prog, sky, bright, blur, post, vao, empty_vao, tex,
            shprog, gizmo, sphere_vao, sphere_n, shadow, mode: 0, drag: None,
            rdrag: None,
            capsule_vao, capsule_n, ball_vao, ball_n, ring_vao, ring_n,
            play: false, third: false,
            p_pos: Vec3::ZERO, p_vel: Vec3::ZERO, p_spawn: Vec3::ZERO, grounded: false,
            water, fire, water_vaos, ntex, wtex1, wtex2, mats, wtex_img: None,
            aniso_ext, aniso_max, sh_size: SH_SIZE, time: 0.0,
            hdr_ext, hdr: false,
            scene: None, bloom_a: None, bloom_b: None, depth_view: None,
            w: 1, h: 1,
            ents: Vec::new(), next_id: 1, selected: -1,
            cam_pos: Vec3::ZERO, yaw: 0.0, pitch: 0.0,
            mv: Vec3::ZERO, speed: 8.0,
            gfx: GFX_DEF,
            shapes, eprog, edit_vao, edit_buf, edit_id: -1, edit_hover: -1, edit_iso: true,
            pm_root: -1, pm_yaw: 0.0, pm_base: Vec::new(),
            p_speed: 8.0, p_jump: 1.0, p_size: 1.0,
        };
        e.apply_aniso();
        e.reset_camera();
        Ok(e)
    }

    pub fn resize(&mut self, w: u32, h: u32) {
        let (w, h) = (w.clamp(2, 8192), h.clamp(2, 8192));
        if w == self.w && h == self.h && self.scene.is_some() {
            return;
        }
        self.w = w;
        self.h = h;
        self.canvas.set_width(w);
        self.canvas.set_height(h);
        self.build_targets();
    }

    pub fn hdr(&self) -> bool {
        self.hdr
    }

    // ---- графика ----
    pub fn set_gfx(&mut self, i: u32, v: f32) {
        let i = i as usize;
        if i < GFX_N && v.is_finite() {
            self.gfx[i] = v;
        }
        if i == G_SHQ && v.is_finite() {
            let q = v.clamp(0.0, 2.0).round() as i32;
            let size = 1024i32 << q;
            if size != self.sh_size {
                self.sh_size = size;
                self.shadow = make_shadow(&self.gl, size).ok();
            }
        }
        if i == G_TEXQ {
            self.apply_aniso();
        }
    }

    pub fn get_gfx(&self, i: u32) -> f32 {
        self.gfx.get(i as usize).copied().unwrap_or(0.0)
    }

    // ---- камера ----
    pub fn reset_camera(&mut self) {
        if self.play {
            self.p_pos = self.p_spawn;
            self.p_vel = Vec3::ZERO;
        }
        self.cam_pos = Vec3::new(0.0, 4.0, 12.0);
        self.yaw = 0.0;
        self.pitch = -0.25;
    }

    pub fn set_move(&mut self, strafe: f32, forward: f32, up: f32) {
        self.mv = Vec3::new(strafe, up, forward);
    }

    pub fn look(&mut self, dx: f32, dy: f32) {
        let k = 0.004 * self.gfx[G_SENS].clamp(0.05, 5.0);
        self.yaw += dx * k;
        self.pitch = (self.pitch - dy * k).clamp(-1.54, 1.54);
    }

    /// Навести камеру на точку (режим правки).
    pub fn focus_on(&mut self, x: f32, y: f32, z: f32, dist: f32) {
        let t = Vec3::new(x, y, z);
        self.cam_pos = t - self.dir() * dist.clamp(1.0, 200.0);
    }

    /// Точка перед камерой на расстоянии dist.
    pub fn camera_front(&self, dist: f32) -> Vec<f32> {
        let p = self.cam_pos + self.dir() * dist;
        vec![p.x, p.y, p.z]
    }

    // ---- сущности ----
    pub fn clear(&mut self) {
        self.ents.clear();
        self.selected = -1;
    }

    pub fn add_entity(&mut self, name: &str, p: &[f32]) -> i32 {
        let id = self.next_id;
        self.next_id += 1;
        self.ents.push(Entity {
            id,
            name: name.to_string(),
            pos: Vec3::ZERO,
            rot: Vec3::ZERO,
            size: Vec3::ONE,
            color: Vec3::splat(0.8),
            neon: false,
            alpha: 1.0,
            water: p.get(14).copied().unwrap_or(0.0) > 0.5,
            fire: p.get(15).copied().unwrap_or(0.0) > 0.5,
            mat: p.get(16).copied().unwrap_or(0.0).clamp(0.0, 5.0) as u32,
            wtex: p.get(17).copied().unwrap_or(0.0) > 0.5,
            parent: -1,
            shape: p.get(18).copied().unwrap_or(0.0).clamp(0.0, 4.0) as u32,
            e_sub: 0,
            e_round: 0.0,
            e_cells: u64::MAX,
            mesh: None,
        });
        self.set_props(id, p);
        id
    }

    pub fn remove_entity(&mut self, id: i32) {
        let mut gone = self.descendants(id);
        gone.push(id);
        self.ents.retain(|e| !gone.contains(&e.id));
        if gone.contains(&self.selected) {
            self.selected = -1;
        }
    }

    pub fn entity_ids(&self) -> Vec<i32> {
        self.ents.iter().map(|e| e.id).collect()
    }

    pub fn entity_name(&self, id: i32) -> String {
        self.ents.iter().find(|e| e.id == id).map(|e| e.name.clone()).unwrap_or_default()
    }

    /// [pos xyz, rot xyz (град), size xyz, color rgb 0..1, neon 0/1]
    pub fn get_props(&self, id: i32) -> Vec<f32> {
        match self.ents.iter().find(|e| e.id == id) {
            Some(e) => vec![
                e.pos.x, e.pos.y, e.pos.z, e.rot.x, e.rot.y, e.rot.z,
                e.size.x, e.size.y, e.size.z, e.color.x, e.color.y, e.color.z,
                if e.neon { 1.0 } else { 0.0 },
                e.alpha,
                if e.water { 1.0 } else { 0.0 },
                if e.fire { 1.0 } else { 0.0 },
                e.mat as f32,
                if e.wtex { 1.0 } else { 0.0 },
                e.shape as f32,
            ],
            None => Vec::new(),
        }
    }

    pub fn set_props(&mut self, id: i32, p: &[f32]) {
        if p.len() < 12 || p.iter().any(|v| !v.is_finite()) {
            return;
        }
        let mut moved = Vec3::ZERO;
        let mut shape_changed = false;
        if let Some(e) = self.ents.iter_mut().find(|e| e.id == id) {
            let np = Vec3::new(p[0], p[1], p[2]);
            moved = np - e.pos;
            e.pos = np;
            e.rot = Vec3::new(p[3], p[4], p[5]);
            e.size = Vec3::new(p[6].max(0.05), p[7].max(0.05), p[8].max(0.05));
            e.color = Vec3::new(p[9].clamp(0.0, 1.0), p[10].clamp(0.0, 1.0), p[11].clamp(0.0, 1.0));
            e.neon = p.get(12).copied().unwrap_or(0.0) > 0.5;
            e.alpha = p.get(13).copied().unwrap_or(1.0).clamp(0.0, 1.0);
            if let Some(&m) = p.get(16) {
                e.mat = m.clamp(0.0, 5.0) as u32;
            }
            if let Some(&w) = p.get(17) {
                e.wtex = w > 0.5;
            }
            if let Some(&s) = p.get(18) {
                let ns = s.clamp(0.0, 4.0) as u32;
                if ns != e.shape {
                    e.shape = ns;
                    e.mesh = None;
                    shape_changed = true;
                }
            }
        }
        if shape_changed {
            self.rebuild_mesh(id);
        }
        if moved != Vec3::ZERO {
            self.move_children(id, moved);
        }
    }


    fn rebuild_mesh(&mut self, id: i32) {
        let Self { gl, ents, .. } = self;
        if let Some(e) = ents.iter_mut().find(|e| e.id == id) {
            if let Some((v, _)) = e.mesh.take() {
                gl.delete_vertex_array(Some(&v));
            }
            let cps = [1usize, 2, 4][e.e_sub.min(2) as usize];
            if e.shape == 0 && (e.e_sub > 0 || e.e_round > 0.001 || e.e_cells != all_cells(cps)) {
                let data = edit_mesh(e.e_sub, e.e_round, e.e_cells);
                if let Ok(v) = make_mesh(gl, &data) {
                    e.mesh = Some((v, (data.len() / 6) as i32));
                }
            }
        }
    }

    /// Режим правки: subdiv (0..2), скругление 0..1, ячейки hex.
    pub fn set_edit(&mut self, id: i32, sub: u32, round: f32, cells_hex: &str) {
        if let Some(e) = self.ents.iter_mut().find(|e| e.id == id) {
            e.e_sub = sub.min(2);
            e.e_round = round.clamp(0.0, 1.0);
            let h = cells_hex.trim().trim_start_matches("0x");
            if let Ok(c) = u64::from_str_radix(h, 16) {
                e.e_cells = c;
            }
            e.shape = 0;
            e.mesh = None;
        }
        self.rebuild_mesh(id);
    }

    pub fn edit_toggle(&mut self, id: i32, cell: u32) {
        if let Some(e) = self.ents.iter_mut().find(|e| e.id == id) {
            if cell < 64 {
                let bit = 1u64 << cell;
                let cps = [1usize, 2, 4][e.e_sub.min(2) as usize];
                let all = all_cells(cps);
                let mut c = e.e_cells & all;
                c ^= bit;
                if c == 0 {
                    c = bit;
                }
                e.e_cells = c | (!all);
            }
        }
        self.rebuild_mesh(id);
    }

    pub fn edit_reset_cells(&mut self, id: i32) {
        if let Some(e) = self.ents.iter_mut().find(|e| e.id == id) {
            let cps = [1usize, 2, 4][e.e_sub.min(2) as usize];
            e.e_cells = all_cells(cps) | (!all_cells(cps));
        }
        self.rebuild_mesh(id);
    }

    pub fn get_edit(&self, id: i32) -> Vec<f32> {
        match self.ents.iter().find(|e| e.id == id) {
            Some(e) => vec![e.e_sub as f32, e.e_round],
            None => vec![],
        }
    }

    pub fn edit_cells_hex(&self, id: i32) -> String {
        match self.ents.iter().find(|e| e.id == id) {
            Some(e) => format!("{:016x}", e.e_cells),
            None => String::new(),
        }
    }

    pub fn set_edit_id(&mut self, id: i32) {
        self.edit_id = id;
        self.edit_hover = -1;
    }

    pub fn edit_id(&self) -> i32 {
        self.edit_id
    }

    pub fn set_edit_hover(&mut self, cell: i32) {
        self.edit_hover = cell;
    }

    /// Изолировать редактируемый объект (прятать остальные).
    pub fn set_edit_iso(&mut self, on: bool) {
        self.edit_iso = on;
    }

    pub fn edit_iso(&self) -> bool {
        self.edit_iso
    }

    /// Прятать объект при изоляции режима правки?
    fn hide_iso(&self, id: i32) -> bool {
        self.edit_iso && self.edit_id >= 0 && id != self.edit_id && id != self.pm_root
    }

    /// Ячейка сетки под курсором (для режима правки).
    pub fn pick_cell(&self, nx: f32, ny: f32) -> i32 {
        let e = match self.ents.iter().find(|e| e.id == self.edit_id) {
            Some(e) => e,
            None => return -1,
        };
        let inv = (self.proj() * self.view()).inverse();
        let near = inv.project_point3(Vec3::new(nx, ny, -1.0));
        let far = inv.project_point3(Vec3::new(nx, ny, 1.0));
        let dir = (far - near).normalize();
        let t = match ray_obb(near, dir, e.pos, e.quat(), e.size) {
            Some(t) => t,
            None => return -1,
        };
        let hit = near + dir * t;
        let local = e.quat().inverse() * (hit - e.pos);
        let u = (local / e.size + Vec3::splat(0.5)).clamp(Vec3::ZERO, Vec3::splat(0.99999));
        let cps = [1usize, 2, 4][e.e_sub.min(2) as usize];
        let x = (u.x * cps as f32) as usize;
        let y = (u.y * cps as f32) as usize;
        let z = (u.z * cps as f32) as usize;
        (x + y * cps + z * cps * cps) as i32
    }

    pub fn descendants_of(&self, id: i32) -> Vec<i32> {
        self.descendants(id)
    }

    pub fn set_pm_root(&mut self, id: i32) {
        self.pm_root = id;
    }

    pub fn pm_root(&self) -> i32 {
        self.pm_root
    }

    /// Характеристики игрока из скрипта: скорость, прыжок, размер капсулы.
    pub fn set_player_stats(&mut self, speed: f32, jump: f32, size: f32) {
        self.p_speed = speed.clamp(0.1, 200.0);
        self.p_jump = jump.clamp(0.0, 50.0);
        self.p_size = size.clamp(0.2, 10.0);
        self.speed = self.p_speed;
    }

    fn rotate_children(&mut self, id: i32, deg: f32) {
        let root = match self.ents.iter().find(|e| e.id == id) {
            Some(e) => e.pos,
            None => return,
        };
        let q = Quat::from_rotation_y(deg.to_radians());
        let kids = self.descendants(id);
        for k in kids {
            if let Some(e) = self.ents.iter_mut().find(|e| e.id == k) {
                e.pos = root + q * (e.pos - root);
                e.rot.y += deg;
            }
        }
    }

    fn follow_pm(&mut self) {
        if self.pm_root < 0 || !self.play {
            return;
        }
        let delta = self.p_pos - match self.ents.iter().find(|e| e.id == self.pm_root) {
            Some(e) => e.pos,
            None => return,
        };
        if delta.length_squared() > 1e-8 {
            if let Some(e) = self.ents.iter_mut().find(|e| e.id == self.pm_root) {
                e.pos = self.p_pos;
            }
            self.move_children(self.pm_root, delta);
        }
        let yaw_deg = self.yaw.to_degrees();
        let dy = yaw_deg - self.pm_yaw;
        if dy.abs() > 0.001 {
            self.pm_yaw = yaw_deg;
            self.rotate_children(self.pm_root, dy);
            if let Some(e) = self.ents.iter_mut().find(|e| e.id == self.pm_root) {
                e.rot.y = yaw_deg;
            }
        }
    }

    /// Привязка меша объекта (кастомный меш правки или общая фигура).
    fn bind_mesh(&self, e: &Entity) -> i32 {
        let gl = &self.gl;
        if let Some((v, n)) = &e.mesh {
            gl.bind_vertex_array(Some(v));
            return *n;
        }
        let (v, n) = &self.shapes[e.shape.min(4) as usize];
        gl.bind_vertex_array(Some(v));
        *n
    }

    /// Сетка ячеек режима правки поверх объекта.
    fn draw_edit_grid(&self) {
        if self.edit_id < 0 || self.play {
            return;
        }
        let e = match self.ents.iter().find(|e| e.id == self.edit_id) {
            Some(e) => e,
            None => return,
        };
        let gl = &self.gl;
        let p = &self.eprog;
        let vp = self.proj() * self.view();
        let q = e.quat();
        let cps = [1usize, 2, 4][e.e_sub.min(2) as usize];
        let loc = |x: f32, y: f32, z: f32| -> Vec3 { e.pos + q * (Vec3::new(x, y, z) * e.size) };
        let mut v: Vec<f32> = Vec::new();
        let line = |v: &mut Vec<f32>, a: Vec3, b: Vec3| {
            v.extend_from_slice(&[a.x, a.y, a.z, b.x, b.y, b.z]);
        };
        for axis in 0..3 {
            for i in 0..=cps {
                for j in 0..=cps {
                    let (a, b) = (i as f32 / cps as f32 - 0.5, j as f32 / cps as f32 - 0.5);
                    match axis {
                        0 => { line(&mut v, loc(-0.5, a, b), loc(0.5, a, b)); }
                        1 => { line(&mut v, loc(a, -0.5, b), loc(a, 0.5, b)); }
                        _ => { line(&mut v, loc(a, b, -0.5), loc(a, b, 0.5)); }
                    }
                }
            }
        }
        let grid_n = (v.len() / 6) as i32;
        let hover = self.edit_hover;
        let mut hv: Vec<f32> = Vec::new();
        if hover >= 0 && (hover as usize) < cps * cps * cps {
            let s = cps as f32;
            let cx = (hover as usize % cps) as f32;
            let cy = ((hover as usize / cps) % cps) as f32;
            let cz = (hover as usize / (cps * cps)) as f32;
            let bmin = Vec3::new(cx / s - 0.5, cy / s - 0.5, cz / s - 0.5);
            let bmax = bmin + Vec3::splat(1.0 / s);
            let c = [
                loc(bmin.x, bmin.y, bmin.z), loc(bmax.x, bmin.y, bmin.z),
                loc(bmax.x, bmax.y, bmin.z), loc(bmin.x, bmax.y, bmin.z),
                loc(bmin.x, bmin.y, bmax.z), loc(bmax.x, bmin.y, bmax.z),
                loc(bmax.x, bmax.y, bmax.z), loc(bmin.x, bmax.y, bmax.z),
            ];
            for (a, b) in [(0, 1), (1, 2), (2, 3), (3, 0), (4, 5), (5, 6), (6, 7), (7, 4), (0, 4), (1, 5), (2, 6), (3, 7)] {
                line(&mut hv, c[a], c[b]);
            }
        }
        let hover_n = (hv.len() / 6) as i32;
        gl.bind_framebuffer(GL::FRAMEBUFFER, None);
        gl.viewport(0, 0, self.w as i32, self.h as i32);
        gl.enable(GL::DEPTH_TEST);
        gl.disable(GL::CULL_FACE);
        gl.use_program(Some(&p.p));
        gl.uniform_matrix4fv_with_f32_array(p.l("uVP"), false, &vp.to_cols_array());
        gl.bind_vertex_array(Some(&self.edit_vao));
        gl.bind_buffer(GL::ARRAY_BUFFER, Some(&self.edit_buf));
        unsafe {
            let view = js_sys::Float32Array::view(&v);
            gl.buffer_data_with_array_buffer_view(GL::ARRAY_BUFFER, &view, GL::DYNAMIC_DRAW);
        }
        let cc = if hover >= 0 { 0.45 } else { 0.85 };
        gl.uniform4f(p.l("uColor"), cc, cc, cc, 1.0);
        gl.draw_arrays(GL::LINES, 0, grid_n);
        if hover_n > 0 {
            unsafe {
                let view = js_sys::Float32Array::view(&hv);
                gl.buffer_data_with_array_buffer_view(GL::ARRAY_BUFFER, &view, GL::DYNAMIC_DRAW);
            }
            gl.uniform4f(p.l("uColor"), 1.0, 0.62, 0.10, 1.0);
            gl.draw_arrays(GL::LINES, 0, hover_n);
        }
        gl.bind_vertex_array(None);
    }

    /// Своя текстура материала из галереи: квадратная RGBA8 (рекомендуется 256).
    pub fn set_custom_mat(&mut self, data: &[u8], w: u32, h: u32) {
        let size = w as usize;
        if w != h || size == 0 || data.len() != size * size * 4 {
            return;
        }
        let mut hh = vec![0.0f32; size * size];
        for i in 0..size * size {
            let r = data[i * 4] as f32;
            let g = data[i * 4 + 1] as f32;
            let b = data[i * 4 + 2] as f32;
            hh[i] = (r * 0.3 + g * 0.5 + b * 0.2) / 255.0;
        }
        let nrm = noise::normal_map(&hh, size, 6.0);
        let m = &self.mats[5];
        let _ = upload_tex(&self.gl, &m.0, data, w as i32);
        let _ = upload_tex(&self.gl, &m.1, &nrm, w as i32);
        self.apply_aniso();
    }

    /// Своя текстура воды из галереи: квадратная RGBA8 (рекомендуется 256).
    pub fn set_custom_water(&mut self, data: &[u8], w: u32, h: u32) {
        let size = w as usize;
        if w != h || size == 0 || data.len() != size * size * 4 {
            return;
        }
        if self.wtex_img.is_none() {
            self.wtex_img = self.gl.create_texture();
        }
        if let Some(t) = self.wtex_img.clone() {
            let _ = upload_tex(&self.gl, &t, data, w as i32);
            self.apply_aniso();
        }
    }

    pub fn select(&mut self, id: i32) {
        self.selected = if self.ents.iter().any(|e| e.id == id) { id } else { -1 };
    }

    pub fn selected(&self) -> i32 {
        self.selected
    }

    pub fn pick(&mut self, nx: f32, ny: f32) -> i32 {
        let inv = (self.proj() * self.view()).inverse();
        let near = inv.project_point3(Vec3::new(nx, ny, -1.0));
        let far = inv.project_point3(Vec3::new(nx, ny, 1.0));
        let dir = (far - near).normalize();
        let mut best = (f32::MAX, -1);
        for e in &self.ents {
            if let Some(t) = ray_obb(near, dir, e.pos, e.quat(), e.size) {
                if t < best.0 {
                    best = (t, e.id);
                }
            }
        }
        self.selected = best.1;
        best.1
    }

    /// Высота волн в точке (x, z) относительно уровня воды (для будущей плавучести).
    pub fn water_height(&self, x: f32, z: f32) -> f32 {
        wave_height(x, z, self.time, self.gfx[G_WAVEH], self.gfx[G_WAVES])
    }

    pub fn parent_of(&self, id: i32) -> i32 {
        self.ents.iter().find(|e| e.id == id).map(|e| e.parent).unwrap_or(-1)
    }

    pub fn set_parent(&mut self, id: i32, parent: i32) {
        if id == parent || !self.ents.iter().any(|e| e.id == id) {
            return;
        }
        if parent >= 0 && !self.ents.iter().any(|e| e.id == parent) {
            return;
        }
        let mut cur = parent;
        while cur >= 0 {
            if cur == id {
                return;
            }
            cur = self.parent_of(cur);
        }
        if let Some(e) = self.ents.iter_mut().find(|e| e.id == id) {
            e.parent = parent;
        }
    }

    pub fn set_play(&mut self, on: bool) {
        if on == self.play {
            return;
        }
        self.play = on;
        self.drag = None;
        self.rdrag = None;
        self.mv = Vec3::ZERO;
        if on {
            self.p_pos = self.cam_pos - Vec3::Y * EYE_H;
            self.p_spawn = self.p_pos;
            self.p_vel = Vec3::ZERO;
            self.grounded = false;
            self.selected = -1;
            self.pm_base.clear();
            if self.pm_root >= 0 {
                let ids: Vec<i32> = std::iter::once(self.pm_root)
                    .chain(self.descendants(self.pm_root))
                    .collect();
                for id in ids {
                    if let Some(e) = self.ents.iter().find(|e| e.id == id) {
                        self.pm_base.push((id, e.pos, e.rot));
                    }
                }
                self.pm_yaw = self.yaw.to_degrees();
            }
        } else {
            for (id, pos, rot) in std::mem::take(&mut self.pm_base) {
                if let Some(e) = self.ents.iter_mut().find(|e| e.id == id) {
                    e.pos = pos;
                    e.rot = rot;
                }
            }
        }
    }

    pub fn set_third(&mut self, on: bool) {
        self.third = on;
    }

    pub fn is_play(&self) -> bool {
        self.play
    }

    pub fn player_pos(&self) -> Vec<f32> {
        vec![self.p_pos.x, self.p_pos.y, self.p_pos.z]
    }

    pub fn set_mode(&mut self, m: u32) {
        self.mode = m.min(3);
        self.rdrag = None;
        self.drag = None;
    }

    pub fn gizmo_begin(&mut self, nx: f32, ny: f32) -> bool {
        self.drag = None;
        if self.mode == 0 {
            return false;
        }
        if self.mode == 3 {
            return self.rot_begin(nx, ny);
        }
        let sel = self.selected;
        let (id, pos0, size0, hs) = match self.ents.iter().find(|e| e.id == sel) {
            Some(e) => (e.id, e.pos, e.size, self.handles(e)),
            None => return false,
        };
        let (o, d) = self.ray(nx, ny);
        let mut best: Option<(f32, usize)> = None;
        for (i, (p, _, _, r)) in hs.iter().enumerate() {
            let c = *p - o;
            let t = c.dot(d);
            if t <= 0.0 {
                continue;
            }
            let miss2 = c.length_squared() - t * t;
            let rr = *r * 1.7;
            if miss2 <= rr * rr && best.map_or(true, |b| t < b.0) {
                best = Some((t, i));
            }
        }
        match best {
            Some((_, h)) => {
                let axis = hs[h].1;
                let s0 = axis_param(o, d, pos0, axis).unwrap_or(0.0);
                self.drag = Some(Drag { id, handle: h, axis, s0, pos0, size0 });
                true
            }
            None => false,
        }
    }

    pub fn gizmo_drag(&mut self, nx: f32, ny: f32) -> bool {
        if self.mode == 3 {
            return self.rot_drag(nx, ny);
        }
        let (id, h, axis, s0, pos0, size0) = match &self.drag {
            Some(d) => (d.id, d.handle, d.axis, d.s0, d.pos0, d.size0),
            None => return false,
        };
        let (o, d) = self.ray(nx, ny);
        let s = match axis_param(o, d, pos0, axis) {
            Some(s) => s,
            None => return true,
        };
        let mut delta = ((s - s0) / 0.05).round() * 0.05;
        let mode = self.mode;
        let mut moved = Vec3::ZERO;
        let mut ok = false;
        if let Some(e) = self.ents.iter_mut().find(|e| e.id == id) {
            let old = e.pos;
            if mode == 1 {
                e.pos = pos0 + axis * delta;
                moved = e.pos - old;
            } else {
                let c = h / 2;
                let ns = (size0[c] + delta).max(0.05);
                delta = ns - size0[c];
                e.size = size0;
                e.size[c] = ns;
                e.pos = pos0 + axis * (delta * 0.5);
            }
            ok = true;
        }
        if moved != Vec3::ZERO {
            self.move_children(id, moved);
        }
        ok
    }

    pub fn gizmo_end(&mut self) {
        self.rdrag = None;
        self.drag = None;
    }

    pub fn frame(&mut self, dt: f32) {
        let (sy, cy) = self.yaw.sin_cos();
        let fwd = Vec3::new(sy, 0.0, -cy);
        let right = Vec3::new(cy, 0.0, sy);
        let mut flat = right * self.mv.x + fwd * self.mv.z;
        if flat.length() > 1.0 {
            flat = flat.normalize();
        }
        if self.play {
            self.step_player(flat, dt);
        } else {
            self.cam_pos += (flat + Vec3::Y * self.mv.y.clamp(-1.0, 1.0)) * self.speed * dt;
        }
        self.time += dt;
        self.render();
    }
}

impl Engine {
    fn render(&self) {
        self.render_scene();
        self.draw_gizmo();
        self.draw_edit_grid();
    }

    /// Анизотропная фильтрация по качеству текстур.
    fn apply_aniso(&self) {
        if !self.aniso_ext {
            return;
        }
        let gl = &self.gl;
        let q = self.gfx[G_TEXQ].clamp(0.0, 2.0).round() as i32;
        let v = match q {
            0 => 1.0f32,
            1 => 4.0,
            _ => 16.0,
        }
        .min(self.aniso_max.max(1.0));
        let set = |t: &WebGlTexture| {
            gl.bind_texture(GL::TEXTURE_2D, Some(t));
            gl.tex_parameterf(GL::TEXTURE_2D, 0x84FE, v);
        };
        set(&self.tex);
        set(&self.ntex);
        set(&self.wtex1);
        set(&self.wtex2);
        for (a, b) in &self.mats {
            set(a);
            set(b);
        }
        if let Some(t) = &self.wtex_img {
            set(t);
        }
        gl.bind_texture(GL::TEXTURE_2D, None);
    }

    fn fov(&self) -> f32 {
        self.gfx[G_FOV].clamp(20.0, 120.0).to_radians()
    }

    fn draw_water(&self, e: &Entity, st: &SkyState, vp: &Mat4, fog_col: Vec3, lvp: &Mat4, under: f32) {
        let gl = &self.gl;
        let g = &self.gfx;
        let p = &self.water;
        let wq = g[G_WQ].clamp(0.0, 2.0).round() as usize;
        let (wvao, wn) = &self.water_vaos[wq.min(2)];
        gl.use_program(Some(&p.p));
        gl.bind_vertex_array(Some(wvao));
        gl.uniform_matrix4fv_with_f32_array(p.l("uVP"), false, &vp.to_cols_array());
        u3(gl, p.l("uPos"), e.pos);
        u3(gl, p.l("uSize"), e.size);
        u3(gl, p.l("uCam"), self.cam_pos);
        gl.uniform1f(p.l("uTime"), self.time);
        gl.uniform1f(p.l("uWaveH"), g[G_WAVEH]);
        gl.uniform1f(p.l("uFogN"), g[G_FOGN]);
        gl.uniform1f(p.l("uMie"), g[G_MIE]);
        gl.active_texture(GL::TEXTURE0);
        gl.bind_texture(GL::TEXTURE_2D, Some(&self.tex));
        gl.uniform1i(p.l("uTex"), 0);
        let (hx, hz) = (e.size.x * 0.5, e.size.z * 0.5);
        let (x0, x1, z0, z1) = (e.pos.x - hx, e.pos.x + hx, e.pos.z - hz, e.pos.z + hz);
        let smax = e.size.x.max(e.size.z).max(0.01);
        let cell = 2.0f32.powf((smax / 330.0).log2().ceil()).clamp(0.25, 2.0);
        let cx = (self.cam_pos.x.clamp(x0, x1) / cell).round() * cell;
        let cz = (self.cam_pos.z.clamp(z0, z1) / cell).round() * cell;
        gl.uniform4f(p.l("uPatch"), cx, cz, cell, WATER_N as f32);
        gl.uniform4f(p.l("uRect"), x0, z0, x1, z1);
        gl.uniform1f(p.l("uWaveS"), g[G_WAVES]);
        let wv: Vec<f32> = WAVES.iter().flatten().copied().collect();
        gl.uniform4fv_with_f32_array(p.l("uWv"), &wv);
        gl.uniform1f(p.l("uBump"), g[G_BUMP]);
        gl.uniform1i(p.l("uW1"), 4);
        gl.uniform1i(p.l("uW2"), 5);
        gl.uniform1i(p.l("uShadow"), 2);
        gl.uniform1f(p.l("uShOn"), if self.shadow.is_some() { g[G_SHADOW] } else { 0.0 });
        gl.uniform_matrix4fv_with_f32_array(p.l("uLVP"), false, &lvp.to_cols_array());
        u3(gl, p.l("uColor"), e.color);
        gl.uniform1f(p.l("uAlpha"), e.alpha);
        u3(gl, p.l("uZenith"), st.zenith);
        u3(gl, p.l("uHorizon"), st.horizon);
        gl.uniform1f(p.l("uSkyB"), g[G_SKYB]);
        u3(gl, p.l("uSunDir"), st.sun_dir);
        u3(gl, p.l("uSunCol"), st.sun_col);
        gl.uniform1f(p.l("uSunVis"), st.sun_vis);
        gl.uniform1f(p.l("uSunset"), st.sunset);
        u3(gl, p.l("uLightDir"), st.light_dir);
        u3(gl, p.l("uLightCol"), st.light_col);
        u3(gl, p.l("uAmb"), st.amb);
        u3(gl, p.l("uFogCol"), fog_col);
        gl.uniform1f(p.l("uFogDen"), g[G_FOGD]);
        gl.uniform1f(p.l("uFogStart"), g[G_FOGS]);
        gl.uniform1i(p.l("uNoise"), 6);
        gl.uniform1f(p.l("uRays"), g[G_RAYS]);
        gl.uniform1f(p.l("uUnder"), under);
        gl.uniform1i(p.l("uWaveN"), 4 + (wq as i32) * 2);
        gl.uniform1f(p.l("uWQual"), if wq > 0 { 1.0 } else { 0.0 });
        let custom = e.wtex && self.wtex_img.is_some();
        gl.uniform1f(p.l("uWtex"), if custom { 1.0 } else { 0.0 });
        gl.uniform1f(p.l("uShoreOn"), if self.depth_view.is_some() { 1.0 } else { 0.0 });
        if let Some((_, dt, _)) = &self.depth_view {
            gl.active_texture(GL::TEXTURE8);
            gl.bind_texture(GL::TEXTURE_2D, Some(dt));
            gl.uniform1i(p.l("uDepthTex"), 8);
        }
        gl.active_texture(GL::TEXTURE7);
        gl.bind_texture(GL::TEXTURE_2D, self.wtex_img.as_ref());
        gl.uniform1i(p.l("uWImg"), 7);
        gl.active_texture(GL::TEXTURE0);
        gl.bind_texture(GL::TEXTURE_2D, Some(&self.tex));
        gl.disable(GL::CULL_FACE);
        gl.draw_elements_with_i32(GL::TRIANGLES, *wn, GL::UNSIGNED_INT, 0);
    }

    fn draw_fire(&self, e: &Entity, vp: &Mat4) {
        let gl = &self.gl;
        let p = &self.fire;
        gl.use_program(Some(&p.p));
        gl.bind_vertex_array(Some(&self.vao));
        gl.active_texture(GL::TEXTURE0);
        gl.bind_texture(GL::TEXTURE_2D, Some(&self.tex));
        gl.uniform1i(p.l("uTex"), 0);
        gl.uniform_matrix4fv_with_f32_array(p.l("uVP"), false, &vp.to_cols_array());
        u3(gl, p.l("uPos"), e.pos);
        u3(gl, p.l("uSize"), e.size);
        u3(gl, p.l("uCam"), self.cam_pos);
        u3(gl, p.l("uColor"), e.color);
        gl.uniform1f(p.l("uTime"), self.time);
        gl.uniform1f(p.l("uInt"), e.alpha);
        gl.enable(GL::CULL_FACE);
        gl.cull_face(GL::BACK);
        gl.draw_arrays(GL::TRIANGLES, 0, 36);
        gl.disable(GL::CULL_FACE);
        gl.cull_face(GL::BACK);
    }

    fn descendants(&self, id: i32) -> Vec<i32> {
        let mut out: Vec<i32> = Vec::new();
        let mut stack = vec![id];
        while let Some(cur) = stack.pop() {
            for e in &self.ents {
                if e.parent == cur && !out.contains(&e.id) {
                    out.push(e.id);
                    stack.push(e.id);
                }
            }
        }
        out
    }

    fn move_children(&mut self, id: i32, d: Vec3) {
        let ds = self.descendants(id);
        for e in self.ents.iter_mut() {
            if ds.contains(&e.id) {
                e.pos += d;
            }
        }
    }

    fn water_level(&self, p: Vec3) -> Option<f32> {
        for e in self.ents.iter().filter(|e| e.water) {
            if (p.x - e.pos.x).abs() > e.size.x * 0.5 || (p.z - e.pos.z).abs() > e.size.z * 0.5 {
                continue;
            }
            let surf = e.pos.y + e.size.y * 0.5
                + wave_height(p.x, p.z, self.time, self.gfx[G_WAVEH], self.gfx[G_WAVES]);
            if p.y <= surf && p.y >= e.pos.y - e.size.y * 0.5 {
                return Some(surf);
            }
        }
        None
    }

    /// Насколько камера под водой: 0..1 (полная глубина на 0.5 м).
    fn under_amount(&self) -> f32 {
        match self.water_level(self.cam_pos) {
            Some(surf) => ((surf - self.cam_pos.y) * 2.0).clamp(0.0, 1.0),
            None => 0.0,
        }
    }

    fn collide_player(&mut self) {
        let r = PLAYER_R;
        let mut pos = self.p_pos;
        let mut vel = self.p_vel;
        let mut grounded = false;
        let offs = [r, PLAYER_H * 0.5, PLAYER_H - r];
        for _ in 0..4 {
            let mut any = false;
            for &oy in &offs {
                let mut c = pos + Vec3::Y * oy;
                for e in self.ents.iter().filter(|e| !e.water && !e.fire) {
                    if let Some(push) = shape_push(c, r, e.pos, e.quat(), e.size, e.shape) {
                        pos += push;
                        c += push;
                        let l = push.length();
                        if l > 1e-6 {
                            let n = push / l;
                            let vn = vel.dot(n);
                            if vn < 0.0 {
                                vel -= n * vn;
                            }
                            if n.y > 0.6 {
                                grounded = true;
                            }
                        }
                        any = true;
                    }
                }
            }
            if !any {
                break;
            }
        }
        self.p_pos = pos;
        self.p_vel = vel;
        self.grounded = grounded;
    }

    fn player_tick(&mut self, flat: Vec3, dt: f32) {
        let swim = self.water_level(self.p_pos + Vec3::Y * 1.1).is_some();
        let sp = if swim { WALK * 0.55 } else { WALK };
        let target = flat * sp;
        let accel = if self.grounded { 45.0 } else if swim { 12.0 } else { 14.0 };
        let vh = Vec3::new(self.p_vel.x, 0.0, self.p_vel.z);
        let dv = target - vh;
        let st = accel * dt;
        let nv = if dv.length() <= st { target } else { vh + dv.normalize() * st };
        self.p_vel.x = nv.x;
        self.p_vel.z = nv.z;
        let up = self.mv.y.clamp(-1.0, 1.0);
        if swim {
            self.p_vel.y -= 3.0 * dt;
            self.p_vel.y += up * 16.0 * dt;
            self.p_vel.y *= (1.0 - 3.0 * dt).max(0.0);
        } else {
            self.p_vel.y -= 25.0 * dt;
            if up > 0.5 && self.grounded {
                self.p_vel.y = 8.5;
            }
        }
        self.p_vel.y = self.p_vel.y.max(-60.0);
        self.p_pos += self.p_vel * dt;
        self.grounded = false;
        self.collide_player();
        if self.p_pos.y < -80.0 {
            self.p_pos = self.p_spawn;
            self.p_vel = Vec3::ZERO;
        }
    }

    fn step_player(&mut self, flat: Vec3, dt: f32) {
        let n = ((dt / 0.01667).ceil() as i32).clamp(1, 8);
        let h = dt / n as f32;
        for _ in 0..n {
            self.player_tick(flat, h);
        }
        self.follow_pm();
        let eye = self.p_pos + Vec3::Y * EYE_H;
        self.cam_pos = if self.third { eye - self.dir() * 4.5 } else { eye };
    }

    fn ring_radius(&self, e: &Entity) -> f32 {
        (e.size.length() * 0.5).max(0.5) * 1.15 + 0.15
    }

    fn draw_rings(&self, e: &Entity) {
        let gl = &self.gl;
        let p = &self.gizmo;
        let vp = self.proj() * self.view();
        gl.bind_vertex_array(Some(&self.ring_vao));
        gl.uniform_matrix4fv_with_f32_array(p.l("uVP"), false, &vp.to_cols_array());
        u3(gl, p.l("uCam"), self.cam_pos);
        let q = e.quat();
        let rad = self.ring_radius(e);
        let hot = self.rdrag.as_ref().map(|d| d.k as i32).unwrap_or(-1);
        let blue = Vec3::new(0.25, 0.50, 1.0);
        let red = Vec3::new(1.0, 0.25, 0.25);
        let green = Vec3::new(0.25, 0.85, 0.35);
        for (k, (ax, col)) in [(Vec3::X, blue), (Vec3::Y, red), (Vec3::Z, green)].iter().enumerate() {
            let a = q * *ax;
            let m = Mat3::from_quat(Quat::from_rotation_arc(Vec3::Y, a));
            gl.uniform_matrix3fv_with_f32_array(p.l("uM"), false, &m.to_cols_array());
            u3(gl, p.l("uC"), e.pos);
            gl.uniform1f(p.l("uR"), rad);
            u3(gl, p.l("uColor"), *col);
            gl.uniform1f(p.l("uHot"), if k as i32 == hot { 1.0 } else { 0.0 });
            gl.draw_arrays(GL::TRIANGLES, 0, self.ring_n);
        }
    }

    fn rot_begin(&mut self, nx: f32, ny: f32) -> bool {
        let sel = self.selected;
        let (id, pos, q, rad) = match self.ents.iter().find(|e| e.id == sel) {
            Some(e) => (e.id, e.pos, e.quat(), self.ring_radius(e)),
            None => return false,
        };
        let (o, d) = self.ray(nx, ny);
        let mut best: Option<(f32, usize, Vec3, Vec3, Vec3, f32)> = None;
        for (k, ax) in [Vec3::X, Vec3::Y, Vec3::Z].iter().enumerate() {
            let a = q * *ax;
            let den = a.dot(d);
            if den.abs() < 1e-4 {
                continue;
            }
            let t = a.dot(pos - o) / den;
            if t <= 0.0 {
                continue;
            }
            let rel = o + d * t - pos;
            let score = (rel.length() - rad).abs();
            let tol = (0.12 * rad).max(0.03 * t);
            if score < tol && best.map_or(true, |b| score < b.0) {
                let u = a.any_orthonormal_vector();
                let v = a.cross(u);
                let ang = rel.dot(v).atan2(rel.dot(u));
                best = Some((score, k, a, u, v, ang));
            }
        }
        match best {
            Some((_, k, axis, u, v, ang)) => {
                self.rdrag = Some(RotDrag { id, k, axis, u, v, q0: q, last: ang, total: 0.0 });
                true
            }
            None => false,
        }
    }

    fn rot_drag(&mut self, nx: f32, ny: f32) -> bool {
        let (id, axis, u, v, q0, last, total) = match &self.rdrag {
            Some(d) => (d.id, d.axis, d.u, d.v, d.q0, d.last, d.total),
            None => return false,
        };
        let pos = match self.ents.iter().find(|e| e.id == id) {
            Some(e) => e.pos,
            None => return false,
        };
        let (o, d) = self.ray(nx, ny);
        let den = axis.dot(d);
        if den.abs() < 1e-4 {
            return true;
        }
        let t = axis.dot(pos - o) / den;
        if t <= 0.0 {
            return true;
        }
        let rel = o + d * t - pos;
        let ang = rel.dot(v).atan2(rel.dot(u));
        let mut dl = ang - last;
        if dl > PI {
            dl -= 2.0 * PI;
        } else if dl < -PI {
            dl += 2.0 * PI;
        }
        let total = total + dl;
        if let Some(r) = self.rdrag.as_mut() {
            r.last = ang;
            r.total = total;
        }
        let step = 5.0f32.to_radians();
        let snapped = (total / step).round() * step;
        let nq = Quat::from_axis_angle(axis, snapped) * q0;
        let (x, y, z) = nq.to_euler(EulerRot::XYZ);
        let r2 = |a: f32| (a.to_degrees() * 100.0).round() / 100.0;
        if let Some(e) = self.ents.iter_mut().find(|e| e.id == id) {
            e.rot = Vec3::new(r2(x), r2(y), r2(z));
            return true;
        }
        false
    }

    fn ray(&self, nx: f32, ny: f32) -> (Vec3, Vec3) {
        let inv = (self.proj() * self.view()).inverse();
        let near = inv.project_point3(Vec3::new(nx, ny, -1.0));
        let far = inv.project_point3(Vec3::new(nx, ny, 1.0));
        (near, (far - near).normalize())
    }

    /// 6 шаров: (позиция, направление оси, цвет, радиус)
    fn handles(&self, e: &Entity) -> [(Vec3, Vec3, Vec3, f32); 6] {
        let q = e.quat();
        let dist = (e.pos - self.cam_pos).length().max(0.5);
        let off = 0.06 * dist + 0.25;
        let blue = Vec3::new(0.25, 0.50, 1.0);
        let red = Vec3::new(1.0, 0.25, 0.25);
        let green = Vec3::new(0.25, 0.85, 0.35);
        let spec = [
            (Vec3::X, 0usize, blue), (Vec3::NEG_X, 0usize, blue),
            (Vec3::Y, 1usize, red), (Vec3::NEG_Y, 1usize, red),
            (Vec3::Z, 2usize, green), (Vec3::NEG_Z, 2usize, green),
        ];
        let mut out = [(Vec3::ZERO, Vec3::ZERO, Vec3::ZERO, 0.0f32); 6];
        for (i, &(ax, c, col)) in spec.iter().enumerate() {
            let dir = q * ax;
            let p = e.pos + dir * (e.size[c] * 0.5 + off);
            let r = 0.045 * (p - self.cam_pos).length().max(0.5);
            out[i] = (p, dir, col, r);
        }
        out
    }

    fn draw_gizmo(&self) {
        if self.mode == 0 || self.play { return; }
        let e = match self.ents.iter().find(|e| e.id == self.selected) {
            Some(e) => e,
            None => return,
        };
        let gl = &self.gl;
        let p = &self.gizmo;
        let vp = self.proj() * self.view();
        gl.bind_framebuffer(GL::FRAMEBUFFER, None);
        gl.viewport(0, 0, self.w as i32, self.h as i32);
        gl.disable(GL::DEPTH_TEST);
        gl.disable(GL::CULL_FACE);
        gl.use_program(Some(&p.p));
        if self.mode == 3 {
            self.draw_rings(e);
            return;
        }
        gl.bind_vertex_array(Some(&self.sphere_vao));
        gl.uniform_matrix4fv_with_f32_array(p.l("uVP"), false, &vp.to_cols_array());
        u3(gl, p.l("uCam"), self.cam_pos);
        gl.uniform_matrix3fv_with_f32_array(p.l("uM"), false, &Mat3::IDENTITY.to_cols_array());
        let hot = self.drag.as_ref().map(|d| d.handle as i32).unwrap_or(-1);
        for (i, (pos, _, col, r)) in self.handles(e).iter().enumerate() {
            u3(gl, p.l("uC"), *pos);
            gl.uniform1f(p.l("uR"), *r);
            u3(gl, p.l("uColor"), *col);
            gl.uniform1f(p.l("uHot"), if i as i32 == hot { 1.0 } else { 0.0 });
            gl.draw_arrays(GL::TRIANGLES, 0, self.sphere_n);
        }
    }

    fn light_vp(&self, ld: Vec3, size: i32) -> Mat4 {
        let (s, c) = self.yaw.sin_cos();
        let mut center = self.cam_pos + Vec3::new(s, 0.0, -c) * (SH_R * 0.4);
        center.y = 0.0;
        let up = if ld.y.abs() > 0.95 { Vec3::Z } else { Vec3::Y };
        let view = Mat4::look_at_rh(ld * 150.0, Vec3::ZERO, up);
        let p = view.transform_point3(center);
        let texel = 2.0 * SH_R / size as f32;
        let sx = (p.x / texel).round() * texel;
        let sy = (p.y / texel).round() * texel;
        let proj = Mat4::orthographic_rh_gl(
            sx - SH_R, sx + SH_R, sy - SH_R, sy + SH_R, -p.z - 150.0, -p.z + 150.0,
        );
        proj * view
    }

    /// Ближайшие неоновые блоки как точечные источники света.
    fn neon_lights(&self, strength: f32) -> (Vec<f32>, Vec<f32>, i32) {
        let mut v: Vec<(f32, &Entity)> = self
            .ents
            .iter()
            .filter(|e| e.neon || e.fire)
            .map(|e| ((e.pos - self.cam_pos).length_squared(), e))
            .collect();
        v.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap_or(std::cmp::Ordering::Equal));
        v.truncate(NL_MAX);
        let mut p = vec![0.0f32; NL_MAX * 4];
        let mut c = vec![0.0f32; NL_MAX * 4];
        for (i, (_, e)) in v.iter().enumerate() {
            let ext = e.size.max_element() * 0.5;
            let fl = if e.fire {
                e.alpha * (1.3 + 0.2 * (self.time * 11.0 + e.pos.x).sin() + 0.1 * (self.time * 17.3 + e.pos.z).sin())
            } else {
                1.0
            };
            let s = if e.fire { strength.max(0.85) } else { strength };
            let rad = if e.fire { 11.0 + ext * 2.5 } else { 8.0 + ext * 2.0 };
            p[i * 4..i * 4 + 4].copy_from_slice(&[e.pos.x, e.pos.y, e.pos.z, rad]);
            c[i * 4..i * 4 + 4].copy_from_slice(&[
                e.color.x * s * fl, e.color.y * s * fl, e.color.z * s * fl, ext,
            ]);
        }
        (p, c, v.len() as i32)
    }

    fn dir(&self) -> Vec3 {
        let (sy, cy) = self.yaw.sin_cos();
        let (sp, cp) = self.pitch.sin_cos();
        Vec3::new(cp * sy, sp, -cp * cy)
    }

    fn view(&self) -> Mat4 {
        Mat4::look_to_rh(self.cam_pos, self.dir(), Vec3::Y)
    }

    fn proj(&self) -> Mat4 {
        Mat4::perspective_rh_gl(self.fov(), self.w as f32 / self.h.max(1) as f32, 0.1, 3200.0)
    }

    fn build_targets(&mut self) {
        let gl = &self.gl;
        for t in [self.scene.take(), self.bloom_a.take(), self.bloom_b.take()].into_iter().flatten() {
            free_target(gl, &t);
        }
        if let Some((f, t, d2)) = self.depth_view.take() {
            gl.delete_framebuffer(Some(&f));
            gl.delete_texture(Some(&t));
            gl.delete_texture(Some(&d2));
        }
        let (w, h) = (self.w as i32, self.h as i32);
        let mut used = false;
        let set = if self.hdr_ext {
            match make_set(gl, w, h, true) {
                Ok(s) => {
                    used = true;
                    Ok(s)
                }
                Err(_) => make_set(gl, w, h, false),
            }
        } else {
            make_set(gl, w, h, false)
        };
        self.hdr = used;
        if let Ok((s, a, b)) = set {
            self.scene = Some(s);
            self.bloom_a = Some(a);
            self.bloom_b = Some(b);
        }
        self.depth_view = make_depth_view(gl, w, h).ok();
    }

    fn fs_draw(&self) {
        self.gl.bind_vertex_array(Some(&self.empty_vao));
        self.gl.draw_arrays(GL::TRIANGLES, 0, 3);
    }

    fn set_entity_uniforms(&self, e: &Entity) {
        let gl = &self.gl;
        let p = &self.prog;
        u3(gl, p.l("uPos"), e.pos);
        gl.uniform_matrix3fv_with_f32_array(p.l("uRot"), false, &Mat3::from_quat(e.quat()).to_cols_array());
        u3(gl, p.l("uSize"), e.size);
        u3(gl, p.l("uColor"), e.color);
        gl.uniform1f(p.l("uNeon"), if e.neon { 1.0 } else { 0.0 });
        gl.uniform1f(p.l("uOpa"), if e.alpha < 0.999 { e.alpha } else { 0.0 });
        let mi = (e.mat as usize).min(5);
        let m = &self.mats[mi];
        gl.active_texture(GL::TEXTURE0);
        gl.bind_texture(GL::TEXTURE_2D, Some(&m.0));
        gl.active_texture(GL::TEXTURE3);
        gl.bind_texture(GL::TEXTURE_2D, Some(&m.1));
        gl.active_texture(GL::TEXTURE0);
        gl.uniform1f(p.l("uMatK"), MAT_K[mi]);
        gl.uniform1f(p.l("uMatP"), MAT_P[mi]);
        gl.uniform1f(p.l("uMatB"), MAT_B[mi]);
        gl.uniform1f(p.l("uMatS"), MAT_S[mi]);
    }

    fn blur_pass(&self, src: &Target, dst: &Target, dx: f32, dy: f32) {
        let gl = &self.gl;
        let p = &self.blur;
        gl.bind_framebuffer(GL::FRAMEBUFFER, Some(&dst.fbo));
        gl.viewport(0, 0, dst.w, dst.h);
        gl.use_program(Some(&p.p));
        gl.active_texture(GL::TEXTURE0);
        gl.bind_texture(GL::TEXTURE_2D, Some(&src.tex));
        gl.uniform1i(p.l("uSrc"), 0);
        gl.uniform2f(p.l("uStep"), dx * 1.5 / src.w as f32, dy * 1.5 / src.h as f32);
        self.fs_draw();
    }

    fn render_scene(&self) {
        let gl = &self.gl;
        let g = &self.gfx;
        let (w, h) = (self.w as i32, self.h as i32);
        let st = sky_state(g[G_TIME], g[G_AMB]);
        let vp = self.proj() * self.view();
        let fog_col = st.horizon * g[G_SKYB];
        let under = self.under_amount();

        // --- теневая карта ---
        let lvp = self.light_vp(st.light_dir, self.sh_size);
        if let Some((sfbo, stex)) = &self.shadow {
            if g[G_SHADOW] > 0.01 {
                let p = &self.shprog;
                gl.bind_framebuffer(GL::FRAMEBUFFER, Some(sfbo));
                gl.viewport(0, 0, self.sh_size, self.sh_size);
                gl.enable(GL::DEPTH_TEST);
                gl.depth_mask(true);
                gl.clear(GL::DEPTH_BUFFER_BIT);
                gl.enable(GL::POLYGON_OFFSET_FILL);
                gl.polygon_offset(2.0, 4.0);
                gl.use_program(Some(&p.p));
                gl.uniform_matrix4fv_with_f32_array(p.l("uLVP"), false, &lvp.to_cols_array());
                for e in self.ents.iter().filter(|e| !e.water && !e.fire && e.alpha > 0.05 && !self.hide_iso(e.id)) {
                    gl.uniform1f(p.l("uAlpha"), e.alpha);
                    u3(gl, p.l("uPos"), e.pos);
                    gl.uniform_matrix3fv_with_f32_array(p.l("uRot"), false, &Mat3::from_quat(e.quat()).to_cols_array());
                    u3(gl, p.l("uSize"), e.size);
                    let n = self.bind_mesh(e);
                    gl.draw_arrays(GL::TRIANGLES, 0, n);
                }
                if self.play {
                    gl.bind_vertex_array(Some(&self.ball_vao));
                    u3(gl, p.l("uPos"), self.p_pos);
                    gl.uniform_matrix3fv_with_f32_array(p.l("uRot"), false, &Mat3::IDENTITY.to_cols_array());
                    u3(gl, p.l("uSize"), Vec3::ONE);
                    gl.uniform1f(p.l("uAlpha"), 1.0);
                    gl.draw_arrays(GL::TRIANGLES, 0, self.ball_n);
                }
                gl.disable(GL::POLYGON_OFFSET_FILL);
            }
            gl.active_texture(GL::TEXTURE2);
            gl.bind_texture(GL::TEXTURE_2D, Some(stex));
            gl.active_texture(GL::TEXTURE0);
        }

        gl.active_texture(GL::TEXTURE3);
        gl.bind_texture(GL::TEXTURE_2D, Some(&self.ntex));
        gl.active_texture(GL::TEXTURE4);
        gl.bind_texture(GL::TEXTURE_2D, Some(&self.wtex1));
        gl.active_texture(GL::TEXTURE5);
        gl.bind_texture(GL::TEXTURE_2D, Some(&self.wtex2));
        gl.active_texture(GL::TEXTURE6);
        gl.bind_texture(GL::TEXTURE_2D, Some(&self.tex));
        gl.active_texture(GL::TEXTURE0);

        // текстура шума на юнит 0 ДО привязки сцены (без петли обратной связи)
        gl.active_texture(GL::TEXTURE0);
        gl.bind_texture(GL::TEXTURE_2D, Some(&self.tex));
        gl.bind_framebuffer(GL::FRAMEBUFFER, self.scene.as_ref().map(|t| &t.fbo));
        gl.viewport(0, 0, w, h);
        gl.disable(GL::DEPTH_TEST);
        gl.disable(GL::CULL_FACE);
        gl.clear_color(0.0, 0.0, 0.0, 0.0);
        gl.clear(GL::COLOR_BUFFER_BIT | GL::DEPTH_BUFFER_BIT);

        // --- небо ---
        {
            let p = &self.sky;
            gl.depth_mask(false);
            gl.use_program(Some(&p.p));
            gl.uniform_matrix4fv_with_f32_array(p.l("uInvVP"), false, &vp.inverse().to_cols_array());
            u3(gl, p.l("uCam"), self.cam_pos);
            u3(gl, p.l("uZenith"), st.zenith);
            u3(gl, p.l("uHorizon"), st.horizon);
            u3(gl, p.l("uSunDir"), st.sun_dir);
            u3(gl, p.l("uSunCol"), st.sun_col);
            gl.uniform1f(p.l("uSkyB"), g[G_SKYB]);
            gl.uniform1f(p.l("uSunSize"), g[G_SUN]);
            gl.uniform1f(p.l("uNight"), st.night);
            gl.uniform1f(p.l("uSunset"), st.sunset);
            gl.uniform1f(p.l("uSunVis"), st.sun_vis);
            u3(gl, p.l("uLightDir"), st.light_dir);
            u3(gl, p.l("uLightCol"), st.light_col);
            gl.uniform1f(p.l("uMie"), g[G_MIE]);
            gl.uniform1f(p.l("uUnder"), under);
            self.fs_draw();
            gl.depth_mask(true);
        }

        // --- блоки ---
        gl.enable(GL::DEPTH_TEST);
        {
            let p = &self.prog;
            gl.use_program(Some(&p.p));
            gl.bind_vertex_array(Some(&self.vao));
            gl.uniform1i(p.l("uTex"), 0);
            gl.uniform_matrix4fv_with_f32_array(p.l("uVP"), false, &vp.to_cols_array());
            u3(gl, p.l("uCam"), self.cam_pos);
            u3(gl, p.l("uAmb"), st.amb);
            u3(gl, p.l("uLightCol"), st.light_col);
            u3(gl, p.l("uLightDir"), st.light_dir);
            u3(gl, p.l("uFogCol"), fog_col);
            gl.uniform1f(p.l("uFogDen"), g[G_FOGD]);
            gl.uniform1f(p.l("uFogStart"), g[G_FOGS]);
            gl.uniform1f(p.l("uNeonB"), g[G_NEON]);
            gl.uniform1i(p.l("uNrm"), 3);
            gl.uniform1i(p.l("uNoise"), 6);
            gl.uniform1f(p.l("uRays"), g[G_RAYS]);
            gl.uniform1f(p.l("uUnder"), under);
            gl.uniform1f(p.l("uTime"), self.time);
            gl.uniform1f(p.l("uFogN"), g[G_FOGN]);
            gl.uniform1f(p.l("uMie"), g[G_MIE]);
            gl.uniform1f(p.l("uBump"), g[G_BUMP]);
            u3(gl, p.l("uZenith"), st.zenith);
            u3(gl, p.l("uSunDir"), st.sun_dir);
            gl.uniform1f(p.l("uSkyB"), g[G_SKYB]);
            gl.uniform1f(p.l("uSunset"), st.sunset);
            gl.uniform1i(p.l("uShadow"), 2);
            gl.uniform1f(p.l("uShOn"), if self.shadow.is_some() { g[G_SHADOW] } else { 0.0 });
            gl.uniform_matrix4fv_with_f32_array(p.l("uLVP"), false, &lvp.to_cols_array());
            let (nlp, nlc, nln) = self.neon_lights(g[G_NLIGHT]);
            gl.uniform4fv_with_f32_array(p.l("uNLp"), &nlp);
            gl.uniform4fv_with_f32_array(p.l("uNLc"), &nlc);
            gl.uniform1i(p.l("uNLn"), nln);
            let k = 4.0 * 2.0 * (self.fov() * 0.5).tan() / self.h.max(1) as f32;
            gl.uniform1f(p.l("uOutline"), k);

            gl.uniform1i(p.l("uMode"), 0);
            gl.disable(GL::CULL_FACE);
            for e in self.ents.iter().filter(|e| !e.water && !e.fire && e.alpha >= 0.999 && !self.hide_iso(e.id)) {
                self.set_entity_uniforms(e);
                let n = self.bind_mesh(e);
                gl.draw_arrays(GL::TRIANGLES, 0, n);
            }
            gl.enable(GL::CULL_FACE);

            if self.play && self.third && self.pm_root < 0 {
                gl.bind_vertex_array(Some(&self.ball_vao));
                gl.uniform1i(p.l("uMode"), 0);
                gl.uniform1f(p.l("uBump"), 0.0);
                gl.uniform1f(p.l("uOpa"), 0.0);
                gl.uniform1f(p.l("uNeon"), 0.0);
                gl.uniform1f(p.l("uMatK"), 0.0);
                gl.uniform1f(p.l("uMatP"), 0.0);
                gl.uniform1f(p.l("uMatB"), 0.0);
                u3(gl, p.l("uPos"), self.p_pos);
                gl.uniform_matrix3fv_with_f32_array(p.l("uRot"), false, &Mat3::IDENTITY.to_cols_array());
                u3(gl, p.l("uSize"), Vec3::ONE);
                u3(gl, p.l("uColor"), Vec3::new(0.55, 0.56, 0.58));
                gl.draw_arrays(GL::TRIANGLES, 0, self.ball_n);
                gl.uniform1f(p.l("uBump"), g[G_BUMP]);
                gl.bind_vertex_array(Some(&self.vao));
            }

            if let Some(e) = self.ents.iter().find(|e| e.id == self.selected && !e.fire) {
                gl.enable(GL::CULL_FACE);
                gl.cull_face(GL::FRONT);
                gl.uniform1i(p.l("uMode"), 1);
                self.set_entity_uniforms(e);
                let n = self.bind_mesh(e);
                gl.draw_arrays(GL::TRIANGLES, 0, n);
                gl.disable(GL::CULL_FACE);
                gl.cull_face(GL::BACK);
                gl.uniform1i(p.l("uMode"), 0);
            }
        }

        // --- копия глубины (пена у берега) ---
        if let (Some(sc), Some(dv)) = (&self.scene, &self.depth_view) {
            gl.bind_framebuffer(GL::READ_FRAMEBUFFER, Some(&sc.fbo));
            gl.bind_framebuffer(GL::DRAW_FRAMEBUFFER, Some(&dv.0));
            gl.blit_framebuffer(0, 0, w, h, 0, 0, w, h, GL::DEPTH_BUFFER_BIT, GL::NEAREST);
            gl.bind_framebuffer(GL::FRAMEBUFFER, Some(&sc.fbo));
        }

        // --- огонь (до воды: вода и геометрия корректно его перекрывают) ---
        if self.ents.iter().any(|e| e.fire) {
            gl.enable(GL::DEPTH_TEST);
            gl.enable(GL::BLEND);
            gl.blend_func_separate(GL::ONE, GL::ONE_MINUS_SRC_ALPHA, GL::ZERO, GL::ONE_MINUS_SRC_ALPHA);
            gl.depth_mask(true);
            for e in self.ents.iter().filter(|e| e.fire) {
                self.draw_fire(e, &vp);
            }
            gl.depth_mask(true);
            gl.disable(GL::BLEND);
        }

        // --- прозрачные блоки и вода (от дальних к ближним) ---
        {
            let mut items: Vec<(f32, usize)> = self
                .ents
                .iter()
                .enumerate()
                .filter(|(_, e)| !e.fire && (e.water || e.alpha < 0.999) && !self.hide_iso(e.id))
                .map(|(i, e)| ((e.pos - self.cam_pos).length_squared(), i))
                .collect();
            if !items.is_empty() {
                items.sort_by(|a, b| b.0.partial_cmp(&a.0).unwrap_or(std::cmp::Ordering::Equal));
                gl.enable(GL::BLEND);
                gl.blend_func_separate(GL::SRC_ALPHA, GL::ONE_MINUS_SRC_ALPHA, GL::ZERO, GL::ONE);
                gl.depth_mask(false);
                for (_, i) in items {
                    let e = &self.ents[i];
                    if e.water {
                        self.draw_water(e, &st, &vp, fog_col, &lvp, under);
                    } else {
                        let p = &self.prog;
                        gl.use_program(Some(&p.p));
                        gl.bind_vertex_array(Some(&self.vao));
                        gl.uniform1i(p.l("uMode"), 0);
                        self.set_entity_uniforms(e);
                        let n = self.bind_mesh(e);
                        gl.enable(GL::CULL_FACE);
                        gl.cull_face(GL::FRONT);
                        gl.draw_arrays(GL::TRIANGLES, 0, n);
                        gl.cull_face(GL::BACK);
                        gl.draw_arrays(GL::TRIANGLES, 0, n);
                        gl.disable(GL::CULL_FACE);
                    }
                }
                gl.depth_mask(true);
                gl.disable(GL::BLEND);
            }
        }

        // --- постобработка ---
        if let (Some(sc), Some(ba), Some(bb)) = (&self.scene, &self.bloom_a, &self.bloom_b) {
            gl.disable(GL::DEPTH_TEST);

            // яркие пиксели -> a
            {
                let p = &self.bright;
                gl.bind_framebuffer(GL::FRAMEBUFFER, Some(&ba.fbo));
                gl.viewport(0, 0, ba.w, ba.h);
                gl.use_program(Some(&p.p));
                gl.active_texture(GL::TEXTURE0);
                gl.bind_texture(GL::TEXTURE_2D, Some(&sc.tex));
                gl.uniform1i(p.l("uSrc"), 0);
                gl.uniform2f(p.l("uTexel"), 2.0 / w as f32, 2.0 / h as f32);
                gl.uniform1f(p.l("uThr"), g[G_BTHR]);
                self.fs_draw();
            }
            // размытие (2 итерации)
            for _ in 0..2 {
                self.blur_pass(ba, bb, 1.0, 0.0);
                self.blur_pass(bb, ba, 0.0, 1.0);
            }

            // положение солнца на экране (лучи не гаснут при повороте камеры)
            let sp = self.cam_pos + st.sun_dir * 500.0;
            let clip = vp * Vec4::new(sp.x, sp.y, sp.z, 1.0);
            let fwd = self.dir();
            let face = fwd.dot(st.sun_dir);
            let soft = 0.28 + 0.72 * sstep(-0.35, 0.30, face);
            let (sun_uv, sun_on) = if clip.w > 0.001 {
                let (ux, uy) = (clip.x / clip.w * 0.5 + 0.5, clip.y / clip.w * 0.5 + 0.5);
                let ex = (ux - 0.5).abs().max((uy - 0.5).abs()) * 2.0;
                let fade = (1.0 - 0.75 * sstep(1.2, 3.0, ex)).max(0.25);
                ((ux, uy), st.sun_vis * fade * soft)
            } else {
                // солнце за камерой: источник за краем экрана в его стороне
                let vd = self.view() * Vec4::new(st.sun_dir.x, st.sun_dir.y, st.sun_dir.z, 0.0);
                let l2 = (vd.x * vd.x + vd.y * vd.y).sqrt().max(1e-4);
                let ux = 0.5 + (vd.x / l2) * 2.4;
                let uy = 0.5 + (vd.y / l2) * 2.4;
                ((ux, uy), st.sun_vis * soft * 0.8)
            };

            // финальная композиция на экран
            {
                let p = &self.post;
                gl.bind_framebuffer(GL::FRAMEBUFFER, None);
                gl.viewport(0, 0, w, h);
                gl.use_program(Some(&p.p));
                gl.active_texture(GL::TEXTURE0);
                gl.bind_texture(GL::TEXTURE_2D, Some(&sc.tex));
                gl.active_texture(GL::TEXTURE1);
                gl.bind_texture(GL::TEXTURE_2D, Some(&ba.tex));
                gl.uniform1i(p.l("uScene"), 0);
                gl.uniform1i(p.l("uBloom"), 1);
                if let Some((_, dt, _)) = &self.depth_view {
                    gl.active_texture(GL::TEXTURE8);
                    gl.bind_texture(GL::TEXTURE_2D, Some(dt));
                    gl.uniform1i(p.l("uDepthTex"), 8);
                    gl.active_texture(GL::TEXTURE0);
                }
                gl.uniform2f(p.l("uSun"), sun_uv.0, sun_uv.1);
                gl.uniform1f(p.l("uSunOn"), sun_on);
                u3(gl, p.l("uRayCol"), st.sun_col * (1.0 + st.sunset * 1.2));
                gl.uniform1f(p.l("uRays"), g[G_RAYS]);
                gl.uniform1f(p.l("uBloomS"), g[G_BLOOM]);
                gl.uniform1f(p.l("uExposure"), g[G_EXPOSURE]);
                gl.uniform1f(p.l("uContrast"), g[G_CONTRAST]);
                gl.uniform1f(p.l("uSat"), g[G_SAT]);
                gl.uniform1f(p.l("uVig"), g[G_VIG]);
                gl.uniform1f(p.l("uAsp"), w as f32 / h as f32);
                gl.uniform1f(p.l("uUnder"), under);
                gl.uniform1f(p.l("uTime"), self.time);
                self.fs_draw();
                gl.active_texture(GL::TEXTURE0);
            }
        } else {
            // FBO не создались — залить фон, чтобы не остался чёрный экран
            gl.bind_framebuffer(GL::FRAMEBUFFER, None);
            gl.viewport(0, 0, w, h);
            gl.clear_color(0.07, 0.09, 0.13, 1.0);
            gl.clear(GL::COLOR_BUFFER_BIT);
        }
    }
}

// ---------- проверки целостности ----------
fn line(ok: bool, msg: String) -> String {
    format!("{} {}", if ok { "OK" } else { "FAIL" }, msg)
}

#[wasm_bindgen]
pub fn version() -> String {
    env!("CARGO_PKG_VERSION").to_string()
}

#[wasm_bindgen]
pub fn gfx_defaults() -> Vec<f32> {
    GFX_DEF.to_vec()
}

#[wasm_bindgen]
pub fn run_self_test(en: bool) -> String {
    let tr = |ru: String, e: String| if en { e } else { ru };
    let mut out: Vec<String> = Vec::new();

    let m = Mat4::from_rotation_translation(
        Quat::from_euler(EulerRot::XYZ, 0.3, 0.5, 0.7),
        Vec3::new(1.0, 2.0, 3.0),
    );
    let err = (m * m.inverse() - Mat4::IDENTITY)
        .to_cols_array()
        .iter()
        .fold(0.0f32, |a, b| a.max(b.abs()));
    out.push(line(
        err < 1e-4,
        tr(
            format!("Математика: M·M⁻¹ = I (ошибка {:.1e})", err),
            format!("Math: M·M⁻¹ = I (error {:.1e})", err),
        ),
    ));

    let t = ray_obb(
        Vec3::new(0.0, 5.0, 0.0),
        Vec3::NEG_Y,
        Vec3::new(0.0, -0.5, 0.0),
        Quat::IDENTITY,
        Vec3::new(40.0, 1.0, 40.0),
    );
    let ok = matches!(t, Some(v) if (v - 5.0).abs() < 1e-4);
    out.push(line(
        ok,
        tr(
            format!("Коллизия: луч↔коробка (t = {:?})", t),
            format!("Collision: ray↔box (t = {:?})", t),
        ),
    ));
    let miss = ray_obb(
        Vec3::new(100.0, 5.0, 0.0),
        Vec3::NEG_Y,
        Vec3::new(0.0, -0.5, 0.0),
        Quat::IDENTITY,
        Vec3::new(40.0, 1.0, 40.0),
    );
    out.push(line(
        miss.is_none(),
        tr("Коллизия: промах определяется".into(), "Collision: miss detected".into()),
    ));

    let t1 = noise::fbm_texture(64, 7);
    let t2 = noise::fbm_texture(64, 7);
    out.push(line(t1 == t2, tr("Шум: детерминированность".into(), "Noise: determinism".into())));
    let (mn, mx) = t1.chunks(4).fold((255u8, 0u8), |(a, b), p| (a.min(p[0]), b.max(p[0])));
    out.push(line(
        mx.saturating_sub(mn) > 40,
        tr(format!("Шум: контраст {}..{}", mn, mx), format!("Noise: contrast {}..{}", mn, mx)),
    ));
    let a = noise::perlin(0.3, 0.7, 4, 1);
    let b = noise::perlin(4.3, 0.7, 4, 1);
    out.push(line(
        (a - b).abs() < 1e-3,
        tr("Шум: бесшовность (тайлинг)".into(), "Noise: seamless tiling".into()),
    ));

    let wmax = (0..200)
        .map(|i| wave_height(i as f32 * 0.7, i as f32 * 0.3, 1.5, 1.0, 1.0).abs())
        .fold(0.0f32, f32::max);
    out.push(line(
        wmax > 0.01 && wmax < 0.9,
        tr(format!("Вода: амплитуда волн {:.2}", wmax), format!("Water: wave amplitude {:.2}", wmax)),
    ));

    let sp = sphere_obb(
        Vec3::new(0.0, 0.3, 0.0), 0.4,
        Vec3::new(0.0, -0.5, 0.0), Quat::IDENTITY, Vec3::new(40.0, 1.0, 40.0),
    );
    out.push(line(
        matches!(sp, Some(v) if (v.y - 0.1).abs() < 1e-4 && v.x.abs() < 1e-4),
        tr("Игрок: капсула стоит на плите".into(), "Player: capsule rests on plate".into()),
    ));

    let noon = sky_state(12.0, 1.0);
    let midnight = sky_state(0.0, 1.0);
    out.push(line(
        noon.sun_dir.y > 0.8 && midnight.sun_dir.y < -0.8,
        tr("Небо: положение солнца по времени".into(), "Sky: sun position by time".into()),
    ));

    out.join("\n")
}
