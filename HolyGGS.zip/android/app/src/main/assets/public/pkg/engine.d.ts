/* tslint:disable */
/* eslint-disable */

export class Engine {
    free(): void;
    [Symbol.dispose](): void;
    add_entity(name: string, p: Float32Array): number;
    blender(): boolean;
    /**
     * Точка перед камерой на расстоянии dist.
     */
    camera_front(dist: number): Float32Array;
    /**
     * Прямые потомки объекта.
     */
    children_of(id: number): Int32Array;
    clear(): void;
    descendants_of(id: number): Int32Array;
    /**
     * Массив: count копий маски/модели вдоль оси с шагом step ячеек.
     */
    edit_array(id: number, axis: number, count: number, step: number): void;
    /**
     * Булевы операции с другим объектом: 0 сложить, 1 вычесть, 2 пересечение.
     */
    edit_bool(id: number, op: number, target: number): number;
    edit_cell_on(id: number, cell: number): boolean;
    edit_cells_hex(id: number): string;
    edit_color_at(id: number, cell: number): number;
    /**
     * Цвета ячеек: "idx:rrggbb,..." (пусто = без покраски).
     */
    edit_colors_hex(id: number): string;
    /**
     * Копия маски/модели со сдвигом на dir ячеек (оригинал остаётся).
     */
    edit_copy(id: number, axis: number, dir: number): void;
    /**
     * Выдавливание (совместимо): копия на +1 вдоль оси.
     */
    edit_extrude(id: number, axis: number): void;
    /**
     * Грань+: достроить соседнюю ячейку в направлении грани.
     */
    edit_grow_face(id: number, cell: number, face: number): void;
    /**
     * Дыра: сквозной вырез вдоль нормали грани.
     */
    edit_hole(id: number, cell: number, face: number): void;
    /**
     * Полость: оставить только оболочку.
     */
    edit_hollow(id: number): void;
    edit_id(): number;
    /**
     * Инверсия ячеек.
     */
    edit_invert(id: number): void;
    edit_iso(): boolean;
    edit_mirror(): number;
    /**
     * Симметризация по осям (биты X/Y/Z).
     */
    edit_mirror_fill(id: number, axes: number): void;
    /**
     * Сдвиг ячеек (маски/выделения или всей модели) на dir ячеек вдоль оси.
     */
    edit_move(id: number, axis: number, dir: number): void;
    /**
     * Органика: случайное возмущение ячеек.
     */
    edit_organic(id: number): void;
    edit_paint(id: number, cell: number, rgb: number): void;
    edit_reset_cells(id: number): void;
    /**
     * Поворот маски/модели на 90° вокруг оси (вокруг центра выделения).
     */
    edit_rot(id: number, axis: number): void;
    /**
     * Поставить/снять ячейку; при живом зеркале правка дублируется на близнецов.
     */
    edit_set_cell(id: number, cell: number, on: boolean): void;
    /**
     * Стартовая форма: 0 куб, 1 цилиндр, 2 конус, 3 клин, 4 арка, 5 лестница.
     */
    edit_shape(id: number, kind: number): void;
    edit_toggle(id: number, cell: number): void;
    entity_ids(): Int32Array;
    entity_name(id: number): string;
    /**
     * Навести камеру на точку (режим правки).
     */
    focus_on(x: number, y: number, z: number, dist: number): void;
    frame(dt: number): void;
    get_edit(id: number): Float32Array;
    get_gfx(i: number): number;
    /**
     * [pos xyz, rot xyz (град), size xyz, color rgb 0..1, neon, alpha, water, fire, mat, wtex, shape, rough, visible]
     */
    get_props(id: number): Float32Array;
    gizmo_begin(nx: number, ny: number): boolean;
    gizmo_drag(nx: number, ny: number): boolean;
    gizmo_end(): void;
    hdr(): boolean;
    is_play(): boolean;
    look(dx: number, dy: number): void;
    constructor(canvas_id: string);
    parent_of(id: number): number;
    pick(nx: number, ny: number): number;
    pick_cell(nx: number, ny: number): number;
    /**
     * Луч -> ячейка*8 + грань (0=+X, 1=-X, 2=+Y, 3=-Y, 4=+Z, 5=-Z).
     */
    pick_face(nx: number, ny: number): number;
    player_pos(): Float32Array;
    pm_root(): number;
    remove_entity(id: number): void;
    reset_camera(): void;
    resize(w: number, h: number): void;
    /**
     * Выделение рамкой (NDC-прямоугольник) по центрам ячеек.
     */
    sel_box(id: number, x0: number, y0: number, x1: number, y1: number): void;
    sel_clear(id: number): void;
    sel_count(id: number): number;
    sel_delete(id: number): void;
    /**
     * Заливка связных ячеек (выделение).
     */
    sel_flood(id: number, cell: number): void;
    sel_paint(id: number, rgb: number): void;
    select(id: number): void;
    selected(): number;
    /**
     * Режим Блендера: серый фон, изолированный объект.
     */
    set_blender(on: boolean): void;
    set_custom_mat(data: Uint8Array, w: number, h: number): void;
    /**
     * Своя текстура воды из галереи: квадратная RGBA8 (рекомендуется 256).
     */
    set_custom_water(data: Uint8Array, w: number, h: number): void;
    /**
     * Правка: уровень сетки 0..7, скругление, ячейки hex (4 слова по 16 hex, старшее первым).
     */
    set_edit(id: number, sub: number, round: number, cells_hex: string): void;
    set_edit_colors(id: number, s: string): void;
    set_edit_hover(cell: number): void;
    set_edit_id(id: number): void;
    set_edit_iso(on: boolean): void;
    set_edit_mirror(axes: number): void;
    set_entity_name(id: number, name: string): void;
    set_gfx(i: number, v: number): void;
    set_mode(m: number): void;
    set_move(strafe: number, forward: number, up: number): void;
    set_parent(id: number, parent: number): void;
    set_play(on: boolean): void;
    /**
     * Характеристики игрока из скрипта: скорость, прыжок, размер капсулы.
     */
    set_player_stats(speed: number, jump: number, size: number): void;
    set_pm_root(id: number): void;
    set_props(id: number, p: Float32Array): void;
    set_third(on: boolean): void;
    /**
     * Высота волн в точке (x, z) относительно уровня воды (для будущей плавучести).
     */
    water_height(x: number, z: number): number;
    /**
     * Проекция мировой точки на экран (px) — для биллбордов @UI.Bb.* (UI, привязанный
     * к 3D-точке/объекту, всегда "смотрит" на игрока, т.к. это плоский экранный оверлей).
     * Возвращает [x_px, y_px, visible(1/0), dist].
     */
    world_to_screen(x: number, y: number, z: number): Float32Array;
}

export function gfx_defaults(): Float32Array;

export function run_self_test(en: boolean): string;

export function version(): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_engine_free: (a: number, b: number) => void;
    readonly engine_add_entity: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly engine_blender: (a: number) => number;
    readonly engine_camera_front: (a: number, b: number) => [number, number];
    readonly engine_children_of: (a: number, b: number) => [number, number];
    readonly engine_clear: (a: number) => void;
    readonly engine_descendants_of: (a: number, b: number) => [number, number];
    readonly engine_edit_array: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly engine_edit_bool: (a: number, b: number, c: number, d: number) => number;
    readonly engine_edit_cell_on: (a: number, b: number, c: number) => number;
    readonly engine_edit_cells_hex: (a: number, b: number) => [number, number];
    readonly engine_edit_color_at: (a: number, b: number, c: number) => number;
    readonly engine_edit_colors_hex: (a: number, b: number) => [number, number];
    readonly engine_edit_copy: (a: number, b: number, c: number, d: number) => void;
    readonly engine_edit_extrude: (a: number, b: number, c: number) => void;
    readonly engine_edit_grow_face: (a: number, b: number, c: number, d: number) => void;
    readonly engine_edit_hole: (a: number, b: number, c: number, d: number) => void;
    readonly engine_edit_hollow: (a: number, b: number) => void;
    readonly engine_edit_id: (a: number) => number;
    readonly engine_edit_invert: (a: number, b: number) => void;
    readonly engine_edit_iso: (a: number) => number;
    readonly engine_edit_mirror: (a: number) => number;
    readonly engine_edit_mirror_fill: (a: number, b: number, c: number) => void;
    readonly engine_edit_move: (a: number, b: number, c: number, d: number) => void;
    readonly engine_edit_organic: (a: number, b: number) => void;
    readonly engine_edit_paint: (a: number, b: number, c: number, d: number) => void;
    readonly engine_edit_reset_cells: (a: number, b: number) => void;
    readonly engine_edit_rot: (a: number, b: number, c: number) => void;
    readonly engine_edit_set_cell: (a: number, b: number, c: number, d: number) => void;
    readonly engine_edit_shape: (a: number, b: number, c: number) => void;
    readonly engine_edit_toggle: (a: number, b: number, c: number) => void;
    readonly engine_entity_ids: (a: number) => [number, number];
    readonly engine_entity_name: (a: number, b: number) => [number, number];
    readonly engine_focus_on: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly engine_frame: (a: number, b: number) => void;
    readonly engine_get_edit: (a: number, b: number) => [number, number];
    readonly engine_get_gfx: (a: number, b: number) => number;
    readonly engine_get_props: (a: number, b: number) => [number, number];
    readonly engine_gizmo_begin: (a: number, b: number, c: number) => number;
    readonly engine_gizmo_drag: (a: number, b: number, c: number) => number;
    readonly engine_gizmo_end: (a: number) => void;
    readonly engine_hdr: (a: number) => number;
    readonly engine_is_play: (a: number) => number;
    readonly engine_look: (a: number, b: number, c: number) => void;
    readonly engine_new: (a: number, b: number) => [number, number, number];
    readonly engine_parent_of: (a: number, b: number) => number;
    readonly engine_pick: (a: number, b: number, c: number) => number;
    readonly engine_pick_cell: (a: number, b: number, c: number) => number;
    readonly engine_pick_face: (a: number, b: number, c: number) => number;
    readonly engine_player_pos: (a: number) => [number, number];
    readonly engine_pm_root: (a: number) => number;
    readonly engine_remove_entity: (a: number, b: number) => void;
    readonly engine_reset_camera: (a: number) => void;
    readonly engine_resize: (a: number, b: number, c: number) => void;
    readonly engine_sel_box: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly engine_sel_clear: (a: number, b: number) => void;
    readonly engine_sel_count: (a: number, b: number) => number;
    readonly engine_sel_delete: (a: number, b: number) => void;
    readonly engine_sel_flood: (a: number, b: number, c: number) => void;
    readonly engine_sel_paint: (a: number, b: number, c: number) => void;
    readonly engine_select: (a: number, b: number) => void;
    readonly engine_selected: (a: number) => number;
    readonly engine_set_blender: (a: number, b: number) => void;
    readonly engine_set_custom_mat: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly engine_set_custom_water: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly engine_set_edit: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly engine_set_edit_colors: (a: number, b: number, c: number, d: number) => void;
    readonly engine_set_edit_hover: (a: number, b: number) => void;
    readonly engine_set_edit_id: (a: number, b: number) => void;
    readonly engine_set_edit_iso: (a: number, b: number) => void;
    readonly engine_set_edit_mirror: (a: number, b: number) => void;
    readonly engine_set_entity_name: (a: number, b: number, c: number, d: number) => void;
    readonly engine_set_gfx: (a: number, b: number, c: number) => void;
    readonly engine_set_mode: (a: number, b: number) => void;
    readonly engine_set_move: (a: number, b: number, c: number, d: number) => void;
    readonly engine_set_parent: (a: number, b: number, c: number) => void;
    readonly engine_set_play: (a: number, b: number) => void;
    readonly engine_set_player_stats: (a: number, b: number, c: number, d: number) => void;
    readonly engine_set_pm_root: (a: number, b: number) => void;
    readonly engine_set_props: (a: number, b: number, c: number, d: number) => void;
    readonly engine_set_third: (a: number, b: number) => void;
    readonly engine_water_height: (a: number, b: number, c: number) => number;
    readonly engine_world_to_screen: (a: number, b: number, c: number, d: number) => [number, number];
    readonly gfx_defaults: () => [number, number];
    readonly run_self_test: (a: number) => [number, number];
    readonly version: () => [number, number];
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
