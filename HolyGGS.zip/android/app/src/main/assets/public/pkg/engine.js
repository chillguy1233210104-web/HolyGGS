/* @ts-self-types="./engine.d.ts" */

export class Engine {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        EngineFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_engine_free(ptr, 0);
    }
    /**
     * @param {string} name
     * @param {Float32Array} p
     * @returns {number}
     */
    add_entity(name, p) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArrayF32ToWasm0(p, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.engine_add_entity(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        return ret;
    }
    /**
     * @returns {boolean}
     */
    blender() {
        const ret = wasm.engine_blender(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Точка перед камерой на расстоянии dist.
     * @param {number} dist
     * @returns {Float32Array}
     */
    camera_front(dist) {
        const ret = wasm.engine_camera_front(this.__wbg_ptr, dist);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Прямые потомки объекта.
     * @param {number} id
     * @returns {Int32Array}
     */
    children_of(id) {
        const ret = wasm.engine_children_of(this.__wbg_ptr, id);
        var v1 = getArrayI32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    clear() {
        wasm.engine_clear(this.__wbg_ptr);
    }
    /**
     * @param {number} id
     * @returns {Int32Array}
     */
    descendants_of(id) {
        const ret = wasm.engine_descendants_of(this.__wbg_ptr, id);
        var v1 = getArrayI32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Массив: count копий маски/модели вдоль оси с шагом step ячеек.
     * @param {number} id
     * @param {number} axis
     * @param {number} count
     * @param {number} step
     */
    edit_array(id, axis, count, step) {
        wasm.engine_edit_array(this.__wbg_ptr, id, axis, count, step);
    }
    /**
     * Булевы операции с другим объектом: 0 сложить, 1 вычесть, 2 пересечение.
     * @param {number} id
     * @param {number} op
     * @param {number} target
     * @returns {number}
     */
    edit_bool(id, op, target) {
        const ret = wasm.engine_edit_bool(this.__wbg_ptr, id, op, target);
        return ret >>> 0;
    }
    /**
     * @param {number} id
     * @param {number} cell
     * @returns {boolean}
     */
    edit_cell_on(id, cell) {
        const ret = wasm.engine_edit_cell_on(this.__wbg_ptr, id, cell);
        return ret !== 0;
    }
    /**
     * @param {number} id
     * @returns {string}
     */
    edit_cells_hex(id) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.engine_edit_cells_hex(this.__wbg_ptr, id);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {number} id
     * @param {number} cell
     * @returns {number}
     */
    edit_color_at(id, cell) {
        const ret = wasm.engine_edit_color_at(this.__wbg_ptr, id, cell);
        return ret;
    }
    /**
     * Цвета ячеек: "idx:rrggbb,..." (пусто = без покраски).
     * @param {number} id
     * @returns {string}
     */
    edit_colors_hex(id) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.engine_edit_colors_hex(this.__wbg_ptr, id);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Копия маски/модели со сдвигом на dir ячеек (оригинал остаётся).
     * @param {number} id
     * @param {number} axis
     * @param {number} dir
     */
    edit_copy(id, axis, dir) {
        wasm.engine_edit_copy(this.__wbg_ptr, id, axis, dir);
    }
    /**
     * Выдавливание (совместимо): копия на +1 вдоль оси.
     * @param {number} id
     * @param {number} axis
     */
    edit_extrude(id, axis) {
        wasm.engine_edit_extrude(this.__wbg_ptr, id, axis);
    }
    /**
     * Грань+: достроить соседнюю ячейку в направлении грани.
     * @param {number} id
     * @param {number} cell
     * @param {number} face
     */
    edit_grow_face(id, cell, face) {
        wasm.engine_edit_grow_face(this.__wbg_ptr, id, cell, face);
    }
    /**
     * Дыра: сквозной вырез вдоль нормали грани.
     * @param {number} id
     * @param {number} cell
     * @param {number} face
     */
    edit_hole(id, cell, face) {
        wasm.engine_edit_hole(this.__wbg_ptr, id, cell, face);
    }
    /**
     * Полость: оставить только оболочку.
     * @param {number} id
     */
    edit_hollow(id) {
        wasm.engine_edit_hollow(this.__wbg_ptr, id);
    }
    /**
     * @returns {number}
     */
    edit_id() {
        const ret = wasm.engine_edit_id(this.__wbg_ptr);
        return ret;
    }
    /**
     * Инверсия ячеек.
     * @param {number} id
     */
    edit_invert(id) {
        wasm.engine_edit_invert(this.__wbg_ptr, id);
    }
    /**
     * @returns {boolean}
     */
    edit_iso() {
        const ret = wasm.engine_edit_iso(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {number}
     */
    edit_mirror() {
        const ret = wasm.engine_edit_mirror(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Симметризация по осям (биты X/Y/Z).
     * @param {number} id
     * @param {number} axes
     */
    edit_mirror_fill(id, axes) {
        wasm.engine_edit_mirror_fill(this.__wbg_ptr, id, axes);
    }
    /**
     * Сдвиг ячеек (маски/выделения или всей модели) на dir ячеек вдоль оси.
     * @param {number} id
     * @param {number} axis
     * @param {number} dir
     */
    edit_move(id, axis, dir) {
        wasm.engine_edit_move(this.__wbg_ptr, id, axis, dir);
    }
    /**
     * Органика: случайное возмущение ячеек.
     * @param {number} id
     */
    edit_organic(id) {
        wasm.engine_edit_organic(this.__wbg_ptr, id);
    }
    /**
     * @param {number} id
     * @param {number} cell
     * @param {number} rgb
     */
    edit_paint(id, cell, rgb) {
        wasm.engine_edit_paint(this.__wbg_ptr, id, cell, rgb);
    }
    /**
     * @param {number} id
     */
    edit_reset_cells(id) {
        wasm.engine_edit_reset_cells(this.__wbg_ptr, id);
    }
    /**
     * Поворот маски/модели на 90° вокруг оси (вокруг центра выделения).
     * @param {number} id
     * @param {number} axis
     */
    edit_rot(id, axis) {
        wasm.engine_edit_rot(this.__wbg_ptr, id, axis);
    }
    /**
     * Поставить/снять ячейку; при живом зеркале правка дублируется на близнецов.
     * @param {number} id
     * @param {number} cell
     * @param {boolean} on
     */
    edit_set_cell(id, cell, on) {
        wasm.engine_edit_set_cell(this.__wbg_ptr, id, cell, on);
    }
    /**
     * Стартовая форма: 0 куб, 1 цилиндр, 2 конус, 3 клин, 4 арка, 5 лестница.
     * @param {number} id
     * @param {number} kind
     */
    edit_shape(id, kind) {
        wasm.engine_edit_shape(this.__wbg_ptr, id, kind);
    }
    /**
     * @param {number} id
     * @param {number} cell
     */
    edit_toggle(id, cell) {
        wasm.engine_edit_toggle(this.__wbg_ptr, id, cell);
    }
    /**
     * @returns {Int32Array}
     */
    entity_ids() {
        const ret = wasm.engine_entity_ids(this.__wbg_ptr);
        var v1 = getArrayI32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {number} id
     * @returns {string}
     */
    entity_name(id) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.engine_entity_name(this.__wbg_ptr, id);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Навести камеру на точку (режим правки).
     * @param {number} x
     * @param {number} y
     * @param {number} z
     * @param {number} dist
     */
    focus_on(x, y, z, dist) {
        wasm.engine_focus_on(this.__wbg_ptr, x, y, z, dist);
    }
    /**
     * @param {number} dt
     */
    frame(dt) {
        wasm.engine_frame(this.__wbg_ptr, dt);
    }
    /**
     * @param {number} id
     * @returns {Float32Array}
     */
    get_edit(id) {
        const ret = wasm.engine_get_edit(this.__wbg_ptr, id);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {number} i
     * @returns {number}
     */
    get_gfx(i) {
        const ret = wasm.engine_get_gfx(this.__wbg_ptr, i);
        return ret;
    }
    /**
     * [pos xyz, rot xyz (град), size xyz, color rgb 0..1, neon, alpha, water, fire, mat, wtex, shape, rough, visible]
     * @param {number} id
     * @returns {Float32Array}
     */
    get_props(id) {
        const ret = wasm.engine_get_props(this.__wbg_ptr, id);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {number} nx
     * @param {number} ny
     * @returns {boolean}
     */
    gizmo_begin(nx, ny) {
        const ret = wasm.engine_gizmo_begin(this.__wbg_ptr, nx, ny);
        return ret !== 0;
    }
    /**
     * @param {number} nx
     * @param {number} ny
     * @returns {boolean}
     */
    gizmo_drag(nx, ny) {
        const ret = wasm.engine_gizmo_drag(this.__wbg_ptr, nx, ny);
        return ret !== 0;
    }
    gizmo_end() {
        wasm.engine_gizmo_end(this.__wbg_ptr);
    }
    /**
     * @returns {boolean}
     */
    hdr() {
        const ret = wasm.engine_hdr(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {boolean}
     */
    is_play() {
        const ret = wasm.engine_is_play(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @param {number} dx
     * @param {number} dy
     */
    look(dx, dy) {
        wasm.engine_look(this.__wbg_ptr, dx, dy);
    }
    /**
     * @param {string} canvas_id
     */
    constructor(canvas_id) {
        const ptr0 = passStringToWasm0(canvas_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.engine_new(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        EngineFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @param {number} id
     * @returns {number}
     */
    parent_of(id) {
        const ret = wasm.engine_parent_of(this.__wbg_ptr, id);
        return ret;
    }
    /**
     * @param {number} nx
     * @param {number} ny
     * @returns {number}
     */
    pick(nx, ny) {
        const ret = wasm.engine_pick(this.__wbg_ptr, nx, ny);
        return ret;
    }
    /**
     * @param {number} nx
     * @param {number} ny
     * @returns {number}
     */
    pick_cell(nx, ny) {
        const ret = wasm.engine_pick_cell(this.__wbg_ptr, nx, ny);
        return ret;
    }
    /**
     * Луч -> ячейка*8 + грань (0=+X, 1=-X, 2=+Y, 3=-Y, 4=+Z, 5=-Z).
     * @param {number} nx
     * @param {number} ny
     * @returns {number}
     */
    pick_face(nx, ny) {
        const ret = wasm.engine_pick_face(this.__wbg_ptr, nx, ny);
        return ret;
    }
    /**
     * @returns {Float32Array}
     */
    player_pos() {
        const ret = wasm.engine_player_pos(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {number}
     */
    pm_root() {
        const ret = wasm.engine_pm_root(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {number} id
     */
    remove_entity(id) {
        wasm.engine_remove_entity(this.__wbg_ptr, id);
    }
    reset_camera() {
        wasm.engine_reset_camera(this.__wbg_ptr);
    }
    /**
     * @param {number} w
     * @param {number} h
     */
    resize(w, h) {
        wasm.engine_resize(this.__wbg_ptr, w, h);
    }
    /**
     * Выделение рамкой (NDC-прямоугольник) по центрам ячеек.
     * @param {number} id
     * @param {number} x0
     * @param {number} y0
     * @param {number} x1
     * @param {number} y1
     */
    sel_box(id, x0, y0, x1, y1) {
        wasm.engine_sel_box(this.__wbg_ptr, id, x0, y0, x1, y1);
    }
    /**
     * @param {number} id
     */
    sel_clear(id) {
        wasm.engine_sel_clear(this.__wbg_ptr, id);
    }
    /**
     * @param {number} id
     * @returns {number}
     */
    sel_count(id) {
        const ret = wasm.engine_sel_count(this.__wbg_ptr, id);
        return ret >>> 0;
    }
    /**
     * @param {number} id
     */
    sel_delete(id) {
        wasm.engine_sel_delete(this.__wbg_ptr, id);
    }
    /**
     * Заливка связных ячеек (выделение).
     * @param {number} id
     * @param {number} cell
     */
    sel_flood(id, cell) {
        wasm.engine_sel_flood(this.__wbg_ptr, id, cell);
    }
    /**
     * @param {number} id
     * @param {number} rgb
     */
    sel_paint(id, rgb) {
        wasm.engine_sel_paint(this.__wbg_ptr, id, rgb);
    }
    /**
     * @param {number} id
     */
    select(id) {
        wasm.engine_select(this.__wbg_ptr, id);
    }
    /**
     * @returns {number}
     */
    selected() {
        const ret = wasm.engine_selected(this.__wbg_ptr);
        return ret;
    }
    /**
     * Режим Блендера: серый фон, изолированный объект.
     * @param {boolean} on
     */
    set_blender(on) {
        wasm.engine_set_blender(this.__wbg_ptr, on);
    }
    /**
     * @param {Uint8Array} data
     * @param {number} w
     * @param {number} h
     */
    set_custom_mat(data, w, h) {
        const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.engine_set_custom_mat(this.__wbg_ptr, ptr0, len0, w, h);
    }
    /**
     * Своя текстура воды из галереи: квадратная RGBA8 (рекомендуется 256).
     * @param {Uint8Array} data
     * @param {number} w
     * @param {number} h
     */
    set_custom_water(data, w, h) {
        const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.engine_set_custom_water(this.__wbg_ptr, ptr0, len0, w, h);
    }
    /**
     * Правка: уровень сетки 0..7, скругление, ячейки hex (4 слова по 16 hex, старшее первым).
     * @param {number} id
     * @param {number} sub
     * @param {number} round
     * @param {string} cells_hex
     */
    set_edit(id, sub, round, cells_hex) {
        const ptr0 = passStringToWasm0(cells_hex, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.engine_set_edit(this.__wbg_ptr, id, sub, round, ptr0, len0);
    }
    /**
     * @param {number} id
     * @param {string} s
     */
    set_edit_colors(id, s) {
        const ptr0 = passStringToWasm0(s, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.engine_set_edit_colors(this.__wbg_ptr, id, ptr0, len0);
    }
    /**
     * @param {number} cell
     */
    set_edit_hover(cell) {
        wasm.engine_set_edit_hover(this.__wbg_ptr, cell);
    }
    /**
     * @param {number} id
     */
    set_edit_id(id) {
        wasm.engine_set_edit_id(this.__wbg_ptr, id);
    }
    /**
     * @param {boolean} on
     */
    set_edit_iso(on) {
        wasm.engine_set_edit_iso(this.__wbg_ptr, on);
    }
    /**
     * @param {number} axes
     */
    set_edit_mirror(axes) {
        wasm.engine_set_edit_mirror(this.__wbg_ptr, axes);
    }
    /**
     * @param {number} id
     * @param {string} name
     */
    set_entity_name(id, name) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.engine_set_entity_name(this.__wbg_ptr, id, ptr0, len0);
    }
    /**
     * @param {number} i
     * @param {number} v
     */
    set_gfx(i, v) {
        wasm.engine_set_gfx(this.__wbg_ptr, i, v);
    }
    /**
     * @param {number} m
     */
    set_mode(m) {
        wasm.engine_set_mode(this.__wbg_ptr, m);
    }
    /**
     * @param {number} strafe
     * @param {number} forward
     * @param {number} up
     */
    set_move(strafe, forward, up) {
        wasm.engine_set_move(this.__wbg_ptr, strafe, forward, up);
    }
    /**
     * @param {number} id
     * @param {number} parent
     */
    set_parent(id, parent) {
        wasm.engine_set_parent(this.__wbg_ptr, id, parent);
    }
    /**
     * @param {boolean} on
     */
    set_play(on) {
        wasm.engine_set_play(this.__wbg_ptr, on);
    }
    /**
     * Характеристики игрока из скрипта: скорость, прыжок, размер капсулы.
     * @param {number} speed
     * @param {number} jump
     * @param {number} size
     */
    set_player_stats(speed, jump, size) {
        wasm.engine_set_player_stats(this.__wbg_ptr, speed, jump, size);
    }
    /**
     * @param {number} id
     */
    set_pm_root(id) {
        wasm.engine_set_pm_root(this.__wbg_ptr, id);
    }
    /**
     * @param {number} id
     * @param {Float32Array} p
     */
    set_props(id, p) {
        const ptr0 = passArrayF32ToWasm0(p, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.engine_set_props(this.__wbg_ptr, id, ptr0, len0);
    }
    /**
     * @param {boolean} on
     */
    set_third(on) {
        wasm.engine_set_third(this.__wbg_ptr, on);
    }
    /**
     * Высота волн в точке (x, z) относительно уровня воды (для будущей плавучести).
     * @param {number} x
     * @param {number} z
     * @returns {number}
     */
    water_height(x, z) {
        const ret = wasm.engine_water_height(this.__wbg_ptr, x, z);
        return ret;
    }
    /**
     * Проекция мировой точки на экран (px) — для биллбордов @UI.Bb.* (UI, привязанный
     * к 3D-точке/объекту, всегда "смотрит" на игрока, т.к. это плоский экранный оверлей).
     * Возвращает [x_px, y_px, visible(1/0), dist].
     * @param {number} x
     * @param {number} y
     * @param {number} z
     * @returns {Float32Array}
     */
    world_to_screen(x, y, z) {
        const ret = wasm.engine_world_to_screen(this.__wbg_ptr, x, y, z);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
}
if (Symbol.dispose) Engine.prototype[Symbol.dispose] = Engine.prototype.free;

/**
 * @returns {Float32Array}
 */
export function gfx_defaults() {
    const ret = wasm.gfx_defaults();
    var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
    return v1;
}

/**
 * @param {boolean} en
 * @returns {string}
 */
export function run_self_test(en) {
    let deferred1_0;
    let deferred1_1;
    try {
        const ret = wasm.run_self_test(en);
        deferred1_0 = ret[0];
        deferred1_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
}

/**
 * @returns {string}
 */
export function version() {
    let deferred1_0;
    let deferred1_1;
    try {
        const ret = wasm.version();
        deferred1_0 = ret[0];
        deferred1_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
}
function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg___wbindgen_boolean_get_5b446f51afd21013: function(arg0) {
            const v = arg0;
            const ret = typeof(v) === 'boolean' ? v : undefined;
            return isLikeNone(ret) ? 0xFFFFFF : ret ? 1 : 0;
        },
        __wbg___wbindgen_is_undefined_8865fb403f8fe9d8: function(arg0) {
            const ret = arg0 === undefined;
            return ret;
        },
        __wbg___wbindgen_number_get_2e0e7dee9f701a71: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'number' ? obj : undefined;
            getDataViewMemory0().setFloat64(arg0 + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
        },
        __wbg___wbindgen_throw_41e9ee4f547fc59a: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbg_activeTexture_11079673eac5c921: function(arg0, arg1) {
            arg0.activeTexture(arg1 >>> 0);
        },
        __wbg_attachShader_9567ae57af6746d5: function(arg0, arg1, arg2) {
            arg0.attachShader(arg1, arg2);
        },
        __wbg_bindBuffer_0324f62b876c4403: function(arg0, arg1, arg2) {
            arg0.bindBuffer(arg1 >>> 0, arg2);
        },
        __wbg_bindFramebuffer_378eb18ef219d37a: function(arg0, arg1, arg2) {
            arg0.bindFramebuffer(arg1 >>> 0, arg2);
        },
        __wbg_bindRenderbuffer_e0c5aeef245a913a: function(arg0, arg1, arg2) {
            arg0.bindRenderbuffer(arg1 >>> 0, arg2);
        },
        __wbg_bindTexture_3cf008f256f3ed99: function(arg0, arg1, arg2) {
            arg0.bindTexture(arg1 >>> 0, arg2);
        },
        __wbg_bindVertexArray_f58af0a346185ec5: function(arg0, arg1) {
            arg0.bindVertexArray(arg1);
        },
        __wbg_blendFuncSeparate_2af9d47f7efc0452: function(arg0, arg1, arg2, arg3, arg4) {
            arg0.blendFuncSeparate(arg1 >>> 0, arg2 >>> 0, arg3 >>> 0, arg4 >>> 0);
        },
        __wbg_blitFramebuffer_7b39bfec6cfece56: function(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10) {
            arg0.blitFramebuffer(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9 >>> 0, arg10 >>> 0);
        },
        __wbg_bufferData_5fa44d94fe7a3878: function(arg0, arg1, arg2, arg3) {
            arg0.bufferData(arg1 >>> 0, arg2, arg3 >>> 0);
        },
        __wbg_checkFramebufferStatus_301a7db105ca966b: function(arg0, arg1) {
            const ret = arg0.checkFramebufferStatus(arg1 >>> 0);
            return ret;
        },
        __wbg_clearColor_796427e8ac60fe14: function(arg0, arg1, arg2, arg3, arg4) {
            arg0.clearColor(arg1, arg2, arg3, arg4);
        },
        __wbg_clear_cb96796cc568b7c8: function(arg0, arg1) {
            arg0.clear(arg1 >>> 0);
        },
        __wbg_compileShader_c2b53ff3a8851f60: function(arg0, arg1) {
            arg0.compileShader(arg1);
        },
        __wbg_createBuffer_ffe613371d42cfd3: function(arg0) {
            const ret = arg0.createBuffer();
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_createFramebuffer_2c6b5b0f49c88e5d: function(arg0) {
            const ret = arg0.createFramebuffer();
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_createProgram_cbf448e6f18a9402: function(arg0) {
            const ret = arg0.createProgram();
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_createRenderbuffer_c864095d6ebd60d0: function(arg0) {
            const ret = arg0.createRenderbuffer();
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_createShader_6c1a2295587878a5: function(arg0, arg1) {
            const ret = arg0.createShader(arg1 >>> 0);
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_createTexture_5f2583508ebe379b: function(arg0) {
            const ret = arg0.createTexture();
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_createVertexArray_b223ea69dd08fcab: function(arg0) {
            const ret = arg0.createVertexArray();
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_cullFace_12123c1c97f1ba2c: function(arg0, arg1) {
            arg0.cullFace(arg1 >>> 0);
        },
        __wbg_deleteFramebuffer_3f8ab330098bf8e6: function(arg0, arg1) {
            arg0.deleteFramebuffer(arg1);
        },
        __wbg_deleteRenderbuffer_826c9b43b7ea68f5: function(arg0, arg1) {
            arg0.deleteRenderbuffer(arg1);
        },
        __wbg_deleteTexture_9f42750adb092e4f: function(arg0, arg1) {
            arg0.deleteTexture(arg1);
        },
        __wbg_deleteVertexArray_ca9768805d051d49: function(arg0, arg1) {
            arg0.deleteVertexArray(arg1);
        },
        __wbg_depthMask_06ecff4d4514c38f: function(arg0, arg1) {
            arg0.depthMask(arg1 !== 0);
        },
        __wbg_disableVertexAttribArray_c4c8af1f9e4120d4: function(arg0, arg1) {
            arg0.disableVertexAttribArray(arg1 >>> 0);
        },
        __wbg_disable_19fe787eccdf0272: function(arg0, arg1) {
            arg0.disable(arg1 >>> 0);
        },
        __wbg_document_9854e03c05fc8834: function(arg0) {
            const ret = arg0.document;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_drawArrays_08872e02fb57b847: function(arg0, arg1, arg2, arg3) {
            arg0.drawArrays(arg1 >>> 0, arg2, arg3);
        },
        __wbg_drawBuffers_7a58bd4729f7a1fc: function(arg0, arg1) {
            arg0.drawBuffers(arg1);
        },
        __wbg_drawElements_c8988ba71de1101a: function(arg0, arg1, arg2, arg3, arg4) {
            arg0.drawElements(arg1 >>> 0, arg2, arg3 >>> 0, arg4);
        },
        __wbg_enableVertexAttribArray_d52693866bc8b8dd: function(arg0, arg1) {
            arg0.enableVertexAttribArray(arg1 >>> 0);
        },
        __wbg_enable_cb4fc19b51148c37: function(arg0, arg1) {
            arg0.enable(arg1 >>> 0);
        },
        __wbg_framebufferRenderbuffer_f019e9231b142c0d: function(arg0, arg1, arg2, arg3, arg4) {
            arg0.framebufferRenderbuffer(arg1 >>> 0, arg2 >>> 0, arg3 >>> 0, arg4);
        },
        __wbg_framebufferTexture2D_73c52f23ec33aa22: function(arg0, arg1, arg2, arg3, arg4, arg5) {
            arg0.framebufferTexture2D(arg1 >>> 0, arg2 >>> 0, arg3 >>> 0, arg4, arg5);
        },
        __wbg_generateMipmap_cd49f6eec9558721: function(arg0, arg1) {
            arg0.generateMipmap(arg1 >>> 0);
        },
        __wbg_getContext_635e36719cad2623: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = arg0.getContext(getStringFromWasm0(arg1, arg2));
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        }, arguments); },
        __wbg_getElementById_cc94972b404e4eaa: function(arg0, arg1, arg2) {
            const ret = arg0.getElementById(getStringFromWasm0(arg1, arg2));
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_getExtension_abfda2c5db286b07: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = arg0.getExtension(getStringFromWasm0(arg1, arg2));
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        }, arguments); },
        __wbg_getParameter_974595a6624c6c10: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.getParameter(arg1 >>> 0);
            return ret;
        }, arguments); },
        __wbg_getProgramInfoLog_3276b294d6d42fe2: function(arg0, arg1, arg2) {
            const ret = arg1.getProgramInfoLog(arg2);
            var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg_getProgramParameter_fc7124bb9fb7c675: function(arg0, arg1, arg2) {
            const ret = arg0.getProgramParameter(arg1, arg2 >>> 0);
            return ret;
        },
        __wbg_getShaderInfoLog_7e0cbba353ca95da: function(arg0, arg1, arg2) {
            const ret = arg1.getShaderInfoLog(arg2);
            var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg_getShaderParameter_745acf10b8e45e31: function(arg0, arg1, arg2) {
            const ret = arg0.getShaderParameter(arg1, arg2 >>> 0);
            return ret;
        },
        __wbg_getUniformLocation_50ba45dade572703: function(arg0, arg1, arg2, arg3) {
            const ret = arg0.getUniformLocation(arg1, getStringFromWasm0(arg2, arg3));
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_instanceof_HtmlCanvasElement_0a30c11fbbf41841: function(arg0) {
            let result;
            try {
                result = arg0 instanceof HTMLCanvasElement;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_WebGl2RenderingContext_64c994c14c0790fb: function(arg0) {
            let result;
            try {
                result = arg0 instanceof WebGL2RenderingContext;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Window_82d71df4eddf88bc: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Window;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_linkProgram_acdc299c43d734a0: function(arg0, arg1) {
            arg0.linkProgram(arg1);
        },
        __wbg_of_d5dbecdc59e02e34: function(arg0) {
            const ret = Array.of(arg0);
            return ret;
        },
        __wbg_polygonOffset_81dc8ca84e29572b: function(arg0, arg1, arg2) {
            arg0.polygonOffset(arg1, arg2);
        },
        __wbg_readBuffer_b5d9a34a2f3d20d5: function(arg0, arg1) {
            arg0.readBuffer(arg1 >>> 0);
        },
        __wbg_renderbufferStorage_52b131bbf3112b3a: function(arg0, arg1, arg2, arg3, arg4) {
            arg0.renderbufferStorage(arg1 >>> 0, arg2 >>> 0, arg3, arg4);
        },
        __wbg_set_height_c9789c1c77eaedff: function(arg0, arg1) {
            arg0.height = arg1 >>> 0;
        },
        __wbg_set_width_b0e1267db4b196b5: function(arg0, arg1) {
            arg0.width = arg1 >>> 0;
        },
        __wbg_shaderSource_c8812639b47d87b9: function(arg0, arg1, arg2, arg3) {
            arg0.shaderSource(arg1, getStringFromWasm0(arg2, arg3));
        },
        __wbg_static_accessor_GLOBAL_266715b9d96ba635: function() {
            const ret = typeof global === 'undefined' ? null : global;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_GLOBAL_THIS_10fb7dc1ae063179: function() {
            const ret = typeof globalThis === 'undefined' ? null : globalThis;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_SELF_0b583911f537483a: function() {
            const ret = typeof self === 'undefined' ? null : self;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_WINDOW_d7f903d1508cbdc4: function() {
            const ret = typeof window === 'undefined' ? null : window;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_texImage2D_151a358c7288e555: function() { return handleError(function (arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10) {
            arg0.texImage2D(arg1 >>> 0, arg2, arg3, arg4, arg5, arg6, arg7 >>> 0, arg8 >>> 0, arg9 === 0 ? undefined : getArrayU8FromWasm0(arg9, arg10));
        }, arguments); },
        __wbg_texParameterf_46959960c830a629: function(arg0, arg1, arg2, arg3) {
            arg0.texParameterf(arg1 >>> 0, arg2 >>> 0, arg3);
        },
        __wbg_texParameteri_7864076abcdb03e0: function(arg0, arg1, arg2, arg3) {
            arg0.texParameteri(arg1 >>> 0, arg2 >>> 0, arg3);
        },
        __wbg_texSubImage2D_cff3b090fb77dfe6: function() { return handleError(function (arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10) {
            arg0.texSubImage2D(arg1 >>> 0, arg2, arg3, arg4, arg5, arg6, arg7 >>> 0, arg8 >>> 0, arg9 === 0 ? undefined : getArrayU8FromWasm0(arg9, arg10));
        }, arguments); },
        __wbg_uniform1f_b5856e35a43b65a1: function(arg0, arg1, arg2) {
            arg0.uniform1f(arg1, arg2);
        },
        __wbg_uniform1fv_1bf537fc926ef8b9: function(arg0, arg1, arg2, arg3) {
            arg0.uniform1fv(arg1, getArrayF32FromWasm0(arg2, arg3));
        },
        __wbg_uniform1i_531b98c4a7177366: function(arg0, arg1, arg2) {
            arg0.uniform1i(arg1, arg2);
        },
        __wbg_uniform2f_a92b5bb95dc5b4d9: function(arg0, arg1, arg2, arg3) {
            arg0.uniform2f(arg1, arg2, arg3);
        },
        __wbg_uniform3f_1211579ff87ccfad: function(arg0, arg1, arg2, arg3, arg4) {
            arg0.uniform3f(arg1, arg2, arg3, arg4);
        },
        __wbg_uniform4f_8dd8f311e656ca0d: function(arg0, arg1, arg2, arg3, arg4, arg5) {
            arg0.uniform4f(arg1, arg2, arg3, arg4, arg5);
        },
        __wbg_uniform4fv_cf8ff646c36232c8: function(arg0, arg1, arg2, arg3) {
            arg0.uniform4fv(arg1, getArrayF32FromWasm0(arg2, arg3));
        },
        __wbg_uniformMatrix3fv_472e7824735acce1: function(arg0, arg1, arg2, arg3, arg4) {
            arg0.uniformMatrix3fv(arg1, arg2 !== 0, getArrayF32FromWasm0(arg3, arg4));
        },
        __wbg_uniformMatrix4fv_dff9738d995fd0b1: function(arg0, arg1, arg2, arg3, arg4) {
            arg0.uniformMatrix4fv(arg1, arg2 !== 0, getArrayF32FromWasm0(arg3, arg4));
        },
        __wbg_useProgram_e075c2902e420761: function(arg0, arg1) {
            arg0.useProgram(arg1);
        },
        __wbg_vertexAttribPointer_24b495e18df325dc: function(arg0, arg1, arg2, arg3, arg4, arg5, arg6) {
            arg0.vertexAttribPointer(arg1 >>> 0, arg2, arg3 >>> 0, arg4 !== 0, arg5, arg6);
        },
        __wbg_viewport_16936692526e2ce6: function(arg0, arg1, arg2, arg3, arg4) {
            arg0.viewport(arg1, arg2, arg3, arg4);
        },
        __wbindgen_generic_0000000000000001: function(arg0) {
            // Cast intrinsic for `F64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_generic_0000000000000002: function(arg0, arg1) {
            // Cast intrinsic for `Ref(Slice(F32)) -> NamedExternref("Float32Array")`.
            const ret = getArrayF32FromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_generic_0000000000000003: function(arg0, arg1) {
            // Cast intrinsic for `Ref(Slice(U32)) -> NamedExternref("Uint32Array")`.
            const ret = getArrayU32FromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_generic_0000000000000004: function(arg0, arg1) {
            // Cast intrinsic for `Ref(String) -> Externref`.
            const ret = getStringFromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            const offset = table.grow(4);
            table.set(0, undefined);
            table.set(offset + 0, undefined);
            table.set(offset + 1, null);
            table.set(offset + 2, true);
            table.set(offset + 3, false);
        },
    };
    return {
        __proto__: null,
        "./engine_bg.js": import0,
    };
}

const EngineFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_engine_free(ptr, 1));

function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_externrefs.set(idx, obj);
    return idx;
}

function getArrayF32FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getFloat32ArrayMemory0().subarray(ptr / 4, ptr / 4 + len);
}

function getArrayI32FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getInt32ArrayMemory0().subarray(ptr / 4, ptr / 4 + len);
}

function getArrayU32FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint32ArrayMemory0().subarray(ptr / 4, ptr / 4 + len);
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

let cachedDataViewMemory0 = null;
function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

let cachedFloat32ArrayMemory0 = null;
function getFloat32ArrayMemory0() {
    if (cachedFloat32ArrayMemory0 === null || cachedFloat32ArrayMemory0.byteLength === 0) {
        cachedFloat32ArrayMemory0 = new Float32Array(wasm.memory.buffer);
    }
    return cachedFloat32ArrayMemory0;
}

let cachedInt32ArrayMemory0 = null;
function getInt32ArrayMemory0() {
    if (cachedInt32ArrayMemory0 === null || cachedInt32ArrayMemory0.byteLength === 0) {
        cachedInt32ArrayMemory0 = new Int32Array(wasm.memory.buffer);
    }
    return cachedInt32ArrayMemory0;
}

function getStringFromWasm0(ptr, len) {
    return decodeText(ptr >>> 0, len);
}

let cachedUint32ArrayMemory0 = null;
function getUint32ArrayMemory0() {
    if (cachedUint32ArrayMemory0 === null || cachedUint32ArrayMemory0.byteLength === 0) {
        cachedUint32ArrayMemory0 = new Uint32Array(wasm.memory.buffer);
    }
    return cachedUint32ArrayMemory0;
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        const idx = addToExternrefTable0(e);
        wasm.__wbindgen_exn_store(idx);
    }
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

function passArray8ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 1, 1) >>> 0;
    getUint8ArrayMemory0().set(arg, ptr / 1);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passArrayF32ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 4, 4) >>> 0;
    getFloat32ArrayMemory0().set(arg, ptr / 4);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
        cachedTextDecoder.decode();
        numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;

let wasmModule, wasmInstance, wasm;
function __wbg_finalize_init(instance, module) {
    wasmInstance = instance;
    wasm = instance.exports;
    wasmModule = module;
    cachedDataViewMemory0 = null;
    cachedFloat32ArrayMemory0 = null;
    cachedInt32ArrayMemory0 = null;
    cachedUint32ArrayMemory0 = null;
    cachedUint8ArrayMemory0 = null;
    wasm.__wbindgen_start();
    return wasm;
}

async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (!module.ok) {
            throw new Error(`failed to fetch Wasm: ${module.status} ${module.statusText} fetching '${module.url}'`);
        }

        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);
            } catch (e) {
                const validResponse = expectedResponseType(module.type);

                if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else { throw e; }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);
    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };
        } else {
            return instance;
        }
    }

    function expectedResponseType(type) {
        switch (type) {
            case 'basic': case 'cors': case 'default': return true;
        }
        return false;
    }
}

function initSync(module) {
    if (wasm !== undefined) return wasm;


    if (module !== undefined) {
        if (Object.getPrototypeOf(module) === Object.prototype) {
            ({module} = module)
        } else {
            console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
        }
    }

    const imports = __wbg_get_imports();
    if (!(module instanceof WebAssembly.Module)) {
        module = new WebAssembly.Module(module);
    }
    const instance = new WebAssembly.Instance(module, imports);
    return __wbg_finalize_init(instance, module);
}

async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;


    if (module_or_path !== undefined) {
        if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
            ({module_or_path} = module_or_path)
        } else {
            console.warn('using deprecated parameters for the initialization function; pass a single object instead')
        }
    }

    if (module_or_path === undefined) {
        module_or_path = new URL('engine_bg.wasm', import.meta.url);
    }
    const imports = __wbg_get_imports();

    if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
        module_or_path = fetch(module_or_path);
    }

    const { instance, module } = await __wbg_load(await module_or_path, imports);

    return __wbg_finalize_init(instance, module);
}

export { initSync, __wbg_init as default };
