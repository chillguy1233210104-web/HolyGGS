// ui.js — UI-слой HolyGGS: элементы экрана (frame, label, button, textbox)
// с настройкой текста, фона, рамки, цвета и позиции в px + % от родителя (как Roblox UDim2).
// Общий модуль редактора и игры.

export const UI_TYPES = ['frame', 'label', 'button', 'textbox', 'joystick', 'imagelabel'];

export function uiDef(type, name) {
  return {
    type, name: name || (type === 'frame' ? 'Frame' : type === 'label' ? 'TextLabel' : type === 'button' ? 'Button' : type === 'textbox' ? 'TextBox' : type === 'imagelabel' ? 'ImageLabel' : 'Joystick'),
    parent: '',
    img: '', imgAlpha: 255,
    billboard: 0, wx: 0, wy: 0, wz: 0, wfollow: '',
    bbOffscreen: 0,
    x: { px: 20, pr: 0 }, y: { px: 20, pr: 0 },
    w: { px: type === 'frame' ? 320 : type === 'joystick' ? 150 : 220, pr: 0 }, h: { px: type === 'frame' ? 220 : type === 'joystick' ? 150 : 42, pr: 0 },
    text: type === 'button' ? 'Кнопка' : type === 'label' ? 'Текст' : '',
    placeholder: type === 'textbox' ? 'Введите…' : '',
    bg: [40, 40, 52, type === 'label' ? 0 : 210],
    fg: [255, 255, 255, 255],
    borderW: 0, border: [255, 255, 255, 255], radius: 0,
    fontSize: 16, font: '', align: 'left', anchor: 'top-left', scaled: 0,
    stroke: [0, 0, 0, 255], strokeW: 0,
    visible: 1, zIndex: 0,
    onClick: '', onChange: '', onMove: '',
    valX: 0, valY: 0, active: 0,
  };
}

const num = (v) => (isFinite(+v) ? +v : 0);
const rgba = (c) => `rgba(${Math.round(num(c[0]))},${Math.round(num(c[1]))},${Math.round(num(c[2]))},${Math.round(num(c[3] === undefined ? 255 : c[3])) / 255})`;
const unit = (c) => `calc(${num(c && c.px)}px + ${num(c && c.pr)}%)`;

// автоподбор размера шрифта под размер блока (аналог Roblox TextScaled):
// меряем текст на канвасе при fontSize=100 и масштабируем так, чтобы он
// вписался и по ширине, и по высоте блока (с небольшими полями по краям).
let _measureCtx = null;
export function fitFontSize(dom, d) {
  const text = String((d.text != null && d.text !== '') ? d.text : (d.placeholder || ''));
  const fallback = num(d.fontSize) || 16;
  if (!text) return fallback;
  const bw = dom.clientWidth, bh = dom.clientHeight;
  if (!bw || !bh) return fallback;
  if (!_measureCtx) _measureCtx = document.createElement('canvas').getContext('2d');
  const ref = 100;
  const fam = dom.style.fontFamily || 'sans-serif';
  _measureCtx.font = ref + 'px ' + fam;
  const w100 = _measureCtx.measureText(text).width || ref;
  const availW = Math.max(4, bw - 10);
  const availH = Math.max(4, bh - 6);
  const size = Math.floor(ref * Math.min(availW / w100, availH / ref));
  return Math.max(6, Math.min(400, size));
}

// значение вида 200, "50%", "50%+12", {px,pr} → {px,pr}
export function toUnit(v) {
  if (v && typeof v === 'object' && !Array.isArray(v)) return { px: num(v.px), pr: num(v.pr) };
  if (typeof v === 'string') {
    const s = v.trim();
    const m = s.match(/^([+-]?[\d.]+)\s*%\s*(?:([+-])\s*([+-]?[\d.]+))?$/);
    if (m) return { px: m[2] ? (m[2] === '-' ? -parseFloat(m[3]) : parseFloat(m[3])) : 0, pr: parseFloat(m[1]) || 0 };
    const m2 = s.match(/^([+-]?[\d.]+)\s*([+-])\s*([+-]?[\d.]+)\s*%$/);
    if (m2) return { px: parseFloat(m2[1]) || 0, pr: m2[2] === '-' ? -(parseFloat(m2[3]) || 0) : (parseFloat(m2[3]) || 0) };
    if (s.endsWith('%')) return { px: 0, pr: parseFloat(s) || 0 };
    return { px: parseFloat(s) || 0, pr: 0 };
  }
  return { px: num(v), pr: 0 };
}

// anchor: к какой точке элемента относится pos (как Roblox)
const FONTS = {
  '': '',
  sans: "system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif",
  serif: "Georgia, 'Times New Roman', serif",
  mono: "ui-monospace, Menlo, Consolas, monospace",
  round: "'Trebuchet MS', 'Comic Sans MS', system-ui, sans-serif",
  cond: "'Arial Narrow', 'Roboto Condensed', system-ui, sans-serif",
  bold: "Impact, 'Arial Black', system-ui, sans-serif",
};

// Якорь: какая точка элемента стоит в точке pos.
// Понимает слова (center / top-right / bottom, center), синонимы (centre, middle)
// и числа в стиле Roblox: anchor(0.5, 0.5) = центр.
const AX = { left: 0, start: 0, west: 0, l: 0, center: 0.5, centre: 0.5, middle: 0.5, mid: 0.5, c: 0.5, right: 1, end: 1, east: 1, r: 1 };
const AY = { top: 0, up: 0, north: 0, t: 0, center: 0.5, centre: 0.5, middle: 0.5, mid: 0.5, c: 0.5, bottom: 1, down: 1, south: 1, b: 1 };
export function anchorVec(str) {
  const s = String(str === undefined || str === null ? '' : str).toLowerCase().replace(/[-_\s,;/]+/g, ' ').trim();
  if (!s) return [0, 0];
  const toks = s.split(' ').filter(Boolean);
  const nums = toks.filter((t) => isFinite(parseFloat(t)));
  // числа в стиле Roblox: anchor(0.5, 0.5) — какая доля элемента стоит в точке pos
  if (nums.length === toks.length && nums.length) {
    const a = parseFloat(nums[0]);
    const b = nums.length > 1 ? parseFloat(nums[1]) : a;
    return [Math.max(0, Math.min(1, a)), Math.max(0, Math.min(1, b))];
  }
  let ax = 0.5, ay = 0.5, gx = false, gy = false, any = false;
  // 1-й проход: слова одной оси (top/bottom/left/right)
  for (const t of toks) {
    const h = t in AX, v = t in AY;
    if (h && v) continue;                       // center/middle — во 2-м проходе
    if (h && !gx) { ax = AX[t]; gx = true; any = true; }
    else if (v && !gy) { ay = AY[t]; gy = true; any = true; }
  }
  // 2-й проход: center/middle центрирует те оси, что ещё не заданы
  for (const t of toks) if (t in AX && t in AY) { if (!gx) ax = 0.5; if (!gy) ay = 0.5; any = true; }
  // задана только одна ось — вторую центрируем (top = сверху по центру, left = слева по центру)
  if (!gx && gy) ax = 0.5;
  if (!gy && gx) ay = 0.5;
  if (!any) { ax = 0; ay = 0; }                 // ничего не поняли — как top-left
  return [ax, ay];
}
const anchorCss = (str) => { const [ax, ay] = anchorVec(str); return `translate(${(-ax * 100).toFixed(4)}%, ${(-ay * 100).toFixed(4)}%)`; };

const CSS_BASE = 'position:absolute;box-sizing:border-box;margin:0;font:inherit;line-height:1.25;white-space:pre-wrap;overflow:hidden;touch-action:none;';

export class UIMgr {
  constructor(root, opts = {}) {
    this.root = root;
    this.edit = !!opts.edit;
    this.dragging = ''; // имя элемента, который сейчас тащат пальцем (пока идёт драг — DOM не пересоздаём)
    this.onSelect = opts.onSelect || null;
    this.onEvent = opts.onEvent || null;
    this.onMutate = opts.onMutate || null;
    this.list = [];
    this.doms = new Map();
    this.knobs = new Map();
    this.imgLayers = new Map(); // для imagelabel: отдельный слой с картинкой (своя прозрачность, независимая от фона)
    root.classList.add('uiRoot');
  }

  load(list) {
    this.list = Array.isArray(list) ? list.map((d) => this._norm(d)) : [];
    this.render();
  }
  collect() {
    return JSON.parse(JSON.stringify(this.list));
  }
  _norm(d) {
    const b = uiDef(d && d.type, d && d.name);
    const o = Object.assign(b, d || {});
    o.x = toUnit(o.x); o.y = toUnit(o.y); o.w = toUnit(o.w); o.h = toUnit(o.h);
    // пресет стиля: style(primary|danger|ghost) задаёт цвета/скругление, но явные свойства важнее
    if (o.style && UI_STYLES[o.style]) {
      const st = UI_STYLES[o.style];
      if (!d || d.bg === undefined) o.bg = st.bg.slice();
      if (!d || d.fg === undefined) o.fg = st.fg.slice();
      if (!d || d.radius === undefined) o.radius = st.radius;
      if (!d || d.borderW === undefined) o.borderW = st.borderW;
    }
    for (const k of ['bg', 'fg', 'border', 'stroke']) o[k] = normCol(o[k], b[k]);
    o.strokeW = num(o.strokeW);
    o.font = String(o.font || '');
    if (o.alpha !== undefined && o.alpha !== null) {
      const av = num(o.alpha);
      o.bg[3] = Math.max(0, Math.min(255, av > 1 ? av : av * 255));
      delete o.alpha;
    }
    o.visible = o.visible === 0 || o.visible === false ? 0 : 1;
    return o;
  }
  // язык: @UI.X = {...} — создать/обновить
  create(name, def) {
    const n = this._norm(Object.assign({}, def || {}, { name }));
    n.name = String(name || n.name);
    const ex = this.find(n.name);
    if (ex) {
      for (const k of Object.keys(n)) ex[k] = n[k];
      this.render();
      if (this.onMutate) this.onMutate();
      return n.name;
    }
    this.list.push(n);
    this.render();
    if (this.onMutate) this.onMutate();
    return n.name;
  }
  destroy(name) { return this.remove(name); }
  click(name) {
    const d = this.find(name);
    if (d && this.onEvent) this.onEvent(d, 'click', null);
  }
  uniqueName(base) {
    const names = new Set(this.list.map((d) => d.name));
    if (!names.has(base)) return base;
    for (let i = 2; ; i++) if (!names.has(base + ' ' + i)) return base + ' ' + i;
  }
  find(name) { return this.list.find((d) => d.name === name) || null; }
  get(name, prop) {
    // из кода и из твинов читают get(имя, свойство) — раньше prop игнорировался
    if (prop === undefined || prop === null || prop === '') return this.find(name);
    return this.getProp(name, prop);
  }

  add(def) {
    const d = this._norm(def || {});
    d.name = this.uniqueName(d.name || d.type);
    this.list.push(d);
    this.render();
    if (this.onMutate) this.onMutate();
    return d.name;
  }
  remove(name) {
    const i = this.list.findIndex((d) => d.name === name);
    if (i < 0) return false;
    this.list.splice(i, 1);
    for (const d of this.list) if (d.parent === name) d.parent = '';
    this.render();
    if (this.onMutate) this.onMutate();
    return true;
  }
  clear() {
    this.list = [];
    this.render();
    if (this.onMutate) this.onMutate();
  }
  show(name) { const d = this.find(name); if (d) { d.visible = 1; this.render(); } }
  hide(name) { const d = this.find(name); if (d) { d.visible = 0; this.render(); } }
  setEdit(on) { this.edit = !!on; this.render(); }

  // ——— язык: @UI.name.prop = value / методы ———
  set(name, prop, val, fast) {
    const d = this.find(name);
    if (!d) return false;
    const p = String(prop || '').toLowerCase();
    const pair = (k, v) => { d[k] = toUnit(v); };
    if (p === 'x' || p === 'posx' || p === 'left') pair('x', val);
    else if (p === 'y' || p === 'posy' || p === 'top') pair('y', val);
    else if (p === 'w' || p === 'width' || p === 'sizex') pair('w', val);
    else if (p === 'h' || p === 'height' || p === 'sizey') pair('h', val);
    else if (p === 'pos') {
      if (d.billboard && Array.isArray(val) && val.length >= 3) { d.wx = num(val[0]); d.wy = num(val[1]); d.wz = num(val[2]); }
      else { pair('x', val[0]); pair('y', val[1]); }
    }
    else if (p === 'size') { pair('w', val[0]); pair('h', val[1]); }
    else if (p === 'billboard' || p === 'bb') d.billboard = val ? 1 : 0;
    else if (p === 'follow' || p === 'wfollow' || p === 'target') d.wfollow = String(val || '');
    else if (p === 'img' || p === 'image' || p === 'picture' || p === 'sprite') d.img = String(val || '');
    else if (p === 'imgalpha' || p === 'imageopacity' || p === 'imgopacity') {
      const v = Number(val);
      d.imgAlpha = Math.max(0, Math.min(255, isFinite(v) ? (v <= 1 ? v * 255 : v) : 255));
    }
    else if (p === 'text' || p === 'value') d.text = val == null ? '' : String(val);
    else if (p === 'placeholder') d.placeholder = val == null ? '' : String(val);
    else if (p === 'font' || p === 'fontsize') {
      // число — размер шрифта, строка — семейство (удобно и так, и так)
      if (typeof val === 'number' || (typeof val === 'string' && val.trim() !== '' && isFinite(+val))) d.fontSize = num(val);
      else d.font = String(val || '');
    }
    else if (p === 'fontfamily' || p === 'fontname') d.font = String(val || '');
    else if (p === 'stroke' || p === 'strokecolor' || p === 'outlinecolor') d.stroke = normCol(val, d.stroke);
    else if (p === 'strokew' || p === 'strokewidth' || p === 'outline') d.strokeW = num(val);
    else if (p === 'shadow') d.shadow = val ? 1 : 0;
    else if (p === 'draggable') d.draggable = val ? 1 : 0;
    else if (p === 'scaled' || p === 'textscaled') d.scaled = val ? 1 : 0;
    else if (p === 'style') d.style = String(val || '').toLowerCase();
    else if (p === 'align' || p === 'textalign') d.align = String(val || 'left');
    else if (p === 'radius' || p === 'borderradius') d.radius = num(val);
    else if (p === 'borderw' || p === 'borderwidth') d.borderW = num(val);
    else if (p === 'border') {
      if (Array.isArray(val) && val.length && (typeof val[0] === 'number')) {
        if (val.length >= 2 && !Array.isArray(val[1])) { d.borderW = num(val[0]); d.border = normCol(val.slice(1), d.border); }
        else d.border = normCol(val, d.border);
      } else if (typeof val === 'number' && val <= 255 && Number.isInteger(val) && val >= 0 && val < 20) d.borderW = val;
      else d.border = normCol(val, d.border);
    }
    else if (p === 'color' || p === 'bg' || p === 'background') d.bg = normCol(val, d.bg);
    else if (p === 'fg' || p === 'textcolor') d.fg = normCol(val, d.fg);
    else if (p === 'bordercolor') d.border = normCol(val, d.border);
    else if (p === 'alpha') {
      const av = num(val);
      d.bg[3] = Math.max(0, Math.min(255, av > 1 ? av : av * 255));
    }
    else if (p === 'anchor') d.anchor = String(val || 'top-left');
    else if (p === 'visible') d.visible = (val === 0 || val === false || val === '0' || val === 'false') ? 0 : 1;
    else if (p === 'zindex') d.zIndex = num(val);
    else if (p === 'parent') { d.parent = String(val || ''); }
    else if (p === 'onclick') d.onClick = val == null ? '' : String(val);
    else if (p === 'onchange') d.onChange = val == null ? '' : String(val);
    else if (p === 'onmove') d.onMove = val == null ? '' : String(val);
    else if (p === 'value' || p === 'axis' || p === 'stick') {
      if (Array.isArray(val)) { d.valX = num(val[0]); d.valY = num(val[1]); }
      else if (val && typeof val === 'object') { d.valX = num(val.x); d.valY = num(val.y); }
    }
    else return false;
    if (fast && p !== 'parent' && p !== 'name') {
      this.refresh(name);
      return true;
    }
    this.render();
    if (this.onMutate) this.onMutate();
    return true;
  }
  getProp(name, prop) {
    const d = this.find(name);
    if (!d) return null;
    const p = String(prop || '').toLowerCase();
    const [head, leaf] = p.split('.');
    if (d.type === 'joystick') {
      if (p === 'value' || p === 'axis' || p === 'stick') return [d.valX, d.valY];
      if (p === 'vx' || p === 'jx' || p === 'stickx' || p === 'valuex') return num(d.valX);
      if (p === 'vy' || p === 'jy' || p === 'sticky' || p === 'valuey') return num(d.valY);
      if (p === 'active' || p === 'pressed') return d.active ? 1 : 0;
    }
    const units = { x: d.x, y: d.y, w: d.w, h: d.h, posx: d.x, posy: d.y, width: d.w, height: d.h };
    if (units[head]) {
      if (leaf === 'px') return units[head].px;
      if (leaf === 'pr' || leaf === 'pct') return units[head].pr;
      return { px: units[head].px, pr: units[head].pr };
    }
    const map = {
      text: d.text, value: d.text, placeholder: d.placeholder,
      font: d.fontSize, fontsize: d.fontSize, align: d.align,
      radius: d.radius, borderradius: d.radius, borderw: d.borderW,
      font: d.font, fontfamily: d.font,
      stroke: d.stroke.slice(), strokecolor: d.stroke.slice(),
      strokew: d.strokeW, strokewidth: d.strokeW,
      shadow: d.shadow ? 1 : 0, draggable: d.draggable ? 1 : 0,
      scaled: d.scaled ? 1 : 0, textscaled: d.scaled ? 1 : 0,
      billboard: d.billboard ? 1 : 0, bb: d.billboard ? 1 : 0, follow: d.wfollow || '', wfollow: d.wfollow || '',
      img: d.img || '', image: d.img || '',
      imgalpha: (d.imgAlpha === undefined ? 255 : d.imgAlpha) / 255, imageopacity: (d.imgAlpha === undefined ? 255 : d.imgAlpha) / 255,
      bg: d.bg.slice(), color: d.bg.slice(), fg: d.fg.slice(), textcolor: d.fg.slice(), bordercolor: d.border.slice(),
      alpha: (d.bg[3] === undefined ? 255 : d.bg[3]) / 255,
      visible: d.visible, zindex: d.zIndex, parent: d.parent, type: d.type,
      anchor: d.anchor || 'top-left',
      onclick: d.onClick, onchange: d.onChange, onmove: d.onMove,
    };
    return head in map ? map[head] : null;
  }

  // ——— отрисовка ———
  _applyStyle(dom, d) {
    if (d.type === 'textbox') {
      if (dom.value !== (d.text || '')) dom.value = d.text || '';
      dom.placeholder = d.placeholder || '';
    } else if (d.type === 'label' || d.type === 'button') {
      dom.textContent = d.text || '';
    } else if (d.type === 'imagelabel') {
      dom.textContent = '';
    }
    dom.style.left = unit(d.x); dom.style.top = unit(d.y);
    dom.style.width = unit(d.w); dom.style.height = unit(d.h);
    dom.style.background = rgba(d.bg);
    dom.style.backgroundImage = 'none';
    if (d.type === 'imagelabel') {
      // картинка — на отдельном слое со своей непрозрачностью (imgAlpha), НЕ связанной
      // с прозрачностью фона (d.bg[3]/"Фон"): можно сделать фон прозрачным, а картинку — нет
      const img = this.imgLayers.get(d.name);
      if (img) {
        img.style.backgroundImage = d.img ? `url(${d.img})` : 'none';
        img.style.opacity = String((d.imgAlpha === undefined ? 255 : d.imgAlpha) / 255);
      }
    }
    dom.style.color = rgba(d.fg);
    dom.style.border = d.borderW > 0 ? `${num(d.borderW)}px solid ${rgba(d.border)}` : 'none';
    dom.style.borderRadius = (d.type === 'joystick' ? '50%' : num(d.radius) + 'px');
    dom.style.fontFamily = FONTS[String(d.font || '').toLowerCase()] || String(d.font || '') || 'inherit';
    if (d.scaled && (d.type === 'label' || d.type === 'button' || d.type === 'textbox')) {
      dom.style.fontSize = fitFontSize(dom, d) + 'px';
    } else {
      dom.style.fontSize = num(d.fontSize) + 'px';
    }
    dom.style.textAlign = d.align || 'left';
    const sw = num(d.strokeW);
    if (sw > 0) {
      dom.style.webkitTextStroke = sw.toFixed(1) + 'px ' + rgba(d.stroke);
      dom.style.paintOrder = 'stroke fill';
    } else {
      dom.style.webkitTextStroke = '';
      dom.style.paintOrder = '';
    }
    dom.style.display = (d.visible && !(d.billboard && d.bbOffscreen)) ? '' : 'none';
    dom.style.zIndex = num(d.zIndex) || 0;
    dom.style.boxShadow = d.shadow ? '0 4px 14px rgba(0, 0, 0, 0.45)' : '';
    dom.style.overflow = num(d.radius) > 0 ? 'hidden' : '';
    dom.style.transform = anchorCss(d.anchor);
    if (d.type === 'button' || d.type === 'joystick') dom.style.cursor = 'pointer';
    if (d.type === 'joystick') {
      const knob = this.knobs.get(d.name);
      if (knob) {
        knob.style.background = rgba(d.fg);
        knob.style.width = '44%';
        knob.style.height = '44%';
        knob.style.left = `calc(50% + ${(num(d.valX) * 28).toFixed(2)}%)`;
        knob.style.top = `calc(50% + ${(num(d.valY) * 28).toFixed(2)}%)`;
      }
    }
  }
  // каждый кадр: биллборды (@UI.Bb.*) пересчитывают экранные x/y из 3D-точки/объекта,
  // которому привязаны, через engine.world_to_screen — поэтому они всегда "смотрят" на
  // игрока (это плоский 2D-оверлей экрана, спроецированный из 3D, как BillboardGui в Roblox).
  updateBillboards(engine, canvasEl) {
    if (!engine || !engine.world_to_screen) return;
    // world_to_screen считает в "device"-пикселях бэкбуфера канваса (после devicePixelRatio),
    // а оверлей с UI живёт в CSS-пикселях — пересчитываем через реальное соотношение размеров
    const sxk = (canvasEl && canvasEl.width) ? (canvasEl.clientWidth / canvasEl.width) : 1;
    const syk = (canvasEl && canvasEl.height) ? (canvasEl.clientHeight / canvasEl.height) : 1;
    for (const d of this.list) {
      if (!d.billboard) continue;
      let wx = d.wx, wy = d.wy, wz = d.wz;
      if (d.wfollow) {
        try {
          const ids = engine.entity_ids();
          for (let i = 0; i < ids.length; i++) {
            if (engine.entity_name(ids[i]) === d.wfollow) {
              const pr = engine.get_props(ids[i]);
              wx = pr[0] + d.wx; wy = pr[1] + d.wy; wz = pr[2] + d.wz;
              break;
            }
          }
        } catch (e) { /* объект мог исчезнуть — используем последнюю известную точку */ }
      }
      let r;
      try { r = engine.world_to_screen(wx, wy, wz); } catch (e) { continue; }
      if (!r || r.length < 4) continue;
      const [sx, sy, vis] = r;
      d.x = { px: sx * sxk, pr: 0 };
      d.y = { px: sy * syk, pr: 0 };
      d.bbOffscreen = vis > 0.5 ? 0 : 1;
      const dom = this.doms.get(d.name);
      if (dom) this._applyStyle(dom, d);
    }
  }
  // обновить один элемент без пересборки DOM (анимации)
  refresh(name) {
    const d = this.find(name);
    const dom = this.doms.get(name);
    if (!d || !dom) return;
    this._applyStyle(dom, d);
  }
  render() {
    const root = this.root;
    root.innerHTML = '';
    this.doms.clear();
    this.knobs.clear();
    this.imgLayers.clear();
    const made = new Map();
    const mk = (d) => {
      if (made.has(d.name)) return made.get(d.name);
      let dom;
      if (d.type === 'textbox') {
        dom = document.createElement('input');
        dom.type = 'text';
      } else {
        dom = document.createElement(d.type === 'button' ? 'button' : 'div');
        if (d.type === 'button') dom.type = 'button';
      }
      made.set(d.name, dom);
      this.doms.set(d.name, dom);
      // родитель: имя frame-элемента (защита от циклов)
      let parName = d.parent, guard = 0;
      while (parName && guard++ < 64) {
        const pd = this.find(parName);
        if (!pd || pd.name === d.name) { parName = ''; break; }
        if (pd.type === 'frame') break;
        parName = pd.parent;
      }
      const parDom = parName ? (made.get(parName) || (this.find(parName) ? mk(this.find(parName)) : root)) : root;
      (parDom || root).appendChild(dom);
      dom.style.cssText = CSS_BASE;
      if (d.type === 'joystick') {
        const knob = document.createElement('div');
        knob.style.cssText = 'position:absolute;border-radius:50%;transform:translate(-50%,-50%);pointer-events:none;box-shadow:0 2px 8px #0006;';
        dom.appendChild(knob);
        this.knobs.set(d.name, knob);
      }
      if (d.type === 'imagelabel') {
        // отдельный слой под картинку: его opacity управляется НЕЗАВИСИМО от d.bg[3]
        // (фон можно сделать прозрачным, а саму картинку оставить непрозрачной, и наоборот)
        const img = document.createElement('div');
        img.style.cssText = 'position:absolute;left:0;top:0;right:0;bottom:0;pointer-events:none;background-size:cover;background-position:center;background-repeat:no-repeat;';
        dom.appendChild(img);
        this.imgLayers.set(d.name, img);
      }
      this._applyStyle(dom, d);
      this._wire(dom, d);
      return dom;
    };
    for (const d of this.list) if (!made.has(d.name)) mk(d);
  }

  _wire(dom, d) {
    if (this.edit) {
      if (d.billboard) {
        // биллборд всегда позиционируется из 3D-точки/объекта (pos/follow), а не руками —
        // таскать его в редакторе нельзя (это ничего не меняет в игре и только путает);
        // можно только выбрать тапом, позицию менять через "Точка в мире"/"Следовать за".
        dom.addEventListener('pointerdown', (ev) => {
          if (ev.button !== undefined && ev.button > 0) return;
          ev.preventDefault();
          ev.stopPropagation();
          if (this.onSelect) this.onSelect(d.name);
        });
        return;
      }
      dom.addEventListener('pointerdown', (ev) => {
        if (ev.button !== undefined && ev.button > 0) return;
        ev.preventDefault();
        ev.stopPropagation();
        const name = d.name;
        if (this.onSelect) this.onSelect(name);
        // захват пальца на самом элементе: слушатели не висят на window и не могут «уехать»
        try { dom.setPointerCapture(ev.pointerId); } catch (e) { /* ок */ }
        const el = () => this.doms.get(name) || dom;
        const start = this.find(name);
        if (!start) return;
        const ox = num(start.x.px), oy = num(start.y.px);
        const sx = ev.clientX, sy = ev.clientY;
        let moved = false, raf = 0, last = null;
        this.dragging = '';
        const apply = () => {
          raf = 0;
          if (!last) return;
          const t = this.find(name);
          if (!t) return;
          // компенсируем порог: элемент не дёргается в момент начала перетаскивания
          const dx = last.clientX - sx, dy = last.clientY - sy;
          const k = moved ? 1 : 0;
          t.x.px = Math.round(ox + dx * k);
          t.y.px = Math.round(oy + dy * k);
          const nd = el();
          nd.style.left = unit(t.x);
          nd.style.top = unit(t.y);
          if (this.onDragMove) this.onDragMove(name, t);
        };
        const mv = (e) => {
          if (!moved) {
            if (Math.abs(e.clientX - sx) + Math.abs(e.clientY - sy) < 6) return; // мёртвая зона от дрожи пальца
            moved = true;
            this.dragging = name;
          }
          last = e;
          if (!raf) raf = requestAnimationFrame(apply);
        };
        const up = () => {
          if (raf) { cancelAnimationFrame(raf); raf = 0; apply(); }
          dom.removeEventListener('pointermove', mv);
          dom.removeEventListener('pointerup', up);
          dom.removeEventListener('pointercancel', up);
          try { dom.releasePointerCapture(ev.pointerId); } catch (e) { /* ок */ }
          this.dragging = '';
          if (moved && this.onMutate) this.onMutate();
        };
        dom.addEventListener('pointermove', mv);
        dom.addEventListener('pointerup', up);
        dom.addEventListener('pointercancel', up);
      });
      return;
    }
    // игровой режим: события
    dom.addEventListener('pointerdown', (ev) => ev.stopPropagation());
    // draggable(true) — элемент можно перетаскивать пальцем в игре (не для биллбордов —
    // их позицию каждый кадр пересчитывает мир, ручной драг всё равно будет тут же затёрт)
    if (d.draggable && !this.edit && !d.billboard) {
      dom.style.touchAction = 'none';
      dom.addEventListener('pointerdown', (ev) => {
        try { dom.setPointerCapture(ev.pointerId); } catch (e) { /* ок */ }
        ev.preventDefault(); ev.stopPropagation();
        const sx = ev.clientX, sy = ev.clientY;
        const ox = d.x.px, oy = d.y.px;
        const mv = (e) => {
          d.x.px = Math.round(ox + (e.clientX - sx));
          d.y.px = Math.round(oy + (e.clientY - sy));
          dom.style.left = unit(d.x); dom.style.top = unit(d.y);
        };
        const up = () => {
          window.removeEventListener('pointermove', mv);
          window.removeEventListener('pointerup', up);
          window.removeEventListener('pointercancel', up);
        };
        window.addEventListener('pointermove', mv);
        window.addEventListener('pointerup', up);
        window.addEventListener('pointercancel', up);
      });
    }
    if (d.type === 'joystick') {
      dom.addEventListener('pointerdown', (ev) => {
        ev.preventDefault();
        try { dom.setPointerCapture(ev.pointerId); } catch (e) { /* ок */ }
        const move = (e) => {
          const r = dom.getBoundingClientRect();
          const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
          let dx = r.width ? (e.clientX - cx) / (r.width / 2) : 0;
          let dy = r.height ? (e.clientY - cy) / (r.height / 2) : 0;
          const m = Math.hypot(dx, dy);
          if (m > 1) { dx /= m; dy /= m; }
          d.valX = dx; d.valY = dy; d.active = 1;
          this.refresh(d.name);
          if (this.onEvent) this.onEvent(d, 'move', [dx, dy]);
        };
        const up = () => {
          d.valX = 0; d.valY = 0; d.active = 0;
          this.refresh(d.name);
          if (this.onEvent) this.onEvent(d, 'move', [0, 0]);
          dom.removeEventListener('pointermove', move);
          dom.removeEventListener('pointerup', up);
          dom.removeEventListener('pointercancel', up);
        };
        move(ev);
        dom.addEventListener('pointermove', move);
        dom.addEventListener('pointerup', up);
        dom.addEventListener('pointercancel', up);
      });
      return;
    }
    if (d.type === 'button' || d.type === 'frame' || d.type === 'label') {
      dom.addEventListener('click', (ev) => {
        ev.preventDefault(); ev.stopPropagation();
        if (this.onEvent) this.onEvent(d, 'click', null);
      });
    }
    if (d.type === 'textbox') {
      const fire = () => { if (this.onEvent) this.onEvent(d, 'change', dom.value); };
      dom.addEventListener('change', fire);
      dom.addEventListener('input', () => { d.text = dom.value; });
    }
  }
}

// цвет: [r,g,b(,a)] 0-255, hex int, "#rrggbb", имя → [r,g,b,a] 0-255
const COL_NAMES = {
  white: [255, 255, 255], black: [0, 0, 0], red: [230, 57, 70], green: [42, 157, 84],
  blue: [38, 110, 214], yellow: [247, 196, 44], orange: [242, 140, 40], gray: [128, 128, 128],
  grey: [128, 128, 128], cyan: [64, 190, 200], magenta: [200, 64, 190], purple: [128, 64, 200],
  pink: [240, 130, 170], brown: [140, 90, 50], transparent: [0, 0, 0, 0],
};
function normCol(v, prev) {
  const out = (prev || [255, 255, 255, 255]).slice();
  if (v == null) return out;
  if (typeof v === 'string') {
    const s = v.trim();
    const named = COL_NAMES[s.toLowerCase()];
    if (named) {
      out[0] = named[0]; out[1] = named[1]; out[2] = named[2];
      if (named[3] !== undefined) out[3] = named[3];
      return out;
    }
    if (s.startsWith('#')) {
      const h = parseInt(s.slice(1), 16);
      if (!isNaN(h)) {
        if (s.length === 7) { out[0] = (h >> 16) & 255; out[1] = (h >> 8) & 255; out[2] = h & 255; }
        else if (s.length === 4) { out[0] = ((h >> 8) & 15) * 17; out[1] = ((h >> 4) & 15) * 17; out[2] = (h & 15) * 17; }
        return out;
      }
    }
    const n = parseFloat(s);
    if (!isNaN(n)) v = n; else return out;
  }
  if (typeof v === 'number') {
    const h = Math.min(0xffffff, Math.max(0, v)) >>> 0;
    out[0] = (h >> 16) & 255; out[1] = (h >> 8) & 255; out[2] = h & 255;
    return out;
  }
  if (Array.isArray(v)) {
    if (v.length && v[0] <= 1 && v[1] <= 1 && v[2] <= 1 && v[0] > 0) {
      out[0] = Math.round(num(v[0]) * 255); out[1] = Math.round(num(v[1]) * 255); out[2] = Math.round(num(v[2]) * 255);
    } else {
      out[0] = Math.round(num(v[0])); out[1] = Math.round(num(v[1])); out[2] = Math.round(num(v[2]));
    }
    if (v[3] !== undefined) out[3] = Math.round(num(v[3]));
    return out;
  }
  return out;
}
