const D = {
  ru: {
    projects: 'Проекты',
    empty: 'Проектов пока нет.\nНажмите «+», чтобы создать первый.',
    newProject: 'Новый проект',
    iconLabel: 'Иконка',
    namePh: 'Название игры',
    create: 'Создать',
    copyLog: 'Копировать лог',
    outChip: 'Вывод',
    copied: 'Скопировано',
    close: 'Закрыть',
    menu: '‹ Меню',
    rotate: 'Поверните телефон\nгоризонтально',
    pos: 'Позиция',
    rot: 'Поворот°',
    size: 'Размер',
    color: 'Цвет',
    settings: 'Настройки',
    language: 'Язык',
    plate: 'Плита',
    checkFail: 'Ошибка проверки',
    log_start: 'Проверка целостности движка',
    log_core_fail: 'Rust core не загрузился: {0}',
    log_core_ok: 'Rust core v{0}',
    log_webgl: 'WebGL2 · GPU: {0}',
    log_tex: 'Макс. текстура: {0}px',
    log_webgl_fail: 'WebGL2: {0}',
    log_store_ok: 'Хранилище проектов',
    log_store_fail: 'Хранилище: {0}',
    log_threads: 'Потоки (SharedArrayBuffer): {0}',
    thr_yes: 'доступны',
    thr_no: 'недоступны, пока не нужны',
    log_physics: 'Физика: модуль ещё не подключён (план v0.3)',
    log_all_ok: 'Все проверки пройдены',
    log_some_fail: 'Есть ошибки, см. лог',
    log_exc: 'Исключение: {0}',
    confirmDel: 'Вы уверены, что хотите удалить проект "{0}"?',
    del_note: 'Восстановление невозможно',
    cancel_x: 'Отмена',
    del_ok: 'Удалить',
    tip1: 'Совет: Вы можете изменять параметры тумана во вкладке Graphics',
    tip2: 'Совет: Кнопка «Проверить» в редакторе кода найдёт ошибки до запуска',
    tip3: 'Совет: Дочерние объекты следуют за родителем — удобно для групп и машин',
    tip4: 'Совет: Скрипт игрока запускается при нажатии ▶ — события OnUpdate(dt) вызываются каждый кадр',
    saveFail: 'Не удалось сохранить: {0}',
    coreNotLoaded: 'Rust core не загружен: {0}',
    engineFail: 'Не удалось создать движок: {0}',
    imgFail: 'Не удалось открыть картинку',
  },
  en: {
    projects: 'Projects',
    empty: 'No projects yet.\nTap “+” to create your first one.',
    newProject: 'New project',
    iconLabel: 'Icon',
    namePh: 'Game name',
    create: 'Create',
    copyLog: 'Copy log',
    outChip: 'Output',
    copied: 'Copied',
    close: 'Close',
    menu: '‹ Menu',
    rotate: 'Rotate your phone\nto landscape',
    pos: 'Position',
    rot: 'Rotation°',
    size: 'Size',
    color: 'Color',
    settings: 'Settings',
    language: 'Language',
    plate: 'Plate',
    checkFail: 'Check failed',
    log_start: 'Engine integrity check',
    log_core_fail: 'Rust core failed to load: {0}',
    log_core_ok: 'Rust core v{0}',
    log_webgl: 'WebGL2 · GPU: {0}',
    log_tex: 'Max texture size: {0}px',
    log_webgl_fail: 'WebGL2: {0}',
    log_store_ok: 'Project storage',
    log_store_fail: 'Storage: {0}',
    log_threads: 'Threads (SharedArrayBuffer): {0}',
    thr_yes: 'available',
    thr_no: 'unavailable, not needed yet',
    log_physics: 'Physics: module not connected yet (planned v0.3)',
    log_all_ok: 'All checks passed',
    log_some_fail: 'Errors found, see log',
    log_exc: 'Exception: {0}',
    confirmDel: 'Are you sure you want to delete project "{0}"?',
    del_note: 'This cannot be undone',
    cancel_x: 'Cancel',
    del_ok: 'Delete',
    tip1: 'Tip: You can tweak fog settings in the Graphics tab',
    tip2: 'Tip: The Check button in the code editor catches errors before running',
    tip3: 'Tip: Child objects follow their parent — great for groups and vehicles',
    tip4: 'Tip: The player script starts with the ▶ button — OnUpdate(dt) fires every frame',
    saveFail: 'Failed to save: {0}',
    coreNotLoaded: 'Rust core is not loaded: {0}',
    engineFail: 'Failed to create engine: {0}',
    imgFail: 'Could not open the image',
  },
};

let lang = 'ru';
try {
  const s = localStorage.getItem('eng.lang');
  if (s === 'ru' || s === 'en') lang = s;
} catch {}

export const getLang = () => lang;

export function t(key, ...args) {
  let s = (D[lang] && D[lang][key]) ?? D.ru[key] ?? key;
  args.forEach((v, i) => { s = s.split('{' + i + '}').join(v); });
  return s;
}

export function applyDom() {
  document.documentElement.lang = lang;
  document.querySelectorAll('[data-i18n]').forEach((e) => { e.textContent = t(e.dataset.i18n); });
  document.querySelectorAll('[data-i18n-ph]').forEach((e) => { e.placeholder = t(e.dataset.i18nPh); });
  document.querySelectorAll('[data-i18n-tip]').forEach((e) => { const s = t(e.dataset.i18nTip); e.title = s; e.setAttribute('aria-label', s); });
}

export function setLang(l) {
  if (l !== 'ru' && l !== 'en') return;
  lang = l;
  try { localStorage.setItem('eng.lang', l); } catch {}
  applyDom();
}

Object.assign(D.ru, {
  block: 'Блок', addBlock: 'Блок', neon: 'Неон', del: 'Удалить', graphics: 'Графика', reset: 'Сброс',
  grp_time: 'Время и небо', grp_fx: 'Эффекты', grp_col: 'Цвет', grp_fog: 'Туман',
  g_time: 'Время суток', g_contrast: 'Контраст', g_exposure: 'Яркость', g_sat: 'Насыщенность',
  g_rays: 'Лучи', g_neon: 'Яркость неона', g_bloom: 'Блум', g_bthr: 'Порог блума',
  g_fogd: 'Плотность', g_fogs: 'Начало от игрока', g_skyb: 'Яркость неба', g_sun: 'Размер солнца',
  g_vig: 'Виньетка', g_amb: 'Окружающий свет',
});
Object.assign(D.en, {
  block: 'Block', addBlock: 'Block', neon: 'Neon', del: 'Delete', graphics: 'Graphics', reset: 'Reset',
  grp_time: 'Time & sky', grp_fx: 'Effects', grp_col: 'Color', grp_fog: 'Fog',
  g_time: 'Time of day', g_contrast: 'Contrast', g_exposure: 'Brightness', g_sat: 'Saturation',
  g_rays: 'Light rays', g_neon: 'Neon brightness', g_bloom: 'Bloom', g_bthr: 'Bloom threshold',
  g_fogd: 'Density', g_fogs: 'Start distance', g_skyb: 'Sky brightness', g_sun: 'Sun size',
  g_vig: 'Vignette', g_amb: 'Ambient light',
});

Object.assign(D.ru, { g_shadow: 'Тени', g_nlight: 'Свет от неона' });
Object.assign(D.en, { g_shadow: 'Shadows', g_nlight: 'Neon light' });

Object.assign(D.ru, {
  alpha: 'Прозрачн.', water: 'Вода', grp_water: 'Вода', grp_cam: 'Камера',
  g_waveh: 'Высота волн', g_waves: 'Скорость волн', g_bump: 'Рельеф поверхности',
  g_fov: 'Поле зрения (FOV)', g_sens: 'Чувствительность камеры',
});
Object.assign(D.en, {
  alpha: 'Opacity', water: 'Water', grp_water: 'Water', grp_cam: 'Camera',
  g_waveh: 'Wave height', g_waves: 'Wave speed', g_bump: 'Surface relief',
  g_fov: 'Field of view (FOV)', g_sens: 'Camera sensitivity',
});

Object.assign(D.ru, { fire: 'Огонь' });
Object.assign(D.en, { fire: 'Fire' });

Object.assign(D.ru, { g_fogn: 'Шум тумана', g_mie: 'Рассеяние света', g_clouds: 'Облака', server: 'Серверные скрипты', server_new: 'Новый скрипт', edit_brush: 'Кисть', edit_invert: 'Инверт', edit_mirror: 'Зеркало', edit_blender: 'Блендер', edit_face: 'Грань+', edit_hole: 'Дыра', edit_hollow: 'Полость', edit_organic: 'Органика', edit_mat: 'Материал', edit_rough: 'Шоршавость', edit_tex: 'Текстура…', edit_flood: 'Заливка', edit_box: 'Рамка', edit_paint: 'Краска', edit_dropper: 'Пип.', edit_sel_del: 'Удалить', edit_sel_clear: 'Снять', edit_redo: 'Повтор', edit_hist: 'История', shape_cube: 'Куб', shape_cyl: 'Цилиндр', shape_cone: 'Конус', shape_wedge: 'Клин', shape_arch: 'Арка', shape_stairs: 'Лестница', pm_create: 'Создать', pm_import: 'Импорт', pm_filter: 'Фильтр проектов', pm_sort: 'Сортировка:', pm_sort_date: 'Последнее изменение', pm_sort_name: 'Название', pm_edit: 'Редактировать', pm_play: 'Запустить', pm_rename: 'Переименовать', pm_dup: 'Дублировать', pm_export: 'Экспорт .mapp', pm_del: 'Удалить', pm_about: 'О программе', pm_fav: 'Избранное', pm_rename_q: 'Новое имя проекта', pm_dup_name: '(копия)' });
Object.assign(D.en, { g_fogn: 'Fog noise', g_mie: 'Light scattering', g_clouds: 'Clouds', server: 'Server scripts', server_new: 'New script', edit_brush: 'Brush', edit_invert: 'Invert', edit_mirror: 'Mirror', edit_blender: 'Blender', edit_face: 'Face+', edit_hole: 'Hole', edit_hollow: 'Hollow', edit_organic: 'Organic', edit_mat: 'Material', edit_rough: 'Roughness', edit_tex: 'Texture…', edit_flood: 'Fill', edit_box: 'Box', edit_paint: 'Paint', edit_dropper: 'Pick', edit_sel_del: 'Delete', edit_sel_clear: 'Deselect', edit_redo: 'Redo', edit_hist: 'History', shape_cube: 'Cube', shape_cyl: 'Cylinder', shape_cone: 'Cone', shape_wedge: 'Wedge', shape_arch: 'Arch', shape_stairs: 'Stairs', pm_create: 'Create', pm_import: 'Import', pm_filter: 'Filter projects', pm_sort: 'Sort:', pm_sort_date: 'Last modified', pm_sort_name: 'Name', pm_edit: 'Edit', pm_play: 'Run', pm_rename: 'Rename', pm_dup: 'Duplicate', pm_export: 'Export .mapp', pm_del: 'Delete', pm_about: 'About', pm_fav: 'Favorite', pm_rename_q: 'New project name', pm_dup_name: '(copy)' });

Object.assign(D.ru, {
  grp_qual: 'Качество', g_texq: 'Качество текстур', g_shq: 'Качество теней', g_wq: 'Качество воды',
  q_low: 'Низкое', q_med: 'Среднее', q_high: 'Высокое',
  material: 'Материал', mat_stone: 'Камень', mat_glass: 'Стекло', mat_sand: 'Песок',
  mat_wood: 'Древесина', mat_planks: 'Доски', mat_custom: 'Из галереи',
  wtex: 'Текстура воды', wtex_std: 'Обычная', wtex_gal: 'Из галереи',
});
Object.assign(D.en, {
  grp_qual: 'Quality', g_texq: 'Texture quality', g_shq: 'Shadow quality', g_wq: 'Water quality',
  q_low: 'Low', q_med: 'Medium', q_high: 'High',
  material: 'Material', mat_stone: 'Stone', mat_glass: 'Glass', mat_sand: 'Sand',
  mat_wood: 'Wood', mat_planks: 'Planks', mat_custom: 'From gallery',
  wtex: 'Water texture', wtex_std: 'Default', wtex_gal: 'From gallery',
});
Object.assign(D.ru, {
  player: 'Игрок', player_model: 'Модель', player_model_none: 'не выбрана',
  player_create: 'Создать модель', shape: 'Форма', shape_cube: 'Куб', shape_tri: 'Призма',
  shape_sphere: 'Сфера', shape_wheel: 'Колесо', shape_oval: 'Овал',
  edit: 'Правка', edit_open: '✎ Открыть', edit_title: 'Режим правки', edit_grid: 'Сетка (кубиков)',
  edit_round: 'Скругление', edit_reset: 'Сбросить ячейки',
  edit_hint: 'Тап — кубик. Кисть — ведите пальцем. Грань+ / Дыра — тап по грани. Полость — вырезать внутри. Зеркало X/Y/Z. ↻ — поворот, ⇈ — выдавить. Блендер — изолированный режим. ✕ — готово.',
  script_title: 'player.hgs', script_reset: 'Сбросить', save: 'Сохранить',
  script_hint: 'Скрипт игрока на языке @W/@L/@P/@F/@E. Запускается при ▶.',
  obj_script: 'Скрипт', edit_undo: 'Отмена', edit_iso: 'Изолировать',
  ce_check: 'Проверить', ce_fmt: 'Формат', ce_run: 'Запустить', ce_save: 'Сохранить', out_copy: 'Копировать', err_copy: 'Копировать ошибки', cop_ok: 'Скопировано', saved_ok: 'Сохранено',
  ce_find_ph: 'Поиск… (Ctrl+F)',
  ce_hints: 'Ctrl+Space — подсказки · Ctrl+F — поиск · Ctrl+Enter — проверить · Tab — отступ',
  player_view: 'Вид игрока', player_sphere: 'Сфера', player_human: 'Модель',
  rotate_tip: 'Нажмите, чтобы продолжить',
  mappSaved: 'Файл .mapp сохранён', mappImported: 'Проект импортирован', mappBad: 'Неверный файл .mapp',
});
Object.assign(D.en, {
  player: 'Player', player_model: 'Model', player_model_none: 'not set',
  player_create: 'Create model', shape: 'Shape', shape_cube: 'Cube', shape_tri: 'Prism',
  shape_sphere: 'Sphere', shape_wheel: 'Wheel', shape_oval: 'Oval',
  edit: 'Edit', edit_open: '✎ Open', edit_title: 'Edit mode', edit_grid: 'Grid (cells)',
  edit_round: 'Rounding', edit_reset: 'Reset cells',
  edit_hint: 'Tap — cell. Brush: drag. Face+ / Hole: tap a face. Hollow — cut inside. Mirror X/Y/Z. ↻ rotate, ⇈ extrude. Blender — isolated mode. ✕ to finish.',
  script_title: 'player.hgs', script_reset: 'Reset', save: 'Save',
  script_hint: 'Player script in @W/@L/@P/@F/@E language. Runs on ▶.',
  obj_script: 'Script', edit_undo: 'Undo', edit_iso: 'Isolate',
  ce_check: 'Check', ce_fmt: 'Format', ce_run: 'Run', ce_save: 'Save', out_copy: 'Copy', err_copy: 'Copy errors', cop_ok: 'Copied', saved_ok: 'Saved',
  ce_find_ph: 'Search… (Ctrl+F)',
  ce_hints: 'Ctrl+Space — hints · Ctrl+F — search · Ctrl+Enter — check · Tab — indent',
  player_view: 'Player view', player_sphere: 'Sphere', player_human: 'Model',
  rotate_tip: 'Tap to continue',
  mappSaved: '.mapp file saved', mappImported: 'Project imported', mappBad: 'Invalid .mapp file',
});

Object.assign(D.ru, { pm_export_apk: 'Экспорт APK', apkSaved: 'APK готов:', apkFail: 'Ошибка сборки APK', grp_sysui: 'Системный интерфейс', sysui_joy: 'Джойстик', sysui_cam: 'Поворот камеры', sysui_jump: 'Кнопка прыжка', sysui_fps: 'Счётчик FPS' });
Object.assign(D.en, { pm_export_apk: 'Export APK', apkSaved: 'APK ready:', apkFail: 'APK build failed', grp_sysui: 'System UI', sysui_joy: 'Joystick', sysui_cam: 'Camera turn', sysui_jump: 'Jump button', sysui_fps: 'FPS counter' });

/* ---- R40: UI (@UI) + модели ---- */
Object.assign(D.ru, {
  ui_new: 'Новый элемент', ui_frame: 'Frame', ui_label: 'TextLabel', ui_button: 'Button', ui_textbox: 'TextBox', ui_imagelabel: 'ImageLabel',
  ui_name: 'Имя', ui_parent: 'Родитель', ui_text: 'Текст', ui_ph: 'Подсказка',
  ui_colors: 'Цвета', ui_fg: 'Текст', ui_bg: 'Фон', ui_border: 'Рамка', ui_brw: 'Толщина рамки',
  ui_radius: 'Скругление', ui_font: 'Шрифт', ui_zvis: 'Z / вид.',
  ui_screen: 'экран', ui_hint: 'X/Y/W/H: px + % от родителя. Клик по элементу — выбор, перетаскивание — движение.',
  group_name: 'Имя модели (группы)', vis: 'виден',
});
Object.assign(D.en, {
  ui_new: 'New element', ui_frame: 'Frame', ui_label: 'TextLabel', ui_button: 'Button', ui_textbox: 'TextBox', ui_imagelabel: 'ImageLabel',
  ui_name: 'Name', ui_parent: 'Parent', ui_text: 'Text', ui_ph: 'Placeholder',
  ui_colors: 'Colors', ui_fg: 'Text', ui_bg: 'Background', ui_border: 'Border', ui_brw: 'Border width',
  ui_radius: 'Radius', ui_font: 'Font', ui_zvis: 'Z / vis.',
  ui_screen: 'screen', ui_hint: 'X/Y/W/H: px + % of parent. Click — select, drag — move.',
  group_name: 'Model (group) name', vis: 'visible',
});
Object.assign(D.ru, { ui_joystick: 'Joystick', });
Object.assign(D.en, { ui_joystick: 'Joystick', });
Object.assign(D.ru, { ui_anchor: 'Якорь' });
Object.assign(D.en, { ui_anchor: 'Anchor' });
Object.assign(D.ru, { ui_fontfam: 'Шрифт', ui_stroke: 'Обводка', ui_strokew: 'Толщина обводки', ui_shadow: 'Тень / перенос', ui_drag: 'таскать в игре', yes: 'вкл', ui_scaled: 'Текст по размеру', ui_img: 'Картинка', ui_imgpick: 'Выбрать…', ui_bb: 'Биллборд (3D)', ui_bbpos: 'Точка в мире', ui_bbfollow: 'Следовать за объектом', ui_imgalpha: 'Непрозрачность картинки', ui_bbauto: 'Масштаб по расстоянию (как настоящий объект)', ui_bbrefdist: 'Базовое расстояние (м)' });
Object.assign(D.en, { ui_fontfam: 'Font', ui_stroke: 'Outline', ui_strokew: 'Outline width', ui_shadow: 'Shadow / drag', ui_drag: 'drag in game', yes: 'on', ui_scaled: 'Text scaled', ui_img: 'Image', ui_imgpick: 'Choose…', ui_bb: 'Billboard (3D)', ui_bbpos: 'World point', ui_bbfollow: 'Follow object', ui_imgalpha: 'Image opacity', ui_bbauto: 'Scale with distance (like a real object)', ui_bbrefdist: 'Reference distance (m)' });
Object.assign(D.ru, { g_rayq: 'Лучи в тумане (0/1/2)' });
Object.assign(D.en, { g_rayq: 'Fog rays (0/1/2)' });
