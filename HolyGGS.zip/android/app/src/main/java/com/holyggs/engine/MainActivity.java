package com.holyggs.engine;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private byte[] saveBytes;
    private String saveName = "project.mapp";

    private static final int PICK_FILE = 1001;
    private static final int SAVE_FILE = 1002;
    private static final String HOST = "appassets.local";

    private static final Map<String, String> MIME = new HashMap<>();

    static {
        MIME.put("html", "text/html");
        MIME.put("htm", "text/html");
        MIME.put("js", "text/javascript");
        MIME.put("mjs", "text/javascript");
        MIME.put("css", "text/css");
        MIME.put("json", "application/json");
        MIME.put("wasm", "application/wasm");
        MIME.put("png", "image/png");
        MIME.put("jpg", "image/jpeg");
        MIME.put("jpeg", "image/jpeg");
        MIME.put("gif", "image/gif");
        MIME.put("svg", "image/svg+xml");
        MIME.put("ico", "image/x-icon");
        MIME.put("txt", "text/plain");
        MIME.put("woff", "font/woff");
        MIME.put("woff2", "font/woff2");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(0xFF0F1115);
        getWindow().setNavigationBarColor(0xFF0F1115);

        web = new WebView(this);
        setContentView(web);
        hideSysUi();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);

        web.setBackgroundColor(0xFF0F1115);
        web.setLayerType(WebView.LAYER_TYPE_HARDWARE, null);

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }
                fileCallback = callback;
                // SAF не понимает расширения (.mapp) — как MIME они ломают фильтр
                // и файлы становятся недоступными для выбора. Берём только реальные MIME.
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                java.util.ArrayList<String> mimes = new java.util.ArrayList<>();
                String[] at = params.getAcceptTypes();
                if (at != null) {
                    for (String a : at) {
                        if (a == null) continue;
                        a = a.trim();
                        if (a.isEmpty() || a.startsWith(".")) continue;
                        if ("*/*".equals(a)) { mimes.clear(); mimes.add("*/*"); break; }
                        if (a.contains("/")) mimes.add(a);
                    }
                }
                if (mimes.isEmpty() || (mimes.size() == 1 && "*/*".equals(mimes.get(0)))) {
                    i.setType("*/*");
                } else if (mimes.size() == 1) {
                    i.setType(mimes.get(0));
                } else {
                    i.setType("*/*");
                    i.putExtra(Intent.EXTRA_MIME_TYPES, mimes.toArray(new String[0]));
                }
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,
                        params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try {
                    startActivityForResult(i, PICK_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (u == null || !HOST.equals(u.getHost())) return null;
                String path = u.getPath();
                if (path == null || path.isEmpty() || path.equals("/")) path = "/index.html";
                return serveAsset(path);
            }
        });

        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.addJavascriptInterface(new JsBridge(), "Android");
        web.loadUrl("https://appassets.local/index.html");
    }

    private WebResourceResponse serveAsset(String path) {
        InputStream in;
        try {
            in = getAssets().open("public" + path);
        } catch (Exception e) {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                    new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
        }
        String mime = "application/octet-stream";
        int dot = path.toLowerCase(Locale.US).lastIndexOf('.');
        if (dot >= 0) {
            String ext = path.toLowerCase(Locale.US).substring(dot + 1);
            if (MIME.containsKey(ext)) mime = MIME.get(ext);
        }
        String enc = (mime.startsWith("text/") || mime.equals("application/json")) ? "utf-8" : null;
        Map<String, String> headers = new HashMap<>();
        headers.put("Cache-Control", "public, max-age=31536000");
        headers.put("Access-Control-Allow-Origin", "*");
        return new WebResourceResponse(mime, enc, 200, "OK", headers, in);
    }

    public class JsBridge {
        @JavascriptInterface
        public void saveFile(String name, String base64) {
            try {
                saveBytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
            } catch (Exception e) {
                saveBytes = null;
            }
            saveName = (name == null || name.isEmpty()) ? "project.mapp" : name;
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/octet-stream");
            i.putExtra(Intent.EXTRA_TITLE, saveName);
            try {
                startActivityForResult(i, SAVE_FILE);
            } catch (Exception ignored) {
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PICK_FILE) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                String d = data.getDataString();
                if (d != null) {
                    results = new Uri[]{Uri.parse(d)};
                } else if (data.getClipData() != null) {
                    ClipData cd = data.getClipData();
                    results = new Uri[cd.getItemCount()];
                    for (int i = 0; i < cd.getItemCount(); i++) {
                        results[i] = cd.getItemAt(i).getUri();
                    }
                }
            }
            if (fileCallback != null) {
                fileCallback.onReceiveValue(results);
                fileCallback = null;
            }
            return;
        }
        if (requestCode == SAVE_FILE) {
            if (resultCode == RESULT_OK && data != null && saveBytes != null) {
                Uri u = data.getData();
                if (u != null) {
                    try (OutputStream os = getContentResolver().openOutputStream(u)) {
                        if (os != null) os.write(saveBytes);
                    } catch (Exception ignored) {
                    }
                }
            }
            saveBytes = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    /** Полноэкранный режим: системная строка состояния и навигация скрыты (immersive). */
    private void hideSysUi() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSysUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSysUi();
        if (web != null) web.onResume();
    }

    @Override
    protected void onPause() {
        if (web != null) web.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
