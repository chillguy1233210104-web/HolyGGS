#!/usr/bin/env bash
# Сборка HolyGGS.apk без gradle: aapt2 + javac + d8 + zipalign + apksigner.
# Требуется: JDK 11+, Android SDK build-tools 34.0.0, platforms/android-34 (android.jar),
#            rustup (wasm32-unknown-unknown), wasm-bindgen-cli 0.2.129.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BT="${BT:-/opt/android-sdk/build-tools/34.0.0}"
AJ="${AJ:-/opt/android-sdk/platforms/android-34/android.jar}"
JDK="${JDK:-/usr/lib/jvm/jdk-11}"
export JAVA_HOME="$JDK"
export PATH="$JDK/bin:$BT:$PATH"

echo "==> 1. wasm"
cd "$ROOT/engine"
cargo build --release --target wasm32-unknown-unknown
wasm-bindgen --target web --out-dir public/pkg target/wasm32-unknown-unknown/release/engine.wasm

echo "==> 2. assets"
cd "$ROOT"
rm -rf android/app/src/main/assets
mkdir -p android/app/src/main/assets
cp -r engine/public android/app/src/main/assets/public
find android/app/src/main/assets/public -name '*.bak*' -delete

echo "==> 3. resources + java"
cd "$ROOT/android"
rm -rf build && mkdir -p build/obj build/dex
aapt2 compile --dir app/src/main/res -o build/res.zip
aapt2 link -o build/app-unsigned.apk -I "$AJ" \
  --manifest app/src/main/AndroidManifest.xml -R build/res.zip -A app/src/main/assets \
  --auto-add-overlay \
  --min-sdk-version 26 --target-sdk-version 34 \
  --version-code "${VCODE:-11}" --version-name "${VNAME:-0.4.5}"
javac --release 8 -encoding UTF-8 -nowarn -classpath "$AJ" -d build/obj \
  app/src/main/java/com/holyggs/engine/*.java
d8 --release --lib "$AJ" --output build/dex build/obj/com/holyggs/engine/*.class

echo "==> 4. pack + sign"
cp build/app-unsigned.apk build/app-zip.apk
(cd build/dex && zip -q -j ../app-zip.apk classes.dex)
zipalign -f 4 build/app-zip.apk build/app-aligned.apk
apksigner sign --ks "$ROOT/../holyggs.jks" --ks-pass pass:hgs-sign-2026 \
  --ks-key-alias holyggs --key-pass pass:hgs-sign-2026 \
  --out "$ROOT/HolyGGS.apk" build/app-aligned.apk
apksigner verify "$ROOT/HolyGGS.apk"
echo "=== ГОТОВО: $ROOT/HolyGGS.apk ==="
