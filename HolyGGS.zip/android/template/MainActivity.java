package com.holyggs.game;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.view.View;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final String TAG = "HolyGGSGame";
    private static final int PICK_FILE = 4321;
    private ValueCallback<Uri[]> fileCb;
    private WebView wv;

    private static final Map<String, String> MIME = new HashMap<>();
    static {
        MIME.put("html", "text/html");
        MIME.put("js", "text/javascript");
        MIME.put("mjs", "text/javascript");
        MIME.put("css", "text/css");
        MIME.put("json", "application/json");
        MIME.put("wasm", "application/wasm");
        MIME.put("png", "image/png");
        MIME.put("jpg", "image/jpeg");
        MIME.put("jpeg", "image/jpeg");
        MIME.put("gif", "image/gif");
        MIME.put("svg", "image/svg+xml");
        MIME.put("webp", "image/webp");
        MIME.put("mapp", "application/octet-stream");
        MIME.put("bin", "application/octet-stream");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            final String err = Log.getStackTraceString(e);
            Log.e(TAG, "crash", e);
            runOnUiThread(() -> {
                try {
                    new AlertDialog.Builder(MainActivity.this)
                        .setTitle("HolyGGS Game — ошибка")
                        .setMessage(err.length() > 4000 ? err.substring(0, 4000) : err)
                        .setPositiveButton("OK", null)
                        .show();
                } catch (Exception ignored) { }
            });
        });
        try {
            wv = new WebView(this);
            setContentView(wv);
            hideSysUi();
            wv.setLayerType(WebView.LAYER_TYPE_HARDWARE, null);
            WebSettings s = wv.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setAllowFileAccess(true);
            s.setMediaPlaybackRequiresUserGesture(false);
            wv.setBackgroundColor(0xFF0f1115);
            wv.setWebViewClient(new WebViewClient() {
                @Override
                public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                    try {
                        Uri url = req.getUrl();
                        String host = url.getHost();
                        if (host == null || !host.equals("appassets.local")) return null;
                        String path = url.getPath();
                        if (path == null || path.isEmpty()) path = "/index.html";
                        InputStream in = getAssets().open("public" + path);
                        String mime = "application/octet-stream";
                        int dot = path.lastIndexOf('.');
                        if (dot >= 0) {
                            String m = MIME.get(path.substring(dot + 1).toLowerCase());
                            if (m != null) mime = m;
                        }
                        return new WebResourceResponse(mime, "UTF-8", in);
                    } catch (Exception e) {
                        return null;
                    }
                }

                @Override
                public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                    String scheme = req.getUrl().getScheme();
                    if (scheme != null && (scheme.equals("http") || scheme.equals("https"))) {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, req.getUrl()));
                        } catch (Exception ignored) { }
                        return true;
                    }
                    return false;
                }
            });
            wv.setWebChromeClient(new WebChromeClient() {
                @Override
                public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                    fileCb = cb;
                    try {
                        startActivityForResult(params.createIntent(), PICK_FILE);
                    } catch (Exception e) {
                        fileCb = null;
                    }
                    return true;
                }
            });
            wv.addJavascriptInterface(new Object() {
                @android.webkit.JavascriptInterface
                public void saveFile(final String name, final String base64) {
                    // сохранение из игр не требуется; мост оставлен для совместимости
                }
            }, "Android");
            wv.loadUrl("https://appassets.local/index.html");
        } catch (Throwable e) {
            Log.e(TAG, "onCreate", e);
            String err = Log.getStackTraceString(e);
            try {
                AlertDialog.Builder b = new AlertDialog.Builder(this)
                    .setTitle("HolyGGS Game — ошибка запуска")
                    .setMessage(err.length() > 4000 ? err.substring(0, 4000) : err)
                    .setPositiveButton("OK", null);
                b.show();
            } catch (Exception ignored) { }
        }
    }

    /** Полноэкранный режим: системная строка состояния и навигация скрыты (immersive). */
    private void hideSysUi() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSysUi();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE && fileCb != null) {
            Uri[] res = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                res = new Uri[]{ data.getData() };
            }
            fileCb.onReceiveValue(res);
            fileCb = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (wv != null && wv.canGoBack()) {
            wv.goBack();
            return;
        }
        super.onBackPressed();
    }
}
