#!/usr/bin/env bash
# Сборка template.apk (шаблон экспорта игры) без gradle: aapt v1 + javac + d8 + zip.
# ВАЖНО: в d8 передаются ВСЕ .class (включая внутренние MainActivity$1/$2/...)!
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
BT="${BT:-/opt/android-sdk/build-tools/34.0.0}"
AJ="${AJ:-/opt/android-sdk/platforms/android-34/android.jar}"
JDK="${JDK:-/usr/lib/jvm/jdk-11}"
export JAVA_HOME="$JDK"
export PATH="$JDK/bin:$BT:$PATH"
OUT="${1:-$HERE/../../engine/public/template.apk}"
BUILD="$HERE/../../../build-tpl"

rm -rf "$BUILD" && mkdir -p "$BUILD/dex"
aapt package -f -M AndroidManifest.xml -S res -I "$AJ" -F "$BUILD/unsigned.apk" \
  --min-sdk-version 26 --target-sdk-version 29 --version-code 1 --version-name 1.0
javac -encoding UTF-8 --release 8 -nowarn -classpath "$AJ" -d "$BUILD/dex" MainActivity.java
d8 --lib "$AJ" --output "$BUILD/dex" "$BUILD"/dex/com/holyggs/game/*.class
# самопроверка: внутренние классы обязаны быть в dex
N=$(find "$BUILD/dex/com" -name 'MainActivity$*.class' | wc -l)
if [ "$N" -lt 1 ]; then echo "FAIL: нет внутренних классов MainActivity\$*"; exit 1; fi
mkdir -p "$BUILD/zx"
(cd "$BUILD/zx" && unzip -q "$BUILD/unsigned.apk" && cp "$BUILD/dex/classes.dex" . && zip -q -0 -r "$BUILD/tpl.apk" .)
cp "$BUILD/tpl.apk" "$OUT"
dexdump "$OUT" >/dev/null
if ! unzip -p "$OUT" classes.dex | strings | grep -q 'MainActivity$1'; then
  echo "FAIL: MainActivity\$1 отсутствует в classes.dex"; exit 1
fi
echo "OK template: $OUT"
