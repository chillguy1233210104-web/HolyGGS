# HolyGGS

Версия v0.22.1 (код 49): синтаксис по спеке — @UI.ТИП.Имя (Frame/TextLabel/Button/TextBox/Joystick), anchor(center) и 9 якорей, твины как у @W: tween(size, (280, 280), 1, ease_in_out), композиты 50%+12, динамические имена @UI.Spark[i], alpha 0-255; кнопка прыжка ⇧ починена; @F.End() закрывает функции.

## Состав
- `engine/` — исходники: Rust (`src/lib.rs`, `Cargo.toml`), веб-приложение (`public/`)
- `android/` — Android-обёртка: `AndroidManifest.xml`, `java/`, `res/`, `build_apk.sh`, `template/` (шаблон экспорта игр)
- `HolyGGS.apk` — готовое приложение (версия 0.22.1, код 49)

## Фикс v0.5.1
- `smoothstep` с перевёрнутыми рёбрами (edge0 > edge1) — UB в GLSL — везде исправлен:
  лучи (маска глубины), следы на песке (VS/FS), искры огня.
- Геометрия лучей как в v1.10: acc/20, 0.45 + exp(-r*1.4), 32 шага, затухание 0.945.

## Функции
Редактор блоков, вода, огонь, солнце с лучами, тени, постобработка, персонаж с физикой,
песок со следами-отпечатками, .mapp (📂/⬇), редактор кода (F2), ярлычок «Вывод», палитра цвета.

## Сборка движка
```
cd engine
cargo build --release --target wasm32-unknown-unknown
wasm-bindgen --target web --out-dir public/pkg target/wasm32-unknown-unknown/release/engine.wasm
```

## Сборка APK
```
cd android
JAVA_HOME=/usr/lib/jvm/jdk-11 ./build_apk.sh
```
