# HolyGGS

Версия v0.22.2 (код 50): @UI.controls(hide|show) — скрыть шаблонное управление (джойстики и кнопку прыжка) прямо из скрипта (для кликеров/UI-игр); всё из 0.22.1: @UI.ТИП.Имя, anchor(center)+9 якорей, твины как у @W, композиты 50%+12, @UI.Spark[i], alpha 0-255; кнопка прыжка ⇧ починена.

## Состав
- `engine/` — исходники: Rust (`src/lib.rs`, `Cargo.toml`), веб-приложение (`public/`)
- `android/` — Android-обёртка: `AndroidManifest.xml`, `java/`, `res/`, `build_apk.sh`, `template/` (шаблон экспорта игр)
- `HolyGGS.apk` — готовое приложение (версия 0.22.2, код 50)

## Фикс v0.5.1
- `smoothstep` с перевёрнутыми рёбрами (edge0 > edge1) — UB в GLSL — везде исправлен:
  лучи (маска глубины), следы на песке (VS/FS), искры огня.
- Геометрия лучей как в v1.10: acc/20, 0.45 + exp(-r*1.4), 32 шага, затухание 0.945.

## Функции
Редактор блоков, вода, огонь, солнце с лучами, тени, постобработка, персонаж с физикой,
песок со следами-отпечатками, .mapp (📂/⬇), редактор кода (F2), ярлычок «Вывод», палитра цвета.

## Сборка движка
```
cd engine
cargo build --release --target wasm32-unknown-unknown
wasm-bindgen --target web --out-dir public/pkg target/wasm32-unknown-unknown/release/engine.wasm
```

## Сборка APK
```
cd android
JAVA_HOME=/usr/lib/jvm/jdk-11 ./build_apk.sh
```
