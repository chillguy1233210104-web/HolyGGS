# HolyGGS

Версия v0.22.3 (код 51): живые привязки `:` (@UI.hpText.text : "HP: " .. [@P.hp], @L.X : выражение — пересчитываются каждый кадр); @UI.Joystick = {enabled, style(circle|square|minimal|neon), alpha, color(0xffffff), knobColor, size, pos, cameraSwipe, jumpButton} — настройка встроенного джойстика по документации; стили style(primary|danger|ghost), shadow(true), draggable(true), anchor(top, right), parent(screen); всё из 0.22.2 (@UI.controls(hide), @UI.ТИП.Имя, твины как у @W, композиты 50%+12).

## Состав
- `engine/` — исходники: Rust (`src/lib.rs`, `Cargo.toml`), веб-приложение (`public/`)
- `android/` — Android-обёртка: `AndroidManifest.xml`, `java/`, `res/`, `build_apk.sh`, `template/` (шаблон экспорта игр)
- `HolyGGS.apk` — готовое приложение (версия 0.22.3, код 51)

## Фикс v0.5.1
- `smoothstep` с перевёрнутыми рёбрами (edge0 > edge1) — UB в GLSL — везде исправлен:
  лучи (маска глубины), следы на песке (VS/FS), искры огня.
- Геометрия лучей как в v1.10: acc/20, 0.45 + exp(-r*1.4), 32 шага, затухание 0.945.

## Функции
Редактор блоков, вода, огонь, солнце с лучами, тени, постобработка, персонаж с физикой,
песок со следами-отпечатками, .mapp (📂/⬇), редактор кода (F2), ярлычок «Вывод», палитра цвета.

## Сборка движка
```
cd engine
cargo build --release --target wasm32-unknown-unknown
wasm-bindgen --target web --out-dir public/pkg target/wasm32-unknown-unknown/release/engine.wasm
```

## Сборка APK
```
cd android
JAVA_HOME=/usr/lib/jvm/jdk-11 ./build_apk.sh
```
