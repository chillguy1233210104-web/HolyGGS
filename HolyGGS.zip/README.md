# HolyGGS

Версия v0.21.8 (код 46): UI-редактор (@UI) — TextLabel/Button/TextBox/Frame с px+% позицией, кастомизацией текста/фона/рамки; группировка объектов в модели (копирование поддерева); язык HolyGGS: @UI.X = {…}, @UI.show/hide/find, onClick(@F.…), 50% размеры.

## Состав
- `engine/` — исходники: Rust (`src/lib.rs`, `Cargo.toml`), веб-приложение (`public/`)
- `android/` — Android-обёртка: `AndroidManifest.xml`, `java/`, `res/`, `build_apk.sh`, `template/` (шаблон экспорта игр)
- `HolyGGS.apk` — готовое приложение (версия 0.21.8, код 46)

## Фикс v0.5.1
- `smoothstep` с перевёрнутыми рёбрами (edge0 > edge1) — UB в GLSL — везде исправлен:
  лучи (маска глубины), следы на песке (VS/FS), искры огня.
- Геометрия лучей как в v1.10: acc/20, 0.45 + exp(-r*1.4), 32 шага, затухание 0.945.

## Функции
Редактор блоков, вода, огонь, солнце с лучами, тени, постобработка, персонаж с физикой,
песок со следами-отпечатками, .mapp (📂/⬇), редактор кода (F2), ярлычок «Вывод», палитра цвета.

## Сборка движка
```
cd engine
cargo build --release --target wasm32-unknown-unknown
wasm-bindgen --target web --out-dir public/pkg target/wasm32-unknown-unknown/release/engine.wasm
```

## Сборка APK
```
cd android
JAVA_HOME=/usr/lib/jvm/jdk-11 ./build_apk.sh
```
